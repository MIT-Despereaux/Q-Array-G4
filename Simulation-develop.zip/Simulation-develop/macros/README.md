This file describes some macro commands and the content of the macro repository. 

## Archieved
This folder contains all the macros defining old geometry/Lyon geometry.

## CRY_Examples
All the macros related to the cosmogenic simulations can be found in this folder. 

## Examples
This folder contains macros showing some general uses, especially for reactogenic and radiogenic simulations. More infos about background simulations can be found in the SimulationBackground git repository. 

## Spectra
Contains values to generate neutron spectra from different sources. 

All the other macros not contained in subdirectories are "main"/most used macros. A brief description of these macros is given below:

- RUN013/RUN014/FinalDesign: these macros are used to construct geometry according to the correspoonding RUN/setup. 
- BolometerSelection/MuonVetoSelection: show how to record the events when interactions occur in the bolometer/muon veto
- CosmicILL_RicochetFinalDesing: general generation of cosmogenics at ILL
- ReactogenicGamma/ReactogenicNeutron: gamma/neutron spectra, to be used as a generator


-----

I) GEOMETRY

/geometry/Ricochet/Basic/setConfig RicochetFinalDesign

Used to have the CryoConcept design of the cryostat, the real lead & polyethylene shielding design and the real muon veto design.
By default, the CryoCube is installed in this design

-----

/geometry/Ricochet/Basic/BuildCryoCube true/false

true by default with RicochetFinalDesign.
Choose if the cryocube is used or not
If true is choosen, BuildMiniCryoCube is set to false

-----

/geometry/Ricochet/Basic/BuildMiniCryoCube true/false

false by default with RicochetFinalDesign.
Choose if the minicryocube is used or not
If true is choosen, BuildCryoCube is set to false

----

/geometry/detector/GermaniumBolometer/build x y z unit

Put a germanium bolometer with casing at the position x,y,z. Be careful, nothing prevent to use this and the previous commands.
The macro bolometerArray.mac put 27 bolometer in the cryostat, as in the CryoCcube, but without the CryoCube strucure.

----

/geometry/Ricochet/Basic/BuildMuonVeto True

true by default with RicochetFinalDesign.
Build the muon veto

----

/geometry/Ricochet/Basic/MuonVeto/BuildCryoMuonVeto True

false by default
Build a 100% coverage cryo muon veto at the inner top of the 4K screen

----

/geometry/shielding/RingInnerShielding/addRing minRadius maxRadius unit material zShift unit length unit

Add a ring vertical of "material" defined by min and max radius, and length. The ring is centered on 0,0,zShift
This command is used to add polyethylen ring surrounding the cryostat's screens (what is called "chaussettes"). This geometry is not official yet and not included in RicochetFinalDesign. 
To use these rings, see macro RicochetFinalDesign.mac 

-----

II) OUTPUT

/ricochetSim/event/TriggerStrategy All/Hits/Steps/StepsAndHits

Choose which events are registered in the output file. To study a specific sensitive volume for a simulation (ex : germanium bolometers), you must use StepsAndHits strategy, using the StepRecorder selections :

/ricochetSim/run/stepRecorder/AddSelectionMaterial Germanium

StepRecorder selection also works with volume names and particle names :
/ricochetSim/run/stepRecorder/AddSelectionVolume .*MuonVeto.* (useful for muon veto simulations)
/ricochetSim/run/stepRecorder/AddSelectionParticle *particle_name*

Register parent particle steps option :
/ricochetSim/run/stepRecorder/RecordParentStep true/false

-----

III) GENERATOR

1) Generator from the side of a box

/generator/build GpsOnBox

Choose to generate particles from the 6 sides of a box. Particle properties are set using the GeneralParticleSource command, except the direction. The 
particles are emmited isotropically towards the inside of the box

----

/generator/GpsOnBox/ShootOnlyFromSides

Do the same but only from the 4 lateral sides of the box.
This option is used for reactogenic neutron simulation, since they are coming mostly horizontally

----

/generator/GpsOnBox/SetBoxDimensions deltaX deltaY deltaY unit

Set the box size, usually 2.8 2.8 3.6 m

----

/generator/GpsOnBox/SetBoxCenter x y z unit

Set the box center (default is centered on the 10mK plate)


2) Generate according neutron and gamma spectra

The spectra are in the directory macros/spectra in the GeneralParticleSource Format. Usually, neutrons_IN20.mac is used for neutrons.
See gammaExample.mac and neutronExample.mac for examples.

3) Generating inside a material

/generator/build GpsInMaterial

Events will be positionned randomly in all the defined materials. All the other parameter of the event should be set with the GeneralParticleSource command.

4) Generating cosmogenics with CRY files

Example macro : CosmicILL_RicochetFinalDesign.mac

/generator/build ILL
Choose ILL cosmogenic generator. It uses as input CRY output files. These can be found on ccin2p3 here : /sps/ricochet/simulations/ILL/
The files are stored in multiple folders of different sizes : input, big_input, huge_input.

To choose the input file :
/generator/ILL/InputFilePattern /sps/ricochet/simulations/ILL/input_0/cosmic_ILL_0.root

To choose multiple input files :
/generator/ILL/InputFilePattern /sps/ricochet/simulations/ILL/input_0/cosmic_ILL

Setting proper center of the generation box :
/generator/ILL/StereoCentre 0 0 180 cm
This moves GEANT4 build origin relatively to the generation box center ; here floor is GEANT4 origin, which is located 180cm down the generation box center

----

/generator/GpsInMaterial/SetMaterial StainlessSteel

Set the geant4 material name. It can be only a part of the material name. For example, if there are 2 material names StainlessSteelFlange and 
StainlessSteelCylinder
/generator/GpsInMaterial/SetMaterial StainlessSteel   will generate from both of them
/generator/GpsInMaterial/SetMaterial StainlessSteelFlange and /generator/GpsInMaterial/SetMaterial StainlessSteelCylinder will generate only from one of 
them.

-----

IV ) Visualization

use the visRicochetFinalDesign.mac macro in addition of the RicochetFinalDesign.mac to display the geometry : 
./bin/RicochetSimulation -p none RicochetFinalDesign.mac visRicochetFinalDesign.mac
