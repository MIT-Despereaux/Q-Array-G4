# Install all macros in a portable way, relative to the source directory

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "${CMAKE_BINARY_DIR}/install")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" "" CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the install component
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Collect all macros
file(GLOB_RECURSE MACRO_FILES
     "${CMAKE_SOURCE_DIR}/macros/*.mac"
     "${CMAKE_SOURCE_DIR}/macros/Examples/*.mac")

# Install all macros to share/macros
if(MACRO_FILES)
  install(FILES ${MACRO_FILES} DESTINATION "share/macros")
else()
  message(WARNING "No macro files found in macros/ or macros/Examples/. Skipping macro installation.")
endif()
