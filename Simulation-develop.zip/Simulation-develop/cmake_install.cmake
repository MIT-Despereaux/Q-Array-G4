# Install script for the Simulation project

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "${CMAKE_BINARY_DIR}/install")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" "" CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the install component
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install main executable (portable)
set(EXECUTABLE_FILE "${CMAKE_BINARY_DIR}/RicochetSimulation")
if(EXISTS "${EXECUTABLE_FILE}")
  install(PROGRAMS "${EXECUTABLE_FILE}" DESTINATION "${CMAKE_INSTALL_PREFIX}/bin")
endif()

# Include the install scripts for all subdirectories (relative paths)
foreach(SUBDIR CRY SimuOutput Utility G4Helpers G4Rubbish Physics ROOTHelpers Generator Geometry Event macros GDMLExporter)
  set(INSTALL_SCRIPT "${CMAKE_SOURCE_DIR}/${SUBDIR}/cmake_install.cmake")
  if(EXISTS "${INSTALL_SCRIPT}")
    include("${INSTALL_SCRIPT}")
  endif()
endforeach()

# Generate install manifest
if(CMAKE_INSTALL_COMPONENT)
  set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

file(WRITE "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_MANIFEST}" "")
