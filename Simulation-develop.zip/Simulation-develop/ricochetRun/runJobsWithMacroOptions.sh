#!/bin/sh
#clear

if [ $# -lt 3 ]; then
    echo "usage : runJobsWithMacro.sh SimuName MacroFile nbJob (inputFile)"
    exit
fi


    #  ******* Initialisation *******

echo "***************WARNING***************
This script as been set in $HOME the code version and environment originate from this directory, to change it modify the SOFTDIR and RUNDIR variables in the script." 
echo "The main output directory is set to $RICOCHET_OUTPUT, please change it enter your output directory : "
read output_directory
if [ "$output_directory" = "" ]; then output_directory=$RICOCHET_OUTPUT; fi

source $SOURCE
export name=$1 
export SOFTDIR=$RICOCHET_INSTALL 
export MACRO_FULLPATH=$2
export RUN_DIR=$RUNDIR
export OUT_DIR=$output_directory/$name
start=0
end=`expr $3 + $start`

#echo "This script is reading the macro name to create custom output directory. If 'neutron' or 'gamma' is in the macro name the output will be : $output_directory/reactogenic/$name, if you want this option to be disabled type 'n'."
#read option 
#if [ "$option" = "n" ]; then export OUT_DIR=$output_directory/$name
#else export OUT_DIR=$output_directory/reactogenic/$name
#fi

export MACRO_FILE=`echo $MACRO_FULLPATH  | awk -F"/" '{print $NF}' `
echo "the macro file is $MACRO_FILE"

if [[ $name == *"/"* ]]; then 
    name=$(echo "$name" | awk -F"/" '{print $2}')
    path=$(echo "$name" | awk -F"/" '{print $1}')
    export OUT_DIR=$output_directory/$name
    echo $name
fi

#  ******* Checking if the output directory exit and creating it *******

if [ -d "$OUT_DIR" ]; then
    echo "output directory $OUT_DIR exist already. Do you want to delete it ? (type y/n to yes/no)"
    read answer
    if [ "$answer" = "y" ]; then
        rm -rf "$OUT_DIR"
    else 
        exit
    fi
fi

echo "********** create output directory *********** $OUT_DIR"
mkdir $OUT_DIR
if [ ! -d $OUT_DIR ]; then
    echo "cannot create $OUT_DIR. Stop script"
    exit
fi

cp -r $RUN_DIR/$MACRO_FULLPATH $OUT_DIR
mkdir $OUT_DIR/rootFiles
mkdir $OUT_DIR/logFiles

chmod -R g+rw $OUT_DIR


# ******* Jobs launching *******

echo "launch $3 jobs with name $name"
i=$start
while [ $i -lt $end ];
do
    echo "Process run $i to run $end"
    export jobNb=$i
    export jobName="${name}_${i}"
    echo "sbatch -t 0-20:00 -n 1 --mem 8G  --output=${OUT_DIR}/logFiles/${jobName}.log $RUN_DIR/simu.sh"
    sbatch -t 0-20:00 -n 1 --mem 8G  --output=${OUT_DIR}/logFiles/${jobName}.log $RUN_DIR/simu.sh
    ((i++))
done

squeue -s

exit
