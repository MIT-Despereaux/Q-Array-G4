#!/bin/sh
########################################
# SLURM options
########################################
#SBATCH --mem 2000 # memory in MB per default
#SBATCH --time 0-20:00 # time (D-HH:MM)
#SBATCH --partition htc
####################################

W=`pwd`

cd $TMPDIR

echo " "
echo "Start of job $jobNb in $TMPDIR ... ########################################"
echo "inDir $SOFTDIR, outDir $OUT_DIR"
echo " "
echo "... Program copying ... #########################################"

echo "cp $W/$MACRO_FULLPATH ."
cp $W/$MACRO_FULLPATH .

echo "cp -r $SOFTDIR/* ."
cp -r $SOFTDIR/* .
echo "--> done !"

echo "macro $MACRO_FILE"
cat $MACRO_FILE
echo "-------------------------------------------------------------------------"

echo "list of files in $TMPDIR"
ls -lrt

echo "ROOTSYS : ${ROOTSYS} "
echo "PATH : ${PATH} "
echo " "
echo "... Program running ... `date` ###########"
echo "./bin/RicochetSimulation $MACRO_FILE >& tmpFile.tmp"
./bin/RicochetSimulation $MACRO_FILE >& tmpFile.tmp


echo "--> done !"
ls -lrt
echo " "
echo " "
echo "... Saving output files ... #####################################"
echo "Copying files ..."
echo "cp tmpFile.tmp $OUT_DIR/logFiles/simu${name}${jobNb}.log"
cp tmpFile.tmp $OUT_DIR/logFiles/simu${name}${jobNb}.log

outputFile=`cat ${MACRO_FILE} | grep /ricochetSim/run/FileName  | awk '{print $2}' | awk -F"." '{print $1}'` #a quoi sert le '{print $1}' et le cat {}


if [ $jobNb -lt 10 ]; then
    rootFileName=${outputFile}_000${jobNb}.root
elif [ $jobNb -lt 100 ]; then
    rootFileName=${outputFile}_00${jobNb}.root
elif [ $jobNb -lt 1000 ]; then
    rootFileName=${outputFile}_0${jobNb}.root
else
    rootFileName=${outputFile}_${jobNb}.root
fi


echo "cp $outputFile.root $OUT_DIR/rootFiles/$rootFileName"
cp $outputFile.root $OUT_DIR/rootFiles/$rootFileName
echo "--> done !"
echo " "

echo "... End of job ##################################################"

exit
