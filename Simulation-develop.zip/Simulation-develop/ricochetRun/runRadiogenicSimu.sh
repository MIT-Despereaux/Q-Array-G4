#!/bin/sh

if [ $# -lt 2 ]; then
    echo "usage : runRadiogenicSimu.sh macroFolder nbJobs_per_macro"
    exit
fi

export macroFolder=$1
export start=0
export end=`expr $2 + $start`
export output_directory



echo "
***************WARNING***************
This script as been set in $HOME the code version and environment originate from this directory, to change it modify the SOFTDIR and RUNDIR variables in the script runJobsWithMacro.sh." 
echo "The main output directory is set to $RICOCHET_OUTPUT, please change it enter your output directory : "
read output_directory
if [ "$output_directory" = "" ]; then output_directory=$RICOCHET_OUTPUT; fi




nb_of_macros=$( ls $macroFolder | wc -l )
echo "number of macros in $macroFolder  : $nb_of_macros
"
ls $macroFolder
echo ""

nb_of_jobs=$( echo "$end*$nb_of_macros" | bc )
nb_of_simus_per_macro=$( echo "3000/$nb_of_macros" | bc )

if [[ $nb_of_jobs -gt 3000 ]]; then #3000 is the limit number of jobs subscription per day 
    echo "nbJobs_per_macro*nb_of_macros = $nb_of_jobs > 3000, there is too many jobs to launch please enter a smaller number of simus or split the macros file too keep the same number of simus per macro. The maximum number of simulations you can compute per macro is : $nb_of_simus_per_macro"
    exit
fi



for file in $macroFolder*.mac; do 
    name=$( echo "$file" | awk -F"/" '{print $3}' | awk -F"." '{print $1}' )
    echo "simu name : $name
    "
    echo "$file"
    echo "./runJobsWithMacro.sh $name $file $end"
    ./runJobsWithMacro.sh $name $file $end
done

squeue -s

exit
