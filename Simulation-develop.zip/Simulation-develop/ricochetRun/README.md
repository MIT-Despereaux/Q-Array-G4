# RICOCHETRUN

This is the folder where you should run the RICOCHET simulation code, it contains all the scripts and macros you need to launch radiogenic and radiogenic simulations.

## Description of the different scripts
There are 2 base scripts used every time you launch a series of simulations: simu.sh and runJobsWithMacro.sh. The two work together, with the first one (simu.sh) being called by the second one in a while loop. The idea is that we can set everything up with runJobsWithMacro.sh and then call simu.sh for each simulation launch.
runJobsWithMacroOption.sh is made to run a series of simulations for a given macro. It is a more user-friendly version of runJobsWithMacro.sh.
runRadiogenicSimu.sh is intended to run radiogenic simulations. It runs a series of simulations for each macro contained in the macro folder.
radiogenicMacro.sh is made to create custom radiogenic macros from a list.txt of nuclei. This script is intended to be used to create the radiogenic macro folder used by runRadiogenicSimu.sh.

## A short guide for the use of runJobsWithMacro.sh 
runJobsWithMacro.sh takes three parameters: the name you want for the simulation, the path to the macro that parameterizes the simulation, and the number of simulations you want to run. It is a good idea to have a macro folder inside the RICOCHET run directory so that the macro's path is short. However, you need to be careful with this script since the software directory and run directory are set inside the script and need to be changed to match your system. If you try to run a series of simulations with this script, it won't work because the output directory isn't set within it. This script is intended to be called by runRadiogenicSimu.sh, which asks the user to enter the output directory.
### Requirements 
Environment script path need to be changed line 12.
You need simu.sh in the same directory.
Change the directories set inside before using it.
### Usage 
You are not supposed to call this script directly from the terminal.

## A short guide for the use of runJobsWithMacroOption.sh
If you want to run a series of simulations for a given macro, you should use runJobsWithMacroOption.sh, which is designed for this purpose. Warning messages about the run, software, and output directories are displayed to indicate the environment in which the script is set. You should modify these directories to match your own before running the script. runJobsWithMacroOption.sh takes the same parameters as runJobsWithMacro.sh.
### Tips 
Once you changed this line (the 16th) to your main output directory you can just press enter when the warning message display (if the output directory correspond to the one you want).
```
if [ "$output_directory" = "" ]; then output_directory=/sps/ricochet/yourCClogin/directory; fi
```

### Requirements
The environment script path needs to be changed on line 18.
You need simu.sh in the same directory.
Change the directories inside before using it.
### Usage
Once everything is properly set, you should be able to launch your first series of simulations by running: 
```
./runJobsWithMacroOptions.sh YourSimuName macros/YourMacros.mac 100
```

## A short guide for the use of runRadiogenicSimu.sh
Since radiogenics simulations consist in producing radioctive nuclei inside volumes or materials you need to do a serie of simulations for each radioactive nuclei contained by the material/volume. This script intend to ease the run of those radiogenic simulations by allowing the user to run a serie of simulation for each nuclei using only one command in the terminal instead of one command for each nuclei. The names of the simulations are automaticaly generated from informations found in the macro file, the name template is : radiogenic[method][nuclei][atomic mass]. 
This scripts is taking 2 parameters : the path to the macro folder and the number of simulations you want for each nuclei/macros in your folder. This is the script calling runJobsWithMacro.sh. 
You can either enter your output directory when you run the script or change it as the tip sub part suggest in the short guide for runJobsWithMacroOption.sh. All your simulation's folder will be found in your output directory, it is a good idea to create a new directory named after the volume/material you are simulating, it will make the analysis part easier. I recommend organizing your simulation output like this: /sps/ricochet/yourLogin/simulation2023/radiogenic/material_or_volume_name/
### Requirements
You need to have both simu.sh and runJobsWithMacro.sh in the same directory before using this script. Make sure to change the directories inside the script to match your own environment before running it.
### Usage
```
./runRadiogenicSimu.sh macros/YourCustomMacrosFolder 400
```

## A short guide for the use of radiogenicMacro.sh
radiogenicMacro.sh is a script that generates custom radiogenic macros for a list of nuclei. It takes 2 parameters: a text file containing the list of nuclei, and the path to the output directory. For each line in the input file, a corresponding macro file is created using a naming convention based on the method, nuclei, and atomic mass.
### About the listNuclei.txt
You'll find 2 examples of lists of nuclei on the git, you should write your list.txt following thoses examples.
A quick note on how the file is read : 1st it look for the key word "method" inside the .txt, it will change the configuration of the macro. You have the choice between 2 method : gps and GpsInMaterial, the lines following are setting the method parameters you should refer to Geant4 documentation for the setting of theses lines.
After the method has been found radiogenicMacro.sh read the file line by line and stop when it read 'method' so you HAVE to write the 'nuclei lines' before the method part. radiogenicMacro.sh interprete a 3 word line as a full radioactive decay chain and a 6 word line as a part of a chain. The right way to write a 3 words line is : atomic_symbol atomic_mass atomic_number (like when you configure a Geant4 macro). 
For a 6 token line this is a bit special because the line is setting both the starting nuclei, the upper and lower limit for atomic number and atomic mass. radiogenicMacro.sh is reading token after token inside lines : the 1st token is the atomic symbol of the last nuclei you want to simulate, the 2nd token is the atomic symbol of the starting nuclei, the 3rd one is the lower limit on atomic mass, the 4th is the upper limit on atomic mass and the starting atomic mass (corresponding to the 2nd token), the 5th is the either the smallest or the largest atomic number inside the part of the decay chain you want to simulate depending if the starting nuclei is decaying by alpha (in this case : 5th token = smallest atomic number) or beta (5th token : largest atomic number), the 6th is the starting atomic number (corresponf to the atomic symbol at the 2nd token position).
Check the listNucleiInternalLead.txt and the macros folder internalLeadCC, these has been wrote using radiogenicMacro.sh If you have any doubt on your limit configuration you can change the event and tracking verbosiy to 2 in the macro (as well as the number of event, /run/beamOn 5) then run one simulation and check (in the simu log file or directly in the terminal if you runned it from the executable RicochetSimulation) if you are simulating the part of the decay chain you want. 
### Tips 
It's a good idea to name your output directory after the volume/material name and to store your folder inside your macros folder.
### Requirements 
radiogenicMacroPattern.txt inside your directory. This file contain the common pattern of each RICOCHET macros.
A list.txt well configured (see About the list.txt part).
### Usage 
```
./radiogenicMacro yourNucleiList.txt macros/yourOutputFolderName
```