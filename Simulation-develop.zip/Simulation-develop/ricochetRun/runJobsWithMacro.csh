#!/bin/csh
#clear

if ( $# < 3 ) then
    echo "usage : runJobsWithMacro.csh SimuName MacroFile nbJob (inputFile)"
    exit
endif

setenv name "$1"
setenv SOFTDIR $RICOCHET_INSTALL
setenv OUT_DIR $RICOCHET_OUTPUT/$1
setenv MACRO_FULLPATH $2
setenv RUN_DIR $RUNDIR
setenv start 0
#@ start++
setenv end `expr $3 + $start`
#echo $end
#setenv end $3

setenv MACRO_FILE `echo $MACRO_FULLPATH  | awk -F"/" '{print $NF}' `
echo "the macro file is $MACRO_FILE"


if ( -d $OUT_DIR) then
    echo "output directory $OUT_DIR exist allready. Do you want to delete it ? (type y/n to yes/no)"
    set answer = $<
    if ( $answer == "y" ) then
    	rm -rf $OUT_DIR
    else 
        exit
    endif
endif

echo "launch $3 jobs with name $name"

source /pbs/throng/ricochet/cazes/env.csh

echo "********** create output directory *********** $OUT_DIR"
mkdir $OUT_DIR
if ( ! -d $OUT_DIR) then
    echo "cannot create $OUT_DIR. Stop script"
    exit
endif
#tar czf $OUT_DIR/UsedSoftware.tgz $SOFT_DIR/RicochetSim.cc $SOFT_DIR/src $SOFT_DIR/include 
echo "$SOFTDIR"
#cd $SOFTDIR
cp -r $RUN_DIR/$MACRO_FULLPATH $OUT_DIR
mkdir $OUT_DIR/rootFiles
mkdir $OUT_DIR/logFiles

chmod -R g+rw $OUT_DIR

echo "Process run $start to run $end"

#cd $SOFTDIR
set i=$start
while ( $i < $end )
setenv jobName "${name}_${i}"
setenv jobNb $i
#setenv inputFile `cat ${MACRO_FILE} | grep /ricochetSim/generator/FileName   | awk '{print $2}'`
#if( $inputFile != $4 ) then
#    echo "input file in macro diffentent : $inputFile"
#    exit
#@endif
#setenv inputFile $4
#echo "inputFile $inputFile"
echo "sbatch -t 0-20:00 -n 1 --mem 4G  --output=${OUT_DIR}/logFiles/${jobName}.log $RUN_DIR/simu.csh"
sbatch -t 0-20:00 -n 1 --mem 4G  --output=${OUT_DIR}/logFiles/${jobName}.log $RUN_DIR/simu.csh
@ i++
end

squeue -s

exit
