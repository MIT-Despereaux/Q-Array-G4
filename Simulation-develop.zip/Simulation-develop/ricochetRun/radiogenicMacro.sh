#!/bin/sh

if [ $# -lt 2 ]; then
    echo "usage : radiogenicMacro.sh listOfNuclei.txt macroOutputPath"
    exit
fi

export listOfNuclei=$1
export macroOutputPath=$2

echo "************* WARNING *************
The current geometry of the detectors is 3 miniCryoCubes 1cm appart, if you want to change this modify the MiniCryoCube part of radiogenicMacroPattern.txt (line 25-28)." 

#  ******* Checking if the output directory exist and creating it *******

if [ -d "$macroOutputPath" ]; then
    echo "output directory $macroOutputPath exist already. Do you want to delete it ? (type y/n to yes/no)"
    read answer
    if [ "$answer" = "y" ]; then
        rm -rf "$macroOutputPath"
    else 
        exit
    fi
fi

echo "********** create output directory *********** $macroOutputPath"
mkdir $macroOutputPath
if [ ! -d $macroOutputPath ]; then
    echo "cannot create $macroOutputPath. Stop script"
    exit
fi

#***********Looking for the pattern method in the listoOfNuclei.txt***********

method=$( grep "method" $listOfNuclei | awk -F": " '{print $2}' )
echo "method :$method"

nb_of_events=$( grep "nb_of_events" $listOfNuclei | awk -F": " '{print $2}' )
echo "nb_of_events :$nb_of_events"


#***********************Gps***********************

if [ $method == "gps" ]; 
then
#**************Extracting all the parameter we need to configure the GeneralParticleSource primary events**************
    shape=$( grep "shape" $listOfNuclei | awk -F": " '{print $2}' )
    echo "shape :$shape"

    centre=$( grep "centre" $listOfNuclei | awk -F": " '{print $2}' )
    echo "centre :$centre"

    radius=$( grep "radius" $listOfNuclei | awk -F": " '{print $2}' )
    echo "radius :$radius"

    halfz=$( grep "halfz" $listOfNuclei | awk -F": " '{print $2}' )
    echo "halfz :$halfz"

    rot1=$( grep "rot1" $listOfNuclei | awk -F": " '{print $2}' )
    echo "rot1 :$rot1"

    rot2=$( grep "rot2" $listOfNuclei | awk -F": " '{print $2}' )
    echo "rot2 :$rot2"
    
    while read line; 
    do 
        if [[ $line == *"method"* ]]; then echo "$line"; break ; fi #here the while loop iterate to find which nuclei will be generated in the Geant4Gps 
        #echo "$line"
        nb_of_words=$( echo "$line" | wc -w )
        
        if [ $nb_of_words == 3 ]; #a 3 word line correspond to a complete desintegration chain  
        then echo "$line"
            symbol=$( echo "$line" | awk -F" " '{print $1}')
            #echo "symbol = $symbol"
            atomic_mass=$( echo "$line" | awk -F" " '{print $2}')
            #echo "atomic_mass = $atomic_mass"
            atomic_number=$( echo "$line" | awk -F" " '{print $3}')
            #echo "atomic_number = $atomic_number"
            macroName="radiogenic$method"_"$symbol$atomic_mass"
            #echo "$macroName"
            #cat radiogenicMacroPattern.txt
            
            sed "7i/ricochetSim/run/FileName $macroName.root" radiogenicMacroPattern.txt > $macroOutputPath/$macroName.mac #we are adding /ricochetSim/run/FileName $macroName.root at the 7th line (see 7i at the begining of the sed 'string') of the radiogenicMacroPattern.txt file before copying it to a .mac
            
            #cat $macroOutputPath/$macroName.mac
            echo " 
                    ###Generator####
    
/generator/build $method
/gps/pos/type Volume 
/gps/pos/shape $shape 
/gps/pos/centre $centre
/gps/pos/radius $radius
/gps/pos/rot1 $rot1
/gps/pos/rot2 $rot2
/gps/pos/halfz $halfz
/gps/source/intensity 1
/gps/energy 0 MeV  ## Energie initial des noyaux, immobiles
/gps/ang/type iso
/gps/particle ion
/gps/ion $atomic_number $atomic_mass 0 0 ##Numero atomique, masse atomique, charge, excitation energy
    
/run/beamOn $nb_of_events" >> $macroOutputPath/$macroName.mac #we are adding the generator part to the macro. the generator part is custom for each nuclei.
    
        elif [ $nb_of_words == 6 ]; #a 6 word line correspond to a part of a desintegration chain
        then echo "$line"
            symbol_min=$( echo "$line" | awk -F" " '{print $1}')
            #echo "symbol_min = $symbol_min"
            symbol_max=$( echo "$line" | awk -F" " '{print $2}')
            #echo "symbol_max = $symbol_max"
            atomic_mass_min=$( echo "$line" | awk -F" " '{print $3}')
            #echo "atomic_mass_min = $atomic_mass_min"
            atomic_mass_max=$( echo "$line" | awk -F" " '{print $4}')
            #echo "atomic_mass_max = $atomic_mass_max"
            atomic_number_min=$( echo "$line" | awk -F" " '{print $5}')
            echo "atomic_number_min = $atomic_number_min"
            atomic_number_max=$( echo "$line" | awk -F" " '{print $6}')
            echo "atomic_number_max = $atomic_number_max"
            macroName="radiogenic$method"_"$symbol_min$atomic_mass_min-$symbol_max$atomic_mass_max"
            #echo "$macroName"
            #cat radiogenicMacroPattern.txt
            
            sed "7i/ricochetSim/run/FileName $macroName.root" radiogenicMacroPattern.txt > $macroOutputPath/$macroName.mac #we are adding /ricochetSim/run/FileName $macroName.root at the 7th line (see 7i at the begining of the sed 'string') of the radiogenicMacroPattern.txt file before copying it to a .mac
            
            #cat $macroOutputPath/$macroName.mac
            echo " 
                    ###Generator####
    
/generator/build $method
/gps/pos/type Volume ##To set the positionnal distribution
/gps/pos/shape $shape 
/gps/pos/centre $centre
/gps/pos/radius $radius
/gps/pos/rot1 $rot1
/gps/pos/rot2 $rot2
/gps/pos/halfz $halfz
/gps/source/intensity 1
/gps/energy 0 MeV  ## Energie initial des noyaux, immobiles
/gps/ang/type iso
/gps/particle ion
/gps/ion $atomic_number_max $atomic_mass_max
/grdm/nucleusLimits $atomic_mass_min $atomic_mass_max $atomic_number_min $atomic_number_max #A_min, A_max, Z_min, Z_max

/run/beamOn $nb_of_events" >> $macroOutputPath/$macroName.mac #Adding the generator ppart to the macro 
        
    
        fi
    done < $listOfNuclei
    

#***********************GpsInMaterial***********************

elif [ $method == "GpsInMaterial" ];
then
    material=$( grep "material" $listOfNuclei | awk -F": " '{print $2}' )
    echo "material : $material"
    echo "Which macro command should be used : /generator/GpsInMaterial/SetMaterial or /generator/GpsInMaterial/SetStrictlyMaterial (1 or 2)"
    read answer
    if [ "$answer" = "1" ]; then
        setMaterialCommand="/generator/GpsInMaterial/SetMaterial"
        echo "The macro command : $setMaterialCommand, The primaries will be generated from all of the materials whose names contain the string : $material"
    elif [ "$answer" = "2" ]; then
        setMaterialCommand="/generator/GpsInMaterial/SetStrictlyMaterial"
        echo "The macro command : $setMaterialCommand, The primaries will be generated only from the material named exactly after the string : $material"
    else echo "input not recognized, the default material command is /generator/GpsInMaterial/SetMaterial."
        setMaterialCommand="/generator/GpsInMaterial/SetMaterial"
    fi
    while read line; 
    do 
        if [[ $line == *"method"* ]]; then echo "$line"; break ; fi #the configuration of the macro is at the end of the list file
        #echo "$line"
        nb_of_words=$( echo "$line" | wc -w )
        
        if [ $nb_of_words == 3 ]; 
        then echo "$line"
            symbol=$( echo "$line" | awk -F" " '{print $1}')
            #echo "symbol = $symbol"
            atomic_mass=$( echo "$line" | awk -F" " '{print $2}')
            #echo "atomic_mass = $atomic_mass"
            atomic_number=$( echo "$line" | awk -F" " '{print $3}')
            #echo "atomic_number = $atomic_number"
            macroName="radiogenicGpsIn$material"_"$symbol$atomic_mass"
            #echo "$macroName"
            #cat radiogenicMacroPattern.txt
            
            sed "7i/ricochetSim/run/FileName $macroName.root" radiogenicMacroPattern.txt > $macroOutputPath/$macroName.mac #we are adding /ricochetSim/run/FileName $macroName.root at the 7th line (see 7i at the begining of the sed 'string') of the radiogenicMacroPattern.txt file before copying it to a .mac
            
            #cat $macroOutputPath/$macroName.mac
            echo " 
                    ###Generator####
    
/generator/build $method
$setMaterialCommand $material
/gps/source/intensity 1
/gps/energy 0 MeV  ## Energie initial des noyaux, immobiles
/gps/ang/type iso
/gps/particle ion
/gps/ion $atomic_number $atomic_mass 0 0 ##Numero atomique, masse atomique, charge, excitation energy
    
/run/beamOn $nb_of_events" >> $macroOutputPath/$macroName.mac
    
        elif [ $nb_of_words == 6 ]; 
        then echo "$line"
            symbol_min=$( echo "$line" | awk -F" " '{print $1}')
            #echo "symbol_min = $symbol_min"
            symbol_max=$( echo "$line" | awk -F" " '{print $2}')
            #echo "symbol_max = $symbol_max"
            atomic_mass_min=$( echo "$line" | awk -F" " '{print $3}')
            #echo "atomic_mass_min = $atomic_mass_min"
            atomic_mass_max=$( echo "$line" | awk -F" " '{print $4}')
            #echo "atomic_mass_max = $atomic_mass_max"
            atomic_number_min=$( echo "$line" | awk -F" " '{print $5}')
            echo "atomic_number_min = $atomic_number_min"
            atomic_number_max=$( echo "$line" | awk -F" " '{print $6}')
            echo "atomic_number_max = $atomic_number_max"
            macroName="radiogenicGpsIn$material"_"$symbol_min$atomic_mass_min-$symbol_max$atomic_mass_max"
            #echo "$macroName"
            #cat radiogenicMacroPattern.txt
            
            sed "7i/ricochetSim/run/FileName $macroName.root" radiogenicMacroPattern.txt > $macroOutputPath/$macroName.mac #we are adding /ricochetSim/run/FileName $macroName.root at the 7th line (see 7i at the begining of the sed 'string') of the radiogenicMacroPattern.txt file before copying it to a .mac
            
            #cat $macroOutputPath/$macroName.mac
            echo " 
                    ###Generator####
    
/generator/build $method
$setMaterialCommand $material
/gps/source/intensity 1
/gps/energy 0 MeV  ## Energie initial des noyaux, immobiles
/gps/ang/type iso
/gps/particle ion
/gps/ion $atomic_number_max $atomic_mass_max
/grdm/nucleusLimits $atomic_mass_min $atomic_mass_max $atomic_number_min $atomic_number_max #A_min, A_max, Z_min, Z_max

/run/beamOn $nb_of_events" >> $macroOutputPath/$macroName.mac
        
    
        fi
    done < $listOfNuclei

fi

exit