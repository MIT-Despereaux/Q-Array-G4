include(CMakeFindDependencyMacro)

find_dependency(Geant4 REQUIRED)

if(NOT TARGET Ricochet::G4Rubbish)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetG4RubbishTargets.cmake")
endif()
