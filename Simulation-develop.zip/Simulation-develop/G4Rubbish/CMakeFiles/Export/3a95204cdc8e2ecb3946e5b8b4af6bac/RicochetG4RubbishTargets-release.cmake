#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::G4Rubbish" for configuration "Release"
set_property(TARGET Ricochet::G4Rubbish APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::G4Rubbish PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetG4Rubbish.so"
  IMPORTED_SONAME_RELEASE "libRicochetG4Rubbish.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::G4Rubbish )
list(APPEND _cmake_import_check_files_for_Ricochet::G4Rubbish "${_IMPORT_PREFIX}/lib64/libRicochetG4Rubbish.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
