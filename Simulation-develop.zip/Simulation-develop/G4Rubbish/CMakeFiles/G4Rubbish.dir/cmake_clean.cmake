file(REMOVE_RECURSE
  "CMakeFiles/G4Rubbish.dir/src/G4LindhardPartition.cc.o"
  "CMakeFiles/G4Rubbish.dir/src/G4LindhardPartition.cc.o.d"
  "CMakeFiles/G4Rubbish.dir/src/G4ScreenedNuclearRecoil.cc.o"
  "CMakeFiles/G4Rubbish.dir/src/G4ScreenedNuclearRecoil.cc.o.d"
  "CMakeFiles/G4Rubbish.dir/src/PhysListEmStandardNR.cc.o"
  "CMakeFiles/G4Rubbish.dir/src/PhysListEmStandardNR.cc.o.d"
  "libRicochetG4Rubbish.pdb"
  "libRicochetG4Rubbish.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/G4Rubbish.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
