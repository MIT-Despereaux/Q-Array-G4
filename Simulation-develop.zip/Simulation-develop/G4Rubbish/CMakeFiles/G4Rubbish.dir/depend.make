# Empty dependencies file for G4Rubbish.
# This may be replaced when dependencies are built.
