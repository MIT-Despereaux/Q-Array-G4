#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::G4Helpers" for configuration "Release"
set_property(TARGET Ricochet::G4Helpers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::G4Helpers PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetG4Helpers.so"
  IMPORTED_SONAME_RELEASE "libRicochetG4Helpers.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::G4Helpers )
list(APPEND _cmake_import_check_files_for_Ricochet::G4Helpers "${_IMPORT_PREFIX}/lib64/libRicochetG4Helpers.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
