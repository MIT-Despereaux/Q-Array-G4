file(REMOVE_RECURSE
  "CMakeFiles/G4Helpers.dir/src/DimensionedValue.cc.o"
  "CMakeFiles/G4Helpers.dir/src/DimensionedValue.cc.o.d"
  "CMakeFiles/G4Helpers.dir/src/TransformationParser.cc.o"
  "CMakeFiles/G4Helpers.dir/src/TransformationParser.cc.o.d"
  "libRicochetG4Helpers.pdb"
  "libRicochetG4Helpers.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/G4Helpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
