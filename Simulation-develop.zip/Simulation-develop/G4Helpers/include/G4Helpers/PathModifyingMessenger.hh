/**************************************************************************
* @file PathModifyingMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Modify command paths with PathModifier::FullPath before adding
* Geant4 commands via the inherited Messenger::AddCommand
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_COMMANDTWEAKINGMESSENGER_HH
#define RICOCHET_G4HELPERS_COMMANDTWEAKINGMESSENGER_HH

#include <utility>
#include <string>

namespace G4Helpers
{

    template <class Messenger, class PathModifier>
    class PathModifyingMessenger : public Messenger
    {
    protected:
        ~PathModifyingMessenger() = default;//must not be used as pointer to PathModifyingMessenger
    public:
        using Messenger::Messenger;
        PathModifyingMessenger(const PathModifyingMessenger<Messenger, PathModifier>&) = default;
        PathModifyingMessenger(PathModifyingMessenger<Messenger, PathModifier>&&) = default;
        PathModifyingMessenger<Messenger, PathModifier>& operator=(const PathModifyingMessenger<Messenger, PathModifier>&) = default;
        PathModifyingMessenger<Messenger, PathModifier>& operator=(PathModifyingMessenger<Messenger, PathModifier>&&) = default;
        template <class CommandType, class Callable>
        void AddCommand(const char* commandPath, Callable&& callable);
        template <class CommandType, class Callable>
        void AddCommand(const char* commandPath, const char* description, Callable&& callable);
    };

    template <class Messenger, class PathModifier>
    template <class CommandType, class Callable>
    void PathModifyingMessenger<Messenger, PathModifier>::AddCommand(const char* commandPath, Callable&& callable)
    {
        Messenger::template AddCommand<CommandType>(PathModifier::FullPath(commandPath).c_str(), std::forward<Callable>(callable));
    }

    template <class Messenger, class PathModifier>
    template <class CommandType, class Callable>
    void PathModifyingMessenger<Messenger, PathModifier>::AddCommand(const char* commandPath, const char* description, Callable&& callable)
    {
        Messenger::template AddCommand<CommandType>(PathModifier::FullPath(commandPath).c_str(), description, std::forward<Callable>(callable));
    }

}

#endif /* RICOCHET_G4HELPERS_COMMANDTWEAKINGMESSENGER_HH */
