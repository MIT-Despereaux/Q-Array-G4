/**************************************************************************
* @file InitialisableMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Pass Initialiser template argument implementing Initialise
* to run Messenger's public commands in the constructor of the newly
* created class InitialisableMessenger<Messenger>
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_INITIALISABLEMESSENGER_HH
#define RICOCHET_G4HELPERS_INITIALISABLEMESSENGER_HH

#include  <utility>

namespace G4Helpers
{

    template <class Messenger, class Initialiser>
    class InitialisableMessenger : public Messenger
    {
    protected:
        ~InitialisableMessenger() = default;//must not be used as pointer to InitialisableMessenger
    public:
        template <class... Args>
        InitialisableMessenger(Args&&... args);
        InitialisableMessenger(const InitialisableMessenger<Messenger, Initialiser>&) = default;
        InitialisableMessenger(InitialisableMessenger<Messenger, Initialiser>&&) = default;
        InitialisableMessenger<Messenger, Initialiser>& operator=(const InitialisableMessenger<Messenger, Initialiser>&) = default;
        InitialisableMessenger<Messenger, Initialiser>& operator=(InitialisableMessenger<Messenger, Initialiser>&&) = default;
    };

    template <class Messenger, class Initialiser>
    template <class... Args>
    InitialisableMessenger<Messenger, Initialiser>::InitialisableMessenger(Args&&... args)
    :Messenger(std::forward<Args>(args)...)
    {
        Initialiser::Initialise(*this);
    }

}



#endif /* RICOCHET_G4HELPERS_INITIALISABLEMESSENGER_HH */
