/****************************************************************************
* @file GenericMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 10 Oct 2019
* @brief Geant4 GenericMessenger class template.
* Provides memory managment of Geant4 commands and a straightfoward
* AddCommand to instantiate new commands. Meant to be used as a template
* argument of e.g. InitialisableMessenger<GenericMessenger,...>
* **************************************************************************/

#ifndef RICOCHET_G4HELPERS_GENERIC_MESSENGER
#define RICOCHET_G4HELPERS_GENERIC_MESSENGER

#include <unordered_map>
#include <memory>
#include <functional>
#include "G4UImessenger.hh"

namespace G4Helpers
{

    template <class WorkerType>
    class GenericMessenger : public G4UImessenger
    {
        WorkerType* fWorker;//non-owning
        using WorkerCall = std::function<void(WorkerType&, const std::string&)>;
        using CommandMap = std::unordered_map<std::unique_ptr<G4UIcommand>, WorkerCall>;
        CommandMap fCommandMap;
    protected:
        ~GenericMessenger() = default;//must not be used as pointer to GenericMessenger<WorkerType>
    public:
        GenericMessenger(WorkerType& worker);
        GenericMessenger(const GenericMessenger<WorkerType>&) = default;
        GenericMessenger(GenericMessenger<WorkerType>&&) = default;
        GenericMessenger<WorkerType>& operator=(const GenericMessenger<WorkerType>&) = default;
        GenericMessenger<WorkerType>& operator=(GenericMessenger<WorkerType>&&) = default;
        template <class CommandType, class Callable>
        void AddCommand(const char* commandPath, Callable&& callable);
        template <class CommandType, class Callable>
        void AddCommand(const char* commandPath, const char* description, Callable&& callable);
        void SetNewValue(G4UIcommand* command, G4String macroArgument) override;
    };

    template <class WorkerType>
    template <class CommandType, class Callable>
    void GenericMessenger<WorkerType>::AddCommand(const char* commandPath, Callable&& callable)
    {
        AddCommand<CommandType>(commandPath, "", std::forward<Callable>(callable));
    }

    template <class WorkerType>
    template <class CommandType, class Callable>
    void GenericMessenger<WorkerType>::AddCommand(const char* commandPath, const char* description, Callable&& callable)
    {
        auto command = std::make_unique<CommandType>(commandPath, this);
        command->SetGuidance(description);
        fCommandMap[std::move(command)] = std::forward<Callable>(callable);
    }

    template <class WorkerType>
    GenericMessenger<WorkerType>::GenericMessenger(WorkerType& worker)
    :fWorker(&worker)
    { }

    template <class WorkerType>
    void GenericMessenger<WorkerType>::SetNewValue(G4UIcommand* command, G4String macroArgument)
    {
        auto it = std::find_if(std::cbegin(fCommandMap), std::cend(fCommandMap),[command](const auto& pair){return command == pair.first.get();});
        if(it == std::cend(fCommandMap))
        {
            auto message = "Command '"+command->GetCommandPath()+"' not registered!";
            throw std::logic_error(message);
        }
        else it->second(*fWorker, macroArgument);
    }

}

#endif /* RICOCHET_G4HELPERS_GENERIC_MESSENGER */
