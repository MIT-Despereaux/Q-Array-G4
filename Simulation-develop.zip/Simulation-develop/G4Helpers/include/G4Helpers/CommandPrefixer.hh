/**************************************************************************
* @file CommandPrefixer.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Provide preprocessor macro to define functors prefixing Geant4
* commands or C-strings
* ************************************************************************/

#ifndef G4HELPERS_COMMANDPREFIXER_HH
#define G4HELPERS_COMMANDPREFIXER_HH

#include <string>

#define DEFINE_COMMAND_PREFIXER(CommandPrefixer, Prefix)\
    struct CommandPrefixer {\
        static std::string FullPath(const char* commandPath) {return std::string(Prefix) + commandPath;}\
    };\

#endif /* G4HELPERS_COMMANDPREFIXER_HH */
