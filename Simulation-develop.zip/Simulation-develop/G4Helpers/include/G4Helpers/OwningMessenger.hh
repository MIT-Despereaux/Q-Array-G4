/**************************************************************************
* @file OwningMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 10 Oct 2019
* @brief This class handles the link between the Worker and Messenger
* without the need to force the Messenger into your Worker class (such
* that your Worker class remains standalone if you don't use
* Geant4's broken macros). The ugly inheritance is there because Geant4
* relies on the G4VUserPrimaryWorkerAction to select types.
* ************************************************************************/

#ifndef G4HELPERS_OWNING_MESSENGER_HH
#define G4HELPERS_OWNING_MESSENGER_HH

#include "G4Helpers/GenericMessenger.hh"

namespace G4Helpers{

    template <class WorkerType, class MessengerType>
    class OwningMessenger : public WorkerType, public MessengerType
    {
    public:
        template  <class... Args>
        OwningMessenger(Args&&... workerArgs);
    };

    template <class WorkerType, class MessengerType>
    template  <class... Args>
    OwningMessenger<WorkerType, MessengerType>::OwningMessenger(Args&&... workerArgs):
    WorkerType(std::forward<Args>(workerArgs)...),MessengerType(static_cast<WorkerType&>(*this))
    { }

}

#endif /* G4HELPERS_OWNING_MESSENGER_HH */
