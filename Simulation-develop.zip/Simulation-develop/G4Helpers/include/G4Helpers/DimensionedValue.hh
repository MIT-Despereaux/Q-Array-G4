/**************************************************************************
* @file DimensionedValue.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 18 Sep 2020
* @brief Class that can be built from streams representing a number with
* a unit e.g. (42.3e-1mm); implicity convertible to double
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_DIMENSIONEDVALUE_HH
#define RICOCHET_G4HELPERS_DIMENSIONEDVALUE_HH

#include <istream>

namespace G4Helpers
{

    struct DimensionedValue
    {
        double value;
        double unit;
        operator double() const {return value * unit;}
    };

    std::istream& operator>>(std::istream& input, DimensionedValue& dimensionedValue);

}

#endif /* RICOCHET_G4HELPERS_DIMENSIONEDVALUE_HH */
