/**************************************************************************
* @file InitialisablePathModifyingMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Helper alias to simplify mixing of messenger command definition
* (via the Initialisation policy) and command path tweaking
* (via the PathModifier policy) features
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_INITIALISABLEPATHMODIFYINGMESSENGER_HH
#define RICOCHET_G4HELPERS_INITIALISABLEPATHMODIFYINGMESSENGER_HH

#include "G4Helpers/InitialisableMessenger.hh"
#include "G4Helpers/PathModifyingMessenger.hh"
#include "G4Helpers/GenericMessenger.hh"

namespace G4Helpers
{

    template <class Worker, class Initialiser, class PathModifier>
    using InitialisablePathModifyingMessenger =
    InitialisableMessenger<
        PathModifyingMessenger<GenericMessenger<Worker>, PathModifier>,
    Initialiser>;

}

#endif /* RICOCHET_G4HELPERS_INITIALISABLEPATHMODIFYINGMESSENGER_HH */
