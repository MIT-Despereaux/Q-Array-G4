/**************************************************************************
* @file TransformationParser.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 11 Sep 2020
* @brief Add missing streaming operators for HepGeom::Transform3D
* ************************************************************************/

#ifndef G4HELPERS_TRANSFORMATIONPARSER_HH
#define G4HELPERS_TRANSFORMATIONPARSER_HH

#include "G4UIcommand.hh"
#include <CLHEP/Geometry/Transform3D.h>
#include "Utility/String.hh"

namespace G4Helpers
{

    namespace TransformationParser
    {

        HepGeom::Transform3D Parse(const std::string& string);
        std::istream& operator>>(std::istream& input, HepGeom::Transform3D& transformation);
        std::ostream& operator<<(std::ostream& output, const HepGeom::Transform3D& transformation);
        template <class Vector>
        Vector ParseAsVectorWithUnit(const std::string& string);

        // Implementations

        template <class Vector>
        Vector ParseAsVectorWithUnit(const std::string& string)
        {
            auto tokens = Utility::Split(string, ",");
            if(tokens.size() == 4)
            {
                double unit = G4UIcommand::ValueOf(tokens[3].c_str());
                return Vector{unit * std::stod(tokens[0]), unit * std::stod(tokens[1]), unit * std::stod(tokens[2])};
            }
            else throw std::logic_error("'"+string+"' is not a vector with unit");
        }

    }

}

#endif /* G4HELPERS_TRANSFORMATIONPARSER_HH */
