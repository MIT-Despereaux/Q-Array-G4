# Install script for directory: /pbs/home/f/freyes/Ricochet/Simulation/G4Helpers

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/sps/ricochet/freyes/Simulation/install")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/cvmfs/sft.cern.ch/lcg/releases/clang/16.0.3-9dda8/x86_64-el9/bin/llvm-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include" TYPE DIRECTORY FILES "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/include/")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so"
         RPATH "$ORIGIN/../lib64:/cvmfs/sft.cern.ch/lcg/releases/ROOT/6.30.02-fb5be/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib64:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/releases/LCG_105/ROOT/6.30.02/x86_64-el9-clang16-opt/lib")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib64" TYPE SHARED_LIBRARY FILES "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/libRicochetG4Helpers.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so"
         OLD_RPATH "/cvmfs/sft.cern.ch/lcg/releases/ROOT/6.30.02-fb5be/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib64:/pbs/home/f/freyes/Ricochet/Simulation/Utility:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/releases/LCG_105/ROOT/6.30.02/x86_64-el9-clang16-opt/lib:"
         NEW_RPATH "$ORIGIN/../lib64:/cvmfs/sft.cern.ch/lcg/releases/ROOT/6.30.02-fb5be/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib64:/cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/lib:/cvmfs/sft.cern.ch/lcg/releases/LCG_105/ROOT/6.30.02/x86_64-el9-clang16-opt/lib")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/cvmfs/sft.cern.ch/lcg/releases/clang/16.0.3-9dda8/x86_64-el9/bin/llvm-strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/libRicochetG4Helpers.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers/RicochetG4HelpersTargets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers/RicochetG4HelpersTargets.cmake"
         "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/CMakeFiles/Export/64388d3bf538f4d76741d4cc6d9f2397/RicochetG4HelpersTargets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers/RicochetG4HelpersTargets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers/RicochetG4HelpersTargets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers" TYPE FILE FILES "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/CMakeFiles/Export/64388d3bf538f4d76741d4cc6d9f2397/RicochetG4HelpersTargets.cmake")
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers" TYPE FILE FILES "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/CMakeFiles/Export/64388d3bf538f4d76741d4cc6d9f2397/RicochetG4HelpersTargets-release.cmake")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib64/cmake/G4Helpers" TYPE FILE FILES "/pbs/home/f/freyes/Ricochet/Simulation/G4Helpers/RicochetG4HelpersConfig.cmake")
endif()

