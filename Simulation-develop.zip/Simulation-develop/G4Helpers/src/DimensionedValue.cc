#include "G4Helpers/DimensionedValue.hh"
#include <regex>
#include "G4UIcommand.hh"

namespace G4Helpers
{

    std::istream& operator>>(std::istream& input, DimensionedValue& dimensionedValue)
    {
        std::string string;
        input >> string;
        std::regex regex{"(.*?)([A-Za-z]+)"};
        std::smatch matches;
        std::regex_match(string, matches, regex);
        if(matches.size() == 3)
        {
            dimensionedValue.value  = std::stod(matches[1]);
            dimensionedValue.unit = G4UIcommand::ValueOf(matches[2].str().c_str());
        }
        else throw std::logic_error("'"+string+"' is not a number with a unit");
        return input;
    }

}
