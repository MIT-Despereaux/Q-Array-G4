#include "G4Helpers/TransformationParser.hh"
#include <regex>
#include <CLHEP/Geometry/Transform3D.h>
#include "Utility/String.hh"

namespace G4Helpers
{

namespace TransformationParser
{

    namespace
    {

        std::regex GuessRegex(const std::string& string)
        {
            std::regex reg;
            if(Utility::StartsWith(string, "((")) reg.assign("\\({2}(.*)\\),\\((.*)\\){2}");//two nested groups
            else reg.assign("\\((.*?)\\)");
            return reg;
        }

        std::smatch SplitParenthesisedGroups(const std::string& string)
        {
            auto regex = GuessRegex(string);
            std::smatch matches;
            std::regex_match(string, matches, regex);
            return matches;
        }

    }

    HepGeom::Transform3D Parse(const std::string& string)
    {
        auto matches = SplitParenthesisedGroups(string);
        if(!matches.empty())
        {
            auto centre = ParseAsVectorWithUnit<CLHEP::Hep3Vector>(matches[1]);
            if(matches.size() == 2) return {{}, centre};
            else
            {
                auto rotation = ParseAsVectorWithUnit<CLHEP::HepRotation>(matches[2]);
                return {rotation, centre};
            }
        }
        else throw std::logic_error("Transformation string must be (x,y,z,unit) or ((x,y,z,unit),(phi,theta,psi,unit))");
    }

    std::istream& operator>>(std::istream& input, HepGeom::Transform3D& transformation)
    {
        std::string string;
        input >> string; // matches will contain references to string elements
        transformation = Parse(string);
        return input;
    }

    std::ostream& operator<<(std::ostream& output, const HepGeom::Transform3D& transformation)
    {
        constexpr unsigned numberOfRows = 3;
        constexpr unsigned numberOfColumns = 3;
        for(unsigned i = 0; i < numberOfRows; ++i)
        {
            for(unsigned j = 0; j < numberOfColumns; ++j)
            {
                output<<std::setw(10)<<std::right<<transformation(i, j);
                if(j < numberOfColumns - 1) output<<"\t";
            }
            if(i < numberOfRows - 1) output<<"\n";
        }
        return output;
    }

}

}
