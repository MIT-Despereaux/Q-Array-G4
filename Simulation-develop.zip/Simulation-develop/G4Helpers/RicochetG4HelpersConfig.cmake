include(CMakeFindDependencyMacro)

find_dependency(Geant4 REQUIRED)
find_dependency(RicochetUtility REQUIRED)

if(NOT TARGET Ricochet::G4Helpers)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetG4HelpersTargets.cmake")
endif()
