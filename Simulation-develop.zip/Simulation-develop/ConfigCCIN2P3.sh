#!/bin/bash

### Config file to use when using the simulation software at CCIN2P3. You can source this file in the .bashrc for extra laziness

# Load clang and specific root version
function setup_SFT(){
    local SFT_BASE=$1
    [[ ! -d $SFT_BASE ]] && echo $SFT_BASE is not a directory && return 1

    source $SFT_BASE/views/LCG_105/x86_64-el9-clang16-opt/setup.sh
    source $SFT_BASE/releases/LCG_105/ROOT/6.30.02/x86_64-el9-clang16-opt/bin/thisroot.sh

}

# version LCG_105
# SFT_BASE = /cvmfs/sft.cern.ch/lcg
# source /cvmfs/sft.cern.ch/lcg/views/LCG_105/x86_64-el9-clang16-opt/setup.sh
# source /cvmfs/sft.cern.ch/lcg/releases/Geant4/11.2.0-52c79/x86_64-el9-clang16-opt/bin/geant4.sh 
# source /cvmfs/sft.cern.ch/lcg/releases/LCG_105/ROOT/6.30.02/x86_64-el9-clang16-opt/bin/thisroot.sh

setup_SFT /cvmfs/sft.cern.ch/lcg 

# ROOT support
export PATH=$PATH:$ROOTSYS/bin
if [ ! $LD_LIBRARY_PATH ] 
then
	export LD_LIBRARY_PATH=$ROOTSYS/lib
else	
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ROOTSYS/lib:$ROOTSYS/lib/root
fi

####### Path you will use for installation and usage  #######

#Where this config file is
export SOURCE=$HOME/Ricochet/Simulation/ConfigCCIN2P3.sh
#Where your sps is
export SPS_PATH=/sps/ricochet/freyes

#### Simulation ####

#Git clone
export RICOCHET_PATH=$HOME/Ricochet


#Build install and output
export RIWORKDIR=${SPS_PATH}/Simulation
export RICOCHET_BUILD=${RIWORKDIR}/build 
export RICOCHET_INSTALL=${RIWORKDIR}/install 
export RICOCHET_OUTPUT=${RIWORKDIR}/output 
export RUNDIR=${RIWORKDIR}/ricochetRun

export SimuOutput=${RICOCHET_INSTALL}/lib64/cmake/RicochetSimuOutput

#### Analysis ####

#Git clone
export ANALYSIS_PATH=$HOME/Ricochet 

#Build install and output
export ANWORKDIR=${SPS_PATH}/Analysis

export ANACUTS_BUILD=${ANWORKDIR}/simulationanalysiscuts/build 
export ANACUTS_INSTALL=${ANWORKDIR}/simulationanalysiscuts/install 
export ANACUTS_OUTPUT=${ANWORKDIR}/simulationanalysiscuts/output

export SIMANACUTS=${ANACUTS_INSTALL}/lib64/cmake/SimAnaCuts

export SHARED_BUILD=${ANWORKDIR}/sharedcodes/build 
export SHARED_INSTALL=${ANWORKDIR}/sharedcodes/install 
export SHARED_OUTPUT=${ANWORKDIR}/sharedcodes/output

export SHARED_CMAKE=${ANALYSIS_PATH}/sharedcodes/SimulationAnalysis/SimuAnalysis 

export RUNANALYSIS=${RIWORKDIR}/runAnalysis
export RADIOGENIC_OUTPUT=${RUNANALYSIS}/radiogenic

EXE=$RIWORKDIR/build/RicochetSimulation


export LIBCRY=$HOME/Ricochet/cry/Linux_el7

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$RIWORKDIR/install/lib
export PATH=$PATH:$RIWORKDIR/install/Simulation/bin
export RICOCHET_DATA=$RIWORKDIR/install/data
