# Empty dependencies file for GDMLExporter.
# This may be replaced when dependencies are built.
