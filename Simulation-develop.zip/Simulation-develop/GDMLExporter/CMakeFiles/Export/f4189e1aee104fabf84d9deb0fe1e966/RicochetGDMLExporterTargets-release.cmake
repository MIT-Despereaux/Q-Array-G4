#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::GDMLExporter" for configuration "Release"
set_property(TARGET Ricochet::GDMLExporter APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::GDMLExporter PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetGDMLExporter.so"
  IMPORTED_SONAME_RELEASE "libRicochetGDMLExporter.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::GDMLExporter )
list(APPEND _cmake_import_check_files_for_Ricochet::GDMLExporter "${_IMPORT_PREFIX}/lib64/libRicochetGDMLExporter.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
