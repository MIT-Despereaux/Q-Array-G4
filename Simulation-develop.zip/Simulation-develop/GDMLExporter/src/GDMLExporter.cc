#include "GDMLExporter/GDMLExporter.hh"

/// Standard includes
#include <cstdio>

namespace resolve_std /// avoid std::remove conflict
{
    using std::remove;
}

#include <fstream>
#include <sstream>

/// Geant4 includes
#include "G4GDMLParser.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"


namespace GDMLExporter
{

    const G4LogicalVolume& GetLogicalWorld()
    {
        G4PhysicalVolumeStore* store = G4PhysicalVolumeStore::GetInstance();

        if(store)
        {
            return *(store->at(0)->GetLogicalVolume());
        }
        else
        {
            throw std::runtime_error("G4PhysicalVolumeStore::GetInstance() return nullptr !");
        }
    }

    std::string FileToString(std::string filename)
    {
        std::ifstream in(filename);
        std::stringstream sstr;
        sstr << in.rdbuf();
        return sstr.str();
    }

    std::string GeometryToGDML(const G4LogicalVolume& world)
    {
        std::string temporary_filename = "geometry_temporary.gdml";

        G4GDMLParser parser;
        parser.Write(temporary_filename, &world);

        std::string gdml_str = FileToString(temporary_filename);

        std::remove(temporary_filename.c_str()); // delete file

        return gdml_str;
    }

    void ExportGeometryToGDML(const G4LogicalVolume& world, std::string filename)
    {
        std::string gdml_str = GeometryToGDML(world);

        std::ofstream out(filename);

        out << gdml_str;
    }

    void ExportWorlGeometryToGDML(std::string filename)
    {
        ExportGeometryToGDML(GetLogicalWorld(), filename);
    }
}
