#include "GDMLExporter/GDMLExporterMessenger.hh"

/// Project includes
#include "GDMLExporter/GDMLExporter.hh"

namespace GDMLExporter
{
    GDMLExporterMessenger::GDMLExporterMessenger(std::string cmdPrefixPath)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("GDMLExporter command directory");

        mCmdExportGeometry.reset(new G4UIcmdWithAString((cmdPrefixPath + "ExportGeometry").c_str(), this));
        mCmdExportGeometry->AvailableForStates(G4State_Idle);
    }

    void GDMLExporterMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdExportGeometry.get())
        {
            ExportWorlGeometryToGDML(valueStr);
        }
    }
}


