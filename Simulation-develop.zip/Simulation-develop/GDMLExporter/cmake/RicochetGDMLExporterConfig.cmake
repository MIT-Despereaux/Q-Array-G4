include(CMakeFindDependencyMacro)

find_dependency(Geant4 REQUIRED COMPONENTS gdml)

if(NOT TARGET Ricochet::GDMLExporter)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetGDMLExporterTargets.cmake")
endif()

