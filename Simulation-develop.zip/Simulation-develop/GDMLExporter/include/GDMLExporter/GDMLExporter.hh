#ifndef GDMLEXPORTER_H
#define GDMLEXPORTER_H

/// Standard includes
#include <string>

/// Geant4 includes
#include "G4LogicalVolume.hh"

namespace GDMLExporter
{
    std::string GeometryToGDML(const G4LogicalVolume& world);

    void ExportGeometryToGDML(const G4LogicalVolume& world, std::string filename);

    /// Find world using global singleton
    void ExportWorlGeometryToGDML(std::string filename);
}

#endif /// GDMLEXPORTER_H
