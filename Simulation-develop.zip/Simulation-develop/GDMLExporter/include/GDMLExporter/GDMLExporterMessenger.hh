#ifndef GDMLEXPORTERMESSENGER_H
#define GDMLEXPORTERMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"

namespace GDMLExporter
{
    class GDMLExporterMessenger: public G4UImessenger
    {
        public:
            GDMLExporterMessenger(std::string cmdPrefixPath = "/geometry/GDML/");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWithAString> mCmdExportGeometry;
    };
}

#endif /// GDMLEXPORTERMESSENGER_H
