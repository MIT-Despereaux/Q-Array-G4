/**************************************************************************
* @file ShieldingWithEmNR.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 06 Feb 2020
* @brief Physics list replacing the electromagnetism of the Shielding
* physics list. More precisely, the G4VPhysicsConstructor of
* electromagnetism is replaced with PhysListEmStandardNR, which contains
* the G4ScreenedNuclearRecoil process; both of which are taken from the
* Geant4 Em7 example.
* ************************************************************************/

#ifndef PHYSICS_SHIELDINGWITHEMNR_HH
#define PHYSICS_SHIELDINGWITHEMNR_HH

#include "Shielding.hh"

struct ShieldingWithEmNR : Shielding
{
    ShieldingWithEmNR(int verbosity, const std::string& n_model = "HP");
};

#endif /* PHYSICS_SHIELDINGWITHEMNR_HH */
