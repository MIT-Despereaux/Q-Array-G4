/**************************************************************************
* @file BuildPhysicsList.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 06 Feb 2020
* @brief map strings to types of physics list
* ************************************************************************/

#ifndef PHYSICS_BUILDPHYSICSLIST_HH
#define PHYSICS_BUILDPHYSICSLIST_HH

#include <string>

class G4VModularPhysicsList;

G4VModularPhysicsList* BuildPhysicsList(const std::string& listName, int verbosity);

#endif /* PHYSICS_BUILDPHYSICSLIST_HH */
