include(CMakeFindDependencyMacro)

find_dependency(Geant4 REQUIRED)
find_dependency(RicochetG4Rubbish REQUIRED)

if(NOT TARGET Ricochet::Physics)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetPhysicsTargets.cmake")
endif()
