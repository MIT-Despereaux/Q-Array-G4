file(REMOVE_RECURSE
  "CMakeFiles/Physics.dir/src/BuildPhysicsList.cc.o"
  "CMakeFiles/Physics.dir/src/BuildPhysicsList.cc.o.d"
  "CMakeFiles/Physics.dir/src/ShieldingWithEmNR.cc.o"
  "CMakeFiles/Physics.dir/src/ShieldingWithEmNR.cc.o.d"
  "libRicochetPhysics.pdb"
  "libRicochetPhysics.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Physics.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
