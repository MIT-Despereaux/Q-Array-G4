#include "Physics/BuildPhysicsList.hh"
#include "Shielding.hh"
#include "Physics/ShieldingWithEmNR.hh"

G4VModularPhysicsList* BuildPhysicsList(const std::string& listName, int verbosity)
{
  G4VModularPhysicsList* physicsList;

  if(listName == "Shielding") physicsList = new Shielding(verbosity);
  else if(listName == "ShieldingWithEmNR") physicsList = new ShieldingWithEmNR(verbosity);
  else if(listName == "none") physicsList = new G4VModularPhysicsList;
  else throw std::logic_error("BuildPhysicsList: Unknown physics list '"+listName+"'");

  physicsList->SetVerboseLevel(verbosity);

  return physicsList;
}
