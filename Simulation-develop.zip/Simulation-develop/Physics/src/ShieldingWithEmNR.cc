#include "Physics/ShieldingWithEmNR.hh"
#include "G4Rubbish/PhysListEmStandardNR.hh"

ShieldingWithEmNR::ShieldingWithEmNR(int verbosity, const std::string& n_model)
    :Shielding(verbosity, n_model)
{
    ReplacePhysics(new PhysListEmStandardNR);
}
