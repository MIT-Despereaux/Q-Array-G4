/// Standard includes
#include <iostream>
#include <string>
#include <functional>
#include <map>

/// ROOT includes
#include "TCanvas.h"
#include "TH1.h"
#include "TRint.h"
#include "TStyle.h"
#include "THStack.h"

/// Ricochet includes
#include "SimuOutput/SimuRunInfo.hh"
#include "SimuOutput/SimuTreeReader.hh"
#include "SimuOutput/InfoHeaderReader.hh"

using namespace std;

void RunRootApp(std::function<void()> func);

int main(int argc, char* argv[])
{
    if(argc != 2 || string(argv[1]) == "-h")
    {
        cout << "Usage: AnalysisProject <SimuOuputFilename.root>" << endl;

        return EXIT_FAILURE;
    }

    TFile* file = TFile::Open(argv[1], "READ");
    SimuRunInfo runInfo = SimuRunInfo::ReadFrom("SimuRunInfo", *file);
    InfoHeaderReader ILLInfoReader("ILLFile", *file);
    auto simulatedTime = ILLInfoReader.GetKeyValue<double>("SimulatedTime");
    SimuTreeReader tree(*file);


    TH1D::AddDirectory(false);
    TH1D hInitEnergy("hInitEnergy", ";Energy;Counts", 100, 0, 10000);
    TH1D hMultiplicity("hMultiplicity", ";Multiplicity;Counts", 31, -0.5, 30.5);
    map<string, TH1D> hEnergySpectra;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    const SimuEvent& event = tree.GetEvent();
    while(tree.LoopWithProgress())
    {
        for(const auto& primary : event.PrimaryEvents)
        {
            hInitEnergy.Fill(primary.E);
        }

        hMultiplicity.Fill(event.DetectorEvents.size());

        for(const auto& det : event.DetectorEvents)
        {
            if(hEnergySpectra.find(det.DetectorName) == hEnergySpectra.end())
            {
                hEnergySpectra[det.DetectorName] = TH1D(Form("hEnergySpectrum_%s", det.DetectorName.c_str()), Form("%s;Energy;Counts", det.DetectorName.c_str()), 100, 0, 10000);
            }
            hEnergySpectra[det.DetectorName].Fill(det.Energy());
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///-- Print simulation info
    cout << "\nSimulation run info:" << endl;
    cout << Form(" - Nb of simulated events = %lu", runInfo.NbOfEvents) << endl;
    cout << Form(" - Simulated time = %.4f", simulatedTime) << endl;

    RunRootApp([&] ()
    {
        new TCanvas("canEnergy", "Energy");
        hInitEnergy.Draw();

        new TCanvas("canMultiplicity", "Multiplicity");
        hMultiplicity.Draw();

        gStyle->SetOptTitle(0);
        gStyle->SetOptStat(0);

        gStyle->SetPalette(1);
        TCanvas* canEnergySpectra = new TCanvas("canEnergySpectra", "EnergySpectra");
        THStack* histoCollection = new THStack("histoCollection", "Bolometer energy spectra");
        for(auto& pairHistoEnergySpectrum : hEnergySpectra)
        {
            histoCollection->Add(&(pairHistoEnergySpectrum.second));
            pairHistoEnergySpectrum.second.SetLineWidth(2);
        }
        histoCollection->Draw("plc nostack");
        canEnergySpectra->BuildLegend();
    });

    return EXIT_SUCCESS;
}

void RunRootApp(std::function<void()> func)
{
    int argc = 2;
    char nameApp[] = "RootApp";
    char optionNoRootHeaderOutput[] = "-l";
    char* argv[] = {nameApp, optionNoRootHeaderOutput};

    TRint* theApp = new TRint("RootApp", &argc, argv);

    func();

    theApp->Run();
}
