#include <fstream>
#include <algorithm>
#include "getopt.h"
#include "Utility/String.hh"
#include "GitVersion.hh"
#include "ProgramOptions.hh"

namespace ProgramOptions
{

    MacroCommands ParseMacroStreamCommands(std::istream& macroStream)
    {
        MacroCommands commands;
        for(std::string line; std::getline(macroStream, line); )
        {
            line = line.substr(0, line.find_first_of('#'));
            bool whiteSpacesOnly = std::all_of(line.begin(), line.end(), [] (char c) {return std::isspace(c);});
            if(!whiteSpacesOnly) commands.emplace_back(line);
        }
        return commands;
    }

    bool CommandsNeedVisualiser(const MacroCommands& commands)
    {
        auto it = std::find_if(std::begin(commands), std::end(commands),
            [](const auto& command){return Utility::StartsWith(command, "/vis/");}
        );
        return it != std::end(commands);
    }

    void AppendCommands(const MacroCommands& commands, Options& options)
    {
        options.macroCommands.insert(options.macroCommands.end(), commands.begin(), commands.end());
        if(!options.useGUI) options.useGUI = CommandsNeedVisualiser(commands);
    }

    void ParseMacroStream(std::istream& macroStream, const std::string& streamName, Options& options)
    {
            auto currentCommands = ParseMacroStreamCommands(macroStream);
            if(currentCommands.empty())
            {
                std::cerr<<"Macro '"<<streamName<<"' does not contain executable commands!\n";
                options.errorCode = 1;
            }
            else AppendCommands(currentCommands, options);
    }

    void ParseMacro(const std::string& macroPath, Options& options)
    {
        std::ifstream macroStream(macroPath);
        if(macroStream) ParseMacroStream(macroStream, macroPath, options);
        else
        {
            std::cerr<<"Macro '"<<macroPath<<"' not accessible!\n";
            options.errorCode = 1;
        }
    }

    void PrintUsage(std::ostream& output)
    {
        Options defaults{};
        output<<"Usage: RicochetSimulation [options] macro(s)\n"
            <<"Options:\n"
            <<"  -V <int>      Verbosity (default: "<<defaults.verbosity<<")\n"
            <<"  -o <path>     Output filename (superseded by macro contents)\n"
            <<"  -p <string>   Physics list's name (default: "<<defaults.physicsListName<<")\n"
            <<"  -v            Print version\n"
            <<"  -h            Display this help message\n"
            ;
    }

    void ParseFlag(char flag, Options& options)
    {
        switch(flag)
        {
            case 'V':
                options.verbosity = std::stoi(optarg);
                break;
            case 'o':
                options.outputFileName = optarg;
                break;
            case 'p':
                options.physicsListName = optarg;
                break;
            case 'v':
                Simulation::GitVersion::Print(std::cout);
                options.errorCode = 0;
                break;
            case 'h':
            case '?':
                PrintUsage(std::cerr);
                options.errorCode = 1;
        }
    }

    void ParsePositionalArgs(int beginPositional, int endPositional, char** argv, Options& options)
    {
        if(beginPositional == endPositional) ParseMacroStream(std::cin, "console input", options);
        else for(int macroIndex = beginPositional ; macroIndex < endPositional ; ++macroIndex)
            ParseMacro(argv[macroIndex], options);
    }

    Options ParseArgs(int argc, char** argv)
    {
        Options options;
        char flag;
        while((flag = getopt(argc, argv, "V:o:p:vh")) != -1)
        {
            ParseFlag(flag, options);
            if(options.errorCode >= 0) return options;
        }
        ParsePositionalArgs(optind, argc, argv, options);
        return options;
    }

}
