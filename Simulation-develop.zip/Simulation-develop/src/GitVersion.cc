#include <ostream>
#include "GitVersion.hh"

namespace Simulation{

    namespace GitVersion{

        std::string Describe() {
            return std::string("v1.3-48-g6c71620");
        }

        std::string Hash() {
            return std::string("6c71620cf8ef5e630efe69393b0dd4e076555297") + " (dirty)";
        }

        std::string Refspec() {
            return "refs/heads/CopperCryoCubeHolder_merge";
        }

        void Print(std::ostream& output){

            output<< "Git Describe: " << Describe() <<"\n"
                  << "Git Hash: " << Hash() <<"\n"
                  << "Git Refspec: " << Refspec() << std::endl;

        }

    }

}
