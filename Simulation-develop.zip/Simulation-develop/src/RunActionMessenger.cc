#include "RunActionMessenger.hh"
#include "G4UIcmdWithAString.hh"

void RunActionCommandsCreator::Initialise(RunActionMessenger& messenger)
{
    messenger.AddCommand<G4UIcmdWithAnInteger>("verbose", "RunAction's verbosity",
         [](auto& runAction, const std::string& macroArgument){runAction.SetVerbose(std::stoi(macroArgument));});
    messenger.AddCommand<G4UIcmdWithAString>("FileName", "Output filename", &RunAction::SetOutputFileName);
    messenger.AddCommand<G4UIcmdWithAnInteger>("FirstEventNumber", "First run event number",
         [](auto& runAction, const std::string& macroArgument){runAction.SetFirstEventNumber(std::stoi(macroArgument));});
    messenger.AddCommand<G4UIcmdWithAnInteger>("RandomSeed", "Random generator' seed",
         [](auto& runAction, const std::string& macroArgument){runAction.SetRandomSeed(std::stoul(macroArgument));});
    messenger.AddCommand<G4UIcmdWithAnInteger>("OutputCompression", "TFile's output compression setting",
         [](auto& runAction, const std::string& macroArgument){runAction.SetOutputCompression(std::stoi(macroArgument));});
}
