//==============================================================================
#include "globals.hh"

#include "G4UIdirectory.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "LeadBlock.hh"
#include "LeadBlockMessenger.hh"
#include "G4SystemOfUnits.hh"

//==============================================================================
namespace lyongeom {

  LeadBlockMessenger::LeadBlockMessenger(LeadBlock* myLeadBlock) :
    m_LeadBlock(myLeadBlock) {

    G4String directory = "/ricochetSim/lyongeom/LeadBlock/";
    m_dirDetector = new G4UIdirectory(directory);
    m_dirDetector->SetGuidance("UI commands specific to the Lead Block.");

    G4String strVerbose = directory;
    strVerbose.append("verbose");
    cmdVerbose = new G4UIcmdWithAnInteger(strVerbose,this);
    cmdVerbose->SetGuidance("Set verbose level of LeadBlock");
    cmdVerbose->SetParameterName("val",false);
    cmdVerbose->AvailableForStates(G4State_Idle);


    // Set x of the Lead Block

    G4String strSet_x_PbBlock = directory;
    strSet_x_PbBlock.append("Set_x_PbBlock");
    cmdSet_x_PbBlock = new G4UIcmdWithADoubleAndUnit(strSet_x_PbBlock, this);
    cmdSet_x_PbBlock->SetGuidance("Specifiy the x of the Lead Block Position");
    cmdSet_x_PbBlock->SetDefaultUnit("cm");
    cmdSet_x_PbBlock->AvailableForStates(G4State_PreInit, G4State_Idle);


    // Set y of the Lead Block

    G4String strSet_y_PbBlock = directory;
    strSet_y_PbBlock.append("Set_y_PbBlock");
    cmdSet_y_PbBlock = new G4UIcmdWithADoubleAndUnit(strSet_y_PbBlock, this);
    cmdSet_y_PbBlock->SetGuidance("Specifiy the y of the Lead Block Position");
    cmdSet_y_PbBlock->SetDefaultUnit("cm");
    cmdSet_y_PbBlock->AvailableForStates(G4State_PreInit, G4State_Idle);
  
  
    // Set z of the Lead Block

    G4String strSet_z_PbBlock = directory;
    strSet_z_PbBlock.append("Set_z_PbBlock");
    cmdSet_z_PbBlock = new G4UIcmdWithADoubleAndUnit(strSet_z_PbBlock, this);
    cmdSet_z_PbBlock->SetGuidance("Specifiy the z of the Lead Block Position");
    cmdSet_z_PbBlock->SetDefaultUnit("cm");
    cmdSet_z_PbBlock->AvailableForStates(G4State_PreInit, G4State_Idle);



    // Set theta of the Lead Block
  
    G4String strSet_theta_PbBlock = directory;
    strSet_theta_PbBlock.append("Set_theta_PbBlock");
    cmdSet_theta_PbBlock = new G4UIcmdWithADoubleAndUnit(strSet_theta_PbBlock, this);
    cmdSet_theta_PbBlock->SetGuidance("Specifiy the theta of the Lead Block Position");
    cmdSet_theta_PbBlock->SetDefaultUnit("degree");
    cmdSet_theta_PbBlock->AvailableForStates(G4State_PreInit, G4State_Idle);

  

  }

  LeadBlockMessenger::~LeadBlockMessenger() {
    delete m_dirDetector;
    delete cmdVerbose;
    delete cmdSet_x_PbBlock;
    delete cmdSet_y_PbBlock;
    delete cmdSet_z_PbBlock;
    delete cmdSet_theta_PbBlock;

  }

  void LeadBlockMessenger::SetNewValue(G4UIcommand* command, G4String newValue) {
    if( command == cmdVerbose){
      m_LeadBlock->SetVerbose(cmdVerbose->GetNewIntValue(newValue));
    } else if( command == cmdSet_x_PbBlock){
      m_LeadBlock->Setx_PbBlock(cmdSet_x_PbBlock->GetNewDoubleValue(newValue));
    } else if( command == cmdSet_y_PbBlock){
      m_LeadBlock->Sety_PbBlock(cmdSet_y_PbBlock->GetNewDoubleValue(newValue));
    } else if( command == cmdSet_z_PbBlock){
      m_LeadBlock->Setz_PbBlock(cmdSet_z_PbBlock->GetNewDoubleValue(newValue));
    } else if( command == cmdSet_theta_PbBlock){
      m_LeadBlock->Settheta_PbBlock(cmdSet_theta_PbBlock->GetNewDoubleValue(newValue));
    } 


  }

} //namespace lyongeom
