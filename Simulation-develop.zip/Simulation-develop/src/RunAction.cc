#include "RunAction.hh"
#include "RunActionMessenger.hh"
#include "DetectorConstruction.hh"
#include "G4Helpers/OwningMessenger.hh"
#include "Event/ActionMessenger.hh"
#include "Event/SteppingAction.hh"
#include "Generator/Primary.hh"
#include "Geometry/ObjectSerialiser.hh"
#include "SimuOutput/SimuRunInfo.hh"
#include "SimuOutput/SimuTreeWriter.hh"
#include "SimuOutput/VolumeHasher.hh"
#include "GitVersion.hh"
#include "MacroRecorder.hh"

#include "Randomize.hh"
#include "G4Run.hh"
#include "G4RunManager.hh"

#include <random>

RunAction::RunAction(
        G4Helpers::OwningMessenger<Generator::Primary, Generator::PrimaryMessenger>& primaryGeneratorAction,
        G4Helpers::OwningMessenger<Event::Action, Event::ActionMessenger>& Action,
        Event::SteppingAction& steppingAction,
        const std::string& outputFileName_, int verbosity_
        )
    :
    outputFileName(outputFileName_),
    outputFile(nullptr),
    fPrimaryGeneratorAction(&primaryGeneratorAction),
    fEventAction(&Action),
    fSteppingAction(&steppingAction),
    fVerbose(verbosity_),
    fFirstEventNumber(1)
{
}

void RunAction::SetGlobalGeneratorSeeds()
{
  if(fAutoSeed)
  {
    if(fVerbose > 1) std::cout<<"*** Random seed ON ***"<<std::endl;
    fRndGenSeed = std::random_device{}();
  }
  std::mt19937_64 seeder(fRndGenSeed);
  long seed[] = {long(seeder()) , long(seeder())};
  CLHEP::HepRandom::setTheSeeds(seed);
  if (fVerbose > 0) std::cout << "*** Seeds : " << seed[0] << " / " << seed[1] << std::endl;  
}

void RunAction::SetOutputCompression(int outputCompression_)
{
    outputCompression = outputCompression_;
}

void RunAction::SetOutputFile()
{
  if(outputFileName.empty()) throw std::runtime_error("RunAction::SetOutputFile empty output filename!");
  if(fVerbose > 1) std::cout<<"OuputFile Name : "<<outputFileName<<std::endl;
  outputFile.reset(new TFile(outputFileName.c_str(), "RECREATE", "", outputCompression));
}

void RunAction::SetupStepRecorder()
{
  if(fStepRecorderMessenger.GetActivationStatus())
  {
      fStepRecorder.InitTree(*outputFile);
      fEventAction->SetStepRecorder(fStepRecorder);
      fSteppingAction->SetStepRecorder(fStepRecorder);
  }
}

void RunAction::BeginOfRunAction(const G4Run* aRun) {

  if(fVerbose > 1) G4cout << "### Run " << aRun->GetRunID() << " start." << G4endl;

  SetGlobalGeneratorSeeds();
  SetOutputFile();

  fSimuTreeWriter.InitTree(*outputFile);
  fEventAction->SetSimuTreeWriter(fSimuTreeWriter);
  SetupStepRecorder();
  fEventAction->SetSteppingAction(*fSteppingAction);
  fEventAction->Initialise();

  if(fVerbose>0) std::cout << "exit BeginOfRunAction" << std::endl;
}

void RunAction::WriteRunInfo(const G4Run& run, const char* headerName) const
{
    SimuRunInfo runInfo;

    runInfo.NbOfEvents = run.GetNumberOfEvent();
    runInfo.GitDescribe = Simulation::GitVersion::Describe();
    runInfo.GitHash = Simulation::GitVersion::Hash();
    runInfo.GitRefspec = Simulation::GitVersion::Refspec();
    runInfo.Macro = MacroRecorder::GetSingleton().GetMacroAsStr();
    runInfo.RndSeed = fRndGenSeed;

    runInfo.WriteIn(headerName, *outputFile);
}

void RunAction::WriteGeometryInfo(const char* outputDirectoryName) const
{
    auto& geometryDirectory = *(outputFile->mkdir(outputDirectoryName));
    Geometry::ObjectSerialiser objectSerialiser(geometryDirectory);

    auto detector = static_cast<const Geometry::DetectorConstruction*>(G4RunManager::GetRunManager()->GetUserDetectorConstruction());
    detector->SerialiseActivatedBuilders(objectSerialiser);
    detector->WriteVolumeNames(geometryDirectory, "PhysicalVolumes");
}


void RunAction::EndOfRunAction(const G4Run* aRun)
{
    if(fVerbose>0) std::cout << "enter EndOfRunAction" << std::endl;

    WriteGeometryInfo("GeometryInfo");
    WriteRunInfo(*aRun, "SimuRunInfo");
    fPrimaryGeneratorAction->Write(*(outputFile->mkdir("GeneratorInfo")));
    fSimuTreeWriter.Save();
    if(fStepRecorderMessenger.GetActivationStatus()) fStepRecorder.Save();

    outputFile.reset(nullptr);

    if(fVerbose>0) std::cout << "exit EndOfRunAction" << std::endl;
}


