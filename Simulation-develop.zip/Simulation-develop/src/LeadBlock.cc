#include "LeadBlock.hh"
#include "LeadBlockMessenger.hh"

#include "G4Box.hh"
#include "G4VisAttributes.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"

#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4PVPlacement.hh"
#include "G4AssemblyVolume.hh"

namespace lyongeom {

  LeadBlock::LeadBlock(bool overlap):

    m_checkOverlaps(overlap) {

        (void) m_checkOverlaps;//warning fix until variables are sensibly used

    m_LeadBlockMessenger = new LeadBlockMessenger(this);

    Alpha = 0.*deg;
    DeltaAlpha = 360.*deg;

    // --- Position of the Lead Block. It needs to change with the source, put the same value as the source, because automatic 5 cm distance from the source point to the Pb block surface imbedded in LeadBlock.cc : PlaceLeadBlock(*motherLogic)

    x_PbBlock = 0.;
    y_PbBlock = 0.;
    z_PbBlock = 0.; // enter the same value as the source, the centre of Pb Block will be brought automatically 10 cm away from the source position.
    theta_PbBlock = 0.; // enter the same value as the source, the centre of Pb Block will be brought automatically 10 cm away from the source position.

    m_name = "LeadBlock";
    m_verbose = 0;

  }

  //
  //Geometry Constants
  //

  G4double LeadBlock::PbBlock_l() {
    return 12.*cm;
  }
  G4double LeadBlock::PbBlock_e() {
    return 20.*cm;
  }


  LeadBlock::~LeadBlock() {
    delete m_LeadBlockMessenger;
  }


  G4LogicalVolume* LeadBlock::Construct() {

    if (m_verbose > 0) {
      G4cout << "> Construct " << m_name << " geometry"
	     << G4endl;
    }

    G4Colour grey(G4Colour::White());
    G4Colour::GetColour("Lead", grey);
    G4VisAttributes* visAttLead = new G4VisAttributes(grey);
    visAttLead->SetVisibility(true);


    G4ThreeVector Tm;
    G4RotationMatrix Rm;
    Rm.set(0.,0.,0.); Tm.set(0.,0.,0.);
    G4Transform3D  Tf = G4Transform3D(Rm,Tm);


    // --- Define the Lead Block

    G4double LeadBlock_x = PbBlock_l()/2.;
    G4double LeadBlock_y = PbBlock_e()/2.;
    G4double LeadBlock_z = PbBlock_l()/2.;

    G4Box* solidLeadBlock = new G4Box("solidLeadBlock", LeadBlock_x, LeadBlock_y, LeadBlock_z);
    G4LogicalVolume* logicLeadBlock = new G4LogicalVolume(solidLeadBlock, G4Material::GetMaterial("Lead"), "logicLeadBlock");
    logicLeadBlock->SetVisAttributes(visAttLead);


    if (m_verbose > 0) {
      G4cout << m_name << " Constructed." << G4endl;
    }

    return logicLeadBlock;

  }


  void LeadBlock::PlaceLeadBlock(G4LogicalVolume *motherLogic) {

    G4ThreeVector Tm;
    G4RotationMatrix Rm;

    Tm.set(0., y_PbBlock-(PbBlock_e()/2.+50.)*sin(theta_PbBlock), z_PbBlock+(PbBlock_e()/2.+50.)*cos(theta_PbBlock)); // 50. = 50.*mm automatically 5 cm from the source point.
    Rm.set(0., 90.*deg-theta_PbBlock, 0.);
    G4Transform3D Tf = G4Transform3D(Rm,Tm);

    new G4PVPlacement(Tf,Construct(),"LeadBlock",motherLogic,false,0);

  }

} //namespace lyongeom
