//==============================================================================
#include "globals.hh"

#include "G4UIdirectory.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "DetectorConstruction.hh"
#include "LyonDetectorMessenger.hh"
#include "G4SystemOfUnits.hh"


namespace lyongeom {


  //==============================================================================
  LyonDetectorMessenger::LyonDetectorMessenger(Geometry::DetectorConstruction* myDet) :
    m_detector(myDet) {

    G4String directory = "/ricochetSim/lyongeom/";
    m_dirDetector = new G4UIdirectory(directory);
    m_dirDetector->SetGuidance("UI commands specific to the cryostat.");

    G4String strVerbose = directory;
    strVerbose.append("verbose");
    cmdVerbose = new G4UIcmdWithAnInteger(strVerbose,this);
    cmdVerbose->SetGuidance("Set verbose level of DetectorConstruction");
    cmdVerbose->SetParameterName("val",false);
    cmdVerbose->SetRange("val>=0");
    cmdVerbose->AvailableForStates(G4State_Idle);

    G4String strAlpha = directory;
    strAlpha.append("Alpha");
    cmdAlpha = new G4UIcmdWithADoubleAndUnit(strAlpha, this);
    cmdAlpha->SetGuidance("angle for display");
    cmdAlpha->SetDefaultUnit("deg");
    cmdAlpha->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strDeltaAlpha = directory;
    strDeltaAlpha.append("DeltaAlpha");
    cmdDeltaAlpha = new G4UIcmdWithADoubleAndUnit(strDeltaAlpha, this);
    cmdDeltaAlpha->SetGuidance("angle for display");
    cmdDeltaAlpha->SetDefaultUnit("deg");
    cmdDeltaAlpha->AvailableForStates(G4State_PreInit, G4State_Idle);


    G4String strBuildLabo = directory;
    strBuildLabo.append("BuildLabo");
    cmdBuildLabo = new G4UIcmdWithoutParameter(strBuildLabo, this);
    cmdBuildLabo->SetGuidance("Build the Labo");
    cmdBuildLabo->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strBuildCryostat = directory;
    strBuildCryostat.append("BuildCryostat");
    cmdBuildCryostat = new G4UIcmdWithoutParameter(strBuildCryostat, this);
    cmdBuildCryostat->SetGuidance("Build the cryostat");
    cmdBuildCryostat->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strBuildFrame = directory;
    strBuildFrame.append("BuildFrame");
    cmdBuildFrame = new G4UIcmdWithoutParameter(strBuildFrame, this);
    cmdBuildFrame->SetGuidance("Build the Frame");
    cmdBuildFrame->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strBuildLeadShieldEX = directory;
    strBuildLeadShieldEX.append("BuildLeadShieldEX");
    cmdBuildLeadShieldEX = new G4UIcmdWithoutParameter(strBuildLeadShieldEX, this);
    cmdBuildLeadShieldEX->SetGuidance("Build the LeadShieldEX");
    cmdBuildLeadShieldEX->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strBuildAll = directory;
    strBuildAll.append("BuildAll");
    cmdBuildAll = new G4UIcmdWithoutParameter(strBuildAll, this);
    cmdBuildAll->SetGuidance("Build all the volumes");
    cmdBuildAll->AvailableForStates(G4State_PreInit, G4State_Idle);

    G4String strAddLeadBlock = directory;
    strAddLeadBlock.append("AddLeadBlock");
    cmdAddLeadBlock = new G4UIcmdWithoutParameter(strAddLeadBlock, this);
    cmdAddLeadBlock->SetGuidance("Add a Lead Block");
    cmdAddLeadBlock->AvailableForStates(G4State_PreInit, G4State_Idle);

  }

  LyonDetectorMessenger::~LyonDetectorMessenger() {
    delete m_dirDetector;
    delete cmdVerbose;
    delete cmdAlpha;
    delete cmdDeltaAlpha;
    delete cmdBuildLabo;
    delete cmdBuildCryostat;
    delete cmdBuildFrame;
    delete cmdBuildLeadShieldEX;
    delete cmdBuildAll;
    delete cmdAddLeadBlock;
  }

  void LyonDetectorMessenger::SetNewValue(G4UIcommand* command, G4String newValue) {
    if( command == cmdVerbose){
      m_detector->SetVerbosity(cmdVerbose->GetNewIntValue(newValue));
    }  else if ( command == cmdAlpha ) {
      m_detector->SetAlpha(cmdAlpha->GetNewDoubleValue(newValue));
    }  else if ( command == cmdDeltaAlpha ) {
      m_detector->SetDeltaAlpha(cmdDeltaAlpha->GetNewDoubleValue(newValue));
    } else if ( command == cmdBuildLabo ) {
      m_detector->BuildLabo();
    } else if ( command == cmdBuildCryostat ) {
      m_detector->BuildCryostat();
    } else if ( command == cmdBuildFrame ) {
      m_detector->BuildFrame();
    } else if ( command == cmdBuildLeadShieldEX ) {
      m_detector->BuildLeadShieldEX();
    } else if ( command == cmdBuildAll ) {
      m_detector->BuildLabo();
      m_detector->BuildCryostat();
      m_detector->BuildFrame();
      m_detector->BuildLeadShieldEX();
    } else if ( command == cmdAddLeadBlock) {
      m_detector->AddLeadBlock();
    }
  }

} //namespace lyongeom
