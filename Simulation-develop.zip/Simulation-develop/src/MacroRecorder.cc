#include "MacroRecorder.hh"

/// Standard includes
#include <fstream>
#include <cctype>
#include <algorithm>

/// Geant4 includes
#include "G4UImanager.hh"

namespace
{
    std::string GetErrorMessage(int commandStatus)
    {
        if(commandStatus == fCommandNotFound)
        {
            return "command not found";
        }
        else if(commandStatus == fIllegalApplicationState)
        {
            return "illegal application state";
        }
        else if((commandStatus / 100) * 100 == fParameterOutOfRange)
        {
            int parameterPos = commandStatus % 100;
            return std::string("parameter ") + std::to_string(parameterPos) + std::string(" out of range");
        }
        else if((commandStatus / 100) * 100 == fParameterUnreadable)
        {
            int parameterPos = commandStatus % 100;
            return std::string("parameter ") + std::to_string(parameterPos) + std::string(" unreadable");
        }
        else if((commandStatus / 100) * 100 == fParameterOutOfCandidates)
        {
            int parameterPos = commandStatus % 100;
            return std::string("parameter ") + std::to_string(parameterPos) + std::string(" out of candidates");
        }
        else if(commandStatus == fAliasNotFound)
        {
            return "alias not found";
        }
        else
        {
            return "unknown error (code: " + std::to_string(commandStatus) + ")";
        }
    }

}

MacroRecorder::MacroRecorder() : mUIManager(G4UImanager::GetUIpointer()) {}

MacroRecorder& MacroRecorder::GetSingleton()
{
    static MacroRecorder macroRecorder;

    return macroRecorder;
}

G4UImanager* MacroRecorder::GetUIManager()
{
    return mUIManager;
}

void MacroRecorder::ExecuteMacroCmd(const std::string& command)
{
    macroStr += command + "\n";
    int commandStatus = mUIManager->ApplyCommand(command);

    if(commandStatus != fCommandSucceeded)
        throw std::runtime_error("Macro command error (" + std::to_string(commandStatus) + std::string("): ") + GetErrorMessage(commandStatus) + ".\n" + command);
}

void MacroRecorder::ExecuteMacroCommands(const std::vector<std::string>& commands)
{
    for(const auto& command : commands) ExecuteMacroCmd(command);
}

const std::string& MacroRecorder::GetMacroAsStr() const
{
    return macroStr;
}

