#include "Labo.hh"

#include "G4Box.hh"
#include "G4VisAttributes.hh"
#include "G4SystemOfUnits.hh"

#include "G4Polyhedra.hh"
#include "G4PVPlacement.hh"
#include "G4AssemblyVolume.hh"
#include "G4SubtractionSolid.hh"

namespace lyongeom {

  Labo::Labo(bool overlap):

    m_checkOverlaps(overlap) {

    m_name = "Labo";

    Alpha = 0.*deg;
    DeltaAlpha = 360.*deg;

    m_verbose = 1;
  }


  Labo::~Labo() {
  }

  //
  //Geometry Constants
  //


  // --- Geometry of Labo

  G4double Labo::Labo_h() {
    return 292.*cm;
  }
  G4double Labo::Labo_e() {
    return 20.*cm;
  }
  G4double Labo::Labo_x() {
    return 736*cm;
  }
  G4double Labo::Labo_y() {
    return 1012*cm;
  }

  // ---- Position of Labo in relation to the Cryostat, used in Labo.hh : GetCryostatPosition_x/y/z()

  G4double Labo::Plate10mK_e() {
    return 0.4*cm;
  }
  G4double Labo::disPlate10mK_100mK() {
    return 18.1*cm;
  }
  G4double Labo::Plate100mK_e() {
    return 0.3*cm;
  }
  G4double Labo::disPlate100mK_1K() {
    return 14.6*cm;
  }
  G4double Labo::Plate1K_e() {
    return 0.4*cm;
  }
  G4double Labo::disPlate1K_4K() {
    return 15.*cm;
  }
  G4double Labo::Plate4K_e() {
    return 0.4*cm;
  }
  G4double Labo::disPlate4K_50K() {
    return 20.52*cm;
  }
  G4double Labo::Plate50K_e() {
    return 0.4*cm;
  }
  G4double Labo::disPlate50K_Bride() {
    return 24.3*cm;
  }
  G4double Labo::Bride_h() {
    return 6.6*cm;
  }
  G4double Labo::Pillar_h() {
    return 222.*cm;
  }
  G4double Labo::Frame_e() {
    return 8.*cm;
  }
  G4double Labo::PosCryostat_x() {
    return 142.*cm;
  }
  G4double Labo::PosCryostat_y() {
    return 97.*cm;
  }
  G4double Labo::Chamber_y() {
    return 200.*cm;
  }

  /* G4String Labo::GetLaboratoryName() {
     return myLabName;
     }
  */

  void Labo::Construct(G4LogicalVolume *parentVolume, G4ThreeVector position, G4RotationMatrix* rotation) {

    if(m_verbose > 0) G4cout<<"> Construct "<<m_name<<" geometry"<<G4endl;

    G4Colour Concrete(G4Colour::White());
    G4Colour::GetColour("Concrete_DMX", Concrete);
    G4VisAttributes* visAttLabo = new G4VisAttributes(Concrete);
    visAttLabo->SetForceWireframe(true);
    visAttLabo->SetVisibility(true);

    G4AssemblyVolume* myLaboVolumes = new G4AssemblyVolume();

    G4ThreeVector Tm;
    G4RotationMatrix Rm;

    // --- Define the Lab

    // --- Concrete walls

    G4double Wall_x = Labo_x()/2. + Labo_e();
    G4double Wall_y = Labo_y()/2. + Labo_e();
    G4double Wall_z = Labo_h()/2. + Labo_e();

    // --- Vacancy in the room

    G4double Vacancy_x = Labo_x()/2. ;
    G4double Vacancy_y = Labo_y()/2. ;
    G4double Vacancy_z = Labo_h()/2. ;

    // --- Substract Vacancy from Concrete

    G4Box* solidWall = new G4Box("solidWall", Wall_x, Wall_y, Wall_z);
    G4Box* solidVacancy = new G4Box("solidVacancy", Vacancy_x, Vacancy_y, Vacancy_z);
    G4VSolid* solidLabo = new G4SubtractionSolid("solidLabo", solidWall, solidVacancy);

    G4LogicalVolume* logicLabo = new G4LogicalVolume(solidLabo, G4Material::GetMaterial("Concrete_DMX"),"logicLabo");
    logicLabo->SetVisAttributes(visAttLabo);
    myLaboVolumes->AddPlacedVolume(logicLabo, Tm, &Rm);

    myLaboVolumes->MakeImprint(parentVolume,position,rotation);

    if (m_verbose > 0) G4cout<<m_name<<" Constructed."<<G4endl;

  }



  void Labo::dump() {

    G4cout << "Labo : " << Labo_h()/cm << " " << Labo_e()/cm << " " << Labo_x()/cm << G4endl;

  }

} //namespace lyongeom
