#include "Frame.hh"


#include "G4Box.hh"
#include "G4VisAttributes.hh"
#include "G4SystemOfUnits.hh"

#include "G4AssemblyVolume.hh"
namespace lyongeom {


  Frame::Frame(bool overlap) :
    m_checkOverlaps(overlap) {

    m_name = "Frame";

    Alpha = 0.*deg;
    DeltaAlpha = 360.*deg;

    m_verbose = 1;

  }

  //
  //Geometry Constants
  //

  // ---- Geometry of the upper part of the aluminium frame

  G4double Frame::Frame_e() {
    return 8*cm;
  }
  G4double Frame::Frame_short() {
    return 90*cm;
  }
  G4double Frame::Frame_long() {
    return 150*cm;
  }

  // ---- Geometry of the pillars of the aluminium frame

  G4double Frame::Pillar_h() {
    return 222*cm;
  }

  // ---- Aligne the frame with the "bride", these are used in Frame.hh : GetFrameAligneWithBride()


  G4double Frame::Plate10mK_e() {
    return 0.4*cm;
  }
  G4double Frame::disPlate10mK_100mK() {
    return 18.1*cm;
  }
  G4double Frame::Plate100mK_e() {
    return 0.3*cm;
  }
  G4double Frame::disPlate100mK_1K() {
    return 14.6*cm;
  }
  G4double Frame::Plate1K_e() {
    return 0.4*cm;
  }
  G4double Frame::disPlate1K_4K() {
    return 15.*cm;
  }
  G4double Frame::Plate4K_e() {
    return 0.4*cm;
  }
  G4double Frame::disPlate4K_50K() {
    return 20.52*cm;
  }
  G4double Frame::Plate50K_e() {
    return 0.4*cm;
  }
  G4double Frame::disPlate50K_Bride() {
    return 24.3*cm;
  }
  G4double Frame::Bride_h() {
    return 6.6*cm;
  }

  void Frame::Construct(G4LogicalVolume *parentVolume,
			G4ThreeVector position,
			G4RotationMatrix* rotation) {

    if (m_verbose > 0) {
      G4cout << "> Construct " << m_name << " geometry"
	     << G4endl;
    }

    G4Colour green(G4Colour::White());
    G4Colour::GetColour("Aluminium", green);
    G4VisAttributes* visAttLead = new G4VisAttributes(green);
    visAttLead->SetVisibility(true);

    G4AssemblyVolume* myFrameVolumes = new G4AssemblyVolume();

    G4ThreeVector Tm;
    G4RotationMatrix Rm;
    Rm.set(0.,0.,0.); Tm.set(0.,0.,0.);


    // The point of origin of the entire frame is the centre of the upper part of the frame

    // ---- Define the upper part of the frame

    // ---- Frame short 1

    G4double FrameShort1_x = Frame_e()/2.;
    G4double FrameShort1_y = Frame_short()/2.;
    G4double FrameShort1_z = Frame_e()/2.;
    Tm.set(Frame_long()/2.-Frame_e()/2.,0.,0.);

    G4Box* solidFrameShort1 = new G4Box("FrameShort1", FrameShort1_x, FrameShort1_y, FrameShort1_z);
    G4LogicalVolume* logicFrameShort1 = new G4LogicalVolume(solidFrameShort1, G4Material::GetMaterial("Lead"),"logicFrameShort1");
    logicFrameShort1->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicFrameShort1, Tm, &Rm);


    // ---- Frame short 2

    G4double FrameShort2_x = Frame_e()/2.;
    G4double FrameShort2_y = Frame_short()/2.;
    G4double FrameShort2_z = Frame_e()/2.;
    Tm.set(-Frame_long()/2.+Frame_e()/2.,0.,0.);

    G4Box* solidFrameShort2 = new G4Box("FrameShort2", FrameShort2_x, FrameShort2_y, FrameShort2_z);
    G4LogicalVolume* logicFrameShort2 = new G4LogicalVolume(solidFrameShort2, G4Material::GetMaterial("Lead"),"logicFrameShort2");
    logicFrameShort2->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicFrameShort2, Tm, &Rm);


    // ---- Frame long 1

    G4double FrameLong1_x = Frame_long()/2.;
    G4double FrameLong1_y = Frame_e()/2.;
    G4double FrameLong1_z = Frame_e()/2.;
    Tm.set(0.,Frame_short()/2.+Frame_e()/2.,0.);

    G4Box* solidFrameLong1 = new G4Box("FrameLong1", FrameLong1_x, FrameLong1_y, FrameLong1_z);
    G4LogicalVolume* logicFrameLong1 = new G4LogicalVolume(solidFrameLong1, G4Material::GetMaterial("Lead"),"logicFrameLong1");
    logicFrameLong1->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicFrameLong1, Tm, &Rm);


    // ---- Frame long 2

    G4double FrameLong2_x = Frame_long()/2.;
    G4double FrameLong2_y = Frame_e()/2.;
    G4double FrameLong2_z = Frame_e()/2.;
    Tm.set(0.,-Frame_short()/2.-Frame_e()/2.,0.);

    G4Box* solidFrameLong2 = new G4Box("FrameLong2", FrameLong2_x, FrameLong2_y, FrameLong2_z);
    G4LogicalVolume* logicFrameLong2 = new G4LogicalVolume(solidFrameLong2, G4Material::GetMaterial("Lead"),"logicFrameLong2");
    logicFrameLong2->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicFrameLong2, Tm, &Rm);


    // ---- Pillar 1

    G4double Pillar_1_x = Frame_e()/2.;
    G4double Pillar_1_y = Frame_e()/2.;
    G4double Pillar_1_z = Pillar_h()/2.;
    Tm.set(Frame_long()/2.-Frame_e()/2.,Frame_short()/2.+Frame_e()/2.,-Frame_e()/2.-Pillar_h()/2.);

    G4Box* solidPillar_1 = new G4Box("Pillar_1", Pillar_1_x, Pillar_1_y, Pillar_1_z);
    G4LogicalVolume* logicPillar_1 = new G4LogicalVolume(solidPillar_1, G4Material::GetMaterial("Lead"),"logicPillar_1");
    logicPillar_1->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicPillar_1, Tm, &Rm);


    // ---- Pillar 2

    G4double Pillar_2_x = Frame_e()/2.;
    G4double Pillar_2_y = Frame_e()/2.;
    G4double Pillar_2_z = Pillar_h()/2.;
    Tm.set(-Frame_long()/2.+Frame_e()/2.,Frame_short()/2.+Frame_e()/2.,-Frame_e()/2.-Pillar_h()/2.);

    G4Box* solidPillar_2 = new G4Box("Pillar_2", Pillar_2_x, Pillar_2_y, Pillar_2_z);
    G4LogicalVolume* logicPillar_2 = new G4LogicalVolume(solidPillar_2, G4Material::GetMaterial("Lead"),"logicPillar_2");
    logicPillar_2->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicPillar_2, Tm, &Rm);


    // ---- Pillar 3

    G4double Pillar_3_x = Frame_e()/2.;
    G4double Pillar_3_y = Frame_e()/2.;
    G4double Pillar_3_z = Pillar_h()/2.;
    Tm.set(-Frame_long()/2.+Frame_e()/2.,-Frame_short()/2.-Frame_e()/2.,-Frame_e()/2.-Pillar_h()/2.);

    G4Box* solidPillar_3 = new G4Box("Pillar_3", Pillar_3_x, Pillar_3_y, Pillar_3_z);
    G4LogicalVolume* logicPillar_3 = new G4LogicalVolume(solidPillar_3, G4Material::GetMaterial("Lead"),"logicPillar_3");
    logicPillar_3->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicPillar_3, Tm, &Rm);


    // ---- Pillar 4

    G4double Pillar_4_x = Frame_e()/2.;
    G4double Pillar_4_y = Frame_e()/2.;
    G4double Pillar_4_z = Pillar_h()/2.;
    Tm.set(Frame_long()/2.-Frame_e()/2.,-Frame_short()/2.-Frame_e()/2.,-Frame_e()/2.-Pillar_h()/2.);

    G4Box* solidPillar_4 = new G4Box("Pillar_4", Pillar_4_x, Pillar_4_y, Pillar_4_z);
    G4LogicalVolume* logicPillar_4 = new G4LogicalVolume(solidPillar_4, G4Material::GetMaterial("Lead"),"logicPillar_4");
    logicPillar_4->SetVisAttributes(visAttLead);
    myFrameVolumes->AddPlacedVolume(logicPillar_4, Tm, &Rm);


    myFrameVolumes->MakeImprint(parentVolume,position,rotation);



    if (m_verbose > 0) {
      G4cout << m_name << " Constructed." << G4endl;
    }


  }



  void Frame::dump() {

    G4cout << m_name << " parameter values " << G4endl;

  }

} // namespace lyongeom
