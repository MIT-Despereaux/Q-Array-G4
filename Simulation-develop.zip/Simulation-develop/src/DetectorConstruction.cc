#include "DetectorConstruction.hh"

#include <stdexcept>
#include "G4Element.hh"
#include "G4Box.hh"
#include "G4PhysicalVolumeStore.hh"
#include "Geometry/MaterialsBuilder.hh"
#include "Geometry/WorldMaker.hh"
#include "Geometry/ObjectSerialiser.hh"
#include "SimuOutput/InfoHeaderWriter.hh"
#include "SimuOutput/VolumeHasher.hh"
#include "Utility/Algorithm.hh"
#include "LyonDetectorMessenger.hh"

namespace Geometry{


DetectorConstruction::DetectorConstruction(double worldLength, int verbosity_):
    worldPack(Geometry::MakeWorld(worldLength)),
    messengers(
        /*ActiveOuterShieldingBuilder*/ LogicalWorld(),
        /*ActiveOuterShieldingBuilderWithDT*/ LogicalWorld(),
        /*ActiveChoozBuilder*/ LogicalWorld(),
        /*ActiveColdInnerShieldingBuilder*/ LogicalWorld(),
        /*ActiveCryoConceptBuilder*/ LogicalWorld(),
        /*ActiveCylindricalShieldingBuilder*/ LogicalWorld(),
        /*ActiveGenericCryostatBuilder*/ LogicalWorld(),
        /*ActiveRingInnerShieldingBuilder*/ LogicalWorld(),
        /*ActiveVolumeBuilder*/ LogicalWorld(),
        /*SensitiveCryoCubeBuilder*/ LogicalWorld(),
        /*SensitiveMiniCryoCubeBuilder*/ LogicalWorld(),
	/*SensitiveMuonVetoBuilder*/ LogicalWorld(),
        /*SensitiveDubnaSpectrometerBuilder*/ LogicalWorld(),
        /*SensitiveGermaniumBolometerBuilder*/ LogicalWorld(),
        /*SensitiveSimpleGermaniumBolometerBuilder*/ LogicalWorld(),
        /*SensitiveRicochetBasicBuilder*/ LogicalWorld(),
        /*SensitiveVolumeBuilder*/ LogicalWorld()
               ),
    verbosity(verbosity_)
{

    MaterialsBuilder{}.DefineAllMaterials();
    theLyonDetectorMessenger = std::make_unique<lyongeom::LyonDetectorMessenger>(this);
    fLyonLab = std::make_unique<lyongeom::Labo>(true);
    fCryostat = std::make_unique<Geometry::Cryostat>(true);
    fLeadShieldEX = std::make_unique<lyongeom::LeadShieldEX>(true);
    fFrame = std::make_unique<lyongeom::Frame>(true);
    fLeadBlock = std::make_unique<lyongeom::LeadBlock>(true);

    SetVerbosity(verbosity);

}

// Automatically called by G4RunManager
G4VPhysicalVolume* DetectorConstruction::Construct()  {
    

    return PhysicalWorldPtr();

}

void DetectorConstruction::SetVerbosity(int verbosity_) {
   
    verbosity = verbosity_;

    fLyonLab->SetVerbose(verbosity);
    fCryostat->SetVerbose(verbosity);
    fFrame->SetVerbose(verbosity);
    fLeadShieldEX->SetVerbose(verbosity);
    fLeadBlock->SetVerbose(verbosity);

    GetMessenger<SensitiveCryoCubeBuilder>().SetBuilderVerbosity(verbosity);
}


void DetectorConstruction::SetAlpha(G4double alpha){
    
    fCryostat->SetAlpha(alpha);
    fLeadShieldEX->SetAlpha(alpha);
    fFrame->SetAlpha(alpha);
    fLeadBlock->SetAlpha(alpha);

}
void DetectorConstruction::SetDeltaAlpha(G4double alpha){
    
    fLyonLab->SetDeltaAlpha(alpha);
    fCryostat->SetDeltaAlpha(alpha);
    fLeadShieldEX->SetDeltaAlpha(alpha);
    fFrame->SetDeltaAlpha(alpha);
    fLeadBlock->SetDeltaAlpha(alpha);
}

void DetectorConstruction::BuildLabo() {
   

    G4ThreeVector translation(fLyonLab->GetCryostatPosition_x(),fLyonLab->GetCryostatPosition_y(),fLyonLab->GetCryostatPosition_z());
    fLyonLab->Construct(LogicalWorldPtr(),translation, nullptr);

}
void DetectorConstruction::BuildCryostat() {
   

    fCryostat->Construct(LogicalWorldPtr(), {}, nullptr);

}

void DetectorConstruction::BuildFrame() {
   
    G4ThreeVector translation(0.,0.,fFrame->GetFrameAligneWithBride());
    fFrame->Construct(LogicalWorldPtr(),translation, nullptr);

}
void DetectorConstruction::BuildLeadShieldEX() {
   

    G4ThreeVector translation(0.,0.,fLeadShieldEX->GetLeadShieldUnderOVC());
    fLeadShieldEX->Construct(LogicalWorldPtr(),translation, nullptr);

}

void DetectorConstruction::AddLeadBlock() {
    

    fLeadBlock->PlaceLeadBlock(LogicalWorldPtr());

}

SimuOutput::VolumeNames DetectorConstruction::GetVolumeNames()
{
    auto volumes = G4PhysicalVolumeStore::GetInstance();
    if(volumes)
    {
        SimuOutput::VolumeNames volumeNames;
        std::transform(std::cbegin(*volumes), std::cend(*volumes), std::inserter(volumeNames, std::end(volumeNames)),
            [&volumeNames](auto volumePtr)
            {
                auto name = volumePtr->GetName();
                SimuOutput::VolumeID detectorID = SimuOutput::VolumeHasher::Hash(name);
                auto itExisting = volumeNames.find(detectorID);
                if(itExisting == std::cend(volumeNames))
                    return std::make_pair(detectorID, name);
                else
                {
                    auto existingName = itExisting->second;
                    auto message = "Hash collision for volume '"+name+"': ID "+std::to_string(detectorID)+" already assigned to "+existingName;
                    throw std::logic_error(message);
                }
            }
        );
        return volumeNames;
    }
    else throw std::runtime_error("DetectorConstruction::GetVolumeNames: failed retrieving G4PhysicalVolumeStore");
}

void DetectorConstruction::WriteVolumeNames(TDirectory& output, const char* treeName)
{
    auto volumeNames = GetVolumeNames();
    InfoHeaderWriter writer(treeName, treeName);
    writer.SetKeyValue("VolumeNames", volumeNames);
    writer.WriteIn(output);
}

void DetectorConstruction::SerialiseActivatedBuilders(ObjectSerialiser& objectSerialiser) const{

    Utility::ForEach(messengers, [&objectSerialiser](const auto& messenger){
            auto builder = messenger.GetBuilder();
            if(builder.IsActive()) objectSerialiser.Serialise(builder);
    });

}

} //namespace Geometry
