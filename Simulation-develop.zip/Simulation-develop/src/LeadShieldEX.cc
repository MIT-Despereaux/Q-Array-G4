#include "LeadShieldEX.hh"

#include "G4Box.hh"
#include "G4VisAttributes.hh"
#include "G4SystemOfUnits.hh"

#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4PVPlacement.hh"
#include "G4AssemblyVolume.hh"

namespace lyongeom {

  LeadShieldEX::LeadShieldEX(bool overlap): 

    m_checkOverlaps(overlap) {

    m_name = "LeadShieldEX";
   
    Alpha = 0.*deg;
    DeltaAlpha = 360.*deg;
  
    m_verbose = 1;

  }


  LeadShieldEX::~LeadShieldEX() {
  }


  //
  //Geometry Constants
  //

  // --- Geometry of the external Lead Shield
  
  G4double LeadShieldEX::Lead_h() {
    return 100.*cm; // without the bottom layer
  }
  G4double LeadShieldEX::Lead_e() {
    return 10.*cm;
  }
  G4double LeadShieldEX::LeadBottom_e() {
    return 6.*cm;
  }
  G4double LeadShieldEX::Lead_radius() {
    return 31.48*cm;
  }    
    
  // --- Position of the external Lead Shield in relation to OVC, these are used in LeadShieldEX.hh : GetLeadShieldUnderOVC()
  
  G4double LeadShieldEX::Plate10mK_e() {
    return 0.4*cm;
  }
  G4double LeadShieldEX::disPlate10mK_BottomCu1K() {
    return 20.*cm;
  }
  G4double LeadShieldEX::Cu1K_e() {
    return 0.1*cm;
  }
  G4double LeadShieldEX::disOuterBottomCu1K_InnerBottomCu4K() {
    return 1.95*cm;
  }
  G4double LeadShieldEX::Cu4K_e() {
    return 0.2*cm;
  }
  G4double LeadShieldEX::disOuterBottomCu4K_InnerBottomCu50K() {
    return 1.98*cm;
  }
  G4double LeadShieldEX::Cu50K_e() {
    return 0.2*cm;
  }
  G4double LeadShieldEX::disOuterBottomCu50K_InnerBottomOVCInox() {
    return 9.*cm;
  }
  G4double LeadShieldEX::OVCInox_e() {
    return 0.2*cm;  
  }
  G4double LeadShieldEX::disLeadBottomOVC() {
    return 3.*cm;
  }



  void LeadShieldEX::Construct(G4LogicalVolume *parentVolume,
			       G4ThreeVector position,
			       G4RotationMatrix* rotation) {
				 
    if (m_verbose > 0) {
      G4cout << "> Construct " << m_name << " geometry"
	     << G4endl;
    }
   
    G4Colour grey(G4Colour::White());
    G4Colour::GetColour("Lead", grey);
    G4VisAttributes* visAttLead = new G4VisAttributes(grey);
    visAttLead->SetVisibility(true);

    G4AssemblyVolume* myLeadShieldEXVolumes = new G4AssemblyVolume();

    G4ThreeVector Tm;
    G4RotationMatrix Rm;
    Rm.set(0.,0.,0.); Tm.set(0.,0.,0.);
  
    // external Lead Shield - the centre of internal cylinder is the point of origin.
  
    G4double Lead_z[4] = {-Lead_h()/2.-LeadBottom_e() , -Lead_h()/2. ,-Lead_h()/2. , Lead_h()/2.};
    G4double Lead_ri[4] = {0.*cm , 0.*cm , Lead_radius(), Lead_radius() };
    G4double Lead_ro[4] = {Lead_radius() + Lead_e() , Lead_radius() + Lead_e(), Lead_radius() + Lead_e(), Lead_radius() + Lead_e()};

    G4Polycone* solidLead = new G4Polycone("solidLead", Alpha, DeltaAlpha, 4,Lead_z, Lead_ri, Lead_ro);
    G4LogicalVolume* logicLead = new G4LogicalVolume(solidLead, G4Material::GetMaterial("Lead"),"logicLead");
    logicLead->SetVisAttributes(visAttLead);
    myLeadShieldEXVolumes->AddPlacedVolume(logicLead, Tm, &Rm);
  
    myLeadShieldEXVolumes->MakeImprint(parentVolume,position,rotation);
  	  
    if (m_verbose > 0) {
      G4cout << m_name << " Constructed." << G4endl;
    }


  }


  void LeadShieldEX::dump() {

    G4cout << "Lead : " << Lead_h()/cm << " " << Lead_e()/cm << " " << LeadBottom_e()/cm << " "<< Lead_radius()/cm << G4endl;
  
  }

} //namespace lyongeom
