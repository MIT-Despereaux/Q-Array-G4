#include "ActionInitialization.hh"
#include "G4Helpers/OwningMessenger.hh"
#include "Generator/Primary.hh"
#include "RunActionMessenger.hh"
#include "Event/ActionMessenger.hh"
#include "Event/SteppingAction.hh"


ActionInitialization::ActionInitialization(ProgramOptions::Options options_)
  : G4VUserActionInitialization(),
    options(std::move(options_))
{}

void ActionInitialization::Build() const
{
  auto primaryGeneratorAction = new G4Helpers::OwningMessenger<Generator::Primary, Generator::PrimaryMessenger>();
  auto eventAction = new G4Helpers::OwningMessenger<Event::Action, Event::ActionMessenger>("All", options.verbosity);
  auto steppingAction = new Event::SteppingAction();
  auto runAction = new G4Helpers::OwningMessenger<RunAction, RunActionMessenger>(
          *primaryGeneratorAction, *eventAction, *steppingAction, options.outputFileName, options.verbosity);
  SetUserAction(primaryGeneratorAction);
  SetUserAction(runAction);
  SetUserAction(eventAction);
  SetUserAction(steppingAction);
}
