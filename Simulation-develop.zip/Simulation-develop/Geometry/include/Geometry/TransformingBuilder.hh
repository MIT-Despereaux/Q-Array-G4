/**************************************************************************
* @file TransformingBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Nov 2020
* @brief Use TransformingBuilder<MyBuilder> to add a Build method with 2
* vector and rotation args from a working MyBuilder::Build(Transform3D)
* method with a single arg
* ************************************************************************/

#ifndef GEOMETRY_TRANSFORMINGBUILDER_HH
#define GEOMETRY_TRANSFORMINGBUILDER_HH

#include "CLHEP/Vector/ThreeVector.h"
#include <CLHEP/Geometry/Transform3D.h>

namespace Geometry
{

    template <class Builder>
    struct TransformingBuilder : Builder
    {
        using Builder::Builder;
        using Builder::Build; //prevent shadowing of inherited Build by second Build
        auto Build(const CLHEP::Hep3Vector& offsetToMother, const CLHEP::HepRotation& rotationToMother = {})
        {
            return Builder::Build(HepGeom::Transform3D{rotationToMother, offsetToMother});
        }
    };

}

#endif /* GEOMETRY_TRANSFORMINGBUILDER_HH */
