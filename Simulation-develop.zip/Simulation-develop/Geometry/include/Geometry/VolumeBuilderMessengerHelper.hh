/**************************************************************************
* @file VolumeBuilderMessengerHelper.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Sep 2020
* @brief Select Solid for VolumeBuilder::Add<Solid> call based on runtime
* input, and unpack parsed arguments the call
* ************************************************************************/

#ifndef GEOMETRY_VOLUME_BUILDER_MESSENGER_HELPER_HH
#define GEOMETRY_VOLUME_BUILDER_MESSENGER_HELPER_HH

#include "Geometry/VolumeBuilder.hh"
#include "Geometry/VolumeParser.hh"

namespace Geometry
{

    namespace VolumeBuilderMessengerHelper
    {
        template <class Solid, std::size_t... Is>
        void RunAddCommand(VolumeBuilder& volumeBuilder, std::istream& input, std::index_sequence<Is...>);
        template <class Solid>
        void RunAddCommand(VolumeBuilder& volumeBuilder, std::istream& input);
        void RunAddCommand(const std::string& type, VolumeBuilder& volumeBuilder, std::istream& input);

        // Implementations

        template <class Solid, std::size_t... Is>
        void RunAddCommand(VolumeBuilder& volumeBuilder, std::istream& input, std::index_sequence<Is...>)
        {
            auto args = VolumeParser::ParseArgs<Solid>(input);
            volumeBuilder.Add<Solid>(std::get<Is>(args)...);
        }

        template <class Solid>
        void RunAddCommand(VolumeBuilder& volumeBuilder, std::istream& input)
        {
            using Tuple = decltype(VolumeParser::ParseArgs<Solid>(input));
            RunAddCommand<Solid>(volumeBuilder, input, std::make_index_sequence<std::tuple_size<Tuple>{}>{});
        }

    }

}

#endif /* GEOMETRY_VOLUME_BUILDER_MESSENGER_HELPER_HH */
