/*
 * SimpleGermaniumBolometerBuilder.hh
 *
 *  Created on: 18.02.2021
 *  geometry of the germanium bolometer + simple casing.
 *      Author: cazes
 */
#ifndef GEOMETRY_SIMPLEGERMANIUMBOLOMETERBUILDER_HH
#define GEOMETRY_SIMPLEGERMANIUMBOLOMETERBUILDER_HH

#include "Geometry/GenericBolometerBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"
#include "Geometry/TransformingBuilder.hh"


namespace Geometry{

  struct SensitiveSimpleGermaniumBolometerBuilder;

  class SimpleGermaniumBolometerBuilder : public GenericBolometerBuilder {

  public:

    SimpleGermaniumBolometerBuilder(G4LogicalVolume& mother_) : GenericBolometerBuilder(mother_,"SimpleGermaniumBolometerBuilder"), bolometerAssembly(nullptr) {}

    std::vector<G4LogicalVolume*> Build(HepGeom::Transform3D transformation);

    double GetCrystalMass();
    double GetCrystalVolume();
    double GetBolometerFullHight();

    double CrystalRadius() const;
    double CrystalHeight() const;
    double SupportThickness() const;
    double SupportTopThickness() const;
    double SupportOutRadius() const;
    double SupportSpace() const;
    double SupportHeight() const;
    double GetCrystalVolume() const;
    double GetCrystalMass() const;

  private:

    G4AssemblyVolume* bolometerAssembly;

  };


  DEFINE_ACTIVE_BUILDER_FROM(ActiveSimpleGermaniumBolometerBuilder, TransformingBuilder<SimpleGermaniumBolometerBuilder>)
  DEFINE_SENSITIVE_BUILDER_FROM(SensitiveSimpleGermaniumBolometerBuilder, ActiveSimpleGermaniumBolometerBuilder)



} //namespace Geometry

#endif
