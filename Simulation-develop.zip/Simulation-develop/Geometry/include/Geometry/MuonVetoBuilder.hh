#ifndef GEOMETRY_MUONVETOBUILDER_HH
#define GEOMETRY_MUONVETOBUILDER_HH

#include <vector>
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"
#include "Geometry/VolumePack.hh"
#include "Geometry/VolumeAdder.hh"

/****************************************************
 *                                                  *
 * MuonVetoBuilder.hh                               *
 * Author : Guillaume Chemin                        *
 *                                                  *
 * Implements final design of the muon veto         *
 *                                                  *
 * Cryo muon veto geometry is simplified from final *
 * design                                           *
 *                                                  *
 ****************************************************/

class G4LogicalVolume;
class TDirectory;

namespace Geometry
{

    class MuonVetoBuilder
    {
    	public:
        	MuonVetoBuilder(G4LogicalVolume& mother);
			void SetVerbosity(int level);
			void BuildCryoMuonVeto(bool BuildCryoMuonVeto);
			VolumePack PlaceLongPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation);
			VolumePack PlaceShortPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation);
			VolumePack PlaceLongCutPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation);
			VolumePack PlaceShortCutPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation);
			std::vector<G4LogicalVolume*> PlaceCryoMuonVeto(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation);
        	std::vector<G4LogicalVolume*> Build(const HepGeom::Transform3D& transformationToMother);
			
			// muon veto panels dimensions
			double LongVetoLength{200*CLHEP::cm};
			double ShortVetoLength{157.5*CLHEP::cm};
			double LongCutVetoLength{107.5*CLHEP::cm};
			double ShortCutVetoLength{87.5*CLHEP::cm};
			double VetoWidth{50*CLHEP::cm};
			double VetoThickness{3*CLHEP::cm};
			double RoundedCutRadius{23*CLHEP::cm};
			double EmptySpaceWidth{16.6*CLHEP::cm};
			double AluminiumThickness{2*CLHEP::mm};

			// cryo muon veto dimensions
			double CryoVetoRadius{16.5*CLHEP::cm};
			double CopperThickness{1.6*CLHEP::mm};
			double CopperRodsLength{8.94*CLHEP::cm};
			double CopperRodsRadius{1*CLHEP::cm};
			double LargeRectangleLength{23.8*CLHEP::cm};
			double LargeRectangleWidth{7.3*CLHEP::cm};
			double MediumRectangleLength{10.1*CLHEP::cm};
			double MediumRectangleWidth{4.5*CLHEP::cm};
			double SmallRectangleLength{4*CLHEP::cm};
			double SmallRectangleWidth{1.96*CLHEP::cm};
			double TriangleHeight{9.74*CLHEP::cm};
			double RodRadius{1*CLHEP::cm};
			double RodHeight{8.94*CLHEP::cm};
			double RodXOffset_0{-3*CLHEP::cm}; 
			double RodXOffset_1{-15*CLHEP::cm};
			double RodXOffset_2{6*CLHEP::cm};
			double RodYOffset_1{6*CLHEP::cm};
			double RodYOffset_2{15*CLHEP::cm};

			double CryoVetoOffset{19.5*CLHEP::cm}; // cryo muon veto offset compared to top panels level ; set offset to be at 4K stage
			
			double HeightToGround{8*CLHEP::cm}; // bottom height of side panels relative to ground level
			// Adding an extra distance to the radius to fix volume overlaps of side panels
			double overlapFixPolygonal{15*CLHEP::mm};
			int NumberOfSidePanels{11};
		
			void Write(TDirectory& directory) const;
	
    	private:
    		G4LogicalVolume& mother;
    		int mVerbosity{0};
			bool mBuildCryoMuonVeto{false};
    };
    DEFINE_ACTIVE_BUILDER_FROM(ActiveMuonVetoBuilder, TransformingBuilder<MuonVetoBuilder>)
    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveMuonVetoBuilder, ActiveMuonVetoBuilder)

}

#endif /* GEOMETRY_MUONVETOBUILDER_HH */
