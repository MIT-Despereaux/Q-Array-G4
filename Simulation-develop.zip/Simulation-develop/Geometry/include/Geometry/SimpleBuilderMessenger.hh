/**************************************************************************
* @file SimpleBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 13 May 2019
* @brief Messenger for Builder implementing the usual Build command with
* macro key value given by BuildCommandString<Builder>.
* ************************************************************************/

#ifndef SIMPLE_BUILDER_MESSENGER_HH
#define SIMPLE_BUILDER_MESSENGER_HH

#include "G4Helpers/InitialisableMessenger.hh"
#include "Geometry/BuilderAwareGenericMessenger.hh"
#include "Geometry/BuildCommandCreator.hh"
#include "Geometry/BuildCommandString.hh"

namespace Geometry
{

    template <class Builder>
    using SimpeBuildCommandCreator = BuildCommandCreator<BuildCommandString<Builder>>;

    template <class Builder>
    using SimpleBuilderMessenger =
    G4Helpers::InitialisableMessenger<BuilderAwareGenericMessenger<Builder>, SimpeBuildCommandCreator<Builder>>;

} //namespace Geometry

#endif /* SIMPLE_BUILDER_MESSENGER_HH */
