#ifndef RICOCHETBASICMESSENGER_H
#define RICOCHETBASICMESSENGER_H

/// Standard includes
#include <memory>
#include <string>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"

/// Project includes
#include "Geometry/GenericCryostatMessenger.hh"
#include "Geometry/ColdInnerShieldingMessenger.hh"
#include "Geometry/RingInnerShieldingMessenger.hh"
#include "Geometry/OuterShieldingMessenger.hh"
#include "Geometry/OuterShieldingMessengerWithDT.hh"
#include "Geometry/MuonVetoMessenger.hh"
#include "Geometry/MiniCryoCubeMessenger.hh"

namespace Geometry
{
    struct SensitiveRicochetBasicBuilder;

    class RicochetBasicMessenger: public G4UImessenger
    {
        public:
            using BuilderType = SensitiveRicochetBasicBuilder;
            RicochetBasicMessenger(BuilderType& builder, std::string cmdPrefixPath = "/geometry/Ricochet/Basic/");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            BuilderType& mBuilder;

            GenericCryostatMessenger mCryostatMessenger;
            ColdInnerShieldingMessenger mInnerShieldingMessenger;
            RingInnerShieldingMessenger mRingInnerShieldingMessenger;
            OuterShieldingMessenger mOuterShieldingMessenger;
            OuterShieldingMessengerWithDT mOuterShieldingMessengerWithDT;
            MuonVetoMessenger mMuonVetoMessenger;
            MiniCryoCubeMessenger mMiniCryoCubeMessenger;
	    
            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWith3VectorAndUnit> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;

            std::unique_ptr<G4UIcmdWithAString> mCmdConfig;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildCryostat;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildInnerShielding;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildMylar;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildRingInnerShielding;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildOuterShielding;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildOuterShieldingWithDT;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildCryoCube;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildMiniCryoCube;
            std::unique_ptr<G4UIcmdWithAString> mCmdConfigMiniCryoCube;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildMuonVeto;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInnerShieldingVerticalSpacing;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdCryoCubeTopSpacing;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdCryoCubeBottomSpacing;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdOuterShieldingInnerSpacing;
            std::unique_ptr<G4UIcmdWithABool> mCmdOverwriteInternalShieldingRadius;

            static std::string AppendPath(const std::string& path1, const std::string& path2);
    };
}

#endif /// RICOCHETBASICMESSENGER_H
