/**************************************************************************
* @file WorldMaker.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 14 May 2019
* @brief Simply create cubic invisible world of variable size
* ************************************************************************/

#ifndef WORLDMAKER_HH
#define WORLDMAKER_HH

#include "Geometry/VolumePack.hh"

namespace Geometry{

    VolumePack MakeWorld(double worldLength);

}

#endif /* WORLDMAKER_HH */
