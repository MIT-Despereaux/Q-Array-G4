#ifndef RINGINNERSHIELDING_HH
#define RINGINNERSHIELDING_HH

// Standard includes
#include <vector>

/// Geant4 includes
#include "G4ThreeVector.hh"
#include "CLHEP/Units/SystemOfUnits.h"
#include <CLHEP/Geometry/Transform3D.h>

/// Project includes
#include "Geometry/ActiveBuilder.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class TDirectory;

namespace Geometry
{
    class RingInnerShieldingBuilder
    {
        public:

            RingInnerShieldingBuilder(G4LogicalVolume& mother_);

            void SetVerbosity(int level);

            void SetThickness(double thickness);
            void SetSpacing(double spacing);
            void SetPolyContractionFactor(double factor);
            void SetBuildMylar(bool activate);
            void AddRing(double minRadius, double maxRadius, std::string material = "PolBor3pc", double zShift = 0, double length = -1);
            void SetTopRingAsOrigin(bool topRingOrigin = true);

            void Build(const CLHEP::Hep3Vector& position);
            void Build(const HepGeom::Transform3D& transformation);
            void Write(TDirectory& directory) const;
            void BuildMylar(const std::string& mylarMaterial, double mylarThickness);


        private:
            void SetVisualAttributes(G4LogicalVolume& volume) const;
            G4LogicalVolume& mMother;

            int mVerbosity{0};

            HepGeom::Transform3D mTransformation; /// Origin = Position of the center
            double mThickness{40*CLHEP::cm};
            double mSpacing{0};
            double mPolyContractionFactor{0};
            std::vector<double> mRingRadiusMin;
            std::vector<double> mRingRadiusMax;
            std::vector<std::string> mRingMaterial;
            std::vector<double> mRingZshift;
            std::vector<double> mRingLength;
            bool mTopRingOrigin{false};
            bool mBuildMylar{false};
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveRingInnerShieldingBuilder, RingInnerShieldingBuilder)
}

#endif /* RINGINNERSHIELDING_HH */
