/**************************************************************************
* @file BuilderAwareGenericMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Nov 2020
* @brief Helper alias to have a GenericMessenger-like class yet also
* defining the member alias BuilderType, so that the messenger is aware
* and able to communicate the type of Builder it manages
* ************************************************************************/

#ifndef GEOMETRY_BUILDER_AWARE_GENERIC_MESSENGER_HH
#define GEOMETRY_BUILDER_AWARE_GENERIC_MESSENGER_HH

#include "Geometry/BuilderAwareMessenger.hh"
#include "G4Helpers/GenericMessenger.hh"

namespace Geometry{

    template <class Builder>
    using BuilderAwareGenericMessenger = BuilderAwareMessenger<G4Helpers::GenericMessenger<Builder>, Builder>;

}

#endif /* GEOMETRY_BUILDER_AWARE_GENERIC_MESSENGER_HH */
