/**************************************************************************
* @file DubnaSpectrometerBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 29 Jan 2020
* @brief
* ************************************************************************/

#ifndef GEOMETRY_DUBNASPECTROMETERBUILDER_HH
#define GEOMETRY_DUBNASPECTROMETERBUILDER_HH

#include <vector>
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"

class G4LogicalVolume;

namespace Geometry
{

    class DubnaSpectrometerBuilder
    {
        G4LogicalVolume& mother;
    public:
        DubnaSpectrometerBuilder(G4LogicalVolume& mother_);
        std::vector<G4LogicalVolume*> Build(const HepGeom::Transform3D& transformationToMother);
        static constexpr double CavityDiameter();
        static constexpr double CavityLength();
        static constexpr double TubeDiameter();
        static constexpr double TubeLength();
        static constexpr double CavityRadius();
        static constexpr double TubeRadius();
        static constexpr const char* CavityMaterialName();
        double CavityVolume() const;
        G4Material* CavityMaterial() const;
        double CavityDensity() const;
        double CavityMass() const;
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveDubnaSpectrometerBuilder, TransformingBuilder<DubnaSpectrometerBuilder>)
    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveDubnaSpectrometerBuilder, ActiveDubnaSpectrometerBuilder)

}

#endif /* GEOMETRY_DUBNASPECTROMETERBUILDER_HH */
