#ifndef COLDINNERSHIELDING_HH
#define COLDINNERSHIELDING_HH

/// Geant4 includes
#include "G4ThreeVector.hh"
#include "CLHEP/Units/SystemOfUnits.h"

/// Project includes
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/GeometryConfiguration.hh"
#include "G4UIcmdWithADouble.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class TDirectory;

namespace Geometry
{

    class ColdInnerShieldingBuilder
    {
        public:

            ColdInnerShieldingBuilder(G4LogicalVolume& mother_);

            void SetVerbosity(int level);
            void SetConfig(GeometryConfiguration config);
            //copied from RicochetBasicBuilder.hh from minicryocube
            void SetColdInnerShieldingConfig(double config);

            void SetRadius(double radius);
            void SetLeadRadius(double radius);
            void SetLeadThickness(double leadThickness);
            void SetPolyRadius(double radius);
            void SetPolyethyleneThickness(double polyThickness);
            void SetLeadMaterial(std::string material);
            void SetPolyethyleneMaterial(std::string material);
            void SetUseCryoConceptInternalLead(bool activate);
            void SetPolyethyleneWithHoles(bool activate);
            void BuildRealisticPolyShield(bool build);
            void SetParamRealisticPolyShield(unsigned int nbPolyLayers, double copperThickness);
            void SetHoleRadialPosition(double holeRadialPosition);

            double Radius() const;
            double LeadThickness() const;
            double PolyethyleneThickness() const;
            double HoleRadialPosition() const;
            double HoleAngularSpacing() const;
            double TotalHeight() const;
            double InnerShieldingConfig() const;
            int Verbosity() const;
            G4ThreeVector PolyPosition() const; /// Position of the poly layer center

            void Build(const G4ThreeVector& position);
            void Write(TDirectory& directory) const;
           



        private:
            void SetVisualAttributes(G4LogicalVolume& volume) const;
            G4LogicalVolume& mMother;

            int mVerbosity{0};
            GeometryConfiguration mConfig{GeometryConfiguration::RicochetFinalDesign()};
            // GeometryConfiguration mConfig{GeometryConfiguration::RicochetRUN014()};//added

            G4ThreeVector mPosition; /// Top center position
            bool mUseCryoConceptInternalLead{true};
            bool mUseRealisticPolyethylene{false};
            unsigned int mRealisticPoly_NbPolyLayers{0};
            double mRealisticPoly_CopperThickness{10 * CLHEP::mm}; //default value set from RicochetFinalDesign values 
            bool mPolyWithHoles{true};
            //added to make varible for the cnfiguration to be saved to 
            double mLeadRadius{15*CLHEP::cm};
            double mLeadThickness{5*CLHEP::cm};
            double mPolyRadius{15*CLHEP::cm};
            double mPolyThickness{10*CLHEP::cm};
            std::string mLeadMaterial{"Lead"};
            std::string mPolyMaterial{"PolBor3pc"};
            double mHoleRadialPosition{13*CLHEP::cm};
            double mHoleAngularSpacing{6*CLHEP::deg};
            double mInnerShieldingConfig{};
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveColdInnerShieldingBuilder, ColdInnerShieldingBuilder)
}

#endif /* COLDINNERSHIELDING_HH */
