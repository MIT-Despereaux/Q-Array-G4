#ifndef OuterShieldingBuilderWithDT_HH
#define OuterShieldingBuilderWithDT_HH

/// Geant4 includes
#include "G4ThreeVector.hh"
#include "CLHEP/Units/SystemOfUnits.h"

/// Project includes
#include "Geometry/ActiveBuilder.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class TDirectory;

namespace Geometry
{
    class OuterShieldingBuilderWithDT
    {
        public:

            OuterShieldingBuilderWithDT(G4LogicalVolume& mother_);

            void SetVerbosity(int level);

            void SetInnerRadius(double innerRadius);
            void SetInnerHeight(double innerHeight);
            void SetLeadThickness(double leadThickness);
            void SetIronAsCylinder(bool setcylinder = true);
            void SetIronThickness(double ironThickness);
            void SetFluentalThicknessExtra(double fluentalThicknessExtra);
            void SetPolyethyleneThickness(double polyThickness);
            void SetExtraPolyethyleneLayer(bool activate = true);
            void SetExtraPolyethyleneThickness(double polyThickness);

            void Build(const G4ThreeVector& position);
            void Write(TDirectory& directory) const;

            double OuterRadius() const;
            double TotalThickness() const;

        private:
            G4LogicalVolume& mMother;

            int mVerbosity{1};

            G4ThreeVector mPosition; /// Bottom inner center position
            double mInnerRadius{50*CLHEP::cm};//25
            double mInnerHeight{100*CLHEP::cm};
            double mLeadThickness{20*CLHEP::cm};
            double mPolyThickness{40*CLHEP::cm};
            bool mIronAsCylinder{false};
            double mIronThickness{40*CLHEP::cm};
            double mFluentalThicknessExtra{10*CLHEP::cm};
            bool mExtraPolyLayer{false}; /// activation of external layer of polyethylene
            double mExtraPolyThickness{40*CLHEP::cm};

//            G4ThreeVector mTopShielding_Position; /// Bottom center position
//            double mTopShielding_Radius;
//            double mTopShielding_Thickness_Lead;
//            double mTopShielding_Thickness_PolyB;
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveOuterShieldingBuilderWithDT, OuterShieldingBuilderWithDT)
}

#endif /* OuterShieldingBuilderWithDT_HH */
