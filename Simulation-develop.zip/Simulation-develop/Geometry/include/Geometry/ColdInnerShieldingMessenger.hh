#ifndef COLDINNERSHIELDINGMESSENGER_H
#define COLDINNERSHIELDINGMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"

namespace Geometry
{
    struct ActiveColdInnerShieldingBuilder;

    class ColdInnerShieldingMessenger: public G4UImessenger
    {
        public:
            using BuilderType = ActiveColdInnerShieldingBuilder;
            ColdInnerShieldingMessenger(BuilderType& builder, std::string cmdPrefixPath = "/geometry/shielding/ColdInnerShielding/");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

            std::unique_ptr<G4UIcmdWithADouble> mCmdColdInnerShieldingConfig;

        private:
            BuilderType& mBuilder;

            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWith3VectorAndUnit> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;

            //taking from RicochetBasicMessenger.hh to add a configuration option in the messenger
            

            std::unique_ptr<G4UIcmdWithABool> mCmdUseCryoConceptInternalLead;
            std::unique_ptr<G4UIcmdWithABool> mCmdPolyethyleneWithHoles;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdRadius;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdLeadRadius;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdLeadThickness;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdPolyRadius;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdPolyethyleneThickness;
            std::unique_ptr<G4UIcommand> mCmdBuildRealisticPolyShielding;
            std::unique_ptr<G4UIcmdWithAString> mCmdLeadMaterial;
            std::unique_ptr<G4UIcmdWithAString> mCmdPolyMaterial;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdHoleRadialPosition;
    };
}


#endif /// COLDINNERSHIELDINGMESSENGER_H
