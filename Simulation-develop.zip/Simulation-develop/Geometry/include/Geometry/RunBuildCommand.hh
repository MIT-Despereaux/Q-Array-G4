/**************************************************************************
* @file RunBuildCommand.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Nov 2020
* @brief Parses command arg and runs Builder::Build with legacy centre or
* generic transformation
* ************************************************************************/

#ifndef GEOMETRY_RUNBUILDCOMMAND_HH
#define GEOMETRY_RUNBUILDCOMMAND_HH

#include "Utility/String.hh"
#include "G4Helpers/TransformationParser.hh"

namespace Geometry
{

    struct RunBuildCommand
    {
        template <class Builder>
        void operator()(Builder& builder, const std::string& macroArgument);
    };

    template <class Builder>
    void RunBuildCommand::operator()(Builder& builder, const std::string& macroArgument)
    {
        if(Utility::StartsWith(macroArgument, "("))
        {
            auto transformation = G4Helpers::TransformationParser::Parse(macroArgument);
            builder.Build(transformation);
        }
        else
        {
            auto centre = G4UIcommand::ConvertToDimensioned3Vector(macroArgument.c_str());
            builder.Build(centre);
        }
    }

}

#endif /* GEOMETRY_RUNBUILDCOMMAND_HH */
