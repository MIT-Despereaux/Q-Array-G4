/**************************************************************************
* @file HasSensitiveCommand.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 29 Jan 2020
* @brief Defines alias HasSensitiveCommand<Builder> which has a constexpr
* static member equal to 'true' (SensitiveCommandString<Builder> has been
* defined) or 'false' (SensitiveCommandString<Builder> is an incomplete
* declaration found in the SensitiveCommandString.hh header)
* ************************************************************************/

#ifndef GEOMETRY_HASSENSITIVECOMMAND_HH
#define GEOMETRY_HASSENSITIVECOMMAND_HH

#include <type_traits>
#include "Geometry/SensitiveCommandString.hh"

namespace Geometry
{

    //Privileged definition for argument of type 'Builder'.
    //SensitiveCommandString<Builder> is incomplete if the user did not specialise
    //this struct for 'Builder'. Because sizeof(incomplete) is invalid, SFINAE
    //makes the compiler try the declaration below when SensitiveCommandString<Builder>
    //has not been specialised.
    template <class Builder, std::size_t = sizeof(SensitiveCommandString<Builder>)>
    std::true_type TestSensitiveCommand(Builder&&);

    //Lowest precedence
    std::false_type TestSensitiveCommand(...);

    //TestSensitiveCommand is never called, but we can deduce its return-type and make an
    //alias HasSensitiveCommand of it. The HasSensitiveCommand<Builder> alias type always
    //contains a 'static constexpr bool value' member.
    ////declval allows to select the function accepting an object of type Builder, even if
    //Builder has no default constructor.
    template <class Builder>
    using HasSensitiveCommand = decltype(TestSensitiveCommand(std::declval<Builder>()));

}

#endif /* GEOMETRY_HASSENSITIVECOMMAND_HH */
