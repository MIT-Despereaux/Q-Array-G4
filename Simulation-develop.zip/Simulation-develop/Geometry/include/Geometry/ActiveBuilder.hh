/**************************************************************************
* @file ActiveBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 23 Sep 2019
* @brief Marks Builder class active if Build has been called (useful to
* serialise only 'active' builders)
* ************************************************************************/

#ifndef GEOMETRY_ACTIVE_BUILDER_HH
#define GEOMETRY_ACTIVE_BUILDER_HH

#include <utility>

namespace Geometry
{

    template <class Builder>
    class ActiveBuilder : public Builder
    {
        bool active;
        void MarkActive();
    public:
        template <class... Args>
        ActiveBuilder(Args&&... args);
        template <class... Args>
        auto Build(Args&&... args);
        bool IsActive() const;
        bool IsInactive() const;
    };

    template <class Builder>
    template <class... Args>
    ActiveBuilder<Builder>::ActiveBuilder(Args&&... args)
    :Builder(std::forward<Args>(args)...),
    active(false){

    }

    template <class Builder>
    void ActiveBuilder<Builder>::MarkActive(){

        active = true;

    }

    template <class Builder>
    template <class... Args>
    auto ActiveBuilder<Builder>::Build(Args&&... args){

        MarkActive();
        return Builder::Build(std::forward<Args>(args)...);

    }

    template <class Builder>
    bool ActiveBuilder<Builder>::IsActive() const{

        return active;

    }

    template <class Builder>
    bool ActiveBuilder<Builder>::IsInactive() const{

        return !IsActive();

    }

#define DEFINE_ACTIVE_BUILDER_FROM(ActiveBuilderClass, BuilderClass)\
    struct ActiveBuilderClass : ActiveBuilder<BuilderClass>{\
        using ActiveBuilder<BuilderClass>::ActiveBuilder;\
    };\

}

#endif /* GEOMETRY_ACTIVE_BUILDER_HH */
