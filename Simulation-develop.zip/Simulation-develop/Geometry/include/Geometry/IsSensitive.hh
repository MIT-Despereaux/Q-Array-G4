/**************************************************************************
* @file IsSensitive.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 24 Jan 2020
* @brief Compare IsSensitive<Builder>::value against 'true' or 'false'
* if you want to know wether Builder has defined BuildsSensitiveVolumes
* ************************************************************************/

#ifndef GEOMETRY_ISSENSITIVE_HH
#define GEOMETRY_ISSENSITIVE_HH

#include <type_traits>

namespace Geometry
{

    //Function template selected with top priority for 'Builder' arguments.
    //If the function template does not make sense, i.e. &Builder::BuildsSensitiveVolumes is
    //undefined for the given Builder, other candidates for TestSensitiveFeature will be probed.
    //decltype(X, Object{}) makes sure that the deduced-type is always 'Object'. Here decltype
    //only forces the compiller to check the validity of the '&Builder::BuildsSensitiveVolumes'
    //expression, since we already provide the return type via the second temporary 'Object{}'.
    //Because 'Substitution Failure Is Not An Error' (SFINAE), the compiler will simply try
    //to instantiate another candidate function for invalid expressions.
    template <class Builder>
    decltype(&Builder::BuildsSensitiveVolumes, std::true_type{}) TestSensitiveFeature(Builder&&);

    //Lowest priority
    std::false_type TestSensitiveFeature(...);

    // Defines type alias containing 'static constexpr bool value' member. When the type is
    // aliased to std::true_type, the 'value' member is equal to 'true', this happens
    // with the template candidate for finding out the return type (via decltype) of
    // TestSensitiveFeature is selected.
    template <class Builder>
    using IsSensitive = decltype(TestSensitiveFeature(std::declval<Builder>()));

}

#endif /* GEOMETRY_ISSENSITIVE_HH */
