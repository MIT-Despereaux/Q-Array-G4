/**************************************************************************
* @file SensitiveRicochetBasicMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 24 Jan 2020
* @brief Messenger of sensitive volume builder RicochetBasicBuilder
* ************************************************************************/

#ifndef GEOMETRY_SENSITIVERICOCHETBASICMESSENGER_HH
#define GEOMETRY_SENSITIVERICOCHETBASICMESSENGER_HH

#include "Geometry/RicochetBasicMessenger.hh"
#include "Geometry/SensitiveBuilderMessenger.hh"

namespace Geometry
{

    DEFINE_SENSITIVE_COMMAND(RicochetBasicMessenger::BuilderType, "/geometry/Ricochet/Basic/sensitive")
    using SensitiveRicochetBasicMessenger = SensitiveBuilderMessenger<RicochetBasicMessenger>;

}

#endif /* GEOMETRY_SENSITIVERICOCHETBASICMESSENGER_HH */
