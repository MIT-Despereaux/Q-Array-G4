/**************************************************************************
* @file MaterialColour.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 21 Jan 2020
* @brief Avoids defining the type and a temporary G4Colour
* ************************************************************************/

#ifndef GEOMETRY_MATERIALCOLOUR_HH
#define GEOMETRY_MATERIALCOLOUR_HH

#include "G4Colour.hh"

class G4LogicalVolume;

namespace Geometry
{
    G4Colour GetMaterialColour(const std::string& material);
    void SetColourFromMaterial(G4LogicalVolume* volume, const std::string& material);
    void SetColourFromMaterial(G4LogicalVolume& volume, const std::string& material);
}

#endif /* GEOMETRY_MATERIALCOLOUR_HH */
