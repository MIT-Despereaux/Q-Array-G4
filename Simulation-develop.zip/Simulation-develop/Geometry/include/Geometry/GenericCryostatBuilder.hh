#ifndef GENERICCRYOSTATBUILDER_H
#define GENERICCRYOSTATBUILDER_H

/// Standard includes
#include <exception>

/// Geant4 includes
#include <CLHEP/Geometry/Transform3D.h>
#include "G4LogicalVolume.hh"

/// ROOT includes
#include "TDirectory.h"
#include "TString.h"

/// Project includes
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/GeometryConfiguration.hh"
#include "Geometry/MiniCryoCubeBuilder.hh"
// #include "Geometry/RicochetBasicBuilder.hh"


namespace Geometry
{
    class GenericCryostatBuilder
    {
        public:
            
            // SensitiveMiniCryoCubeBuilder& GetMiniCryoCube();

            
            // GenericCryostatBuilder(G4LogicalVolume& mother);
            GenericCryostatBuilder(G4LogicalVolume& mother, MiniCryoCubeBuilder* miniCryoCube = nullptr);

            // MiniCryoCubeBuilder(G4LogicalVolume& mother);
             void SetMiniCryoCube(MiniCryoCubeBuilder* miniCryoCube) { mMiniCryoCube = miniCryoCube; }
             MiniCryoCubeBuilder* GetMiniCryoCube() { return mMiniCryoCube; }
            // SensitiveMiniCryoCubeBuilder& GetMiniCryoCube();
            // MiniCryoCubeBuilder* mMiniCryoCube;



            void SetVerbosity(int level);
            void SetConfig(GeometryConfiguration config);
            void SetExperimentalZoneHeight(double height); /// Distance between 10mK plate and 10mK screen bottom
            void SetInnerShieldingZoneHeight(double height); /// Distance between 10mK plate and floating plate
            void BuildPillarFloatingPlate(bool build);
            void SetPillarFloatingPlateShiftAngle(double angle);
            void SetPillarFloatingPlateRadialPosition(double radius);
            void SetPlateFloatingThickness(double thickness);

            void BuildScreen(G4String mat, G4String name, double position, double screen_radius, double screen_e, double screen_bot_h, double screen_mid_h, double screen_top_h, double flange_e, double flange_h);

            void Build(const CLHEP::Hep3Vector& position);
            void Build(const HepGeom::Transform3D& transformation);
            void Write(TDirectory& directory) const;

            /// Position in the Cryostat frame of reference
            G4ThreeVector PlateFloatingBottomCenter() const;
            G4ThreeVector OVCBottomCenter() const;



            /// Dimension
            double Plate10mK_e() const;
            double Plate10mK_radius() const;
            double Plate100mK_e() const;
            double Plate100mK_radius() const;
            double DisPlate10mK_100mK() const;
            double Plate1K_e() const;
            double Plate1K_radius() const;
            double DisPlate100mK_1K() const;
            double Plate4K_e() const;
            double Plate4K_radius() const;
            double DisPlate1K_4K() const;
            double Plate50K_e() const;
            double Plate50K_radius() const;
            double DisPlate4K_50K() const;
            double Screen10mK_h() const;
            double Screen10mK_radius() const;
            double Screen10mK_e() const;
            double DisPlate10mK_BottomScreen10mK() const;
            double Screen1K_h() const;
            double Screen1K_radius() const;
            double Screen1K_e() const;
            double DisOuterBottomScreen10mK_InnerBottomScreen1K() const;
            double Screen4K_h() const;
            double Screen4K_radius() const;
            double Screen4K_e() const;
            double DisOuterBottomScreen1K_InnerBottomScreen4K() const;
            double Screen50K_h() const;
            double Screen50K_radius() const;
            double Screen50K_e() const;
            double DisOuterBottomScreen4K_InnerBottomScreen50K() const;
            double OVC_h() const;
            double OVC_radius() const;
            double OVC_e() const;
            double DisOuterBottomScreen50K_InnerBottomOVC() const;
            double Bride_h() const;
            double Bride_radius() const;
            double Bride_e() const;
            double DisPlate50K_Bride() const;
            double PlateFloating_e() const;
            double PlateFloating_radius() const;
            double DisPlateFloating_Plate10mK() const;
            double TotalHeight() const;
            //final design variables
            double DisPlate10mK_InnerBottomOVC() const;
            double Screen1K_bot_h() const;
            double Screen1K_mid_h() const;
            double Screen1K_top_h() const;
            double Screen4K_bot_h() const;
            double Screen4K_mid_h() const;
            double Screen4K_top_h() const;
            double Screen50K_bot_h() const;
            double Screen50K_mid_h() const;
            double Screen50K_top_h() const;
            double OVCFlange_e() const;
            double OVCFlange_h() const;
            double OVC_bot_h() const;
            double OVC_mid_h() const;
            double OVC_top_h() const;

            std::vector<double> MCCpos;
          

        private:
            int mVerbosity{0};

            G4LogicalVolume& mMother;
            MiniCryoCubeBuilder* mMiniCryoCube{nullptr};

            HepGeom::Transform3D mTransformation; /// Position of the 10mK plate bottom center

            GeometryConfiguration mConfig{GeometryConfiguration::RicochetFinalDesign()};
            // GeometryConfiguration mConfig{GeometryConfiguration::RicochetRUN014()};
            // SensitiveMiniCryoCubeBuilder mMiniCryoCube{mMother};

            /// Geometry
            double mPlate10mK_e;
            double mPlate10mK_radius;
            double mPlate100mK_e;
            double mPlate100mK_radius;
            double mDisPlate10mK_100mK;
            double mPlate1K_e;
            double mPlate1K_radius;
            double mDisPlate100mK_1K;
            double mPlate4K_e;
            double mPlate4K_radius;
            double mDisPlate1K_4K;
            double mPlate50K_e;
            double mPlate50K_radius;
            double mDisPlate4K_50K;
            double mScreen10mK_radius;
            double mScreen10mK_e;
            double mDisPlate10mK_BottomScreen10mK;
            double mScreen1K_radius;
            double mScreen1K_e;
            double mDisOuterBottomScreen10mK_InnerBottomScreen1K;
            double mScreen4K_radius;
            double mScreen4K_e;
            double mDisOuterBottomScreen1K_InnerBottomScreen4K;
            double mScreen50K_radius;
            double mScreen50K_e;
            double mDisOuterBottomScreen4K_InnerBottomScreen50K;
            double mOVC_radius;
            double mOVC_e;
            double mDisOuterBottomScreen50K_InnerBottomOVC;
            double mBride_h;
            double mBride_radius;
            double mBride_e;
            double mDisPlate50K_Bride;
            //final design variables
            double mDisPlate10mK_InnerBottomOVC;

            /// Geometry optional
            bool mBuildPlateFloating{false};
            double mPlateFloating_e;
            double mPlateFloating_radius;
            double mDisPlateFloating_Plate10mK;

            bool mBuildPillarFloatingPlate{false};
            double mPillarFloatingPlate_AngleShift{0};
            double mPillarFloatingPlate_RadialPosition{10*CLHEP::cm};

            // cryocube holder
            bool mBuildCryoCubeHolder{false};
            double mDisTop10mKPlate_Plate10mK;
            double mTop10mKPlate_height;
            double mTop10mKPlate_radius;
            double mTop1KPlate_height;
            double mTop1KPlate_radius;
            double mMid10mKPlate_height;
            double mMid10mKPlate_radius;
            double mBottom1KPlate_height;
            double mBottom1KPlate_radius;
            double mBottom10mKPlate_height;
            double mBottom10mKPlate_radius;

            
            double mPillar_radius;
            double mTop1KPillar_length;
            double mTop10mKPillar_length;
            double mBottom1KPillar_length;
            double mBottom10mKPillar_length;
            


            double mMCCstand2_height;
            double mMCCstand2_innerlength;
            double mMCCstand2_innerdepth;
            double mMCCstand2_thickness;
            double mMCCstand1_height;
            double mMCCstand1_innerlength;
            double mMCCstand1_innerdepth;
            double mMCCstand1_thickness;
            double mMCCstand0_height;
            double mMCCstand0_innerlength;
            double mMCCstand0_innerdepth;
            double mMCCstand0_thickness;
            



            //config
            void mfSetConfigLyon();
            void mfSetConfigCross();
            void mfSetConfigCryoConcept2020();
            void mfSetConfigRicochetFinalDesign();
            void mfSetConfigRicochetCryoCubeHolder();
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveGenericCryostatBuilder, GenericCryostatBuilder)
    // DEFINE_SENSITIVE_BUILDER_FROM(SensitiveMiniCryoCubeBuilder, ActiveMiniCryoCubeBuilder)

}

#endif /// GENERICCRYOSTATBUILDER_H
