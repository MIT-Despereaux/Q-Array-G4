#ifndef CHOOZSITEBUILDER_HH
#define CHOOZSITEBUILDER_HH

#include "G4LogicalVolume.hh"
#include <CLHEP/Geometry/Transform3D.h>
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/TransformingBuilder.hh"

namespace Geometry{

  class ChoozBuilder {

      G4LogicalVolume& mother;

  public:
    ChoozBuilder(G4LogicalVolume& mother_);
    void Build(const HepGeom::Transform3D& transformationToMother);
    void BuildPit(const HepGeom::Transform3D& transformationToMother);
    void BuildShell(const HepGeom::Transform3D& transformationToMother);
    void BuildPitInnerVolume(const HepGeom::Transform3D& transformationToMother, const std::string& material, double experimentalRadius);
    void SetPitInnerVolumeMaterial(const std::string& material);

  };

  using ActiveChoozBuilder = ActiveBuilder<TransformingBuilder<ChoozBuilder>>;

}

#endif /* CHOOZSITEBUILDER_HH */
