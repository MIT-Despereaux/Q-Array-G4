#ifndef GEOMETRY_CYLINDRICALSHIELDINGBUILDER_H
#define GEOMETRY_CYLINDRICALSHIELDINGBUILDER_H

/// Standard includes
#include <string>

/// Geant4 includes
#include <CLHEP/Geometry/Transform3D.h>
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"

/// ROOT includes
#include "TDirectory.h"

/// Custom includes
#include "Geometry/ActiveBuilder.hh"

namespace Geometry
{

class CylindricalShieldingBuilder
{
    public:
        CylindricalShieldingBuilder(G4LogicalVolume& mother);

        void SetInitialHeight(double height);
        void SetInitialInnerRadius(double  radius);
        void AddLayer(double thickness, std::string materialName);
        void Build(HepGeom::Transform3D transformation);//G4AssemblyVolume takes non-const...
        void Write(TDirectory& directory) const;

    private:
        void SetVisualAttributes(G4LogicalVolume& volume) const;
        G4LogicalVolume& mMother;

        double mInitialHeight{0.};
        double mInitialInnerRadius{0.};
        unsigned int mNbLayers{0};
        std::vector<double> mThickness;
        std::vector<std::string> mMaterialName;

        int mVerbosity{0};
};

DEFINE_ACTIVE_BUILDER_FROM(ActiveCylindricalShieldingBuilder, CylindricalShieldingBuilder)


}
#endif /// GEOMETRY_CYLINDRICALSHIELDINGBUILDER_H
