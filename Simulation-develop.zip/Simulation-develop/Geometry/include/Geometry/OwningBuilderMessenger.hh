/**************************************************************************
* @file OwningBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 10 May 2019
* @brief OwningBuilderMessenger owns the Builder associated to Messenger
* ************************************************************************/

#ifndef OWNINGBUILDERMESSENGER_HH
#define OWNINGBUILDERMESSENGER_HH

#include "Geometry/DefaultBuilderMessenger.hh"

class G4LogicalVolume;

namespace Geometry{

    template <class Builder, class Messenger = DefaultBuilderMessenger<Builder>>
    struct OwningBuilderMessenger : private Builder, public Messenger
    {
        template  <class... Args>
        OwningBuilderMessenger(Args&&... args);
        template <class... Args>
        void ExecuteBuilder(Args&&... args);
        const Builder& GetBuilder() const;
        void SetBuilderVerbosity(int verbosity);
    };

    template <class Builder, class Messenger>
    template  <class... Args>
    OwningBuilderMessenger<Builder, Messenger>::OwningBuilderMessenger(Args&&... args)
    :Builder(std::forward<Args>(args)...),Messenger(static_cast<Builder&>(*this)){

    }

    template <class Builder, class Messenger>
    template  <class... Args>
    void OwningBuilderMessenger<Builder, Messenger>::ExecuteBuilder(Args&&... args){

        Builder::Build(std::forward<Args>(args)...);

    }

    template <class Builder, class Messenger>
    const Builder& OwningBuilderMessenger<Builder, Messenger>::GetBuilder() const{

        return static_cast<const Builder&>(*this);

    }

    template <class Builder, class Messenger>
    void OwningBuilderMessenger<Builder, Messenger>::SetBuilderVerbosity(int verbosity){

        Builder::SetVerbosity(verbosity);

    }

}

#endif /* OWNINGBUILDERMESSENGER_HH */
