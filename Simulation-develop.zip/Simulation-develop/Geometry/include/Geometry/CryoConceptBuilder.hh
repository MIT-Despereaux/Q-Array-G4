/**************************************************************************
* @file CryoConceptBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 16 Apr 2019
* @brief CryoConcept Hexadry XS UQT fridge builder
* ************************************************************************/

#ifndef GEOMETRY_CRYOCONCEPTBUILDER_HH
#define GEOMETRY_CRYOCONCEPTBUILDER_HH

#include "G4LogicalVolume.hh"
#include <CLHEP/Geometry/Transform3D.h>
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/ActiveBuilder.hh"

namespace Geometry{

    class CryoConceptBuilder{

        G4LogicalVolume& mother;
        public:
        CryoConceptBuilder(G4LogicalVolume& mother_);
        void BuildPlates(const HepGeom::Transform3D& transformationToMother);
        void BuildCans(const HepGeom::Transform3D& transformationToMother);
        void Build(const HepGeom::Transform3D& transformationToMother);

    };

    using ActiveCryoConceptBuilder = ActiveBuilder<TransformingBuilder<CryoConceptBuilder>>;

}

#endif /* GEOMETRY_CRYOCONCEPTBUILDER_HH */
