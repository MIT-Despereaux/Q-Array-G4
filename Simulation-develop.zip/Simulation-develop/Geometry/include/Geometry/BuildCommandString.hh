/**************************************************************************
* @file BuildCommandString.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 13 May 2019
* @brief Define Geant4 build command for simple Builder class whose
* messenger is SimpleBuilderMessenger<Builder>
* ************************************************************************/

#ifndef GEOMETRY_BUILDCOMMANDSTRING_HH
#define GEOMETRY_BUILDCOMMANDSTRING_HH

namespace Geometry{

    template <class Builder>
    struct BuildCommandString;

#define DEFINE_BUILD_COMMAND(BuilderClass, command) \
    template<> \
    struct BuildCommandString<BuilderClass> { \
        static constexpr const char* Get() { return command; } \
    }; \

}

#endif /* GEOMETRY_BUILDCOMMANDSTRING_HH */
