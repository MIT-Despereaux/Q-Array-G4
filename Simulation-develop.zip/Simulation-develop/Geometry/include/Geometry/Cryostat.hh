/*
 * Cryostat.hh
 *
 *  Created on: 19.01.2016
 *      Author: cazes
 */

#ifndef STAT_HH_
#define STAT_HH_

#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"


class G4VPhysicalVolume;

namespace Geometry {

  class Cryostat {
  public:

    Cryostat(bool overlap);
    G4String GetLaboratoryName();
    void Construct(G4LogicalVolume *parentVolume, G4ThreeVector position, G4RotationMatrix* rotation);


    void SetVerbose(G4int i) {
      m_verbose = i;
    }


    void SetAlpha(G4double a) {
      Alpha = a;
    }
    void SetDeltaAlpha(G4double a) {
      DeltaAlpha = a;
    }


    static G4double Plate10mK_e();
    static G4double Plate10mK_radius();
    static G4double Plate10mK_centre();
    static G4double Plate100mK_e();
    static G4double Plate100mK_radius();
    static G4double Plate100mK_centre();
    static G4double disPlate10mK_100mK();
    static G4double Plate1K_e();
    static G4double Plate1K_radius();
    static G4double Plate1K_centre();
    static G4double disPlate100mK_1K();
    static G4double Plate4K_e();
    static G4double Plate4K_radius();
    static G4double Plate4K_centre();
    static G4double disPlate1K_4K();
    static G4double Plate50K_e();
    static G4double Plate50K_radius();
    static G4double Plate50K_centre();
    static G4double disPlate4K_50K();
    static G4double Cu1K_h();
    static G4double Cu1K_radius();
    static G4double Cu1K_e();
    static G4double disPlate10mK_BottomCu1K();
    static G4double Cu4K_h();
    static G4double Cu4K_radius();
    static G4double Cu4K_e();
    static G4double disOuterBottomCu1K_InnerBottomCu4K();
    static G4double Cu50K_h();
    static G4double Cu50K_radius();
    static G4double Cu50K_e();
    static G4double disOuterBottomCu4K_InnerBottomCu50K();
    static G4double OVCInox_h();
    static G4double OVCInox_radius();
    static G4double OVCInox_e();
    static G4double disOuterBottomCu50K_InnerBottomOVCInox();
    static G4double Bride_h();
    static G4double Bride_radius();
    static G4double Bride_e();
    static G4double disPlate50K_Bride();

    void dump() const;


  private:

    //control variables
    G4int m_verbose;
    G4bool m_checkOverlaps;
    G4String m_name;


    G4double Alpha;
    G4double DeltaAlpha;

  };

} //namespace lyongeom

#endif /* STAT_HH_ */
