/**************************************************************************
* @file BuildCommandCreator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Nov 2020
* @brief Adds Build command with macro key "BuildCommandString::Get()" to
* Messenger when run upon the former via Initialise(Messenger&).
* BuildCommandCreator is a useful second template arg for
* G4Helpers::InitialisableMessenger as the former will execute the
* BuildCommandCreator automatically within its constructor.
* ************************************************************************/

#ifndef GEOMETRY_BUILD_COMMAND_CREATOR_HH
#define GEOMETRY_BUILD_COMMAND_CREATOR_HH

#include "G4UIcmdWithAString.hh"
#include "Geometry/RunBuildCommand.hh"

namespace Geometry
{

    template <class BuildCommandString>
    struct BuildCommandCreator
    {
        template <class BuilderMessenger>
        static void Initialise(BuilderMessenger& builderMessenger);
    };

    template <class BuildCommandString>
    template <class BuilderMessenger>
    void BuildCommandCreator<BuildCommandString>::Initialise(BuilderMessenger& builderMessenger)
    {
        builderMessenger.template AddCommand<G4UIcmdWithAString>(
                BuildCommandString::Get(),
                RunBuildCommand{}
                );
    }

}

#endif /* GEOMETRY_BUILD_COMMAND_CREATOR_HH */
