/**************************************************************************
* @file IdenticalVolumeAdder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 29 Jan 2020
* @brief Always build the same Solid type and colour it from the
* material's colour
* ************************************************************************/

#ifndef GEOMETRY_IDENTICALVOLUMEADDER_HH
#define GEOMETRY_IDENTICALVOLUMEADDER_HH

#include "Geometry/BasicIdenticalVolumeAdder.hh"
#include "Geometry/ColouredVolumeAdder.hh"

namespace Geometry
{

    template <class Solid>
    using IdenticalVolumeAdder = ColouredVolumeAdder<BasicIdenticalVolumeAdder<Solid>>;

}

#endif /* GEOMETRY_IDENTICALVOLUMEADDER_HH */
