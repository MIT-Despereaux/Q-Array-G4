#ifndef OuterShieldingBUILDER_HH
#define OuterShieldingBUILDER_HH

/// Geant4 includes
#include "CLHEP/Vector/ThreeVector.h"
#include <CLHEP/Geometry/Transform3D.h>
#include "CLHEP/Units/SystemOfUnits.h"

/// Project includes
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/GeometryConfiguration.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class TDirectory;

namespace Geometry
{
    class OuterShieldingBuilder
    {
        public:
            enum class ExtraPolyConfig {TopAndSide, TopOnly};

            OuterShieldingBuilder(G4LogicalVolume& mother_);

            void SetVerbosity(int level);
            void SetConfig(GeometryConfiguration config);

            void SetInnerRadius(double innerRadius);
            void SetInnerHeight(double innerHeight);
            void SetLeadThickness(double leadThickness);
            void SetPolyethyleneThickness(double polyThickness);
            void SetExtraPolyethyleneLayer(bool activate = true);
            void SetExtraPolyethyleneConfig(ExtraPolyConfig config);
            void SetExtraPolyethyleneThickness(double polyThickness);	    
	    
            void Build(const HepGeom::Transform3D& transformationToMother);
            void Write(TDirectory& directory) const;

            double OuterRadius() const;
            double TotalThickness() const;

        private:
            G4LogicalVolume& mMother;

            int mVerbosity{0};
            GeometryConfiguration mConfig{GeometryConfiguration::RicochetFinalDesign()};
            // GeometryConfiguration mConfig{GeometryConfiguration::RicochetRUN014()}; //added, dont knwo what the point is 

            CLHEP::Hep3Vector mPosition; /// Bottom inner center position
            /// Dimensions of outer shielding at ILL
            double mInnerRadius{23*CLHEP::cm};
            double mInnerHeight{76*CLHEP::cm};
            double mLeadThickness{20*CLHEP::cm};
            double mPolyThickness{35*CLHEP::cm};
            double mPolyLowerThickness{40*CLHEP::cm};
            bool mExtraPolyLayer{true}; /// activation of external layer of polyethylene
            ExtraPolyConfig mExtraPolyConfig{ExtraPolyConfig::TopOnly};
            double mExtraPolyThickness{33.6*CLHEP::cm};
            bool mBuildOuterVeto{false};
            bool mBuildInsideLeadVeto{false};
            bool mBuildInnerVeto{false};
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveOuterShieldingBuilder, TransformingBuilder<OuterShieldingBuilder>)
}

#endif /* OuterShieldingBUILDER_HH */
