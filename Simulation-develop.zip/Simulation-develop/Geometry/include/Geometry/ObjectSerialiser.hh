/**************************************************************************
* @file ObjectSerialiser.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 20 May 2019
* @brief Serialise classes in a minimal way that is useful for simulation
* analysis (originally intented for DetectorBuilders)
* ************************************************************************/

#ifndef GEOMETRY_OBJECTSERIALISER_HH
#define GEOMETRY_OBJECTSERIALISER_HH

class TDirectory;

namespace Geometry{

    struct SensitiveCryoCubeBuilder;
    struct SensitiveMiniCryoCubeBuilder;
    struct ActiveGenericCryostatBuilder;
    struct ActiveCylindricalShieldingBuilder;
    struct ActiveColdInnerShieldingBuilder;
    struct ActiveRingInnerShieldingBuilder;
    struct ActiveOuterShieldingBuilder;
    struct ActiveOuterShieldingBuilderWithDT;
    struct SensitiveRicochetBasicBuilder;
    struct SensitiveDubnaSpectrometerBuilder;

    class ObjectSerialiser{

        TDirectory& output;
    public:
        ObjectSerialiser(TDirectory& output);
        template <class Object>
        void Serialise(const Object&){}
        void Serialise(const SensitiveCryoCubeBuilder& builder);
        void Serialise(const SensitiveMiniCryoCubeBuilder& builder);
        void Serialise(const ActiveGenericCryostatBuilder& builder);
        void Serialise(const ActiveCylindricalShieldingBuilder& builder);
        void Serialise(const ActiveColdInnerShieldingBuilder& builder);
        void Serialise(const ActiveRingInnerShieldingBuilder& builder);
        void Serialise(const ActiveOuterShieldingBuilder& builder);
        void Serialise(const ActiveOuterShieldingBuilderWithDT& builder);
        void Serialise(const SensitiveRicochetBasicBuilder& builder);
        void Serialise(const SensitiveDubnaSpectrometerBuilder& builder);
    };

}

#endif /* GEOMETRY_OBJECTSERIALISER_HH */
