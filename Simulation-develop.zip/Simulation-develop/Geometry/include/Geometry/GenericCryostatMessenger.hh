#ifndef GEOMETRY_GENERICCRYOSTATMESSENGER_H
#define GEOMETRY_GENERICCRYOSTATMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"

namespace Geometry
{
    struct ActiveGenericCryostatBuilder;

    class GenericCryostatMessenger: public G4UImessenger
    {
        public:
            using BuilderType = ActiveGenericCryostatBuilder;
            GenericCryostatMessenger(BuilderType& builder, std::string cmdPrefixPath = "/geometry/cryostat/Generic");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            BuilderType& mBuilder;

            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWithAString> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;

      //            std::unique_ptr<G4UIcmdWithAString> mCmdConfig;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdExperimentalZoneHeight;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInnerShieldingZoneHeight;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdPlateFloatingThickness;
            std::unique_ptr<G4UIcommand> mCmdBuildPillarFloatingPlate;
    };
}


#endif // GEOMETRY_GENERICCRYOSTATMESSENGER_H
