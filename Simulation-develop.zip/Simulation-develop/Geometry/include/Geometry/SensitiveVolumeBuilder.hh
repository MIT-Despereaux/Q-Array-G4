/**************************************************************************
* @file SensitiveVolumeBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief SensitiveVolumeBuilder definition.
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_SENSITIVE_VOLUMEBUILDER_HH
#define RICOCHET_G4HELPERS_SENSITIVE_VOLUMEBUILDER_HH

#include "Geometry/VolumeBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"

namespace Geometry
{

    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveVolumeBuilder, ActiveVolumeBuilder)

}


#endif /* RICOCHET_G4HELPERS_SENSITIVE_VOLUMEBUILDER_HH */
