/**************************************************************************
* @file MaterialsBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 25 Apr 2019
* @brief Instantiate materials and give them colours (moved ugly legacy code
* outside DetectorConstruction)
* ************************************************************************/

#ifndef GEOMETRY_MATERIALSBUILDER_HH
#define GEOMETRY_MATERIALSBUILDER_HH

class G4Material;
class G4Element;

namespace Geometry
{

    class MaterialsBuilder
    {

        G4Element* elH;
        G4Element* elO;
        G4Element* elSi;
        G4Element* elMg;
        G4Element* elAl;
        G4Element* elFe;
        G4Element* elK;
        G4Element* elB;
        G4Element* elC;
        G4Element* elCa;
        G4Element* elNi;
        G4Element* elMn;
        G4Element* elS;
        G4Element* elZn;
        G4Element* elF;
        G4Element* elCr;
        G4Element* elN;
        G4Element* elCu;
        G4Element* elCl;
        G4Element* elP;
        G4Element* elHe3;
        G4Element* elAr40;
        void InitialiseElementsFromNIST();
        void InitialiseUserElements();
    public:
        MaterialsBuilder();
        void DefineBasicsFromNIST() const;
        void DefinePolyethylenes() const;
        void DefineNeutronFilters() const;
        void DefineDoubleChoozLiquids() const;
        void DefineMetals() const;
        void DefineSemiConductors() const;
        void DefineMinerals() const;
        void DefineGases() const;
        void DefineDubnaGas() const;
        void DefineAllMaterials() const;
        void DefineColours() const;
        static G4Material* GetNistMaterial(const char* materialName);

    };

}

#endif /* GEOMETRY_MATERIALSBUILDER_HH */
