/**************************************************************************
* @file SensitiveCommandString.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 24 Jan 2020
* @brief Specialise SensitiveCommandString for your Builder type, it will
* be picked up by SensitiveBuilderMessenger<Builder>
* ************************************************************************/

#ifndef GEOMETRY_SENSITIVECOMMANDSTRING_HH
#define GEOMETRY_SENSITIVECOMMANDSTRING_HH

namespace Geometry
{

    template <class Builder>
    struct SensitiveCommandString;

#define DEFINE_SENSITIVE_COMMAND(BuilderClass, command) \
    template<> \
    struct SensitiveCommandString<BuilderClass> { \
        static constexpr const char* Get() { return command; } \
    }; \

}

#endif /* GEOMETRY_SENSITIVECOMMANDSTRING_HH */
