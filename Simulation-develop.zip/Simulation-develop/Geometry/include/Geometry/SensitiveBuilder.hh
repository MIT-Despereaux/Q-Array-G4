/**************************************************************************
* @file SensitiveBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 21 Jan 2020
* @brief Define a new type SensitiveDetector<MyBuilder> to make the
* logical volumes returned by MyBuilder::Build sensitive
* ************************************************************************/

#ifndef GEOMETRY_SENSITIVEBUILDER_HH
#define GEOMETRY_SENSITIVEBUILDER_HH

#include <utility>
#include "Geometry/SensitiveDetector.hh"

namespace Geometry
{

    template <class Builder>
    class SensitiveBuilder : public Builder
    {
        bool sensitive{true};

        template <class VolumeRange>
        void MakeSensitiveDetectors(VolumeRange&& logicVolumes) const;
    public:
        using Builder::Builder;
        bool BuildsSensitiveVolumes() const;
        void BuildSensitiveVolumes(bool buildSensitiveVolumes);
        template <class... Args>
        auto Build(Args&&... args);
    };


    template <class Builder>
    bool SensitiveBuilder<Builder>::BuildsSensitiveVolumes() const
    {
        return sensitive;
    }

    template <class Builder>
    void SensitiveBuilder<Builder>::BuildSensitiveVolumes(bool buildSensitiveVolumes)
    {
        sensitive = buildSensitiveVolumes;
    }

    template <class Builder>
    template <class... Args>
    auto SensitiveBuilder<Builder>::Build(Args&&... args)
    {
        auto logicVolumes = Builder::Build(std::forward<Args>(args)...);
        if(sensitive) MakeSensitiveDetectors(logicVolumes);
        return logicVolumes;
    }

    template <class Builder>
    template <class VolumeRange>
    void SensitiveBuilder<Builder>::MakeSensitiveDetectors(VolumeRange&& logicVolumes) const
    {
        for(auto logicVolume : logicVolumes)
            MakeSensitiveDetector(*logicVolume, "Sensitive" + logicVolume->GetName());
    }

#define DEFINE_SENSITIVE_BUILDER_FROM(SensitiveBuilderClass, BuilderClass)\
    struct SensitiveBuilderClass : SensitiveBuilder<BuilderClass>{\
        using SensitiveBuilder<BuilderClass>::SensitiveBuilder;\
    };\

}// namespace Geometry

#endif /* GEOMETRY_SENSITIVEBUILDER_HH */
