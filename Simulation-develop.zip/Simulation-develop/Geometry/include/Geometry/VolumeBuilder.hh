/**************************************************************************
* @file VolumeBuilder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 04 Sep 2020
* @brief Caches VolumeAdder::Add<Solid> calls before building and
* positioning all the added objects upon Build call
* ************************************************************************/

#ifndef GEOMETRY_SHAPEBUILDER_HH
#define GEOMETRY_SHAPEBUILDER_HH

#include <functional>
#include <vector>
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/VolumeAdder.hh"

class G4LogicalVolume;

namespace Geometry
{

    class VolumeBuilder
    {
        G4LogicalVolume& mother;
        using AddCall = std::function<VolumePack(BasicVolumeAdder&)>;
        std::vector<AddCall> queuedCalls;
        template<class Solid, std::size_t... Is, class... Args>
        void Add(std::index_sequence<Is...>, Args&&... args);
    public:
        VolumeBuilder(G4LogicalVolume& mother_);
        template<class Solid, class... Args>
        void Add(Args&&... args);
        void ClearQueue();
        template<class... Args>
        std::vector<G4LogicalVolume*> BuildNoClear(Args&&... args) const;
        template<class... Args>
        std::vector<G4LogicalVolume*> Build(Args&&... args);
    };

    template<class Solid, std::size_t... Is, class... Args>
    void VolumeBuilder::Add(std::index_sequence<Is...>, Args&&... args)
    {
        auto tuple = std::make_tuple(std::forward<Args>(args)...);
        queuedCalls.emplace_back([tuple](BasicVolumeAdder& adder)
             {return adder.Add<Solid>(std::get<Is>(tuple)...);}
        );
    }

    template<class Solid, class... Args>
    void VolumeBuilder::Add(Args&&... args)
    {
        Add<Solid>(std::index_sequence_for<Args...>{}, std::forward<Args>(args)...);
    }

    template<class... Args>
    std::vector<G4LogicalVolume*> VolumeBuilder::BuildNoClear(Args&&... args) const
    {
        VolumeAdder volumeAdder{mother, std::forward<Args>(args)...};
        std::vector<G4LogicalVolume*> logicVolumes;
        logicVolumes.reserve(queuedCalls.size());
        std::transform(std::begin(queuedCalls), std::end(queuedCalls), std::back_inserter(logicVolumes),
            [&](const auto& cachedCall){return cachedCall(volumeAdder).Logical();}
        );
        return logicVolumes;
    }

    template<class... Args>
    std::vector<G4LogicalVolume*> VolumeBuilder::Build(Args&&... args)
    {
        auto logicVolumes = BuildNoClear(std::forward<Args>(args)...);
        ClearQueue();
        return logicVolumes;
    }

    DEFINE_ACTIVE_BUILDER_FROM(ActiveVolumeBuilder, VolumeBuilder)

}

#endif /* GEOMETRY_SHAPEBUILDER_HH */
