#ifndef CYLINDRICALSHIELDINGMESSENGER_H
#define CYLINDRICALSHIELDINGMESSENGER_H

#include <memory>
/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"

/// Custom includes
#include "Geometry/CylindricalShieldingBuilder.hh"

namespace Geometry
{

class CylindricalShieldingMessenger: public G4UImessenger
{
    public:
        using BuilderType = ActiveCylindricalShieldingBuilder;
        CylindricalShieldingMessenger(BuilderType& builder);

        void SetNewValue(G4UIcommand* cmd, G4String args);

    private:
        BuilderType& mBuilder;

        std::unique_ptr<G4UIcmdWithAString> mCmdBuild;
        std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInitialHeight;
        std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInitialInnerRadius;
        std::unique_ptr<G4UIcommand> mCmdAddLayer;
        G4UIparameter* mPrmLayerMaterial;
        G4UIparameter* mPrmLayerThickness;
        G4UIparameter* mPrmLayerUnit;

};

}

#endif /// CYLINDRICALSHIELDINGMESSENGER_H
