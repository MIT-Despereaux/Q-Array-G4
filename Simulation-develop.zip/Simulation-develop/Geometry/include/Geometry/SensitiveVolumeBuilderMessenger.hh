/**************************************************************************
* @file SensitiveVolumeBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Messenger for SensitiveVolumeBuilder
* ************************************************************************/

#ifndef RICOCHET_G4HELPERS_SENSITIVEVOLUMEBUILDERMESSENGER_HH
#define RICOCHET_G4HELPERS_SENSITIVEVOLUMEBUILDERMESSENGER_HH

#include "Geometry/VolumeBuilderCommandsCreator.hh"
#include "Geometry/SensitiveVolumeBuilder.hh"

namespace Geometry
{

    DEFINE_COMMAND_PREFIXER(SensitiveVolumeBuilderCommandPrefixer, "/geometry/volumes/sensitive/")
    using SensitiveVolumeBuilderMessenger =
    G4Helpers::InitialisablePathModifyingMessenger<SensitiveVolumeBuilder, VolumeBuilderCommandsCreator, SensitiveVolumeBuilderCommandPrefixer>;

}

#endif /* RICOCHET_G4HELPERS_SENSITIVEVOLUMEBUILDERMESSENGER_HH */
