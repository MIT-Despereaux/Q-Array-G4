/**************************************************************************
* @file BasicVolumeAdder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Apr 2019
* @brief Connect all G4 volume types when building simple shapes
* ************************************************************************/

#ifndef GEOMETRY_BASIC_VOLUMEADDER_HH
#define GEOMETRY_BASIC_VOLUMEADDER_HH

#include <type_traits>
#include "CLHEP/Vector/ThreeVector.h"
#include "G4Transform3D.hh"
#include "Geometry/VolumePack.hh"

class G4LogicalVolume;
class G4VSolid;
class G4PVPlacement;
class G4NistManager;
class G4String;

namespace Geometry{

    // If std::is_convertible::value<T, CLHEP::HepRotation>::value == true
    // then std::enable_if_t is a type alias equal to 'void'. Otherwise, std::enable_if_t
    // does not define a type alias and 'using TypeIfRotation<T> = \emptyset' is ill-formed;
    // the compiler ignores expressions involving TypeIfRotation for this type T.
    template <class T>
    using TypeIfRotation = std::enable_if_t<std::is_convertible<T, CLHEP::HepRotation>::value>;

    class BasicVolumeAdder{

        G4LogicalVolume* fMother;
        G4Transform3D fTransformation;
    public:

        VolumePack PlaceSolid(G4VSolid* solid, const G4String& name, const G4String& material, const G4Transform3D& transformation);

        BasicVolumeAdder(G4LogicalVolume& mother, const CLHEP::Hep3Vector& offsetToMother = {}, const CLHEP::HepRotation& rotationToMother = {});
        BasicVolumeAdder(G4LogicalVolume& mother, G4Transform3D transformation);
        BasicVolumeAdder(G4LogicalVolume* mother = nullptr, const CLHEP::Hep3Vector& offsetToMother = {}, const CLHEP::HepRotation& rotationToMother = {});
        BasicVolumeAdder(G4LogicalVolume* mother, G4Transform3D transformation);
        template<class Solid, class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const G4Transform3D& transformation, Args&&... args);
        // Having an additional template type 'Rotation' makes this method take precendence over the sole <Args...> method.
        // Thus, the compiler tries it first. If TypeIfRotation<Rotation> defines a type alias ('void' here), the compiler can
        // assign 'void' to the unamed template argument, resulting in 'typename (unamed) = void'.
        // If TypeIfRotation<Rotation> is ill-formed, the compiler moves on to try the sole <Args...> method below.
        template<class Solid, class Rotation, typename = TypeIfRotation<Rotation>, class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Rotation&& rotation, Args&&... args);
        template<class Solid, class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args);

    };

    template <class Solid, class... Args>
    VolumePack BasicVolumeAdder::Add(const G4String& name, const G4String& material, const G4Transform3D& transformation, Args&&... args)
    {
        auto solid = new Solid(name, std::forward<Args>(args)...);
        return PlaceSolid(solid, name, material, transformation);
    }

    template<class Solid, class Rotation, typename, class... Args>
    VolumePack BasicVolumeAdder::Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Rotation&& rotation, Args&&... args)
    {
        return Add<Solid>(name, material, G4Transform3D{rotation, centre}, std::forward<Args>(args)...);
    }

    template <class Solid, class... Args>
    VolumePack BasicVolumeAdder::Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args)
    {
        return Add<Solid>(name, material, G4Transform3D{{}, centre}, std::forward<Args>(args)...);
    }

} // namespace Geometry

#endif /* GEOMETRY_BASIC_VOLUMEADDER_HH */
