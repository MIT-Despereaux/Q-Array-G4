/**************************************************************************
* @file VolumePack.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 14 May 2019
* @brief Class storing pointers to various Geant4 volume types
* ************************************************************************/

#ifndef GEOMETRY_VOLUMEPACK_HH
#define GEOMETRY_VOLUMEPACK_HH

#include <tuple>

class G4LogicalVolume;
class G4PVPlacement;

namespace Geometry{

    enum class Volume : unsigned {Logical, Physical};

    class VolumePack{

        std::tuple<G4LogicalVolume*, G4PVPlacement*> volumes;
    public:
        template <class... Args>
        VolumePack(Args&&... args);
        template <class VolumeType>
        VolumeType* Get();
        template <Volume VolumeValue>
        auto* Get();
        G4LogicalVolume* Logical();
        G4PVPlacement* Physical();

    };

    template <class... Args>
    VolumePack::VolumePack(Args&&... args):volumes(std::forward<Args>(args)...){

    }

    template <Volume VolumeValue>
    auto* VolumePack::Get(){

        return std::get<static_cast<unsigned>(VolumeValue)>(volumes);

    }

    template <class VolumeType>
    VolumeType* VolumePack::Get(){

        return std::get<VolumeType*>(volumes);

    }

    template <class VolumeType>
    VolumeType* Get(VolumePack&& volumePack){

        return volumePack.Get<VolumeType>();

    }

    template <Volume VolumeValue>
    auto* Get(VolumePack&& volumePack){

        return volumePack.Get<VolumeValue>();

    }

    template <class VolumeType>
    VolumeType* Get(VolumePack& volumePack){

        return volumePack.Get<VolumeType>();

    }

    template <Volume VolumeValue>
    auto* Get(VolumePack& volumePack){

        return volumePack.Get<VolumeValue>();

    }

} // namespace Geometry

#endif /* GEOMETRY_VOLUMEPACK_HH */
