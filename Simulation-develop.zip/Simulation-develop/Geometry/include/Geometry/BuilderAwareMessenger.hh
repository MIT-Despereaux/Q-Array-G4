/**************************************************************************
* @file BuilderAwareMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Nov 2020
* @brief Use BuilderAwareMessenger<MyMessenger, MyBuilder> to have a new
* messenger defining the BuilderType alias (equal to MyBuilder). Useful
* to detect if MyMessenger manages a sensitive or plainer builder.
* ************************************************************************/

#ifndef GEOMETRY_BUILDER_AWARE_MESSENGER_HH
#define GEOMETRY_BUILDER_AWARE_MESSENGER_HH

namespace Geometry{

    template <class Messenger, class Builder>
    struct BuilderAwareMessenger : Messenger
    {
        using Messenger::Messenger;
        using BuilderType = Builder;
    };

}

#endif /* GEOMETRY_BUILDER_AWARE_MESSENGER_HH */
