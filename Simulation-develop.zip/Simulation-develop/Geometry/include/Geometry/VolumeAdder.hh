/**************************************************************************
* @file MyVolumeAdder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Apr 2019
* @brief Connect all G4 volume types when building simple shapes
* (yes, it leaks, because that is Geant4, one could store the addresses)
* ************************************************************************/

#ifndef GEOMETRY_VOLUMEADDER_HH
#define GEOMETRY_VOLUMEADDER_HH

#include "Geometry/BasicVolumeAdder.hh"
#include "Geometry/ColouredVolumeAdder.hh"

namespace Geometry{

    using VolumeAdder = ColouredVolumeAdder<BasicVolumeAdder>;

} // namespace Geometry

#endif /* GEOMETRY_VOLUMEADDER_HH */
