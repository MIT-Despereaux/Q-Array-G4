/*
 * MiniCryoCubeBuilder.hh
 *
 *  Created on: 9.02.2022
 *  Build the mini cryocube geometry
 *  Author: cazes
 */

#ifndef MINICRYOCUBEBUILDER_HH
#define MINICRYOCUBEBUILDER_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4AssemblyVolume.hh"
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"
#include "Geometry/GenericBolometerBuilder.hh"
#include "Geometry/GermaniumBolometerBuilder.hh"

class TDirectory;

namespace Geometry{

    class MiniCryoCubeBuilder {
        public:
            MiniCryoCubeBuilder(G4LogicalVolume& mother_);
            std::vector<G4LogicalVolume*> Build(HepGeom::Transform3D transformation);//lousy G4Assembly takes non-const args...
            std::vector<G4LogicalVolume*> BuildSeveral(HepGeom::Transform3D transformation);
        
            const std::string& GetName() const {return name;}

            void setCryoCubeHolderFormationEnabled(bool val);     // setter
            bool isCryoCubeHolderFormationEnabled() const;        // optional: getter

            void setAskewAngle(double angle);     // setter
            double AskewAngle() const;


            void SetVerbosity(int level);
            void SetMiniCryoCubeNumber(int miniCryoCubeNumber);
            void SetMiniCryoCubeHorizontalSpacing(double MiniCryoCubeHorizontalSpacing);
            void SetMiniCryoCubeVerticalSpacing(double MiniCryoCubeVerticalSpacing);

            int GetNumberOfBolometers() const { return nbOfBolometers; }
            int GetNumberOfMiniCryoCube() const { return mMiniCryoCubeNumber; }
            int GetNumberOfRows() const {return nrows;}
            double GetVerticalSpacing() const {return mVerticalSpacing;}
            double bottomPlateThickness() const;
            double bottomPlateLength() const;
            double bottomPlateDepth() const;
            double bolometerDistance() const;
            double electronicPlateThickness() const;
            double electronicPlateLength() const;
            double electronicPlateDepth() const;
            double connectionHoleLength() const;
            double connectionHoleDepth() const;
            double electronicHoleThickness() const;
            double electronicHoleLength() const;
            double electronicHoleDepth() const;
            double PCBLength() const;
            double PCBDepth() const;
            double PCBThickness() const;
            double electronicCoverPlateThickness() const;
            double connectorThickness() const;
            double connectorLength() const;
            double connectorDepth() const;
            double connectorSupportLength() const;
            double connectorSupportDepth() const;
            double GetBolometerMass() const { return totalCrystalMass; };
            double TotalHeight() const;

            int Verbosity () const;

        private:

            bool mCryoCubeHolderEnabled = false; 
            void BuildCryoCubeStructure() const;
            void BuildCryoCubeElectronicPlates() const;
            G4AssemblyVolume* miniCryoCubeAssembly;
            G4LogicalVolume& mother;
            std::string name;
            GermaniumBolometerBuilder* bolometerBuilder;
            std::map<std::string,GenericBolometerBuilder*> theBolomterBuilder;
            int nbOfBolometers;
            double totalCrystalMass;
            int mVerbosity{1};
            int mMiniCryoCubeNumber{3};
            int nrows{(mMiniCryoCubeNumber+2)/3};
            double mHorizontalSpacing{1*CLHEP::cm};
            double mVerticalSpacing{1*CLHEP::cm};
            double mAskewAngle{0*CLHEP::deg};
      
    };

    void ROOTWrite(const MiniCryoCubeBuilder& cryocube, TDirectory& directory);

    DEFINE_ACTIVE_BUILDER_FROM(ActiveMiniCryoCubeBuilder, TransformingBuilder<MiniCryoCubeBuilder>)
    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveMiniCryoCubeBuilder, ActiveMiniCryoCubeBuilder)

} // namespace

#endif /* MINICRYOCUBEBUILDER_HH */
