/******************************************************************************
* @file SensitiveBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 23 Jan 2020
* @brief Define a new type SensitiveBuilderMessenger<MyMessenger> to benefit
* from the messenger CommandString to switch on or off the sensitive feature
* of the sensitive-capable builder managed by MyMessenger.
* You must choose the CommandString by specialising it for MyMessenger or by
* using the helper DEFINE_SENSITIVE_COMMAND(MyMessenger, "/my/path/")
* ****************************************************************************/

#ifndef GEOMETRY_SENSITIVEBUILDERMESSENGER_HH
#define GEOMETRY_SENSITIVEBUILDERMESSENGER_HH

#include "G4UIcmdWithABool.hh"
#include "Geometry/SensitiveCommandString.hh"

namespace Geometry
{

    template <class Messenger>
    class SensitiveBuilderMessenger : public Messenger
    {
        using BuilderType = typename Messenger::BuilderType;
        BuilderType& builder;
        G4UIcmdWithABool setSensitive;

    public:
        SensitiveBuilderMessenger(BuilderType& builder_);
        SensitiveBuilderMessenger(BuilderType& builder_, const G4String& buildCommand, const G4String& sensitiveCommand);
        void SetNewValue(G4UIcommand* command, G4String newValue) override;

    };

    template <class Messenger>
    SensitiveBuilderMessenger<Messenger>::SensitiveBuilderMessenger(BuilderType& builder_)
    :
        Messenger(builder_),
        builder(builder_),
        setSensitive(SensitiveCommandString<BuilderType>::Get(), this)
    { }

    template <class Messenger>
    SensitiveBuilderMessenger<Messenger>::SensitiveBuilderMessenger(BuilderType& builder_, const G4String& buildCommand, const G4String& sensitiveCommand)
    :
        Messenger(builder_, buildCommand),
        builder(builder_),
        setSensitive(sensitiveCommand, this)
    { }

    template <class Messenger>
    void SensitiveBuilderMessenger<Messenger>::SetNewValue(G4UIcommand* command, G4String argument)
    {
        Messenger::SetNewValue(command, argument);
        if(command == &setSensitive) builder.BuildSensitiveVolumes(G4UIcommand::ConvertToBool(argument));
    }

} // namespace Geometry

#endif /* GEOMETRY_SENSITIVEBUILDERMESSENGER_HH */
