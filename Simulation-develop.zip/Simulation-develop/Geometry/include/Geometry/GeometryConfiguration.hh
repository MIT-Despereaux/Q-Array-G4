#ifndef GEOMETRYCONFIGURATION_H
#define GEOMETRYCONFIGURATION_H

/// Standard includes
#include <exception>
#include <array>

namespace Geometry
{
            
  class GeometryConfiguration
  {
  private:
    enum class Value
    {
      Lyon,
	    CROSS,
	    CryoConcept2020,
	    RicochetFinalDesign,
      RicochetRUN013,
      RicochetRUN014,
      RicochetRUN015,
      RicochetRUN016
	    // Custom /// not implemented, need to add geometry setters for the GenericCryostatBuilder class
	  };

    template<unsigned int N>
    constexpr GeometryConfiguration(Value value, const char(&name)[N]) : mValue{value}, mName{name} {}

  public:
    GeometryConfiguration() = delete;

    constexpr bool operator==(GeometryConfiguration a) const { return mValue == a.mValue; }
    constexpr bool operator!=(GeometryConfiguration a) const { return mValue != a.mValue; }

    std::string ToStr() const { return mName; }

    static constexpr GeometryConfiguration CROSS() {return {Value::CROSS, "CROSS"};}
    static constexpr GeometryConfiguration Lyon() {return {Value::Lyon, "Lyon"};}
    static constexpr GeometryConfiguration CryoConcept2020() {return {Value::CryoConcept2020, "CryoConcept2020"};}
    static constexpr GeometryConfiguration RicochetFinalDesign() {return {Value::RicochetFinalDesign, "RicochetFinalDesign"};}
    static constexpr GeometryConfiguration RicochetRUN013() {return {Value::RicochetRUN013, "RicochetRUN013"};}
    static constexpr GeometryConfiguration RicochetRUN014() {return {Value::RicochetRUN014, "RicochetRUN014"};} //added
    static constexpr GeometryConfiguration RicochetRUN015() {return {Value::RicochetRUN015, "RicochetRUN015"};} //added
    static constexpr GeometryConfiguration RicochetRUN016() {return {Value::RicochetRUN016, "RicochetRUN016"};} //added
    //static constexpr GeometryConfiguration Custom() {return {"Custom"};} /// not implemented, need to add geometry setters for the GenericCryostatBuilder class
    static constexpr std::array<GeometryConfiguration, 8> ListOfConfig() {return {{CROSS(), Lyon(), CryoConcept2020(), RicochetFinalDesign(), 
    RicochetRUN013(), RicochetRUN014(), RicochetRUN015(),  RicochetRUN016()}};}

    static GeometryConfiguration FromStr(std::string cfgName)
    {
      for(GeometryConfiguration& cfg : ListOfConfig())
	    {
	      if(std::string(cfg.mName) == cfgName) return cfg;
	    }
      throw std::runtime_error("GenericCryostatBuilder::GeometryConfiguration::FromStr(): Wrong config name " + cfgName);
    }

  private:
    Value mValue;
    const char* mName;
  };

}

#endif /// GEOMETRYCONFIGURATION_H
