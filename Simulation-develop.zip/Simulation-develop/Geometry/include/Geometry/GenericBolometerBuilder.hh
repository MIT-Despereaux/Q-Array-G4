/*
 * GermaniumBolomterBuilder.hh
 *
 *  Created on: 1.04.2021
 *  base class for bolometer + casing geometry
 *      Author: cazes
 */
#ifndef GEOMETRY_GENERICBOLOMETERBUILDER_HH
#define GEOMETRY_GENERICBOLOMETERBUILDER_HH


#include "G4AssemblyVolume.hh"
#include "G4VSolid.hh"
#include "G4LogicalVolume.hh"

namespace Geometry{

    class GenericBolometerBuilder {

    public:
        GenericBolometerBuilder(G4LogicalVolume& mother_, const std::string& n = " ") :  mother(mother_), name(n), solidBolo(nullptr) {}
        G4VSolid* GetSolidBolo() { return solidBolo;}
        G4LogicalVolume* GetLogicBolo() { return logicBolo; }

    protected:
        G4LogicalVolume& mother;
        G4String name;
        G4VSolid* solidBolo;
        G4LogicalVolume* logicBolo;

    };


} //namespace Geometry

#endif
