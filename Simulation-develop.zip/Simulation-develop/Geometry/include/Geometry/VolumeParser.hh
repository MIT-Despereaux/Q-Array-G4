/**************************************************************************
* @file VolumeParser.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 11 Sep 2020
* @brief Parse streams into arguments for building named physical
* positionned shapes aka 'volumes'
* ************************************************************************/

#ifndef GEOMETRY_VOLUME_PARSER_HH
#define GEOMETRY_VOLUME_PARSER_HH

#include <iterator>
#include <CLHEP/Geometry/Transform3D.h>
#include "G4Helpers/DimensionedValue.hh"
#include "G4Helpers/TransformationParser.hh"
#include "Geometry/SpecificShapeArgs.hh"
#include "Utility/Demangle.hh"

namespace Geometry
{

    namespace VolumeParser
    {

        template <class Solid>
        auto ParseSpecific(std::istream& input);
        template <class Solid, std::size_t... Is>
        auto ParseArgs(std::istream& input, std::index_sequence<Is...>);
        template <class Solid>
        auto ParseArgs(std::istream& input);

        // Implementations

        template <class Solid>
        auto ParseSpecific(std::istream& input)
        {
            std::array<G4Helpers::DimensionedValue, SpecificShapeArgs<Solid>{}> additionalArgs;
            try
            {
                std::copy_n(std::istream_iterator<G4Helpers::DimensionedValue>{input}, additionalArgs.size(),
                        std::begin(additionalArgs));
            }
            catch(std::logic_error&)
            {
                std::cerr<<"Invalid specific arguments for solid type '"<<Utility::Demangle<Solid>()
                    <<"' ("<<SpecificShapeArgs<Solid>{}<<" dimensioned values expected)\n";
                throw;
            }
            return additionalArgs;
        }

        template <class Solid, std::size_t... Is>
        auto ParseArgs(std::istream& input, std::index_sequence<Is...>)
        {
            std::string name;
            input >> name;
            try
            {
                std::string material;
                HepGeom::Transform3D transformation;
                using G4Helpers::TransformationParser::operator>>;
                input >> material >> transformation;
                auto additionalArgs = ParseSpecific<Solid>(input);
                return std::make_tuple(name, material, transformation, additionalArgs[Is]...);
            }
            catch(std::exception& error)
            {
                std::cerr<<"Failed parsing arguments for solid named '" <<  name << "'\n";
                throw;
            }
        }

        template <class Solid>
        auto ParseArgs(std::istream& input)
        {
            return ParseArgs<Solid>(input, std::make_index_sequence<SpecificShapeArgs<Solid>{}>());
        }

    }

}

#endif /* GEOMETRY_VOLUME_PARSER_HH */
