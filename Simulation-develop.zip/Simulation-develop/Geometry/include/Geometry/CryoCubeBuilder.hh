/*
 * CryoCubeBuilderBuilder.hh
 *
 *  Created on: 19.06.2019
 *  Modified april 2021 : do not describe the 27 bolometer, but the cryocube structure
 *  Use the GenericBolometerBuilder to build and position the bolometer inside the cryocube.
 *      Author: cazes
 */

#ifndef CRYOCUBEBUILDER_HH
#define CRYOCUBEBUILDER_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4AssemblyVolume.hh"
#include "Geometry/TransformingBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"
#include "Geometry/GenericBolometerBuilder.hh"

class TDirectory;

namespace Geometry{

    class CryoCubeBuilder {
        public:
            CryoCubeBuilder(G4LogicalVolume& mother_);
            std::vector<G4LogicalVolume*> Build(HepGeom::Transform3D transformation);//lousy G4Assembly takes non-const args...
            const std::string& GetName() const {return name;}

            void SetVerbosity(int value) { fVerbosity = value;}

            int    GetNumberOfBolometers() const { return nbOfBolometers; }
            double CryoCubeStructureThickness()  const;
            double CryoCubeDepth() const;
            double CryoCubeSideHight()  const;
            double CryoCubeSideSpaceHight() const;
            double CryoCubeSideSpaceShift() const; 
            double CryoCubeSideSpaceLength() const; 
            double SideScrewSupportWidth() const; 
            double TopPlateHole() const;
            double BolometerPlateThickness()  const;
            double BolometerPlateSide()  const;
            double ElectronicPlateSide()  const;
            double ElectronicPlateThickness()  const;
            double ElectronicBoardSide()  const;
            double ElectronicBoardThickness()  const;
            double ElectronicBoardDistanceToEdge()  const;
            double ElectronicBoardSpace()  const;
            double ElectronicBoardCableHoleLength()  const;
            double ElectronicBoardCableHoleWidth()  const;
            double ConnectorPlateLength()  const;
            double ConnectorPlateWidth()  const;
            double ConnectorBoxHigh()  const;
            double ConnectorBoxWidth()  const;
            double ConnectorBoxDistanceToEdge()  const;
            double BolometerDeltaX() const;
            double BolometerDeltaY() const;
            double GetBolometerMass() const { return totalCrystalMass; };
            double TotalHeight() const;

        private:
            void BuildCryoCubeStructure() const;
            void BuildCryoCubeElectronicPlates() const;
            G4AssemblyVolume* cryoCubeAssembly;
            G4LogicalVolume& mother;
            std::string name;
            std::map<std::string,GenericBolometerBuilder*> theBolomterBuilder;
            int nbOfBolometers;
            double totalCrystalMass;
            int fVerbosity;
      
    };

    void ROOTWrite(const CryoCubeBuilder& cryocube, TDirectory& directory);

    DEFINE_ACTIVE_BUILDER_FROM(ActiveCryoCubeBuilder, TransformingBuilder<CryoCubeBuilder>)
    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveCryoCubeBuilder, ActiveCryoCubeBuilder)

} // namespace lyongom

#endif /* CRYOCUBEBUILDER_HH */
