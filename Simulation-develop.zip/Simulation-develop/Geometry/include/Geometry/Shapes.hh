/**************************************************************************
* @file Shapes.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 13 May 2019
* @brief Adapt Geant4 volumes and define classes for template
* specialisations
* ************************************************************************/

#ifndef GEOMETRY_SHAPES_HH
#define GEOMETRY_SHAPES_HH

#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4Polyhedra.hh"
#include "G4SubtractionSolid.hh"

namespace Geometry
{

    struct FilledCube : G4Box
    {
        FilledCube(const G4String& name, double size);
    };

    struct FilledBox : G4Box
    {
        FilledBox(const G4String& name, double length, double depth, double height);
        //name is empty string
        FilledBox(double length, double depth, double height);
    };

    struct Wall : FilledBox
    {
        Wall(const G4String& name, double length, double height, double thickness);
    };

    struct Box : G4SubtractionSolid
    {
        Box(const G4String& name, double innerLength, double outerLength, double innerDepth, double outerDepth, double innerHeight, double outerHeight);
        // adds 'thickness' twice to 'size'
        static constexpr double OuterSize(double size, double thickness);
    };

    struct SameThicknessBox : Box
    {
        SameThicknessBox(const G4String& name, double innerLength, double innerDepth, double innerHeight, double thickness);
    };

    //this has neither floor nor ceiling
    struct SameThicknessHollowBox : Box
    {
        SameThicknessHollowBox(const G4String& name, double innerLength, double innerDepth, double height, double thickness);
    };

    //this has no end caps
    struct Tube : G4Tubs
    {
        Tube(const G4String& name, double minimumRadius, double maximumRadius, double height);
    };

    struct FilledTube : Tube
    {
        FilledTube(const G4String& name, double outerRadius, double height);
        //name is empty string
        FilledTube(double outerRadius, double height);
    };

    struct Bucket : G4Polycone
    {
        /// origin position : inner bottom center
        Bucket(const G4String& name, double innerRadius, double thickness, double height);
        static G4Polycone Build(const G4String& name, double innerRadius, double thickness, double height);
    };

    struct ReversedBucket : G4Polycone
    {
        /// origin position : inner upper center
        ReversedBucket(const G4String& name, double innerRadius, double thickness, double height);
        static G4Polycone Build(const G4String& name, double innerRadius, double thickness, double height);
    };

    //closed volumes at both ends
    struct Cylinder : G4SubtractionSolid
    {
        Cylinder(const G4String& name, double innerRadius, double outerRadius, double innerHeight, double outerHeight);
    };

    //inner height is computed from lateral thickness
    struct SameThicknessCylinder : Cylinder
    {
        SameThicknessCylinder(const G4String& name, double innerRadius, double outerRadius, double outerHeight);
        static constexpr double InnerHeight(double innerRadius, double outerRadius, double outerHeight);
    };
}

#endif /* GEOMETRY_SHAPES_HH */
