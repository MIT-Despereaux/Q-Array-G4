/**************************************************************************
* @file VolumeBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 11 Sep 2020
* @brief
* ************************************************************************/

#ifndef GEOMETRY_VOLUME_BUILDERMESSENGER_HH
#define GEOMETRY_VOLUME_BUILDERMESSENGER_HH

#include "Geometry/VolumeBuilder.hh"
#include "Geometry/VolumeBuilderCommandsCreator.hh"
#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"

namespace Geometry
{

    DEFINE_COMMAND_PREFIXER(VolumeBuilderCommandPrefixer, "/geometry/volumes/")

    struct VolumeBuilderCommandsCreator;
    using VolumeBuilderMessenger =
    G4Helpers::InitialisablePathModifyingMessenger<ActiveVolumeBuilder, VolumeBuilderCommandsCreator, VolumeBuilderCommandPrefixer>;

}

#endif /* GEOMETRY_VOLUME_BUILDERMESSENGER_HH */
