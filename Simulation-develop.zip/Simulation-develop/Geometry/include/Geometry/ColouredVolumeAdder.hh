/**************************************************************************
* @file MyVolumeAdder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Apr 2019
* @brief Calls your MyVolumeAdder::Add and uses the returned volumes to
* colour them based on the material colour
* ************************************************************************/

#ifndef GEOMETRY_COLOURED_VOLUMEADDER_HH
#define GEOMETRY_COLOURED_VOLUMEADDER_HH

#include "Geometry/VolumePack.hh"
#include "Geometry/MaterialColour.hh"

namespace CLHEP{

    class Hep3Vector;

}

class G4String;

namespace Geometry{

    void SetColourFromMaterial(VolumePack& volumePack, const G4String& material);

    template <class MyVolumeAdder>
    struct ColouredVolumeAdder : public MyVolumeAdder
    {
        using MyVolumeAdder::MyVolumeAdder;
        template<class Solid, class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args);
        //for VolumeAdders which already know the Solid they build
        template<class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args);

    };

    template <class MyVolumeAdder>
    template <class Solid, class... Args>
    VolumePack ColouredVolumeAdder<MyVolumeAdder>::Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args)
    {
        auto volumePack = MyVolumeAdder::template Add<Solid>(name, material, centre, std::forward<Args>(args)...);
        SetColourFromMaterial(volumePack.Logical(), material);
        return volumePack;
    }

    template <class MyVolumeAdder>
    template <class... Args>
    VolumePack ColouredVolumeAdder<MyVolumeAdder>::Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args)
    {
        auto volumePack = MyVolumeAdder::Add(name, material, centre, std::forward<Args>(args)...);
        SetColourFromMaterial(volumePack.Logical(), material);
        return volumePack;
    }

} // namespace Geometry

#endif /* GEOMETRY_COLOURED_VOLUMEADDER_HH */
