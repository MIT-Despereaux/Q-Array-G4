#ifndef RICOCHETBASICBUILDER_H
#define RICOCHETBASICBUILDER_H

/// Project includes
#include "Geometry/GenericCryostatBuilder.hh"
#include "Geometry/CryoCubeBuilder.hh"
#include "Geometry/MiniCryoCubeBuilder.hh"
#include "Geometry/ColdInnerShieldingBuilder.hh"
#include "Geometry/RingInnerShieldingBuilder.hh"
#include "Geometry/OuterShieldingBuilder.hh"
#include "Geometry/OuterShieldingBuilderWithDT.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/GeometryConfiguration.hh"
#include "Geometry/MuonVetoBuilder.hh"

namespace Geometry
{
    class RicochetBasicBuilder
    {
        public:
            RicochetBasicBuilder(G4LogicalVolume& mother);

            void SetVerbosity(int level);
            void SetBuildCryostat(bool activate);
            void SetBuildInnerShielding(bool activate);
            void SetBuildRingInnerShielding(bool activate);
            void SetBuildMylar(bool activate);
            void SetBuildOuterShielding(bool activate);
            void SetBuildOuterShieldingWithDT(bool activate);
            void SetBuildCryoCube(bool activate);
            void SetBuildMiniCryoCube(bool activate);
            void SetMiniCryoCubeConfig(std::string config);
            void SetBuildMuonVeto(bool activate);
            void SetSpacingCryoCube_FloatingPlate(double spacing);
            void SetSpacingCryoCube_BottomScreen(double spacing);
            void SetSpacingInnerShielding_Plate10mK(double spacing);
            void SetSpacingOuterShielding_CryostatOVC(double spacing);
            void OverwriteInternalShieldingRadius(bool overwrite);
            void SetConfig(GeometryConfiguration config);
            
            std::vector<G4LogicalVolume*> Build(const G4ThreeVector& position);
            void Write(TDirectory& directory) const;

            ActiveCryoCubeBuilder& GetCryoCube();
            SensitiveMiniCryoCubeBuilder& GetMiniCryoCube();
            ActiveGenericCryostatBuilder& GetCryostat();
            ActiveColdInnerShieldingBuilder& GetInnerShielding();
            ActiveRingInnerShieldingBuilder& GetRingInnerShielding();
            ActiveOuterShieldingBuilder& GetOuterShielding();
            ActiveOuterShieldingBuilderWithDT& GetOuterShieldingWithDT();
            SensitiveMuonVetoBuilder& GetMuonVeto();

        private:
            G4LogicalVolume& mMother;

            int mVerbosity{0};
            GeometryConfiguration mConfig{GeometryConfiguration::RicochetFinalDesign()};
            // GeometryConfiguration mConfig{GeometryConfiguration::RicochetRUN014()};//added

            G4ThreeVector mPosition;
            std::vector<G4LogicalVolume*> SensitiveVolumes;

            ActiveCryoCubeBuilder mCryoCube{mMother};
            SensitiveMiniCryoCubeBuilder mMiniCryoCube{mMother};
            // ActiveGenericCryostatBuilder mCryostat{mMother};
            ActiveGenericCryostatBuilder mCryostat{mMother, &mMiniCryoCube};
            ActiveColdInnerShieldingBuilder mInnerShielding{mMother};
            ActiveRingInnerShieldingBuilder mRingInnerShielding{mMother};
            ActiveOuterShieldingBuilder mOuterShielding{mMother};
            ActiveOuterShieldingBuilderWithDT mOuterShieldingWithDT{mMother};
            SensitiveMuonVetoBuilder mMuonVeto{mMother};
	    
            bool mBuildInnerShielding{true};
            bool mBuildRingInnerShielding{true};
            bool mBuildMylar{true};
            bool mBuildOuterShielding{true};
            bool mBuildOuterShieldingWithDT{false};
            bool mBuildCryostat{true};
            bool mBuildCryoCube{true};
            bool mBuildCryoCubeHolder{false};
            bool mBuildMiniCryoCube{false};
            std::string mMiniCryoCubeConfig{"mid"};
            bool mBuildMuonVeto{true};
            bool mBuildCryoMuonVeto{false};
            double mSpacingCryoCube_FloatingPlate{1*CLHEP::cm};
            double mSpacingCryoCube_BottomScreen{1*CLHEP::cm};
            double mSpacingInnerShielding_Plate10mK{1*CLHEP::cm};
            double mSpacingOuterShielding_CryostatOVC{1*CLHEP::cm};
            bool mOverwriteInternalShieldingRadius{true};
    };

    DEFINE_ACTIVE_BUILDER_FROM(ActiveRicochetBasicBuilder, RicochetBasicBuilder)
    DEFINE_SENSITIVE_BUILDER_FROM(SensitiveRicochetBasicBuilder, ActiveRicochetBasicBuilder)
}

#endif /// RICOCHETBASICBUILDER_H
