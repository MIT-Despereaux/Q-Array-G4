#ifndef GEOMETRY_HIT_HH
#define GEOMETRY_HIT_HH

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"
#include "SimuOutput/HitEvent.hh"
#include "SimuOutput/VolumeID.hh"

namespace Geometry{

    class Hit: public G4VHit
    {
    public:
        Hit() = default;
        bool operator==(const Hit&) const;

        void Draw();
        void Print();//cannot even be marked const or have an 'output' arg (Geant4 is utter rubbish)
        void SetEvtNum(G4int evnum)                 { evtNum = evnum; };
        void SetEdep(G4double de)                   { edep = de; };
        void SetPos(const G4ThreeVector& xyz)              { position = xyz; };
        void SetPDGID(G4int pid)                    { PDGID = pid; };
        void SetVolume(std::string vol)                { volume = std::move(vol); };
        void SetTrackID(G4int tckID)                { trackID = tckID; };
        void SetParentID(G4int parID)               { parentID = parID; };
        void SetPrePosition(const G4ThreeVector& pos0)       { prePosition = pos0; };
        void SetPostPosition(const G4ThreeVector& posf)       { postPosition = posf; };
        void SetMomentum(const G4ThreeVector& mom)         { momentum = mom; };
        void SetKE(G4double ke)                     { kineticEnergy = ke; };
        void SetVertexKE(G4double vertexKE)         { vertexKineticEnergy = vertexKE; };
        void SetSecondaryPDGID(const std::vector<G4int>& idvec) { PDGIDvec = idvec; };
        void SetSecondaryTrackID(const std::vector<G4int>& trkvec) { trackvec = trkvec; };
        void SetTrackLength(G4double len)           { trackLength = len; };
        void SetChargeDriftTime(G4double dt)        { chargeDriftTime = dt; }
        void SetStepTime(G4double t)                { stepTime = t; };

        void SetParticleName(std::string pn){ particleName  = std::move(pn);}
        void SetDetectorID(SimuOutput::VolumeID detectorID_){detectorID  = detectorID_;}
        void SetVtxVolName(std::string vvn){ vtxVolName  = std::move(vvn);}
        void SetLocalPos(const G4ThreeVector& xyz)         { localPoint= xyz;   }
        void SetProcName(std::string pn){ processName = std::move(pn);}
        void SetCreaProcName(std::string cpn){ creaProcName  = std::move(cpn);}

        void SetDetectorSID(int detectorSID_){detectorSID = detectorSID_;}

        G4int           GetEvtNum()                 const { return evtNum; };
        G4double        GetEdep()                   const { return edep; };
        G4ThreeVector   GetPos()                    const { return position; };
        G4int           GetPDGID()                  const { return PDGID; };
        const std::string& GetVolume()                 const { return volume; };
        G4int           GetTrackID()                const { return trackID; };
        G4int           GetParentID()               const { return parentID; };
        const G4ThreeVector&   GetPrePosition()              const { return prePosition;};
        const G4ThreeVector&   GetPostPosition()              const { return postPosition;};
        const G4ThreeVector&   GetMomentum()               const { return momentum; };
        G4double        GetKE()                     const { return kineticEnergy; };
        G4double        GetVertexKE()               const { return vertexKineticEnergy; };
        const std::vector<G4int>& GetSecondaryPDGID()      const { return PDGIDvec; };
        const std::vector<G4int>& GetSecondaryTrackID()    const { return trackvec; };
        G4double        GetTrackLength()            const { return trackLength; };
        G4double        GetChargeDriftTime()        const { return chargeDriftTime; };
        G4double        GetStepTime()               const { return stepTime; };

        const std::string& GetpName()               const { return particleName; }
        SimuOutput::VolumeID GetDetectorID()        const { return detectorID;}
        G4ThreeVector GetPosLocal()                 const { return localPoint;  }
        const std::string& GetProcName()                      const { return processName;    }
        const std::string& GetCreaProcName()                  const { return creaProcName;}
        const std::string& GetVtxVolName()                    const { return vtxVolName;  }

        int GetDetectorSID()  const {return detectorSID;};
        
    private:
        G4double        evtNum;
        G4double        edep;
        G4ThreeVector   position;
        G4int           PDGID;
        std::string     volume;
        G4int           trackID;
        G4int           parentID;
        G4ThreeVector   prePosition;
        G4ThreeVector   postPosition;
        G4ThreeVector   vertexPosition;
        G4ThreeVector   momentum;
        G4double        kineticEnergy;
        G4double        vertexKineticEnergy;
        std::vector<G4int>  PDGIDvec;
        std::vector<G4int>  trackvec;
        G4double        trackLength;
        G4double        chargeDriftTime;
        G4double        stepTime;

        std::string        particleName;
        SimuOutput::VolumeID detectorID;
        G4ThreeVector   localPoint;
        std::string        processName;
        std::string        creaProcName;
        std::string        vtxVolName;

        int detectorSID;


    };

    SimuOutput::HitEvent Convert(const Hit& hit); //conversion to lighter SimuOutput::HitEvent class

    struct HitsCollection : G4THitsCollection<Hit>
    {
        using G4THitsCollection<Hit>::G4THitsCollection;
    };
    inline auto begin(const HitsCollection& collection){return collection.GetVector()->begin();}
    inline auto end(const HitsCollection& collection){return collection.GetVector()->end();}
    std::size_t size(const HitsCollection& collection);
    bool empty(const HitsCollection& collection);

    std::vector<int> GetHitCollectionsIDs();//relies on G4SDManager's dumb global table of hit collections

} //namespace Geometry

#endif

