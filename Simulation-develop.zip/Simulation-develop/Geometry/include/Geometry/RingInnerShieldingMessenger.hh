#ifndef GEOMETRY_RINGINNERSHIELDINGMESSENGER_H
#define GEOMETRY_RINGINNERSHIELDINGMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithABool.hh"


namespace Geometry
{
    class RingInnerShieldingBuilder;

    class RingInnerShieldingMessenger: public G4UImessenger
    {
        public:
            RingInnerShieldingMessenger(RingInnerShieldingBuilder& ringinnershielding, std::string cmdPrefixPath = "/geometry/shielding/RingInnerShielding/");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            RingInnerShieldingBuilder& mRingInnerShielding;

            std::unique_ptr<G4UIcmdWithAString> mCmdBuild;
            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdSetThickness;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdSetSpacing;
            std::unique_ptr<G4UIcmdWithADouble> mCmdSetPolyContractionFactor;
            std::unique_ptr<G4UIcommand> mCmdAddRing;
            std::unique_ptr<G4UIcmdWithABool> mCmdSetTopRingOrigin;
            std::unique_ptr<G4UIcmdWithABool> mCmdBuildMylar;
    };
}


#endif /// GEOMETRY_RINGINNERSHIELDINGMESSENGER_H
