#ifndef GEOMETRY_SENSITIVEMINICRYOCUBEMESSENGER_HH
#define GEOMETRY_SENSITIVEMINICRYOCUBEMESSENGER_HH

#include "Geometry/MiniCryoCubeMessenger.hh"
#include "Geometry/SensitiveBuilderMessenger.hh"

/********************************************************
 *							*
 * SensitiveMiniCryoCubeMessenger.hh			*
 * Author : Maël GONIN			        *
 * Defines the toggle sensitive command using the MiniCryoCube  *
 * messenger						*
 *						        *
 ********************************************************/

namespace Geometry
{

    DEFINE_SENSITIVE_COMMAND(SensitiveMiniCryoCubeBuilder, "/geometry/detector/MiniCryoCube/sensitive")
    using SensitiveMiniCryoCubeMessenger = SensitiveBuilderMessenger<MiniCryoCubeMessenger>;

}

#endif /* GEOMETRY_SENSITIVEMESSENGER_HH */
