/*
 * GermaniumBolomterBuilder.hh
 *
 *  Created on: 1.04.2021
 *  geometry of the germanium bolometer + casing.
 *      Author: cazes
 */
#ifndef GEOMETRY_GERMANIUMBOLOMETERBUILDER_HH
#define GEOMETRY_GERMANIUMBOLOMETERBUILDER_HH

#include "Geometry/GenericBolometerBuilder.hh"
#include "Geometry/ActiveBuilder.hh"
#include "Geometry/SensitiveBuilder.hh"
#include "Geometry/TransformingBuilder.hh"


namespace Geometry{

  struct SensitiveGermaniumBolometerBuilder;

  class GermaniumBolometerBuilder : public GenericBolometerBuilder {

  public:

    GermaniumBolometerBuilder(G4LogicalVolume& mother_) : GenericBolometerBuilder(mother_,"GermaniumBolometerBuilder"), bolometerAssembly(nullptr) {}

    std::vector<G4LogicalVolume*> Build(HepGeom::Transform3D transformation);
    std::vector<G4LogicalVolume*> Build(HepGeom::Transform3D transformation, bool checkOverlaps);

    double GetCrystalMass();
    double GetCrystalVolume();
    double GetBolometerFullHight();
    double CrystalRadius() const;
    double CrystalHeight() const;
    double SupportSpace() const;
    double InnerSupportHeight() const;
    double InnerSupportBottomThickness() const;
    double InnerSupportTopThickness() const;
    double InnerSupportInnerCavityHeight() const;
    double InnerSupportBottomOuterCavityHeight() const;
    double InnerSupportTopOuterCavityHeight() const;
    double InnerSupportInnerCavityRadius() const;
    double InnerSupportOutRadius() const;
    double InnerSupportOuterCavityDepth() const;
    double OuterSupportHeight() const;
    double OuterSupportThickness() const;
    double OuterSupportSmallCavityHeight() const;
    double OuterSupportLargeCavityHeight() const;
    double OuterSupportOutRadius() const;
    double OuterSupportSmallCavityRadius() const;
    double OuterSupportLargeCavityRadius() const;
    double ClampHeight() const;
    double ClampLength() const;
    double ClampWidth() const;
    double SaphirDiameter() const;
    double KaptonLength() const;
    double SideKaptonLength() const;
    double KaptonWidth() const;
    double KaptonThickness() const;
    double KaptonSupportThickness() const;
    double KaptonSpace() const;

    void SetVerbosity(int level) { mVerbosity = level; }
    
  private:

    G4LogicalVolume* BuildBoloInnerSupport() const;
    G4LogicalVolume* BuildBoloOuterSupport() const;
    void BuildBoloFixations() const;
    void BuildKapton() const;
    void CheckOverlaps(bool checkOverlaps = true) const;
    int mVerbosity = 0;  // Add this line
    G4AssemblyVolume* bolometerAssembly;



  };


  DEFINE_ACTIVE_BUILDER_FROM(ActiveGermaniumBolometerBuilder, TransformingBuilder<GermaniumBolometerBuilder>)
  DEFINE_SENSITIVE_BUILDER_FROM(SensitiveGermaniumBolometerBuilder, ActiveGermaniumBolometerBuilder)



} //namespace Geometry

#endif
