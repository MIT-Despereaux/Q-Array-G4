/**************************************************************************
* @file VolumeBuilderCommandsCreator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 01 Oct 2020
* @brief Generic (Sensitive)VolumeBuilder Initialiser
* ************************************************************************/

#ifndef GEOMETRY_VOLUMEBUILDERCOMMANDSCREATOR_HH
#define GEOMETRY_VOLUMEBUILDERCOMMANDSCREATOR_HH

#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "Geometry/RunBuildCommand.hh"

namespace Geometry
{

    struct VolumeBuilderCommandsCreator
    {
        template <class Messenger>
        static void Initialise(Messenger& messenger);
    };

    class VolumeBuilder;
    struct AddCommandRunner
    {
        void operator()(VolumeBuilder& builder, const std::string& commandArg);
    };

    // Implementations

    template <class Messenger>
    void VolumeBuilderCommandsCreator::Initialise(Messenger& messenger)
    {
        messenger.template AddCommand<G4UIcmdWithAString>("add",
                "Enqueue volumes to build",
                Geometry::AddCommandRunner{});

        messenger.template AddCommand<G4UIcmdWithoutParameter>("clearQueue",
                "Clear volume queue",
                [](auto& builder, const std::string&){builder.ClearQueue();});

        messenger.template AddCommand<G4UIcmdWithAString>("build",
                "Build then translate cached volumes",
                RunBuildCommand{}
                );

        messenger.template AddCommand<G4UIcmdWithAString>("buildNoClear",
                "Build then translate cached volumes yet retaining the queue",
                RunBuildCommand{}
                );

    }

}

#endif /* GEOMETRY_VOLUMEBUILDERCOMMANDSCREATOR_HH */
