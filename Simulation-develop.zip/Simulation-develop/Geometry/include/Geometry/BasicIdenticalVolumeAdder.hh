/**************************************************************************
* @file BasicIdenticalVolumeAdder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 23 Jan 2020
* @brief Avoids repeating the Solid type for each Add call when building
* mostly the same Solid type
* ************************************************************************/

#ifndef GEOMETRY_BASICIDENTICALVOLUMEADDER_HH
#define GEOMETRY_BASICIDENTICALVOLUMEADDER_HH

#include "Geometry/BasicVolumeAdder.hh"

namespace Geometry{

    template <class Solid>
    struct BasicIdenticalVolumeAdder : BasicVolumeAdder
    {
        using BasicVolumeAdder::BasicVolumeAdder;
        template<class... Args>
        VolumePack Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args);

    };

    template <class Solid>
    template<class... Args>
    VolumePack BasicIdenticalVolumeAdder<Solid>::Add(const G4String& name, const G4String& material, const CLHEP::Hep3Vector& centre, Args&&... args)
    {
        return BasicVolumeAdder::Add<Solid>(name, material, centre, std::forward<Args>(args)...);
    }

}
#endif /* GEOMETRY_BASICIDENTICALVOLUMEADDER_HH */
