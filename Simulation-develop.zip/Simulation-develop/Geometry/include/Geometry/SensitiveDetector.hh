#ifndef GEOMETRY_SENSITIVEDETECTOR_HH
#define GEOMETRY_SENSITIVEDETECTOR_HH

// ********************************************************************
// * SensitiveDetector.hh                                      *
// *                                                                  *
// * Class for making the Crystal volume sensitive                    *
// *                                                                  *
// * Created by: Adam Anderson                                        *
// * adama@mit.edu                                                    *
// * 21 October 2012                                                  *
// ********************************************************************

#include "G4VSensitiveDetector.hh"
#include "Hit.hh"

class G4Step;
class G4HCofThisEvent;

namespace Geometry{

    class SensitiveDetector: public G4VSensitiveDetector
    {
    public:
        SensitiveDetector(G4String);

        void Initialize(G4HCofThisEvent*);
        G4bool ProcessHits(G4Step*, G4TouchableHistory*);

    private:
        HitsCollection* fHitCollection;
        int HitCollectionID;
    };

    //\brief Creates SensitiveDetector for given logical volume
    //@param sensitiveVolumeName name of the instantiated SensitiveDetector
    //@param logicVolume volume upon which the sensitive detector registers hits
    //@return Volume registered to G4SDManager singleton
    SensitiveDetector* MakeSensitiveDetector(G4LogicalVolume& logicVolume, const std::string& sensitiveVolumeName);

}

#endif //GEOMETRY_SENSITIVEDETECTOR_HH
