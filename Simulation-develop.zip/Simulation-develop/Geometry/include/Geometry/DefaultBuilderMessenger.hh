/***********************************************************************************
* @file DefaultBuilderMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 24 Jan 2020
* @brief Assigns different default messenger type based on capabilities of Builder.
* Presently, DefaultBuilderMessenger<Builder> 'becomes' the
* SensitiveBuilderMessenger<SimpleBuilderMessenger<Builder>> type if Builder is
* sensitive or SimpleBuilderMessenger<Builder> otherwise.
* *********************************************************************************/

#ifndef GEOMETRY_DEFAULTBUILDERMESSENGER_HH
#define GEOMETRY_DEFAULTBUILDERMESSENGER_HH

#include "Geometry/SimpleBuilderMessenger.hh"
#include "Geometry/SensitiveBuilderMessenger.hh"
#include "Geometry/IsSensitive.hh"
#include "Geometry/HasSensitiveCommand.hh"

namespace Geometry
{
    //Instantiations of DefaultBuilderMessenger<Builder> == DefaultBuilderMessenger<Builder, void> will look for
    //a partial specialisation with 'void' as a second type.
    //Because 'enable_if_t<true>' is a type equal to the 'void' type, the unique specialisation with a true condition
    //in its enable_if_t template argument will be selected.
    //For a given Builder, only a single template argument of enable_if_t should evaluate to 'true' in the
    //candidates down there.
    template <class Builder, typename TypeIfSensitive = void, typename TypeIfHasCommand = void>
    struct DefaultBuilderMessenger;

    //For insensitive builders, enable_if_t<true> aliases to 'void': the specialisation is well-formed with '<Builder, void>' and thus selected.
    //For sensitive builders, enable_if_t<false> aliases to nothing and typename 'empty text' is an ill-formed expression, but
    //because Subsitituion Failure Is Not An Error, the compiler will look for another valid template struct
    template <class Builder>
    struct DefaultBuilderMessenger<Builder, std::enable_if_t<!IsSensitive<Builder>{}>, std::enable_if_t<!HasSensitiveCommand<Builder>{}>>
    : SimpleBuilderMessenger<Builder>
    {
        using SimpleBuilderMessenger<Builder>::SimpleBuilderMessenger;
    };

    template <class Builder>
    struct DefaultBuilderMessenger<Builder, std::enable_if_t<IsSensitive<Builder>{}>, std::enable_if_t<!HasSensitiveCommand<Builder>{}>>
    : SimpleBuilderMessenger<Builder>
    {
        using SimpleBuilderMessenger<Builder>::SimpleBuilderMessenger;
    };

    template <class Builder>
    struct DefaultBuilderMessenger<Builder, std::enable_if_t<IsSensitive<Builder>{}>, std::enable_if_t<HasSensitiveCommand<Builder>{}>>
    : SensitiveBuilderMessenger<SimpleBuilderMessenger<Builder>>
    {
        using SensitiveBuilderMessenger<SimpleBuilderMessenger<Builder>>::SensitiveBuilderMessenger;
    };

}

#endif /* GEOMETRY_DEFAULTBUILDERMESSENGER_HH */
