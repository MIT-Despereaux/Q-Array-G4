#ifndef MINICRYOCUBEMESSENGER_H
#define MINICRYOCUBEMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"

/********************************************************
 *							*
 * MiniCryoCubeMessenger.hh				        *
 * Author : Maël GONIN			        *
 * Implements the input commands in the macro related   *
 * to the muon veto					*
 *						        *
 ********************************************************/

namespace Geometry
{
    struct SensitiveMiniCryoCubeBuilder;

    class MiniCryoCubeMessenger: public G4UImessenger
    {
        public:
            using BuilderType = SensitiveMiniCryoCubeBuilder;
            MiniCryoCubeMessenger(BuilderType& builder, std::string cmdPrefixPath = "/geometry/MiniCryoCube");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            BuilderType& mBuilder;

            std::unique_ptr<G4UIdirectory> mCmdDir;

            
            std::unique_ptr<G4UIcmdWith3VectorAndUnit> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdMiniCryoCubeNumber;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdMiniCryoCubeHorizontalSpacing;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdMiniCryoCubeVerticalSpacing;
    };
}

#endif /// MINICRYOCUBEMESSENGER_H
