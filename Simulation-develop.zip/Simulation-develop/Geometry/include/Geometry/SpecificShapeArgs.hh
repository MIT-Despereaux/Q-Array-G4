/**************************************************************************
* @file SpecificShapeArgs.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 11 Sep 2020
* @brief Defines number of specific constructor args of Solid (e.g. a Cube
* has only one specific argument, i.e. the length of any edge)
* ************************************************************************/

#ifndef GEOMETRY_SPECIFICSHAPEARGS_HH
#define GEOMETRY_SPECIFICSHAPEARGS_HH

#include "Geometry/Shapes.hh"

namespace Geometry
{

    template <class Solid>
    struct SpecificShapeArgs;

#define DEFINE_SPECIFIC_SHAPE_NARGS(Solid, sizeValue) \
    template<> \
    struct SpecificShapeArgs<Solid> { \
        constexpr operator size_t() const noexcept {return sizeValue;} \
    }; \

DEFINE_SPECIFIC_SHAPE_NARGS(FilledCube, 1)
DEFINE_SPECIFIC_SHAPE_NARGS(FilledBox, 3)
DEFINE_SPECIFIC_SHAPE_NARGS(Wall, 3)
DEFINE_SPECIFIC_SHAPE_NARGS(Tube, 3)
DEFINE_SPECIFIC_SHAPE_NARGS(Box, 6)
DEFINE_SPECIFIC_SHAPE_NARGS(SameThicknessBox, 4)
DEFINE_SPECIFIC_SHAPE_NARGS(SameThicknessHollowBox, 4)
DEFINE_SPECIFIC_SHAPE_NARGS(FilledTube, 2)
DEFINE_SPECIFIC_SHAPE_NARGS(Bucket, 3)
DEFINE_SPECIFIC_SHAPE_NARGS(ReversedBucket, 3)
DEFINE_SPECIFIC_SHAPE_NARGS(Cylinder, 4)
DEFINE_SPECIFIC_SHAPE_NARGS(SameThicknessCylinder, 3)

#undef DEFINE_SPECIFIC_SHAPE_NARGS

}

#endif /* GEOMETRY_SPECIFICSHAPEARGS_HH */
