#ifndef GEOMETRY_SENSITIVEMUONVETOMESSENGER_HH
#define GEOMETRY_SENSITIVEMUONVETOMESSENGER_HH

#include "Geometry/MuonVetoMessenger.hh"
#include "Geometry/SensitiveBuilderMessenger.hh"

/********************************************************
 *							*
 * SensitiveMuonVetoMessenger.hh			*
 * Author : Guillaume Chemin			        *
 * Defines the toggle sensitive command using the veto  *
 * messenger						*
 *						        *
 ********************************************************/

namespace Geometry
{

    DEFINE_SENSITIVE_COMMAND(MuonVetoMessenger::BuilderType, "/geometry/MuonVeto/sensitive")
    using SensitiveMuonVetoMessenger = SensitiveBuilderMessenger<MuonVetoMessenger>;

}

#endif /* GEOMETRY_SENSITIVEMUONVETOMESSENGER_HH */
