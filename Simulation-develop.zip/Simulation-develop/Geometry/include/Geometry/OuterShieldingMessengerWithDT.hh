#ifndef OuterShieldingMESSENGERWITHDT_H
#define OuterShieldingMESSENGERWITHDT_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"

namespace Geometry
{
    struct ActiveOuterShieldingBuilderWithDT;

    class OuterShieldingMessengerWithDT: public G4UImessenger
    {
        public:
            using BuilderType = ActiveOuterShieldingBuilderWithDT;
            OuterShieldingMessengerWithDT(BuilderType& builder, std::string cmdPrefixPath = "/geometry/shielding/BucketwithDT");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            BuilderType& mBuilder;

            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWith3VectorAndUnit> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;

            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInnerRadius;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdInnerHeight;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdLeadThickness;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdPolyThickness;
            std::unique_ptr<G4UIcmdWithABool> mCmdIronAsCylinder;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdIronThickness;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdFluentalThicknessExtra;
            std::unique_ptr<G4UIcmdWithABool> mCmdExtraPolyLayer;
            std::unique_ptr<G4UIcmdWithADoubleAndUnit> mCmdExtraPolyThickness;
    };
}
#endif /// OuterShieldingMESSENGERWITHDT_H
