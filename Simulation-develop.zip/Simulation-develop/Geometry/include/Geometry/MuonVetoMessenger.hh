#ifndef MUONVETOMESSENGER_H
#define MUONVETOMESSENGER_H

/// Standard includes
#include <memory>

/// Geant4 includes
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"

/********************************************************
 *							*
 * MuonVetoMessenger.hh				        *
 * Author : Guillaume Chemin			        *
 * Implements the input commands in the macro related   *
 * to the muon veto					*
 *						        *
 ********************************************************/

namespace Geometry
{
    struct SensitiveMuonVetoBuilder;

    class MuonVetoMessenger: public G4UImessenger
    {
        public:
            using BuilderType = SensitiveMuonVetoBuilder;
            MuonVetoMessenger(BuilderType& builder, std::string cmdPrefixPath = "/geometry/MuonVeto");
            void SetNewValue(G4UIcommand* command, G4String valueStr);

        private:
            BuilderType& mBuilder;

            std::unique_ptr<G4UIdirectory> mCmdDir;

            std::unique_ptr<G4UIcmdWith3VectorAndUnit> mCmdBuild;
            std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;
	    std::unique_ptr<G4UIcmdWithABool> mCmdBuildCryoMuonVeto;
    };
}

#endif /// MUONVETOMESSENGER_H
