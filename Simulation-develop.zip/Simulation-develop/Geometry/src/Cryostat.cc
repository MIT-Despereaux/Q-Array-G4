/*
 * Cryostat.cc
 *
 *  Created on: 19.01.2016
 *      Author: cazes
 */

#include "Geometry/Cryostat.hh"


#include "G4Box.hh"
#include "G4VisAttributes.hh"
#include "G4SystemOfUnits.hh"


#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4PVPlacement.hh"
#include "G4AssemblyVolume.hh"

namespace Geometry{

  Cryostat::Cryostat(bool overlap) :
    m_checkOverlaps(overlap) {

    m_name = "Cryostat";

    Alpha = 0.*deg;
    DeltaAlpha = 360.*deg;

    m_verbose = 1;

  }

  //
  //Geometry Constants
  //

  // !!!!!!!!!!!!!!!!!!!! Watch out!!! If you change any of these geometry parameters, you MUST also check in Frame/LeadShieldEX/Labo.cc/hh, because these three are defined according to Cryostat, but these variables are not yet linked in the program.


  // ---- Geometry of 10mK Plate

  G4double Cryostat::Plate10mK_e() {
    return 0.4*cm;
  }
  G4double Cryostat::Plate10mK_radius() {
    return 14.95*cm;
  }
  G4double Cryostat::Plate10mK_centre() {
    return 0.*cm;
  }

  // ---- Geometry of 100mK Plate

  G4double Cryostat::Plate100mK_e() {
    return 0.3*cm;
  }
  G4double Cryostat::Plate100mK_radius() {
    return 15.*cm;
  }
  G4double Cryostat::Plate100mK_centre() {
    return 0.*cm;
  }
  G4double Cryostat::disPlate10mK_100mK() {
    return 18.1*cm;
  }

  // ---- Geometry of 1K Plate

  G4double Cryostat::Plate1K_e() {
    return 0.4*cm;
  }
  G4double Cryostat::Plate1K_radius() {
    return 16.7*cm;
  }
  G4double Cryostat::Plate1K_centre() {
    return 0.*cm;
  }
  G4double Cryostat::disPlate100mK_1K() {
    return 14.6*cm;
  }

  // ---- Geometry of 4K Plate

  G4double Cryostat::Plate4K_e() {
    return 0.4*cm;
  }
  G4double Cryostat::Plate4K_radius() {
    return 18.35*cm;
  }
  G4double Cryostat::Plate4K_centre() {
    return 0.*cm;
  }
  G4double Cryostat::disPlate1K_4K() {
    return 15.*cm;
  }

  // ---- Geometry of 50K Plate

  G4double Cryostat::Plate50K_e() {
    return 0.4*cm;
  }
  G4double Cryostat::Plate50K_radius() {
    return 20.*cm;
  }
  G4double Cryostat::Plate50K_centre() {
    return 0.*cm;
  }
  G4double Cryostat::disPlate4K_50K() {
    return 20.52*cm;
  }


  // ---- Geometry of Cu 1K Screen, all the radius of screen are the inner radius() = outer radius - thickness of the screen.

  G4double Cryostat::Cu1K_h() {
    return 53.4*cm;
  }
  G4double Cryostat::Cu1K_e() {
    return 0.1*cm;
  }
  G4double Cryostat::Cu1K_radius() {
    return 15.65*cm;
  }
  G4double Cryostat::disPlate10mK_BottomCu1K() {
    return 20.*cm;
  }

  // ---- Geometry of Cu 4K Screen

  G4double Cryostat::Cu4K_h() {
    return 70.85*cm;
  }
  G4double Cryostat::Cu4K_e() {
    return 0.2*cm;
  }
  G4double Cryostat::Cu4K_radius() {
    return 17.25*cm;
  }
  G4double Cryostat::disOuterBottomCu1K_InnerBottomCu4K() {
    return 1.95*cm;
  }

  // ---- Geometry of Cu 50K Screen

  G4double Cryostat::Cu50K_h() {
    return 93.05*cm;
  }
  G4double Cryostat::Cu50K_e() {
    return 0.2*cm;
  }
  G4double Cryostat::Cu50K_radius() {
    return 18.95*cm;
  }
  G4double Cryostat::disOuterBottomCu4K_InnerBottomCu50K() {
    return 1.98*cm;
  }

  // ---- Geometry of OVC Inox Screen

  G4double Cryostat::OVCInox_h() {
    return 127.85*cm;
  }
  G4double Cryostat::OVCInox_e() {
    return 0.2*cm;
  }
  G4double Cryostat::OVCInox_radius() {
    return 20.65*cm;
  }
  G4double Cryostat::disOuterBottomCu50K_InnerBottomOVCInox() {
    return 9.*cm;
  }

  // ---- Geometry of "bride"

  G4double Cryostat::Bride_h() {
    return 6.6*cm;
  }
  G4double Cryostat::Bride_e() {
    return 4.5*cm;
  }
  G4double Cryostat::Bride_radius() {
    return 20.85*cm;
  }
  G4double Cryostat::disPlate50K_Bride() {
    return 24.3*cm;
  }




  void Cryostat::Construct(G4LogicalVolume *parentVolume,
			   G4ThreeVector position,
			   G4RotationMatrix* rotation) {

    if (m_verbose > 0) G4cout << "> Construct " << m_name << " geometry" << G4endl;

    G4Colour aColour(G4Colour::White());
    G4Colour::GetColour("CopperNOSV", aColour);
    G4VisAttributes* visAttCopperNOSV= new G4VisAttributes(aColour);
    visAttCopperNOSV->SetVisibility(true);

    G4Colour::GetColour("StainlessSteel", aColour);
    G4VisAttributes* visAttStainlessSteel= new G4VisAttributes(aColour);
    visAttStainlessSteel->SetVisibility(true);

    G4Colour grey(G4Colour::White());
    G4Colour::GetColour("Lead", grey);
    G4VisAttributes* visAttLead = new G4VisAttributes(grey);
    visAttLead->SetVisibility(true);

    G4AssemblyVolume* myCryostatVolumes = new G4AssemblyVolume();

    G4double PlateAlpha = 0.*deg; // for visualization aesthetics
    G4double PlateDeltaAlpha = 360.*deg;

    G4ThreeVector translation;

    // Define 10mK Plate - the centre of this plate is the point of origin

    G4double Plate10mK_z = Plate10mK_e()/2.;
    G4double Plate10mK_ri = Plate10mK_centre();
    G4double Plate10mK_ro = Plate10mK_radius();

    G4Tubs* solidPlate10mK = new G4Tubs("10mK Plate", Plate10mK_ri, Plate10mK_ro, Plate10mK_z, PlateAlpha, PlateDeltaAlpha);
    G4LogicalVolume* logicPlate10mK = new G4LogicalVolume(solidPlate10mK, G4Material::GetMaterial("CopperNOSV"),"logicPlate10mK");
    logicPlate10mK->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicPlate10mK, translation, nullptr);


    // Define 100mK Plate

    G4double Plate100mK_z = Plate100mK_e()/2.;
    G4double Plate100mK_ri = Plate100mK_centre();
    G4double Plate100mK_ro = Plate100mK_radius();
    translation.set(0.,0.,disPlate10mK_100mK() + Plate10mK_e()/2. + Plate100mK_e()/2.);

    G4Tubs* solidPlate100mK = new G4Tubs("100mK Plate", Plate100mK_ri, Plate100mK_ro, Plate100mK_z, PlateAlpha, PlateDeltaAlpha);
    G4LogicalVolume* logicPlate100mK = new G4LogicalVolume(solidPlate100mK, G4Material::GetMaterial("CopperNOSV"),"logicPlate100mK");
    logicPlate100mK->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicPlate100mK, translation, nullptr);


    // Define 1K Plate

    G4double Plate1K_z = Plate1K_e()/2.;
    G4double Plate1K_ri = Plate1K_centre();
    G4double Plate1K_ro = Plate1K_radius();
    translation.set(0.,0.,disPlate10mK_100mK() + Plate10mK_e()/2. + Plate100mK_e() + disPlate100mK_1K() + Plate1K_e()/2.);

    G4Tubs* solidPlate1K = new G4Tubs("1K Plate", Plate1K_ri, Plate1K_ro, Plate1K_z, PlateAlpha, PlateDeltaAlpha);
    G4LogicalVolume* logicPlate1K = new G4LogicalVolume(solidPlate1K, G4Material::GetMaterial("CopperNOSV"),"logicPlate1K");
    logicPlate1K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicPlate1K, translation, nullptr);


    // Define 4K Plate

    G4double Plate4K_z = Plate4K_e()/2.;
    G4double Plate4K_ri = Plate4K_centre();
    G4double Plate4K_ro = Plate4K_radius();
    translation.set(0.,0.,disPlate10mK_100mK() + Plate10mK_e()/2. + Plate100mK_e() + disPlate100mK_1K() + Plate1K_e() + disPlate1K_4K() + Plate4K_e()/2.);

    G4Tubs* solidPlate4K = new G4Tubs("4K Plate", Plate4K_ri, Plate4K_ro, Plate4K_z, PlateAlpha, PlateDeltaAlpha);
    G4LogicalVolume* logicPlate4K = new G4LogicalVolume(solidPlate4K, G4Material::GetMaterial("CopperNOSV"),"logicPlate4K");
    logicPlate4K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicPlate4K, translation, nullptr);


    // Define 50K Plate

    G4double Plate50K_z = Plate50K_e()/2.;
    G4double Plate50K_ri = Plate50K_centre();
    G4double Plate50K_ro = Plate50K_radius();
    translation.set(0.,0.,disPlate10mK_100mK() + Plate10mK_e()/2. + Plate100mK_e() + disPlate100mK_1K() + Plate1K_e() + disPlate1K_4K() + Plate4K_e() + disPlate4K_50K() + Plate50K_e()/2.);

    G4Tubs* solidPlate50K = new G4Tubs("50K Plate", Plate50K_ri, Plate50K_ro, Plate50K_z, PlateAlpha, PlateDeltaAlpha);
    G4LogicalVolume* logicPlate50K = new G4LogicalVolume(solidPlate50K, G4Material::GetMaterial("CopperNOSV"),"logicPlate50K");
    logicPlate50K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicPlate50K, translation, nullptr);



    // Define Cu 1K Screen

    G4double Cu1K_z[4] = {-Cu1K_h()/2.-Cu1K_e() , -Cu1K_h()/2. ,-Cu1K_h()/2. , Cu1K_h()/2.};
    G4double Cu1K_ri[4] = { 0.  , 0. , Cu1K_radius() , Cu1K_radius() };
    G4double Cu1K_ro[4] = {Cu1K_radius() + Cu1K_e() , Cu1K_radius() + Cu1K_e() , Cu1K_radius() + Cu1K_e() , Cu1K_radius() + Cu1K_e() };
    translation.set(0.,0.,Cu1K_h()/2. - disPlate10mK_BottomCu1K() - Plate10mK_e()/2.);

    G4Polycone* solidCu1K = new G4Polycone("Cu 1K Screen", Alpha, DeltaAlpha, 4,Cu1K_z,Cu1K_ri, Cu1K_ro);
    G4LogicalVolume* logicCu1K = new G4LogicalVolume(solidCu1K, G4Material::GetMaterial("CopperNOSV"),"logicCu1K");
    logicCu1K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicCu1K, translation, nullptr);


    // Define Cu 4K Screen

    G4double Cu4K_z[4] = {-Cu4K_h()/2.-Cu4K_e() , -Cu4K_h()/2. ,-Cu4K_h()/2. , Cu4K_h()/2.};
    G4double Cu4K_ri[4] = { 0.  , 0. , Cu4K_radius() , Cu4K_radius() };
    G4double Cu4K_ro[4] = {Cu4K_radius() + Cu4K_e() , Cu4K_radius() + Cu4K_e() , Cu4K_radius() + Cu4K_e() , Cu4K_radius() + Cu4K_e() };
    translation.set(0.,0.,Cu4K_h()/2. - disPlate10mK_BottomCu1K() - Plate10mK_e()/2. - Cu1K_e() - disOuterBottomCu1K_InnerBottomCu4K());

    G4Polycone* solidCu4K = new G4Polycone("Cu 4K Screen", Alpha, DeltaAlpha, 4,Cu4K_z,Cu4K_ri, Cu4K_ro);
    G4LogicalVolume* logicCu4K = new G4LogicalVolume(solidCu4K, G4Material::GetMaterial("CopperNOSV"),"logicCu4K");
    logicCu4K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicCu4K, translation, nullptr);


    // Define Cu 50K Screen

    G4double Cu50K_z[4] = {-Cu50K_h()/2.-Cu50K_e() , -Cu50K_h()/2. ,-Cu50K_h()/2. , Cu50K_h()/2.};
    G4double Cu50K_ri[4] = { 0.  , 0. , Cu50K_radius() , Cu50K_radius() };
    G4double Cu50K_ro[4] = {Cu50K_radius() + Cu50K_e() , Cu50K_radius() + Cu50K_e() , Cu50K_radius() + Cu50K_e() , Cu50K_radius() + Cu50K_e() };
    translation.set(0.,0.,Cu50K_h()/2. - disPlate10mK_BottomCu1K() - Plate10mK_e()/2. - Cu1K_e() - disOuterBottomCu1K_InnerBottomCu4K() - Cu4K_e() - disOuterBottomCu4K_InnerBottomCu50K());

    G4Polycone* solidCu50K = new G4Polycone("Cu 50K Screen", Alpha, DeltaAlpha, 4,Cu50K_z,Cu50K_ri, Cu50K_ro);
    G4LogicalVolume* logicCu50K = new G4LogicalVolume(solidCu50K, G4Material::GetMaterial("CopperNOSV"),"logicCu50K");
    logicCu50K->SetVisAttributes(visAttCopperNOSV);
    myCryostatVolumes->AddPlacedVolume(logicCu50K, translation, nullptr);


    // Define OVC inox Screen

    G4double OVCInox_z[4] = {-OVCInox_h()/2.-OVCInox_e() , -OVCInox_h()/2. ,-OVCInox_h()/2. , OVCInox_h()/2.};
    G4double OVCInox_ri[4] = {0.*cm , 0.*cm , OVCInox_radius() , OVCInox_radius() };
    G4double OVCInox_ro[4] = {OVCInox_radius() + OVCInox_e() , OVCInox_radius() + OVCInox_e() , OVCInox_radius() + OVCInox_e() , OVCInox_radius() + OVCInox_e() };
    translation.set(0.,0.,OVCInox_h()/2. - disPlate10mK_BottomCu1K() - Plate10mK_e()/2. - Cu1K_e() - disOuterBottomCu1K_InnerBottomCu4K() - Cu4K_e() - disOuterBottomCu4K_InnerBottomCu50K() - Cu50K_e() - disOuterBottomCu50K_InnerBottomOVCInox());

    G4Polycone* solidOVCInox = new G4Polycone("OVC Inox Screen", Alpha, DeltaAlpha, 4,OVCInox_z,OVCInox_ri, OVCInox_ro);
    G4LogicalVolume* logicOVCInox = new G4LogicalVolume(solidOVCInox, G4Material::GetMaterial("StainlessSteel"),"logicOVCInox");
    logicOVCInox->SetVisAttributes(visAttStainlessSteel);
    myCryostatVolumes->AddPlacedVolume(logicOVCInox, translation, nullptr);


    // Define "bride"

    G4double Bride_z[4]={-Bride_h()/2.,Bride_h()/2.,Bride_h()/2.,Bride_h()/2.+Bride_e()};
    G4double Bride_ri[4]={Bride_radius(),Bride_radius(),0.*cm,0.*cm};
    G4double Bride_ro[4]={Bride_radius()+Bride_e(),Bride_radius()+Bride_e(),Bride_radius()+Bride_e(),Bride_radius()+Bride_e()};
    translation.set(0.,0.,Plate10mK_e()/2+disPlate10mK_100mK()+Plate100mK_e()+disPlate100mK_1K()+Plate1K_e()+disPlate1K_4K()+Plate4K_e()+disPlate4K_50K()+Plate50K_e()+disPlate50K_Bride()-Bride_h()/2.);

    G4Polycone* solidBride = new G4Polycone("Bride", Alpha, DeltaAlpha, 4,Bride_z,Bride_ri, Bride_ro);
    G4LogicalVolume* logicBride = new G4LogicalVolume(solidBride, G4Material::GetMaterial("StainlessSteel"),"logicBride");
    logicBride->SetVisAttributes(visAttStainlessSteel);
    myCryostatVolumes->AddPlacedVolume(logicBride, translation, nullptr);


    myCryostatVolumes->MakeImprint(parentVolume,position,rotation);

    if (m_verbose > 0) G4cout << m_name << " Constructed." << G4endl;


  }



  void Cryostat::dump() const {

    G4cout << m_name << " parameter values " << G4endl;
    G4cout << "display alpha : " <<  Alpha/deg << " " <<  DeltaAlpha/deg << G4endl;
    G4cout << "OVC inox Screen : " << OVCInox_h()/cm << " " << OVCInox_e()/cm << " " << OVCInox_radius()/cm << G4endl;
    G4cout << "Cu 50K Screen : " << Cu50K_h()/cm << " " << Cu50K_e()/cm << " " << Cu50K_radius()/cm << G4endl;
    G4cout << "Cu 4K Screen : " << Cu4K_h()/cm << " " << Cu4K_e()/cm << " " << Cu4K_radius()/cm << G4endl;
    G4cout << "Cu 1K Screen : " << Cu1K_h()/cm << " " << Cu1K_e()/cm << " " << Cu1K_radius()/cm << G4endl;

  }

} //namespace lyongeom
