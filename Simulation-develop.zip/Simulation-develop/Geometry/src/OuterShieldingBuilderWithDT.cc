#include "Geometry/OuterShieldingBuilderWithDT.hh"
#include "CLHEP/Units/SystemOfUnits.h"
#include "G4Material.hh"
#include "G4Isotope.hh"
#include "G4Element.hh"
#include "G4UnitsTable.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4Sphere.hh"
#include "G4LogicalVolume.hh"
#include "G4RotationMatrix.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4AutoDelete.hh"
#include "G4UnionSolid.hh"
#include "G4SubtractionSolid.hh"
#include "G4Polycone.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

/// Standard includes
#include <vector>
#include <iostream>

/// Geant4 includes
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include "G4AssemblyVolume.hh"
#include "G4SDManager.hh"
#include "G4NistManager.hh"
#include "G4Polycone.hh"

/// Project includes
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/Cryostat.hh"
#include "SimuOutput/InfoHeaderWriter.hh"
#include "Geometry/SensitiveDetector.hh"
#include "Geometry/MaterialColour.hh"



namespace Geometry
{
    OuterShieldingBuilderWithDT::OuterShieldingBuilderWithDT(G4LogicalVolume &mother): mMother(mother)
    {

    }

    void OuterShieldingBuilderWithDT::SetVerbosity(int level)
    {
        mVerbosity = level;
    }

    void OuterShieldingBuilderWithDT::SetInnerRadius(double innerRadius)
    {
        mInnerRadius = innerRadius;
    }

    void OuterShieldingBuilderWithDT::SetInnerHeight(double innerHeight)
    {
        mInnerHeight = innerHeight;
    }

    void OuterShieldingBuilderWithDT::SetLeadThickness(double leadThickness)
    {
        mLeadThickness = leadThickness;
    }

    void OuterShieldingBuilderWithDT::SetPolyethyleneThickness(double polyThickness)
    {
        mPolyThickness = polyThickness;
    }
    void OuterShieldingBuilderWithDT::SetIronAsCylinder(bool setcylinder)
    {
        mIronAsCylinder = setcylinder;
    }
    void OuterShieldingBuilderWithDT::SetIronThickness(double ironThickness)
    {
        mIronThickness = ironThickness;
    }
    void OuterShieldingBuilderWithDT::SetFluentalThicknessExtra(double fluentalThicknessExtra)
    {
        mFluentalThicknessExtra = fluentalThicknessExtra;
    }

    void OuterShieldingBuilderWithDT::SetExtraPolyethyleneLayer(bool activate)
    {
        mExtraPolyLayer = activate;
    }

    void OuterShieldingBuilderWithDT::SetExtraPolyethyleneThickness(double polyThickness)
    {
        mExtraPolyThickness = polyThickness;
    }


    void OuterShieldingBuilderWithDT::Build(const G4ThreeVector& position)
    {


            std::cout << "Build OuterShielding geometry with DT" << std::endl;


            VolumeAdder factory(mMother, position);
            CLHEP::HepRotation turnAlongX1{0.0,  CLHEP::halfpi, 0.0};
            VolumeAdder rotatedfactory(mMother, position, turnAlongX1);

            G4double thickness_Veto = 0*CLHEP::mm;//set it zero for the case od DT Generator
            G4double startangle = 0.*deg;
            G4double spanningangle = 360.*deg;
            G4double holeRadius = 15*CLHEP::cm;
            //G4double moderatorRadius = 15.0*CLHEP::cm;

            //compute the parameters of innermost Poly shield
            G4double innerRadius_Poly = mInnerRadius;//25
            G4double height_Poly = mInnerHeight - thickness_Veto;//100
            G4double thickness_Poly = mPolyThickness - thickness_Veto;//40

            //not need for the case of DTgenerator
            G4double height_Poly_Veto = height_Poly + thickness_Poly;//100

            //compute the parameters of Poly outermost Lead shield
            G4double innerRadius_Lead = mInnerRadius + mPolyThickness;//65
            G4double height_Lead = mInnerHeight + mPolyThickness;//140
            G4double thickness_Lead = mLeadThickness;

            G4ThreeVector position_Poly = {0, 0, 0};
            G4ThreeVector position_hole_Poly = {0, innerRadius_Poly+thickness_Poly/2.0, (thickness_Poly-height_Poly)/2.0 -position.z()};

            G4ThreeVector position_Poly_Veto = {0, 0, -thickness_Poly};
            G4ThreeVector position_Poly_Veto_Top = position_Poly_Veto + G4ThreeVector{0, 0, height_Poly_Veto + thickness_Veto/2.};

            G4ThreeVector position_Lead = position_Poly + G4ThreeVector(0, 0, -mPolyThickness);
            G4ThreeVector position_hole_Lead = {0, innerRadius_Lead+thickness_Lead/2.0, mPolyThickness + (thickness_Lead-height_Lead)/2.0 - position.z()};
            G4ThreeVector position_Lead_Top = position_Lead + G4ThreeVector(0, 0, mInnerHeight + mPolyThickness + mLeadThickness/2.);

            //parameter of Lead Cap
            double DD_Height = 20.0*CLHEP::cm;
            double shieldCapHeight= 15.0*CLHEP::cm;
            double Source_radius = (3.4/2)*CLHEP::cm;
            double shieldRadius = 20.0*CLHEP::cm;

            //parameter of Poly sheild aound DT
            double DT_module_remainings = 43.0*CLHEP::cm;//112.0*CLHEP::cm;


            //Design the inner PolyBucket Shielding
            G4RotationMatrix* turnAlongX = new G4RotationMatrix;
            turnAlongX->rotateX(CLHEP::halfpi);

            G4RotationMatrix* turnAlongX_270 = new G4RotationMatrix;
            turnAlongX_270->rotateX(3*CLHEP::halfpi);


            G4Tubs* Shielding_Poly_S  = new G4Tubs("Shielding_Poly_solid", innerRadius_Poly, innerRadius_Poly+ thickness_Poly, (thickness_Poly+height_Poly)/2.0 ,startangle, spanningangle);
            //if(mIronAsCylinder == false)
            G4Cons* hole_S = new G4Cons("hole_solid", 0.0 , holeRadius/4.0, 0.0 , holeRadius, thickness_Poly/2.0,startangle, spanningangle);
          //  }
            //if(mIronAsCylinder == true){
            //G4Tubs* hole_S = new G4Tubs("hole_solid", 0.0 , holeRadius, thickness_Poly/2.0+(2.0)*CLHEP::cm ,startangle, spanningangle);
            //}
            G4SubtractionSolid* OuterShielding_Poly_S= new G4SubtractionSolid("OuterShielding_Poly_S", Shielding_Poly_S, hole_S, turnAlongX, position_hole_Poly);
            G4LogicalVolume*  OuterShielding_Poly_LV= new G4LogicalVolume(OuterShielding_Poly_S, G4Material::GetMaterial("PolBor3pc"), "OuterShielding_Poly");
            SetColourFromMaterial(OuterShielding_Poly_LV, "PolBor3pc");
            new G4PVPlacement(nullptr, position + position_Poly+G4ThreeVector{0,0,(-thickness_Poly+height_Poly)/2.0}, OuterShielding_Poly_LV, "OuterShielding_Poly", &mMother, false, 0, true);



            G4Tubs* Shielding_Lead_S = new G4Tubs("Shielding_Lead_solid2", innerRadius_Lead , innerRadius_Lead + thickness_Lead, (thickness_Lead+height_Lead)/2.0 ,startangle, spanningangle);
            G4Tubs* hole_S2 = new G4Tubs("hole_solid2", 0.0 , holeRadius, thickness_Lead/2.0 + (2.0)*CLHEP::cm  ,startangle, spanningangle);
            //G4Tubs* hole_S2 = new G4Tubs("hole_solid2", 0.0 ,Poly_sheild_thickness, thickness_Lead/2.0 + (2.0)*CLHEP::cm  ,startangle, spanningangle);
            //G4VSolid* hole_S2 =  new G4Box( "hole_solid2", Poly_sheild_thickness, Poly_sheild_thickness, thickness_Lead/2.0 + (2.0)*CLHEP::cm );
            G4SubtractionSolid* OuterShielding_Lead_S= new G4SubtractionSolid("OuterShielding_Lead_S", Shielding_Lead_S, hole_S2, turnAlongX, position_hole_Lead);
            G4LogicalVolume*  OuterShielding_Lead_LV= new G4LogicalVolume(OuterShielding_Lead_S, G4Material::GetMaterial("Lead"), "OuterShielding_Lead");
            SetColourFromMaterial(OuterShielding_Lead_LV, "Lead");
            new G4PVPlacement(nullptr, position + position_Lead+G4ThreeVector{0,0,(-thickness_Lead+height_Lead)/2.0}, OuterShielding_Lead_LV, "OuterShielding_Lead", &mMother, false, 0, true);


            G4Tubs* OuterShielding_Lead_Top_S = new G4Tubs("OuterShielding_Lead_Top_solid", innerRadius_Poly , innerRadius_Lead , mLeadThickness/2.0 ,startangle, spanningangle);
            G4LogicalVolume*  OuterShielding_Lead_Top_LV= new G4LogicalVolume(OuterShielding_Lead_Top_S, G4Material::GetMaterial("Lead"), "OuterShielding_Lead_Top");
            SetColourFromMaterial(OuterShielding_Lead_Top_LV, "Lead");
            new G4PVPlacement(nullptr, position + position_Lead_Top, OuterShielding_Lead_Top_LV, "OuterShielding_Lead_Top", &mMother, false, 0, true);

            G4Tubs* OuterShielding_Lead_Bottom_S = new G4Tubs("OuterShielding_Lead_Bottom_solid", 0.0 , innerRadius_Lead , mLeadThickness/2.0 ,startangle, spanningangle);
            G4LogicalVolume*  OuterShielding_Lead_Bottom_LV= new G4LogicalVolume(OuterShielding_Lead_Bottom_S, G4Material::GetMaterial("Lead"), "OuterShielding_Lead_Bottom");
            SetColourFromMaterial(OuterShielding_Lead_Bottom_LV, "Lead");
            new G4PVPlacement(nullptr, position + position_Poly+G4ThreeVector{0,0,-(mLeadThickness+2*thickness_Poly)/2.0}, OuterShielding_Lead_Bottom_LV, "OuterShielding_Lead_Bottom", &mMother, false, 0, true);


            G4Tubs* OuterShielding_Poly_Bottom_S = new G4Tubs("OuterShielding_Poly_Bottom_solid", 0.0 , innerRadius_Poly , thickness_Poly/2.0 ,startangle, spanningangle);
            G4LogicalVolume*  OuterShielding_Poly_Bottom_LV= new G4LogicalVolume(OuterShielding_Poly_Bottom_S, G4Material::GetMaterial("PolBor3pc"), "OuterShielding_Poly_Bottom");
            SetColourFromMaterial(OuterShielding_Poly_Bottom_LV, "PolBor3pc");
            new G4PVPlacement(nullptr, position + position_Poly+G4ThreeVector{0,0,-(thickness_Poly)/2.0}, OuterShielding_Poly_Bottom_LV, "OuterShielding_Poly_Bottom", &mMother, false, 0, true);

            //parameters of the DT filter
            double IronThickness= thickness_Poly;//(20.0)*CLHEP::cm;
            double FluentalThicknessextra= mFluentalThicknessExtra;//(10.0)*CLHEP::cm; //if one needs more fluental than the thickness of lead
            double FluentalThickness = thickness_Lead+ FluentalThicknessextra ;
            G4ThreeVector position_Iron_Filter = {0, innerRadius_Poly+IronThickness/2.0, -position.z()};
            G4ThreeVector position_Fluental_Moderator = {0, innerRadius_Poly+IronThickness +FluentalThickness/2.0, -position.z()};



            //if(mIronAsCylinder == false){
            G4Cons* Iron_Neutron_Filter_S = new G4Cons("Iron_Neutron_Filter_solid", 0.0 , holeRadius/4.0, 0.0 , holeRadius, IronThickness/2.0, startangle, spanningangle);
            //}
            //if(mIronAsCylinder == true)
            //{
            //     G4Tubs* Iron_Neutron_Filter_S = new G4Tubs("Iron_Neutron_Filter_solid", 0.0, holeRadius, IronThickness/2.0, startangle, spanningangle);
            //}
            G4LogicalVolume*  Iron_Neutron_Filter_LV= new G4LogicalVolume(Iron_Neutron_Filter_S, G4Material::GetMaterial("Iron"),"Iron_Neutron_Filter");
            SetColourFromMaterial(Iron_Neutron_Filter_LV, "Iron");
            new G4PVPlacement(turnAlongX, position + position_Iron_Filter, Iron_Neutron_Filter_LV, "Iron_Neutron_Filter", &mMother, false, 0, true);


            //Placing the DT vertical

            G4Tubs* Fluental_Neutron_Moderator_S = new G4Tubs("Fluental_Neutron_Moderator_solid", 0.0 , holeRadius, FluentalThickness/2.0,  startangle, spanningangle);
            G4LogicalVolume*  Fluental_Neutron_Moderator_LV= new G4LogicalVolume(Fluental_Neutron_Moderator_S, G4Material::GetMaterial("Fluental"), "Fluental_Neutron_Moderator");
            SetColourFromMaterial(Fluental_Neutron_Moderator_LV, "Fluental");
            new G4PVPlacement(turnAlongX, position + position_Fluental_Moderator, Fluental_Neutron_Moderator_LV, "Fluental_Neutron_Moderator", &mMother, false, 0, true);



            //G4double z[6] = {-shieldCapHeight-FluentalThicknessextra,-shieldCapHeight,-shieldCapHeight, 0.0, 0.0, DD_Height};
            //G4double ri[6] = {holeRadius,  holeRadius, 0.0, 0.0, Source_radius ,  Source_radius };
            //G4double ro[6] = {  shieldRadius ,  shieldRadius,  shieldRadius,   shieldRadius,   shieldRadius,   shieldRadius};

            G4double z[4] = {-shieldCapHeight-FluentalThicknessextra,-shieldCapHeight,-shieldCapHeight, DD_Height};
            G4double ri[4] = {holeRadius,  holeRadius, 0.0, 0.0 };
            G4double ro[4] = {  shieldRadius ,  shieldRadius,  shieldRadius,   shieldRadius};



            G4Polycone* Cap_S = new G4Polycone("Cap_solid", startangle, spanningangle, 4, z, ri, ro);
            G4Tubs* hole_S3 = new G4Tubs("hole_solid3", 0.0 , Source_radius, shieldRadius/2.0 ,startangle, spanningangle);
            G4ThreeVector position_hole_DT = {0, -shieldRadius/2.0, 0};
            G4SubtractionSolid* Lead_Cap_S= new G4SubtractionSolid("Lead_Cap_solid", Cap_S, hole_S3, turnAlongX, position_hole_DT);

            //G4Polycone* Lead_Cap_S = new G4Polycone("Lead_Cap_solid", startangle, spanningangle, 6, z, ri, ro);
            G4LogicalVolume*  Lead_Cap_LV= new G4LogicalVolume(Lead_Cap_S, G4Material::GetMaterial("Lead"), "Lead_Cap");
            SetColourFromMaterial(Lead_Cap_LV, "Lead");
            G4ThreeVector position_Lead_Cap = {0, innerRadius_Poly+IronThickness +FluentalThickness+ shieldCapHeight, -position.z()};
            new G4PVPlacement(turnAlongX, position + position_Lead_Cap, Lead_Cap_LV, "Lead_Cap", &mMother, false, 0, true);


            //not needed just drawing just to be clear
            G4Tubs* DT_Generator_S = new G4Tubs("DT_Generator_solid", 0.0 , Source_radius, (DD_Height+DT_module_remainings)/2.0,  startangle, spanningangle);
            G4LogicalVolume*  DT_Generator_LV= new G4LogicalVolume(DT_Generator_S, G4Material::GetMaterial("G4_AIR"), "DT_Generator");
            SetColourFromMaterial(DT_Generator_LV, "StainlessSteel");
            //G4ThreeVector position_DT_Generator = {0, innerRadius_Poly+ IronThickness + FluentalThickness + shieldCapHeight + (DD_Height+DT_module_remainings)/2.0, -position.z()};
            G4ThreeVector position_DT_Generator = {0, (innerRadius_Poly+ IronThickness + FluentalThickness + shieldCapHeight), -position.z()+(DD_Height+DT_module_remainings)/2.0};
            //new G4PVPlacement(turnAlongX, position + position_DT_Generator, DT_Generator_LV, "DT_Generator", &mMother, false, 0, true);
            new G4PVPlacement(nullptr, position + position_DT_Generator, DT_Generator_LV, "DT_Generator", &mMother, false, 0, true);

            //G4Polycone* Poly_Shield_DT_S = new G4Polycone("Poly_Shield_solid", startangle, spanningangle, 6, z1, r1i, r1o);
            //G4Polycone* Poly_Shield_DT_S = new G4Polycone("Poly_Shield_solid", startangle, spanningangle, 8, z1, r1i, r1o);
            //G4LogicalVolume*  Poly_Shield_DT_LV= new G4LogicalVolume(Poly_Shield_DT_S, G4Material::GetMaterial("PolBor3pc"), "Poly_Shield");
            //SetColourFromMaterial(Poly_Shield_DT_LV, "PolBor3pc");
            //G4ThreeVector position_Poly_Shield_DT = {0, innerRadius_Poly + IronThickness + FluentalThickness + shieldCapHeight + DD_Height, -position.z()};
            //new G4PVPlacement(turnAlongX, position + position_Poly_Shield_DT, Poly_Shield_DT_LV, "Poly_Shield_DT", &mMother, false, 0, true)


            //Placing the DT horizontal
/*
            G4double z1[8] = {-thickness_Lead-shieldCapHeight-FluentalThicknessextra-DD_Height,-shieldCapHeight-FluentalThicknessextra-DD_Height,
                                 -shieldCapHeight-FluentalThicknessextra-DD_Height, 0.0, 0.0,
                                  DT_module_remainings, DT_module_remainings, DT_module_remainings+Poly_sheild_thickness};

            G4double r1i[8] = {holeRadius, holeRadius, shieldRadius, shieldRadius,Source_radius,Source_radius, 0.0, 0.0};

            G4double r1o[8] = {  Poly_sheild_thickness,Poly_sheild_thickness,Poly_sheild_thickness ,
                                  Poly_sheild_thickness, Poly_sheild_thickness,Poly_sheild_thickness ,
                                  Poly_sheild_thickness ,  Poly_sheild_thickness };;

            double Poly_Shield_DT_height = (FluentalThickness+shieldCapHeight+DD_Height+DT_module_remainings+Poly_sheild_thickness);

            G4VSolid* Poly_Shield_DT_S  =  new G4Box( "Poly_Shield_DT", Poly_sheild_thickness, Poly_sheild_thickness, Poly_Shield_DT_height/2.0);
            G4LogicalVolume*  Poly_Shield_DT_LV= new G4LogicalVolume(Poly_Shield_DT_S, G4Material::GetMaterial("PolBor3pc"), "Poly_Shield");
            SetColourFromMaterial(Poly_Shield_DT_LV, "PolBor3pc");
            G4ThreeVector position_Poly_Shield_DT = {0,innerRadius_Poly + IronThickness + Poly_Shield_DT_height/2.0,-position.z()};
            new G4PVPlacement(turnAlongX, position + position_Poly_Shield_DT, Poly_Shield_DT_LV, "Poly_Shield_DT", &mMother, false, 0, true);


            G4Tubs* Fluental_Neutron_Moderator_S = new G4Tubs("Fluental_Neutron_Moderator_solid", 0.0 , holeRadius, FluentalThickness/2.0,  startangle, spanningangle);
            G4LogicalVolume*  Fluental_Neutron_Moderator_LV= new G4LogicalVolume(Fluental_Neutron_Moderator_S, G4Material::GetMaterial("Fluental"), "Fluental_Neutron_Moderator");
            SetColourFromMaterial(Fluental_Neutron_Moderator_LV, "Fluental");
            //new G4PVPlacement(turnAlongX, position + position_Fluental_Moderator, Fluental_Neutron_Moderator_LV, "Fluental_Neutron_Moderator", &mMother, false, 0, true);
            position_Fluental_Moderator=G4ThreeVector{0,0,-(Poly_Shield_DT_height-FluentalThickness)/2.0};
            new G4PVPlacement(nullptr, position_Fluental_Moderator, Fluental_Neutron_Moderator_LV, "Fluental_Neutron_Moderator", Poly_Shield_DT_LV, false, 0, true);

            G4double z[6] = {-shieldCapHeight-FluentalThicknessextra,-shieldCapHeight,-shieldCapHeight, 0.0, 0.0, DD_Height};
            G4double ri[6] = {holeRadius,  holeRadius, 0.0, 0.0, Source_radius ,  Source_radius };
            G4double ro[6] = {  shieldRadius ,  shieldRadius,  shieldRadius,   shieldRadius,   shieldRadius,   shieldRadius};

            G4Polycone* Lead_Cap_S = new G4Polycone("Lead_Cap_solid", startangle, spanningangle, 6, z, ri, ro);
            G4LogicalVolume*  Lead_Cap_LV= new G4LogicalVolume(Lead_Cap_S, G4Material::GetMaterial("Lead"), "Lead_Cap");
            SetColourFromMaterial(Lead_Cap_LV, "Lead");
            //G4ThreeVector position_Lead_Cap = {0, innerRadius_Poly+IronThickness +FluentalThickness+ shieldCapHeight, -position.z()};
            G4ThreeVector position_Lead_Cap = {0,0, -(Poly_Shield_DT_height-2*FluentalThickness-2*shieldCapHeight)/2.0};
            new G4PVPlacement(nullptr, position_Lead_Cap, Lead_Cap_LV, "Lead_Cap", Poly_Shield_DT_LV, false, 0, true);


            //not needed just for a drawing fro the proposal
            G4Tubs* DT_Generator_S = new G4Tubs("DT_Generator_solid", 0.0 , Source_radius, (DD_Height+DT_module_remainings)/2.0,  startangle, spanningangle);
            G4LogicalVolume*  DT_Generator_LV= new G4LogicalVolume(DT_Generator_S, G4Material::GetMaterial("G4_AIR"), "DT_Generator");
            SetColourFromMaterial(DT_Generator_LV, "StainlessSteel");
            G4ThreeVector position_DT_Generator = {0,0,-(Poly_Shield_DT_height-2*FluentalThickness-2*shieldCapHeight-DD_Height-DT_module_remainings)/2.0};
            new G4PVPlacement(nullptr, position_DT_Generator, DT_Generator_LV, "DT_Generator", Poly_Shield_DT_LV, false, 0, true);

*/




        //if(mVerbosity == 1) std::cout << "OuterShielding constructed" << std::endl
        std::cout << "OuterShielding with the DT Generator constructed" << std::endl;
    }

    void OuterShieldingBuilderWithDT::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("OuterShieldingWithDT", "Geometry::OuterShieldingBuilderWithDT");
        writer.SetKeyValue("Position_X", mPosition.x());
        writer.SetKeyValue("Position_Y", mPosition.y());
        writer.SetKeyValue("Position_Z", mPosition.z());
        writer.SetKeyValue("InitialInnerRadius", mInnerRadius);
        writer.SetKeyValue("LeadThickness", mLeadThickness);
        writer.SetKeyValue("PolyThickness", mPolyThickness);
        writer.SetKeyValue("IronThickness", mIronThickness);
        writer.SetKeyValue("FluentalThicknessextra", mFluentalThicknessExtra);
        writer.SetKeyValue("ExtraPolyLayer", mExtraPolyLayer);
        writer.SetKeyValue("ExtraPolyThickness", mExtraPolyThickness);
        writer.WriteIn(directory);
    }

    double OuterShieldingBuilderWithDT::OuterRadius() const
    {
        if(mExtraPolyLayer)
        {
            return mInnerRadius + mLeadThickness + mPolyThickness + mExtraPolyThickness;
        }
        else
        {
            return mInnerRadius + mLeadThickness + mPolyThickness;
        }
    }

    double OuterShieldingBuilderWithDT::TotalThickness() const
    {
        return mLeadThickness + mPolyThickness;
    }

}
