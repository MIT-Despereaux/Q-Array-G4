
#include "Geometry/RicochetBasicMessenger.hh"

/// Project includes
#include "Geometry/RicochetBasicBuilder.hh"
#include "Geometry/GeometryConfiguration.hh"

namespace Geometry
{
    RicochetBasicMessenger::RicochetBasicMessenger(BuilderType& builder, std::string cmdPrefixPath)
        : mBuilder(builder), mCryostatMessenger(builder.GetCryostat(), AppendPath(cmdPrefixPath, "Cryostat")),
          mInnerShieldingMessenger(builder.GetInnerShielding(), AppendPath(cmdPrefixPath, "InnerShielding")),
          mRingInnerShieldingMessenger(builder.GetRingInnerShielding(), AppendPath(cmdPrefixPath, "RingInnerShielding")),
          mOuterShieldingMessenger(builder.GetOuterShielding(), AppendPath(cmdPrefixPath, "OuterShielding")),
          mOuterShieldingMessengerWithDT(builder.GetOuterShieldingWithDT(), AppendPath(cmdPrefixPath, "OuterShieldingWithDT")),
          mMuonVetoMessenger(builder.GetMuonVeto(), AppendPath(cmdPrefixPath, "MuonVeto")),
          mMiniCryoCubeMessenger(builder.GetMiniCryoCube(), AppendPath(cmdPrefixPath, "MiniCryoCube"))
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("RicochetBasic geometry command directory");

        mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build a basic geometry of Ricochet experiment which include the CryoCube, the cryostat and an inner + outer shielding");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);

        mCmdConfig.reset(new G4UIcmdWithAString((cmdPrefixPath + "setConfig").c_str(), this));
        mCmdConfig->SetGuidance("Set geometry config");
        mCmdConfig->AvailableForStates(G4State_Idle);

        mCmdBuildCryostat.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildCryostat").c_str(), this));
        mCmdBuildCryostat->SetGuidance("Build cryostat");
        mCmdBuildCryostat->AvailableForStates(G4State_Idle);
        
        mCmdBuildInnerShielding.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildInnerShielding").c_str(), this));
        mCmdBuildInnerShielding->SetGuidance("Build inner shielding");
        mCmdBuildInnerShielding->AvailableForStates(G4State_Idle);

        mCmdBuildRingInnerShielding.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildRingInnerShielding").c_str(), this));
        mCmdBuildRingInnerShielding->SetGuidance("Build ring shielding around cryostat screen");
        mCmdBuildRingInnerShielding->AvailableForStates(G4State_Idle);

        mCmdBuildMylar.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildMylar").c_str(), this));
        mCmdBuildMylar->SetGuidance("Build Mylar around PE rings ");
        mCmdBuildMylar->AvailableForStates(G4State_Idle);


        mCmdBuildOuterShielding.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildOuterShielding").c_str(), this));
        mCmdBuildOuterShielding->SetGuidance("Build outer shielding");
        mCmdBuildOuterShielding->AvailableForStates(G4State_Idle);

        mCmdBuildOuterShieldingWithDT.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildOuterShieldingWithDT").c_str(), this));
        mCmdBuildOuterShieldingWithDT->SetGuidance("Build outer shielding");
        mCmdBuildOuterShieldingWithDT->AvailableForStates(G4State_Idle);
        
        mCmdBuildMuonVeto.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildMuonVeto").c_str(), this));
        mCmdBuildMuonVeto->SetGuidance("Build muon veto");
        mCmdBuildMuonVeto->AvailableForStates(G4State_Idle);

        mCmdBuildCryoCube.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildCryoCube").c_str(), this));
        mCmdBuildCryoCube->SetGuidance("Build CryoCube");
        mCmdBuildCryoCube->AvailableForStates(G4State_Idle);

        mCmdBuildMiniCryoCube.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildMiniCryoCube").c_str(), this));
        mCmdBuildMiniCryoCube->SetGuidance("Build Mini CryoCube");
        mCmdBuildMiniCryoCube->AvailableForStates(G4State_Idle);
              
        mCmdConfigMiniCryoCube.reset(new G4UIcmdWithAString((cmdPrefixPath + "setMiniCryoCubeConfig").c_str(), this));
        mCmdConfigMiniCryoCube->SetGuidance("Set MiniCryoCube geometry config");
        mCmdConfigMiniCryoCube->AvailableForStates(G4State_Idle);

        mCmdCryoCubeTopSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setCryoCubeTopSpacing").c_str(), this));
        mCmdCryoCubeTopSpacing->SetGuidance("Set spacing between top of the CryoCube and the bottom of the plate above, arg = XXX unit (ex: 3 cm)");
        mCmdCryoCubeTopSpacing->AvailableForStates(G4State_Idle);

        mCmdCryoCubeBottomSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setCryoCubeBottomSpacing").c_str(), this));
        mCmdCryoCubeBottomSpacing->SetGuidance("Set spacing between CryoCube bottom and the 10mK-screen bottom, arg = XXX unit (ex: 3 cm)");
        mCmdCryoCubeBottomSpacing->AvailableForStates(G4State_Idle);

        mCmdInnerShieldingVerticalSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerShieldingVerticalSpacing").c_str(), this));
        mCmdInnerShieldingVerticalSpacing->SetGuidance("Set vertical spacing between the inner shielding and surrounding plate, arg = XXX unit (ex: 3 cm");
        mCmdInnerShieldingVerticalSpacing->AvailableForStates(G4State_Idle);

        mCmdOuterShieldingInnerSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setOuterShieldingInnerSpacing").c_str(), this));
        mCmdOuterShieldingInnerSpacing->SetGuidance("Set spacing between OVC and outer shielding, arg = XXX unit (ex: 3 cm");
        mCmdOuterShieldingInnerSpacing->AvailableForStates(G4State_Idle);

        mCmdOverwriteInternalShieldingRadius.reset(new G4UIcmdWithABool((cmdPrefixPath + "overwriteInternalShieldingRadius").c_str(), this));
        mCmdOverwriteInternalShieldingRadius->SetGuidance("Force internal shielding radius to be equals to the 10mk screen radius");
        mCmdOverwriteInternalShieldingRadius->AvailableForStates(G4State_Idle);
    }

    void RicochetBasicMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
        else if(command == mCmdConfig.get())
        {
            mBuilder.SetConfig(GeometryConfiguration::FromStr(valueStr));
        }
        else if(command == mCmdBuildCryostat.get())
        {
            mBuilder.SetBuildCryostat(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildInnerShielding.get())
        {
            mBuilder.SetBuildInnerShielding(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildRingInnerShielding.get())
        {
            mBuilder.SetBuildRingInnerShielding(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildMylar.get())
        {
            mBuilder.SetBuildMylar(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildOuterShielding.get())
        {
            mBuilder.SetBuildOuterShielding(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildOuterShieldingWithDT.get())
        {
            mBuilder.SetBuildOuterShieldingWithDT(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildCryoCube.get())
        {
            mBuilder.SetBuildCryoCube(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildMiniCryoCube.get())
        {
            mBuilder.SetBuildMiniCryoCube(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdConfigMiniCryoCube.get())
        {
            mBuilder.SetMiniCryoCubeConfig(valueStr);
        }
        else if(command == mCmdBuildMuonVeto.get())
        {
            mBuilder.SetBuildMuonVeto(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdCryoCubeTopSpacing.get())
        {
            mBuilder.SetSpacingCryoCube_FloatingPlate(command->ConvertToDimensionedDouble(valueStr.c_str()));
        }
        else if(command == mCmdCryoCubeBottomSpacing.get())
        {
            mBuilder.SetSpacingCryoCube_BottomScreen(command->ConvertToDimensionedDouble(valueStr.c_str()));
        }
        else if(command == mCmdInnerShieldingVerticalSpacing.get())
        {
            mBuilder.SetSpacingInnerShielding_Plate10mK(command->ConvertToDimensionedDouble(valueStr.c_str()));
        }
        else if(command == mCmdOuterShieldingInnerSpacing.get())
        {
            mBuilder.SetSpacingOuterShielding_CryostatOVC(command->ConvertToDimensionedDouble(valueStr.c_str()));
        }
        else if(mCmdOverwriteInternalShieldingRadius)
        {
            mBuilder.OverwriteInternalShieldingRadius(G4UIcommand::ConvertToBool(valueStr));
        }

    }

    std::string RicochetBasicMessenger::AppendPath(const std::string& path1, const std::string& path2)
    {
        if(path1.empty())
        {
            return path2;
        }
        else if(path1.empty())
        {
            return path1;
        }
        else
        {
           return path1.substr(0, path1.size() - (path1.back() == '/')) + "/" + path2.substr(0, path2.size() - (path2.back() == '/'));
        }
    }

}
