#include "Geometry/OuterShieldingMessenger.hh"

/// Project includes
#include "Geometry/OuterShieldingBuilder.hh"

namespace Geometry
{
    OuterShieldingMessenger::OuterShieldingMessenger(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("OuterShielding command directory");

        mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build a bucket shape shielding to place around a cryostat");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);

        mCmdInnerRadius.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerRadius").c_str(), this));
        mCmdInnerRadius->SetGuidance("Set inner radius of the shielding, arg = XXX unit (ex: 3 cm)");
        mCmdInnerRadius->AvailableForStates(G4State_Idle);

        mCmdInnerHeight.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerHeight").c_str(), this));
        mCmdInnerHeight->SetGuidance("Set inner height of the shielding, arg = XXX unit (ex: 3 cm)");
        mCmdInnerHeight->AvailableForStates(G4State_Idle);

        mCmdLeadThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setLeadThickness").c_str(), this));
        mCmdLeadThickness->SetGuidance("Set thickness of lead layer, arg = XXX unit (ex: 3 cm)");
        mCmdLeadThickness->AvailableForStates(G4State_Idle);

        mCmdPolyThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setPolyThickness").c_str(), this));
        mCmdPolyThickness->SetGuidance("Set thickness of polyehtylene layer, arg = XXX unit (ex: 3 cm)");
        mCmdPolyThickness->AvailableForStates(G4State_Idle);

        mCmdExtraPolyLayer.reset(new G4UIcmdWithABool((cmdPrefixPath + "setExtraPolyLayer").c_str(), this));
        mCmdExtraPolyLayer->SetGuidance("Active the extra polyethylene layer as external layer");
        mCmdExtraPolyLayer->AvailableForStates(G4State_Idle);

        mCmdExtraPolyConfig.reset(new G4UIcmdWithAString((cmdPrefixPath + "setExtraPolyConfig").c_str(), this));
        mCmdExtraPolyConfig->SetGuidance("Set extra polyethylene layer configuration: \"TopOnly\" or \"TopAndSide\" (default:TopAndSide)");
        mCmdExtraPolyConfig->AvailableForStates(G4State_Idle);

        mCmdExtraPolyThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setExtraPolyThickness").c_str(), this));
        mCmdExtraPolyThickness->SetGuidance("Set thickness of the extra polyehtylene layer (external), arg = XXX unit (ex: 3 cm)");
        mCmdExtraPolyThickness->AvailableForStates(G4State_Idle);
    }

    void OuterShieldingMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
        else if(command == mCmdInnerRadius.get())
        {
            mBuilder.SetInnerRadius(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdInnerHeight.get())
        {
            mBuilder.SetInnerHeight(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdLeadThickness.get())
        {
            mBuilder.SetLeadThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdPolyThickness.get())
        {
            mBuilder.SetPolyethyleneThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdExtraPolyLayer.get())
        {
            mBuilder.SetExtraPolyethyleneLayer(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdExtraPolyConfig.get())
        {
            OuterShieldingBuilder::ExtraPolyConfig config;
            if(valueStr == "TopAndSide")
            {
                config = OuterShieldingBuilder::ExtraPolyConfig::TopAndSide;
            }
            else if(valueStr == "TopOnly")
            {
                config = OuterShieldingBuilder::ExtraPolyConfig::TopOnly;
            }
            else
            {
                throw std::runtime_error("OuterShieldingMessenger: Config pass by \"setExtraPolyConfig\" macro command is unknown.");
            }
            mBuilder.SetExtraPolyethyleneConfig(config);
        }
        else if(command == mCmdExtraPolyThickness.get())
        {
            mBuilder.SetExtraPolyethyleneThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
    }
}


