// ********************************************************************
// * Hit.cc                                                    *
// *                                                                  *
// * Definition of Hit class for Crystal                              *
// *                                                                  *
// * Created by: Alexander Leder                                      *
// * aleder@mit.edu                                                   *
// * 23 March 2016                                                    *
// * Updated: 23 March 2016 by Alexander Leder (aleder@mit.edu)       *
// ********************************************************************

#include "Geometry/Hit.hh"

#include "G4SDManager.hh"
#include "G4VVisManager.hh"
#include "G4VisAttributes.hh"
#include "G4Circle.hh"
#include "G4Colour.hh"
#include "G4UnitsTable.hh"


namespace Geometry{

    G4Allocator<Geometry::Hit> HitAllocator;

    std::size_t size(const HitsCollection& collection)
    {
        return collection.GetSize();
    }

    bool empty(const HitsCollection& collection)
    {
        return size(collection) == 0;
    }

    SimuOutput::HitEvent Convert(const Hit& hit)
    {
        SimuOutput::HitEvent hitEvent;

        hitEvent.Edep = hit.GetEdep();
        hitEvent.Time = hit.GetStepTime();
        hitEvent.PDG = hit.GetPDGID();
        hitEvent.IncidentEnergy = hit.GetKE();
        hitEvent.ProcessName = hit.GetCreaProcName();
        G4ThreeVector pos = hit.GetPos();
	hitEvent.Position = {pos.x(), pos.y(), pos.z()};
        G4ThreeVector localPoint = hit.GetPosLocal();
	hitEvent.LocalPosition = {localPoint.x(), localPoint.y(), localPoint.z()};
	 
        return hitEvent;
    }

    bool Hit::operator==(const Hit& right) const
    {
        return this==&right;
    }

    void Hit::Draw()
    {
        G4VVisManager* pVVisManager = G4VVisManager::GetConcreteInstance();
        if(pVVisManager)
        {
            G4Circle circle(position);
            circle.SetScreenSize(2.);
            circle.SetFillStyle(G4Circle::filled);
            G4VisAttributes attribs(G4Colour(1.,0.,0.));
            circle.SetVisAttributes(attribs);
            pVVisManager->Draw(circle);
        }
    }

    void Hit::Print()
    {

        std::ostream& output = std::cout;
        output << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
        output << "  energy deposit: " << G4BestUnit(edep,"Energy")
        << "  position: " << G4BestUnit(position,"Length") << "\n";

        output << "Hit : trackID " << trackID;
        output << " parent " << parentID;
        output << " edep " << edep;
        output << " time " << stepTime;
        output << " particuleName " << particleName;
        output << " pPDGCode " << PDGID;
        output << " detectorID " << detectorID;
	output << " detectorSID " << detectorSID;
        output << " position " << position;
        output << " localPoint " << localPoint;
        output << " procName " << processName;
        output << " creaProcName " << creaProcName;
        output << " vtxVolName " << vtxVolName << "\n";

    }

    std::vector<int> GetHitCollectionsIDs()
    {
        std::vector<int> collectionsIDs;

        auto& table = *G4SDManager::GetSDMpointer()->GetHCtable();
        for(int k = 0; k < table.entries(); ++k)
        {
            auto collectionID =  table.GetCollectionID(table.GetHCname(k));
            if(collectionID >= 0) collectionsIDs.emplace_back(collectionID);
        }

        return collectionsIDs;
    }

}
