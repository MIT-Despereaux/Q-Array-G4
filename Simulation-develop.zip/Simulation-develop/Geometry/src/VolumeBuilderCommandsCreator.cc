#include "Geometry/VolumeBuilderCommandsCreator.hh"
#include "Geometry/VolumeBuilderMessengerHelper.hh"

namespace Geometry
{

    void AddCommandRunner::operator()(VolumeBuilder& builder, const std::string& commandArg)
    {
        std::istringstream input{commandArg};
        std::string type;
        input>>type;
        VolumeBuilderMessengerHelper::RunAddCommand(type, builder, input);
    }

}
