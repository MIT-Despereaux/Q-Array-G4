#include "Geometry/ChoozSiteBuilder.hh"
#include "CLHEP/Units/SystemOfUnits.h"

#include "G4Box.hh"
#include "G4SubtractionSolid.hh"
#include "G4Material.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4SDManager.hh"
#include "G4LogicalVolumeStore.hh"
#include "Geometry/Shapes.hh"

namespace Geometry{

    namespace{

        constexpr double ShellThickness() {

            return 100. * CLHEP::mm;//thin concrete shell until water shield surrounding Inner Veto starts

        }

        G4ThreeVector ConcreteOffset(){

            return {0. ,0. , .5 * ShellThickness()};

        }

        constexpr double ExcavationRadius() {

            return 4350. * CLHEP::mm;//where the Chooz rock ends

        }

        constexpr double ExcavationHeight() {

            return 8500. * CLHEP::mm;//where the Chooz rock ends

        }

        constexpr double ExcavationPedestal() {

            return 750. * CLHEP::mm;//amount of Chooz rock below pit and its concrete shell

        }

        constexpr double PitRadius() {

            return ExcavationRadius() - ShellThickness();

        }

        constexpr double PitHeight() {

            return ExcavationHeight() - ShellThickness();

        }

        constexpr double ExperimentalRadius() {

            return 1000. * CLHEP::mm;//vacuum cylinder around crystal, excavation within the Pit's air/scintillator/water

        }

        constexpr double ExperimentalPedestal() {

            return 2000. * CLHEP::mm;// air/scintillator/water below experimental vacuum cylinder

        }

        constexpr double ExperimentalHeight() {

            return PitHeight() - ExperimentalPedestal();

        }

        G4Box* RockBlock(){

            using CLHEP::m;
            return new G4Box("Rock", 6.*m, 6.*m, 5.*m);

        }

        FilledTube* ExcavationTube(){

            return new FilledTube("ExcavationTube", ExcavationRadius(), ExcavationHeight());

        }

        FilledTube* PitTube(){

            return new FilledTube("PitTube", PitRadius(), PitHeight());

        }


    }

    ChoozBuilder::ChoozBuilder(G4LogicalVolume& mother_):mother(mother_){

    }

    void ChoozBuilder::Build(const HepGeom::Transform3D& transformationToMother){

        BuildPit(transformationToMother);
        BuildShell(transformationToMother);
        BuildPitInnerVolume(transformationToMother, "G4_AIR", ExperimentalRadius());

    }

    void ChoozBuilder::BuildPit(const HepGeom::Transform3D& transformationToMother){

        const G4ThreeVector VerticalExcavationOffset{0., 0., ExcavationPedestal()};

        auto transformation = transformationToMother * G4Translate3D(-VerticalExcavationOffset);
        auto PitSolid = new G4SubtractionSolid("ChoozPit", RockBlock(), ExcavationTube(), nullptr, VerticalExcavationOffset);//translates ExcavationTube up by ExcavationOffset before volume subtraction
        auto PitLog = new G4LogicalVolume(PitSolid, G4Material::GetMaterial("ChoozRock"), "logicalRock");
        new G4PVPlacement(transformation, PitLog, "PVRock", &mother, false, 0, true);

        G4VisAttributes visRock(G4Colour(0.398,0.199,0.));
        PitLog->SetVisAttributes(visRock);

    }

    void ChoozBuilder::BuildShell(const HepGeom::Transform3D& transformationToMother){

        auto ShellSolid = new G4SubtractionSolid("ChoozPit_ConcreteShell", ExcavationTube(), PitTube(), nullptr, ConcreteOffset());//translates PitTube up by ConcreteOffset before volume subtraction
        auto ShellLogical = new G4LogicalVolume(ShellSolid, G4Material::GetMaterial("G4_CONCRETE"), "ConcreteShell_logical");
        new G4PVPlacement(transformationToMother, ShellLogical, "ConcreteShell", &mother, false, 0, true);

        G4VisAttributes visShell(G4Colour(0.625,0.625,0.625));
        ShellLogical->SetVisAttributes(visShell);

    }

    void ChoozBuilder::BuildPitInnerVolume(const HepGeom::Transform3D& transformationToMother, const std::string& material, double experimentalRadius) {

        using CLHEP::mm;
        // Offset include to have top of water shield line up with top of pit
        const G4ThreeVector ExperimentalOffset(0., 0., .5 * ExperimentalPedestal());

        auto ExperimentalVolume = new FilledTube("ExperimentalVolume", experimentalRadius, ExperimentalHeight());

        auto transformation = transformationToMother * G4Translate3D(ConcreteOffset());
        auto PitInnerVolumeSolid = new G4SubtractionSolid("PitInnerVolume", PitTube(), ExperimentalVolume, nullptr, ExperimentalOffset);
        auto PitInnerVolumeLogical = new G4LogicalVolume(PitInnerVolumeSolid, G4Material::GetMaterial(material), "PitInnerVolume");
        new G4PVPlacement(transformation, PitInnerVolumeLogical, "PitInnerVolume", &mother, false, 0, true);

        G4VisAttributes visTube(G4Colour(1.,1.,0.,0.4));
        visTube.SetForceAuxEdgeVisible(true);
        PitInnerVolumeLogical->SetVisAttributes(visTube);
    }

    void ChoozBuilder::SetPitInnerVolumeMaterial(const std::string& material) {

        G4LogicalVolume* outerDetector = G4LogicalVolumeStore::GetInstance()->GetVolume("PitInnerVolume");
        outerDetector->SetMaterial(G4Material::GetMaterial(material));

    }

}
