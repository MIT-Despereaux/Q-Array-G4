
#include "Geometry/OuterShieldingBuilder.hh"

/// Standard includes
#include <vector>

/// Geant4 includes
#include "G4Material.hh"
#include "G4VSolid.hh"
#include "G4SubtractionSolid.hh"

/// Project includes
#include "Geometry/MaterialColour.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/Cryostat.hh"
#include "SimuOutput/InfoHeaderWriter.hh"


namespace Geometry
{
    void OuterShieldingBuilder::SetConfig(GeometryConfiguration config)
    {
    	mConfig = config;
    }

    OuterShieldingBuilder::OuterShieldingBuilder(G4LogicalVolume &mother): mMother(mother)
    {

    }

    void OuterShieldingBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
    }

    void OuterShieldingBuilder::SetInnerRadius(double innerRadius)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetInnerRadius forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetInnerRadius forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetInnerRadius forbidden by GeometryConfiguration::RicochetRUN014");
        mInnerRadius = innerRadius;
    }

    void OuterShieldingBuilder::SetInnerHeight(double innerHeight)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetInnerHeight forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetInnerHeight forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetInnerHeight forbidden by GeometryConfiguration::RicochetRUN014");
        mInnerHeight = innerHeight;
    }

    void OuterShieldingBuilder::SetLeadThickness(double leadThickness)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetLeadThickness forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetLeadThickness forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetLeadThickness forbidden by GeometryConfiguration::RicochetRUN014");
        mLeadThickness = leadThickness;
    }

    void OuterShieldingBuilder::SetPolyethyleneThickness(double polyThickness)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetPolyethyleneThickness forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetPolyethyleneThickness forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetPolyethyleneThickness forbidden by GeometryConfiguration::RicochetRUN014");
        mPolyThickness = polyThickness;
    }

    void OuterShieldingBuilder::SetExtraPolyethyleneLayer(bool activate)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetExtraPolyethyleneLayer forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetExtraPolyethyleneLayer forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetExtraPolyethyleneLayer forbidden by GeometryConfiguration::RicochetRUN014");
        mExtraPolyLayer = activate;
    }

    void OuterShieldingBuilder::SetExtraPolyethyleneConfig(OuterShieldingBuilder::ExtraPolyConfig config)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetExtraPolyethyleneConfig forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetExtraPolyethyleneConfig forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetExtraPolyethyleneConfig forbidden by GeometryConfiguration::RicochetRUN014");
        mExtraPolyConfig = config;
    }

    void OuterShieldingBuilder::SetExtraPolyethyleneThickness(double polyThickness)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetExtraPolyethyleneThickness forbidden by GeometryConfiguration::RicochetFinalDesign");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetExtraPolyethyleneThickness forbidden by GeometryConfiguration::RicochetRUN013");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetExtraPolyethyleneThickness forbidden by GeometryConfiguration::RicochetRUN014");
        mExtraPolyThickness = polyThickness;
    }


    void OuterShieldingBuilder::Build(const HepGeom::Transform3D& transformationToMother)
    {
        if(mVerbosity > 0) std::cout << "Build OuterShielding geometry" << std::endl;

        VolumeAdder factory(mMother, transformationToMother);
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
	{
	  // args are : phiStart, phiTotal, numSide, numZplanes, zPlane[], rInner[], rOuter[] for G4Polyhedra
	  G4ThreeVector position_OuterShielding = {0, 0, 0};
	  int nSides = 8;
	  constexpr int nPlans = 2;
	  //double phiStart = 0. ; // Original
	  // rotation de 29.7 degres to make an angle between the D19 wall and the rails direction.
	  // measurment on site by Renuad Serra. 
	  double phiStart = 29.7*CLHEP::pi/180.;
	  
	  double zLeadBot[nPlans]  = {-mLeadThickness-mPolyLowerThickness,-mPolyLowerThickness};
	  double riLeadBot[nPlans] = {0,0};
	  double roLeadBot[nPlans] = {mInnerRadius+mPolyThickness+mLeadThickness, mInnerRadius+mPolyThickness+mLeadThickness};
	  factory.Add<G4Polyhedra>("OuterShielding_Lead_Bot", "LeadOuter_Bottom", position_OuterShielding, phiStart, CLHEP::twopi, nSides, nPlans, zLeadBot, riLeadBot, roLeadBot);
	  
	  double zLeadMid[nPlans]  = {-mPolyLowerThickness,mInnerHeight};
	  double riLeadMid[nPlans] = {mInnerRadius+mPolyThickness,mInnerRadius+mPolyThickness};
	  double roLeadMid[nPlans] = {mInnerRadius+mPolyThickness+mLeadThickness, mInnerRadius+mPolyThickness+mLeadThickness};
	  factory.Add<G4Polyhedra>("OuterShielding_Lead_Mid", "LeadOuter_Mid", position_OuterShielding, phiStart, CLHEP::twopi, nSides, nPlans, zLeadMid, riLeadMid, roLeadMid);
	  
	  double zPEBot[nPlans]  = {-mPolyLowerThickness,0};
	  double riPEBot[nPlans] = {0,0};
	  double roPEBot[nPlans] = {mInnerRadius+mPolyThickness,mInnerRadius+mPolyThickness};
	  factory.Add<G4Polyhedra>("OuterShielding_Poly_Bot", "PolOuter_Bottom", position_OuterShielding, phiStart, CLHEP::twopi, nSides, nPlans, zPEBot, riPEBot, roPEBot);
	    
	  double zPEMid[nPlans]  = {0,mInnerHeight};
	  double riPEMid[nPlans] = {mInnerRadius,mInnerRadius};
	  double roPEMid[nPlans] = {mInnerRadius+mPolyThickness,mInnerRadius+mPolyThickness};
	  factory.Add<G4Polyhedra>("OuterShielding_Poly_Mid", "PolOuter_Mid", position_OuterShielding, phiStart, CLHEP::twopi, nSides, nPlans, zPEMid, riPEMid, roPEMid);
	  
	  
	  // slightly different placement : hole is circular
	  double zLeadTop[nPlans]  = {mInnerHeight,mInnerHeight+mLeadThickness};
	  double riLeadTop[nPlans] = {0,0};//{mInnerRadius,mInnerRadius};
	  double roLeadTop[nPlans] = {mInnerRadius+mPolyThickness+mLeadThickness, mInnerRadius+mPolyThickness+mLeadThickness};
	  G4VSolid* fullLeadTop_solid = new G4Polyhedra("LeadTopFull_solid", phiStart, CLHEP::twopi, nSides, nPlans, zLeadTop, riLeadTop, roLeadTop);
	  G4VSolid* holeLeadTop = new G4Tubs("holeLeadTop", 0, mInnerRadius, mLeadThickness, 0., CLHEP::twopi);
	  G4SubtractionSolid* LeadTop_solid = new G4SubtractionSolid("LeadTop_solid",fullLeadTop_solid,holeLeadTop,nullptr,G4ThreeVector{0,0,mInnerHeight+mLeadThickness/2});
	  auto LeadTop = factory.PlaceSolid(LeadTop_solid,"OuterShielding_Lead_Top","LeadOuter_Top",G4Transform3D(CLHEP::HepRotation(0,0,0),position_OuterShielding));
	  SetColourFromMaterial(LeadTop.Logical(), "LeadOuter_Top");
	  
	  double zExtraPE[nPlans]  = {mInnerHeight+mLeadThickness,mInnerHeight+mLeadThickness+mExtraPolyThickness};
	  double riExtraPE[nPlans] = {0,0};
	  double roExtraPE[nPlans] = {mInnerRadius+mPolyThickness+mLeadThickness,mInnerRadius+mPolyThickness+mLeadThickness};
	  G4VSolid* fullExtraPE_solid = new G4Polyhedra("ExtraPEFull_solid", phiStart, CLHEP::twopi, nSides, nPlans, zExtraPE, riExtraPE, roExtraPE);
	  G4VSolid* holeExtraPE = new G4Tubs("holeExtraPE", 0, mInnerRadius, mExtraPolyThickness, 0., CLHEP::twopi);
	  G4SubtractionSolid* ExtraPE_solid = new G4SubtractionSolid("ExtraPE_solid",fullExtraPE_solid,holeExtraPE,nullptr,G4ThreeVector{0,0,mInnerHeight+mLeadThickness+mExtraPolyThickness/2});
	  auto ExtraPE = factory.PlaceSolid(ExtraPE_solid,"OuterShielding_ExtraPoly","PolOuter_Extra",G4Transform3D(CLHEP::HepRotation(0,0,0),position_OuterShielding));
	  SetColourFromMaterial(ExtraPE.Logical(), "PolOuter_Top");
	    
	}
	
    // I wish to remove this part, this became irrelevant and makes the code less clear
	else
	{
	    double innerRadius_Poly = mInnerRadius;
            double height_Poly = mInnerHeight;
            double thickness_Poly = mPolyThickness;
            G4ThreeVector position_Poly = {0, 0, 0};
            G4ThreeVector position_Lead = position_Poly + G4ThreeVector(0, 0, -mPolyThickness);
            G4ThreeVector position_Lead_Top = position_Lead + G4ThreeVector(0, 0, mInnerHeight + mPolyThickness + mLeadThickness/2.);
            factory.Add<Bucket>("OuterShielding_Poly", "PolBor3pc", position_Poly, innerRadius_Poly, thickness_Poly, height_Poly);

            double innerRadius_Lead = innerRadius_Poly + thickness_Poly;
            double height_Lead = height_Poly + thickness_Poly;
            double thickness_Lead = mLeadThickness;
            VolumePack leadSideVolume = factory.Add<Bucket>("OuterShielding_Lead", "Lead", position_Lead, innerRadius_Lead, thickness_Lead, height_Lead);
            VolumePack leadTopVolume = factory.Add<Tube>("OuterShielding_Lead_Top", "Lead", position_Lead_Top, innerRadius_Poly, innerRadius_Lead + thickness_Lead, thickness_Lead);

            double thickness_Veto = 1*CLHEP::mm;
            VolumeAdder factory_veto_side(leadSideVolume.Logical());
            VolumeAdder factory_veto_top(leadTopVolume.Logical());
	    
            // outdated veto
	    if(mBuildInnerVeto)
            {
                double innerRadius_Veto = innerRadius_Lead;
                double height_Veto = height_Lead;
                G4ThreeVector position_Veto_Side = {0, 0, 0};
                factory_veto_side.Add<Bucket>("OuterShielding_InnerVeto_Side", "PolBor3pc", position_Veto_Side, innerRadius_Veto, thickness_Veto, height_Veto);

                G4ThreeVector position_Veto_Top = G4ThreeVector{0, 0, -(thickness_Lead/2. - thickness_Veto/2.)};
                double outerRadius_Veto = innerRadius_Veto + thickness_Veto;
                factory_veto_top.Add<Tube>("OuterShielding_InnerVeto_Top", "PolBor3pc", position_Veto_Top, innerRadius_Poly, outerRadius_Veto, thickness_Veto);
            }

            if(mBuildInsideLeadVeto)
            {
                double innerRadius_Veto = innerRadius_Lead + thickness_Lead/2.;
                double height_Veto = height_Lead + thickness_Lead/2.;
                G4ThreeVector position_Veto_Side = {0, 0, -thickness_Lead/2.};

                factory_veto_side.Add<Bucket>("OuterShielding_InsideLeadVeto_Side", "PolBor3pc", position_Veto_Side, innerRadius_Veto, thickness_Veto, height_Veto);

                G4ThreeVector position_Veto_Top = G4ThreeVector{0, 0, 0};
                double outerRadius_Veto = innerRadius_Veto + thickness_Veto;
                factory_veto_top.Add<Tube>("OuterShielding_InsideLeadVeto_Top", "PolBor3pc", position_Veto_Top, innerRadius_Poly, outerRadius_Veto, thickness_Veto);

                G4ThreeVector position_Veto_TopSide = G4ThreeVector{0, 0, -thickness_Lead/4. - thickness_Veto/4.};
                factory_veto_top.Add<Tube>("OuterShielding_InsideLeadVeto_TopSide", "PolBor3pc", position_Veto_TopSide, innerRadius_Veto, outerRadius_Veto, thickness_Lead/2. - thickness_Veto/2.);
            }

            if(mBuildOuterVeto)
            {
                double innerRadius_Veto = innerRadius_Lead + thickness_Lead - thickness_Veto;
                double height_Veto = height_Lead + thickness_Lead - thickness_Veto;
                G4ThreeVector position_Veto_Side = {0, 0, -thickness_Lead + thickness_Veto};
                factory_veto_side.Add<Bucket>("OuterShielding_OuterVeto_Side", "PolBor3pc", position_Veto_Side, innerRadius_Veto, thickness_Veto, height_Veto);

                G4ThreeVector position_Veto_Top = G4ThreeVector{0, 0, thickness_Lead/2. - thickness_Veto/2.};
                double outerRadius_Veto = innerRadius_Veto + thickness_Veto;
                factory_veto_top.Add<Tube>("OuterShielding_OuterVeto_Top", "PolBor3pc", position_Veto_Top, innerRadius_Poly, outerRadius_Veto, thickness_Veto);

                G4ThreeVector position_Veto_TopSide = G4ThreeVector{0, 0, -thickness_Veto/2.};
                factory_veto_top.Add<Tube>("OuterShielding_OuterVeto_TopSide", "PolBor3pc", position_Veto_TopSide, innerRadius_Veto, outerRadius_Veto, thickness_Lead - thickness_Veto);
            }

            if(mExtraPolyLayer)
            {
                if(mExtraPolyConfig == ExtraPolyConfig::TopOnly)
                {
                    double innerRadius_ExtraPoly = mInnerRadius;
                    double outerRadius_ExtraPoly = mInnerRadius + mPolyThickness + mLeadThickness;
                    G4ThreeVector position_ExtraPoly = position_Lead_Top + G4ThreeVector(0, 0, mLeadThickness/2. + mExtraPolyThickness/2.);
                    factory.Add<Tube>("OuterShielding_ExtraPoly", "PolBor3pc", position_ExtraPoly, innerRadius_ExtraPoly, outerRadius_ExtraPoly, mExtraPolyThickness);
                }
                else //(mExtraPolyConfig == ExtraLayerConfig::TopAndSide)
                {
                    double h = height_Lead + mLeadThickness * 2;
                    double e = mExtraPolyThickness;
                    double r = innerRadius_Lead + mLeadThickness;
                    double rs = mInnerRadius;
                    constexpr int nbPlans = 4;
                    double z[nbPlans]  = { -h,   0,   0,   e};
                    double ri[nbPlans] = {  r,   r,  rs,  rs};
                    double ro[nbPlans] = {r+e, r+e, r+e, r+e};
                    G4ThreeVector position_ExtraPoly = position_Lead_Top + G4ThreeVector(0, 0, mLeadThickness/2.);
                    factory.Add<G4Polycone>("OuterShielding_ExtraPoly", "PolBor3pc", position_ExtraPoly, 0, CLHEP::twopi, nbPlans, z, ri, ro);
                }
            }
	} 
	

        if(mVerbosity > 0) std::cout << "OuterShielding constructed" << std::endl;
    }

    void OuterShieldingBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("OuterShielding", "Geometry::OuterShieldingBuilder");
        writer.SetKeyValue("Position_X", mPosition.x());
        writer.SetKeyValue("Position_Y", mPosition.y());
        writer.SetKeyValue("Position_Z", mPosition.z());
        writer.SetKeyValue("InitialInnerRadius", mInnerRadius);
        writer.SetKeyValue("LeadThickness", mLeadThickness);
        writer.SetKeyValue("PolyThickness", mPolyThickness);
        writer.SetKeyValue("ExtraPolyLayer", mExtraPolyLayer);
        writer.SetKeyValue("ExtraPolyThickness", mExtraPolyThickness);
        writer.WriteIn(directory);
    }

    double OuterShieldingBuilder::OuterRadius() const
    {
        if(mExtraPolyLayer && mExtraPolyConfig != ExtraPolyConfig::TopOnly)
        {
            return mInnerRadius + mLeadThickness + mPolyThickness + mExtraPolyThickness;
        }
        else
        {
            return mInnerRadius + mLeadThickness + mPolyThickness;
        }
    }

    double OuterShieldingBuilder::TotalThickness() const
    {
        return mLeadThickness + mPolyThickness;
    }

}
