#include "Geometry/VolumePack.hh"

namespace Geometry{

    G4LogicalVolume* VolumePack::Logical(){

        return Get<G4LogicalVolume>();

    }

    G4PVPlacement* VolumePack::Physical(){

        return Get<G4PVPlacement>();

    }

}
