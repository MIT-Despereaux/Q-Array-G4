// ********************************************************************
// * SensitiveDetector.cc                                      *
// *                                                                  *
// * Class for making the Crystal volume sensitive                    *
// *                                                                  *
// * Created by: Alexander Leder                                      *
// * adama@mit.edu                                                    *
// * 23 March 2016                                                    *
// ********************************************************************

#include "Geometry/SensitiveDetector.hh"
#include "Geometry/Hit.hh"
#include "SimuOutput/VolumeHasher.hh"
#include "G4VProcess.hh"
#include "G4HCofThisEvent.hh"
#include "G4Step.hh"
#include "G4ThreeVector.hh"
#include "G4SDManager.hh"
#include "G4Track.hh"

namespace Geometry{

    void SetPositions(Hit& hit, G4Step& step){

        auto prePoint = step.GetPreStepPoint()->GetPosition();
        auto postPoint = step.GetPostStepPoint()->GetPosition();
        hit.SetPrePosition(prePoint);
        hit.SetPostPosition(postPoint);
        hit.SetPos(postPoint);
        // randomize point of energy deposition
        auto pointOfEnergyDeposition = prePoint + CLHEP::HepRandom::getTheEngine()->flat()*(postPoint - prePoint);
        hit.SetLocalPos(step.GetPreStepPoint()->GetTouchable()->GetHistory()->GetTopTransform().TransformPoint(pointOfEnergyDeposition));

    }

    void SetProcesses(Hit& hit, G4Step& step){

        auto process = step.GetTrack()->GetCreatorProcess();
        if(process) hit.SetProcName(process->GetProcessName());
        else hit.SetProcName("none");

        auto creaProc= step.GetTrack()->GetCreatorProcess();
        if(creaProc) hit.SetCreaProcName(creaProc->GetProcessName());
        else hit.SetCreaProcName("none");

    }

    SensitiveDetector* MakeSensitiveDetector(G4LogicalVolume& logicVolume, const std::string& sensitiveVolumeName)
    {
        auto sensitive = new SensitiveDetector(sensitiveVolumeName);
        G4SDManager::GetSDMpointer()->AddNewDetector(sensitive);
        logicVolume.SetSensitiveDetector(sensitive);
        return sensitive;
    }

    SensitiveDetector::SensitiveDetector(G4String name)
    :G4VSensitiveDetector(std::move(name)),
    HitCollectionID(-1)
    {
        collectionName.insert(SensitiveDetectorName+"_StandardHitCollection");//Geant4 actually passes variables down for you to fill by inheritance :facepalm
    }

    void SensitiveDetector::Initialize(G4HCofThisEvent* HitCollectionOfEvent)
    {
        fHitCollection = new Geometry::HitsCollection(SensitiveDetectorName, collectionName[0]);
        if(HitCollectionID<0) HitCollectionID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);//apparently GetCollectionID is slow
        HitCollectionOfEvent->AddHitsCollection( HitCollectionID, fHitCollection );
    }

    G4bool SensitiveDetector::ProcessHits(G4Step* aStep, G4TouchableHistory*)
    {
        double energyDeposited = aStep->GetTotalEnergyDeposit();
        if(!energyDeposited) return true;

        auto hit = new Geometry::Hit();
        hit->SetEdep(energyDeposited);
        hit->SetPDGID(aStep->GetTrack()->GetDefinition()->GetPDGEncoding());
        hit->SetTrackID(aStep->GetTrack()->GetTrackID());
        hit->SetVolume(aStep->GetTrack()->GetVolume()->GetName());
        hit->SetMomentum(aStep->GetTrack()->GetMomentum());
        hit->SetKE(aStep->GetTrack()->GetKineticEnergy());
        hit->SetVertexKE(aStep->GetTrack()->GetVertexKineticEnergy());
        hit->SetParentID(aStep->GetTrack()->GetParentID());
        hit->SetTrackLength(aStep->GetTrack()->GetTrackLength());
        hit->SetStepTime(aStep->GetTrack()->GetGlobalTime());
        hit->SetParticleName(aStep->GetTrack()->GetDefinition()->GetParticleName());
        auto volume = aStep->GetPreStepPoint()->GetTouchable()->GetVolume();
        hit->SetDetectorID(SimuOutput::VolumeHasher::Hash(volume->GetName()));
        hit->SetVtxVolName (aStep->GetPreStepPoint()->GetTouchable()->GetVolume()->GetLogicalVolume()->GetName());

	hit->SetDetectorSID(SimuOutput::BuildVolSID(volume->GetName()));
			    
        SetPositions(*hit, *aStep);
        SetProcesses(*hit, *aStep);

        G4TrackVector& secondaries = *aStep->GetfSecondary();
        std::vector<G4int> secondaryTracks, secondaryPDGIDs;
        for(unsigned jTrack = 0; jTrack < secondaries.size(); ++jTrack)
        {
            secondaryPDGIDs.push_back(secondaries[jTrack]->GetDefinition()->GetPDGEncoding());
            secondaryTracks.push_back(secondaries[jTrack]->GetTrackID());
        }
        hit->SetSecondaryPDGID(secondaryPDGIDs);
        hit->SetSecondaryTrackID(secondaryTracks);
        fHitCollection->insert(hit);
        return true;
    }

}
