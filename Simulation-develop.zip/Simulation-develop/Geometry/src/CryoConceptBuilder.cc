/**************************************************************************
* @file CryoConceptBuilder.cc
* @author Valérian Sibille <vsibille@mit.edu>
* @date 16 Apr 2019
* @brief Class to add a CryoConcept Hexadry XS UQT fridge to a logical
* volume
* ************************************************************************/

#include "CLHEP/Units/SystemOfUnits.h"
#include "Geometry/CryoConceptBuilder.hh"
#include "Geometry/IdenticalVolumeAdder.hh"
#include "Geometry/Shapes.hh"

namespace Geometry{

    using CLHEP::mm;

    CryoConceptBuilder::CryoConceptBuilder(G4LogicalVolume& mother_):mother(mother_){

    }

    void CryoConceptBuilder::BuildPlates(const HepGeom::Transform3D& transformationToMother){

        IdenticalVolumeAdder<Tube> tubeAdder{mother, transformationToMother};
        // plates are numbered from top to bottom
        tubeAdder.Add("FridgeColdPlate_Can4_1", "G4_Cu", {0,0,-98.5*mm}, 0*mm,  0.5*250*mm,  2*1.5*mm);
        tubeAdder.Add("FridgeColdPlate_Can4_2", "G4_Cu", {0,0,-173.2*mm},0*mm,  0.5*250*mm,  2*2*mm);

        tubeAdder.Add("FridgeColdPlateConnector1", "G4_KAPTON", {50*mm, 60*mm, 478*mm}, 0*mm,  0.5*35*mm,  2*116*mm);
        tubeAdder.Add("FridgeColdPlateConnector2", "G4_KAPTON", {35*mm,35*mm, 252.5*mm},0*mm,  0.5*35*mm,  2*103.5*mm);
        tubeAdder.Add("FridgeColdPlateConnector3", "G4_KAPTON", {20*mm, 20*mm, 77.5*mm}, 0*mm,  0.5*40*mm,  2*66.5*mm);
        tubeAdder.Add("FridgeColdPlateConnector4", "G4_KAPTON", {30*mm,30*mm, -45.5*mm},0*mm,  0.5*35*mm,  2*51.5*mm);
        tubeAdder.Add("FridgeColdPlateConnector5", "G4_KAPTON", { 30*mm,30*mm,-135.6*mm},0*mm,  0.5*35*mm,  2*35.6*mm);

    }

    void CryoConceptBuilder::BuildCans(const HepGeom::Transform3D& transformationToMother){

        IdenticalVolumeAdder<Tube> tubeAdder{mother, transformationToMother};

        tubeAdder.Add("FridgeCan1", "G4_STAINLESS-STEEL", {0, 0, 61*mm}, 0.5*364*mm, 0.5*368*mm, 2*533*mm);
        tubeAdder.Add("FridgeCan1BottomDisk", "G4_STAINLESS-STEEL", {0, 0, -475*mm}, 0*mm,  0.5*370*mm,  2*3*mm);
        tubeAdder.Add("FridgeCan1TopDisk", "G4_STAINLESS-STEEL", {0, 0, 602*mm}, 0*mm,  0.5*380*mm,  2*8*mm);

        tubeAdder.Add("FridgeCan2", "G4_Cu", {0, 0, -54*mm}, 0.5*332*mm,  0.5*335*mm,  2*410*mm);
        tubeAdder.Add("FridgeCan2BottomDisk", "G4_Cu", { 0, 0, -466*mm}, 0*mm,  0.5*336*mm,  2*2*mm);
        tubeAdder.Add("FridgeCan2TopDisk", "G4_Cu", {0, 0, 359*mm}, 0*mm,  0.5*360*mm,  2*3*mm);

        tubeAdder.Add("FridgeCan3", "G4_Cu", {0, 0, -158*mm}, 0.5*296*mm,  0.5*299*mm,  2*302*mm);
        tubeAdder.Add("FridgeCan3BottomDisk", "G4_Cu", {0, 0, -462*mm}, 0*mm,  0.5*301*mm,  2*2*mm);
        tubeAdder.Add("FridgeCan3TopDisk", "G4_Cu", {0, 0, 146.5*mm}, 0*mm,  0.5*323*mm,  2*2.5*mm);

        tubeAdder.Add("FridgeCan4", "G4_Cu", {0, 0, -225*mm}, 0.5*263*mm,  0.5*266*mm,  2*231*mm);
        tubeAdder.Add("FridgeCan4BottomDisk", "G4_Cu", {0,0,-458*mm},0*mm,  0.5*268*mm,  2*2*mm);
        tubeAdder.Add("FridgeCan4TopDisk", "G4_Cu", { 0,0,8.5*mm}, 0*mm,  0.5*284*mm,  2*2.5*mm);

        tubeAdder.Add("FridgeCan4", "G4_Cu", {0, 0, -225*mm}, 0.5*263*mm,  0.5*266*mm,  2*231*mm);
        tubeAdder.Add("FridgeCan4BottomDisk", "G4_Cu", {0,0,-458*mm},0*mm,  0.5*268*mm,  2*2*mm);
        tubeAdder.Add("FridgeCan4TopDisk", "G4_Cu", { 0,0,8.5*mm}, 0*mm,  0.5*284*mm,  2*2.5*mm);

    }

    void CryoConceptBuilder::Build(const HepGeom::Transform3D& transformationToMother)
    {
        BuildCans(transformationToMother);
        BuildPlates(transformationToMother);
    }

}
