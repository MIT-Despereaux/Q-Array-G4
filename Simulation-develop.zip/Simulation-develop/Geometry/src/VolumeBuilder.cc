#include "Geometry/VolumeBuilder.hh"

namespace Geometry
{

    VolumeBuilder::VolumeBuilder(G4LogicalVolume& mother_)
    :mother(mother_)
    {}

    void VolumeBuilder::ClearQueue()
    {
        queuedCalls.clear();
    }

}
