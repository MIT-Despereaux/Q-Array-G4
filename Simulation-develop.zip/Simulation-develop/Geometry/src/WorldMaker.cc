#include "G4VisAttributes.hh"
#include "G4LogicalVolume.hh"
#include "Geometry/WorldMaker.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/Shapes.hh"

namespace Geometry{

    VolumePack MakeWorld(double worldLength){

        auto world = VolumeAdder{}.Add<FilledCube>("World", "G4_Galactic", {}, worldLength);
        world.Logical()->SetVisAttributes(G4VisAttributes::GetInvisible());
        return world;
    }

}
