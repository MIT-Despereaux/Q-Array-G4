#include "Geometry/BasicVolumeAdder.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4NistManager.hh"
#include "G4Transform3D.hh"

namespace Geometry{

    VolumePack BasicVolumeAdder::PlaceSolid(G4VSolid* solid, const G4String& name, const G4String& material, const G4Transform3D& transformation)
    {
        auto logicalVolume = new G4LogicalVolume(solid, G4NistManager::Instance()->FindOrBuildMaterial(material), name+"_logic");
        auto physicalVolume = new G4PVPlacement(fTransformation * transformation, logicalVolume, name+"_physical", fMother, false, 0, true);
        return VolumePack{logicalVolume, physicalVolume};
    }

    BasicVolumeAdder::BasicVolumeAdder(G4LogicalVolume& mother, const G4ThreeVector& offsetToMother, const CLHEP::HepRotation& rotationToMother)
    :BasicVolumeAdder(&mother, offsetToMother, rotationToMother)
    { }

    BasicVolumeAdder::BasicVolumeAdder(G4LogicalVolume& mother, G4Transform3D transformation)
    :BasicVolumeAdder(&mother, std::move(transformation))
    { }

    BasicVolumeAdder::BasicVolumeAdder(G4LogicalVolume* mother, const G4ThreeVector& offsetToMother, const CLHEP::HepRotation& rotationToMother)
    :
        fMother(mother),
        fTransformation(rotationToMother, offsetToMother)
    { }

    BasicVolumeAdder::BasicVolumeAdder(G4LogicalVolume* mother, G4Transform3D transformation)
    :
        fMother(mother),
        fTransformation(std::move(transformation))
    { }
}
