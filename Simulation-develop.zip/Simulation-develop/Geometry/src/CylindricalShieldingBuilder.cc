#include "Geometry/CylindricalShieldingBuilder.hh"

/// Standard includes
#include <vector>

/// Geant4 includes
#include "G4Polycone.hh"
#include "G4AssemblyVolume.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"

/// Custom includes
#include "SimuOutput/InfoHeaderWriter.hh"
#include "Geometry/MaterialColour.hh"

namespace Geometry
{

CylindricalShieldingBuilder::CylindricalShieldingBuilder(G4LogicalVolume &mother): mMother(mother)
{

}

void CylindricalShieldingBuilder::SetInitialHeight(double height)
{
    mInitialHeight = height;
}

void CylindricalShieldingBuilder::SetInitialInnerRadius(double radius)
{
    mInitialInnerRadius = radius;
}

void CylindricalShieldingBuilder::AddLayer(double thickness, std::string materialName)
{
    mThickness.push_back(thickness);
    mMaterialName.push_back(materialName);
    ++mNbLayers;
}

void CylindricalShieldingBuilder::Build(HepGeom::Transform3D transformation)
{
    if (mVerbosity > 0) std::cout << "> Build cylindrical shielding geometry" << std::endl;

    G4AssemblyVolume* cylindricalShieldingVolumes = new G4AssemblyVolume();

    G4ThreeVector relativePosition(0, 0, 0);

    double currentHalfHeight = mInitialHeight / 2;
    double currentInnerRadius = mInitialInnerRadius;
    for(unsigned int iLayer = 0; iLayer < mNbLayers; ++iLayer)
    {
        std::string material = mMaterialName[iLayer];
        double t = mThickness[iLayer]; /// thickness
        double hh = currentHalfHeight; /// half height
        double ri = currentInnerRadius; /// inner radius
        double ro = currentInnerRadius + t; /// outer radius

        constexpr int nbEdges = 6;
        const double z[nbEdges]    = {-hh - t, -hh, -hh,  hh,  hh, hh + t};
        const double rIn[nbEdges]  = {      0,   0,  ri,  ri,   0,      0};
        const double rOut[nbEdges] = {     ro,  ro,  ro,  ro,  ro,     ro};
        G4Polycone* solid = new G4Polycone(std::string("solid_Layer_") + material + std::to_string(iLayer), 0, 2*M_PI, nbEdges, z, rIn, rOut);
        auto logic = new G4LogicalVolume(solid, G4Material::GetMaterial(material), std::string("CylindricalShieding_") + material + std::to_string(iLayer));

        SetColourFromMaterial(logic, material);

        cylindricalShieldingVolumes->AddPlacedVolume(logic, relativePosition, 0);

        currentHalfHeight += mThickness[iLayer];
        currentInnerRadius += mThickness[iLayer];
    }

    cylindricalShieldingVolumes->MakeImprint(&mMother, transformation);

    if (mVerbosity > 0) std::cout << "Cylindrical shielding constructed." << std::endl;
}

void CylindricalShieldingBuilder::Write(TDirectory& directory) const
{
    InfoHeaderWriter writer("CylindricalShielding", "BkgShielding::CylindricalShielding");
    writer.SetKeyValue("InitialHeight", mInitialHeight);
    writer.SetKeyValue("InitialInnerRadius", mInitialInnerRadius);
    writer.SetKeyValue("NbLayers", mNbLayers);
    writer.SetKeyValue("Thickness", mThickness);
    writer.SetKeyValue("MaterialName", mMaterialName);
    writer.WriteIn(directory);
}

}
