#include "Geometry/RingInnerShieldingMessenger.hh"

/// Geant4 includes
#include "G4Tokenizer.hh"

/// Project includes
#include "Geometry/RingInnerShieldingBuilder.hh"
#include "Geometry/RunBuildCommand.hh"

namespace Geometry
{
    RingInnerShieldingMessenger::RingInnerShieldingMessenger(RingInnerShieldingBuilder& ringinnershielding, std::string cmdPrefixPath) : mRingInnerShielding(ringinnershielding)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("RingInnerShielding command directory");

        mCmdBuild.reset(new G4UIcmdWithAString((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build rings of inner shielding between cryostat screens");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);

        mCmdSetThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setThickness").c_str(), this));
        mCmdSetThickness->SetGuidance("Set vertical shielding thickness");
        mCmdSetThickness->SetParameterName("val",false);
        mCmdSetThickness->SetRange("val>=0");
        mCmdSetThickness->AvailableForStates(G4State_Idle);

        mCmdSetSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setSpacing").c_str(), this));
        mCmdSetSpacing->SetGuidance("Set spacing between ring and outer screen");
        mCmdSetSpacing->SetParameterName("val",false);
        mCmdSetSpacing->SetRange("val>=0");
        mCmdSetSpacing->AvailableForStates(G4State_Idle);

        mCmdSetPolyContractionFactor.reset(new G4UIcmdWithADouble((cmdPrefixPath + "setPolyContractionFactor").c_str(), this));
        mCmdSetPolyContractionFactor->SetGuidance("Set polyethylene contraction factor of polyethylene (default no contraction: val = 0)");
        mCmdSetPolyContractionFactor->SetParameterName("val",false);
        mCmdSetPolyContractionFactor->SetRange("0 <= val && val < 1 ");
        mCmdSetPolyContractionFactor->AvailableForStates(G4State_Idle);

        mCmdAddRing.reset(new G4UIcommand((cmdPrefixPath + "addRing").c_str(), this));
        mCmdAddRing->SetGuidance("Set vertical shielding thickness");
        mCmdAddRing->SetParameter(new G4UIparameter("minRadius", 'd', false));
        mCmdAddRing->SetParameter(new G4UIparameter("maxRadius", 'd', false));
        mCmdAddRing->SetRange("minRadius >= 0 && maxRadius >= 0");
        G4UIparameter* parUnit = new G4UIparameter("unit", 's', false);
        parUnit->SetParameterCandidates(G4UIcommand::UnitsList(G4UIcommand::CategoryOf("m")));
        mCmdAddRing->SetParameter(parUnit);
        mCmdAddRing->SetParameter(new G4UIparameter("materail", 's', true));
        mCmdAddRing->SetParameter(new G4UIparameter("zShift", 'd', true));
        G4UIparameter* parUnitShift = new G4UIparameter("unitShift", 's', true);
        parUnitShift->SetParameterCandidates(G4UIcommand::UnitsList(G4UIcommand::CategoryOf("m")));
        mCmdAddRing->SetParameter(parUnitShift);
        mCmdAddRing->SetParameter(new G4UIparameter("length", 'd', true));
        G4UIparameter* parUnitLength = new G4UIparameter("unitLength", 's', true);
        parUnitLength->SetParameterCandidates(G4UIcommand::UnitsList(G4UIcommand::CategoryOf("m")));
        mCmdAddRing->SetParameter(parUnitLength);
        mCmdAddRing->AvailableForStates(G4State_Idle);

        mCmdSetTopRingOrigin.reset(new G4UIcmdWithABool((cmdPrefixPath + "setTopRingOrigin").c_str(), this));
        mCmdSetTopRingOrigin->SetGuidance("Set top ring as their origin");
        mCmdSetTopRingOrigin->AvailableForStates(G4State_Idle);

        mCmdBuildMylar.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildMylar").c_str(), this));
        mCmdBuildMylar->SetGuidance("Build Mylar around PE rings");
        mCmdBuildMylar->AvailableForStates(G4State_Idle);
    }

    void RingInnerShieldingMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            RunBuildCommand{}(mRingInnerShielding, valueStr);
        }
        else if(command == mCmdVerbose.get())
        {
            mRingInnerShielding.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
        else if(command == mCmdSetThickness.get())
        {
            mRingInnerShielding.SetThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdSetSpacing.get())
        {
            mRingInnerShielding.SetSpacing(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdSetPolyContractionFactor.get())
        {
            mRingInnerShielding.SetPolyContractionFactor(G4UIcommand::ConvertToDouble(valueStr));
        }
        else if(command == mCmdAddRing.get())
        {
            G4Tokenizer next(valueStr);

            double minRadius = StoD(next());
            double maxRadius = StoD(next());
            std::string unit = next();
            minRadius *= G4UIcommand::ValueOf(unit.c_str());
            maxRadius *= G4UIcommand::ValueOf(unit.c_str());

            std::string material = next();

            double zShift = 0;
            std::string strZshift = next();
            std::string unitZshift = next();
            if(!strZshift.empty())
            {
                zShift = StoD(strZshift.c_str()) * G4UIcommand::ValueOf(unitZshift.c_str());
            }

            std::string strLength = next();
            std::string unitLength = next();

            if(!material.empty())
            {
                if(!strZshift.empty())
                {
                    if(!strLength.empty())
                    {
                        double length = StoD(strLength.c_str()) * G4UIcommand::ValueOf(unitLength.c_str());
                        mRingInnerShielding.AddRing(minRadius, maxRadius, material, zShift, length);
                    }
                    else
                    {
                        mRingInnerShielding.AddRing(minRadius, maxRadius, material, zShift);
                    }
                }
                else
                {
                    mRingInnerShielding.AddRing(minRadius, maxRadius, material);
                }
            }
            else
            {
                mRingInnerShielding.AddRing(minRadius, maxRadius);
            }
        }
        else if(command == mCmdSetTopRingOrigin.get())
        {
            mRingInnerShielding.SetTopRingAsOrigin(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdBuildMylar.get())
        {
            mRingInnerShielding.SetBuildMylar(G4UIcommand::ConvertToBool(valueStr));
        }
    }
}


