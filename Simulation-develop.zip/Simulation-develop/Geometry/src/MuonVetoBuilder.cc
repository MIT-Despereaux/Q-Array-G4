#include "CLHEP/Units/SystemOfUnits.h"
#include "CLHEP/Vector/Rotation.h"
#include <vector>
#include <math.h>

/// Geant4 includes
#include "G4Trd.hh"
#include "G4VSolid.hh"
#include "G4LogicalVolume.hh"
#include "G4UnionSolid.hh"
#include "G4SubtractionSolid.hh"
#include "G4MultiUnion.hh"
#include "G4PVPlacement.hh"
#include "G4VPhysicalVolume.hh"
#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"

/// Project includes
#include "Geometry/MuonVetoBuilder.hh"
#include "Geometry/MaterialColour.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

/****************************************************
 *                                                  *
 * MuonVetoBuilder.cc                               *
 * Author : Guillaume Chemin                        *
 *                                                  *
 * Implements final design of the muon veto         *
 *                                                  *
 * Cryo muon veto geometry is simplified from final *
 * design                                           *
 *                                                  *
 ****************************************************/

namespace Geometry
{
    MuonVetoBuilder::MuonVetoBuilder(G4LogicalVolume& motherLV)
    :mother(motherLV)
    {}

    void MuonVetoBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
    }
    
    void MuonVetoBuilder::BuildCryoMuonVeto(bool BuildCryoMuonVeto)
    {
		// std::cout << "Set BuildCryoMuonVeto to : " << BuildCryoMuonVeto << std::endl;
    	mBuildCryoMuonVeto = BuildCryoMuonVeto;
    }
    
    VolumePack MuonVetoBuilder::PlaceLongPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation)
    {
    	G4VSolid* solidScintillator = new G4Box("Scintillator", LongVetoLength/2., VetoWidth/2., VetoThickness/2.);
		G4VSolid* solidAluminiumFull = new G4Box("AluminiumFull", LongVetoLength/2. + EmptySpaceWidth/2. + AluminiumThickness, VetoWidth/2. + AluminiumThickness, VetoThickness/2. + AluminiumThickness);
		G4VSolid* solidEmptySpace = new G4Box("EmptySpace", LongVetoLength/2. + EmptySpaceWidth/2., VetoWidth/2., VetoThickness/2.);
		G4SubtractionSolid* solidAluminiumFrame = new G4SubtractionSolid("AluminiumFrame",solidAluminiumFull,solidEmptySpace,nullptr,G4ThreeVector{0,0,0});
		auto Scintillator = fVolumeAdder.PlaceSolid(solidScintillator,VolumeName,"Scintillator",transformation);
		SetColourFromMaterial(Scintillator.Logical(), "Scintillator");
		auto AluminiumFrame = fVolumeAdder.PlaceSolid(solidAluminiumFrame,VolumeName + "_AluminiumFrame","Aluminium",transformation * G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{EmptySpaceWidth/2.,0,0}));
		SetColourFromMaterial(AluminiumFrame.Logical(), "Aluminium");
		return Scintillator;
    }
    
    VolumePack MuonVetoBuilder::PlaceShortPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation)
    {
    	G4VSolid* solidScintillator = new G4Box("Scintillator", ShortVetoLength/2., VetoWidth/2., VetoThickness/2.);
		G4VSolid* solidAluminiumFull = new G4Box("AluminiumFull", ShortVetoLength/2. + EmptySpaceWidth/2. + AluminiumThickness, VetoWidth/2. + AluminiumThickness, VetoThickness/2. + AluminiumThickness);
		G4VSolid* solidEmptySpace = new G4Box("EmptySpace", ShortVetoLength/2. + EmptySpaceWidth/2., VetoWidth/2., VetoThickness/2.);
		G4SubtractionSolid* solidAluminiumFrame = new G4SubtractionSolid("AluminiumFrame",solidAluminiumFull,solidEmptySpace,nullptr,G4ThreeVector{0,0,0});
		auto Scintillator = fVolumeAdder.PlaceSolid(solidScintillator,VolumeName,"Scintillator",transformation);
		SetColourFromMaterial(Scintillator.Logical(), "Scintillator");
		auto AluminiumFrame = fVolumeAdder.PlaceSolid(solidAluminiumFrame,VolumeName + "_AluminiumFrame","Aluminium",transformation * G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{EmptySpaceWidth/2.,0,0}));
		SetColourFromMaterial(AluminiumFrame.Logical(), "Aluminium");
		return Scintillator;
    }
    
    VolumePack MuonVetoBuilder::PlaceLongCutPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation)
    {
    	G4VSolid* solidScintillator = new G4Box("MuonVetoScintillator", LongCutVetoLength/2., VetoWidth/2., VetoThickness/2.);
		G4VSolid* solidAluminiumFull = new G4Box("AluminiumFull", LongCutVetoLength/2. + EmptySpaceWidth/2. + AluminiumThickness, VetoWidth/2. + AluminiumThickness, VetoThickness/2. + AluminiumThickness);
		G4VSolid* solidEmptySpace = new G4Box("EmptySpace", LongCutVetoLength/2. + EmptySpaceWidth/2., VetoWidth/2., VetoThickness/2.);
    	G4VSolid* solidScintillatorCut = new G4Tubs("MuonVetoScintillatorCut", 0., RoundedCutRadius, VetoThickness, 0., CLHEP::twopi);
		G4VSolid* solidAluminiumFullCut = new G4Tubs("AluminiumFullCut", 0., RoundedCutRadius-AluminiumThickness, VetoThickness, 0., CLHEP::twopi);
		G4VSolid* solidEmptySpaceCut = new G4Tubs("EmptySpaceCut", 0., RoundedCutRadius, VetoThickness, 0., CLHEP::twopi);
		G4SubtractionSolid* solidCutScintillator = new G4SubtractionSolid("CutMuonVetoScintillator", solidScintillator, solidScintillatorCut, nullptr, G4ThreeVector{-LongCutVetoLength/2., VetoWidth/2., 0.});
		G4SubtractionSolid* solidCutAluminiumFull = new G4SubtractionSolid("CutAluminiumFull", solidAluminiumFull, solidAluminiumFullCut, nullptr, G4ThreeVector{-(LongCutVetoLength/2. + AluminiumThickness + EmptySpaceWidth/2.), VetoWidth/2. + AluminiumThickness, 0.});
		G4SubtractionSolid* solidCutEmptySpace = new G4SubtractionSolid("CutEmptySpace", solidEmptySpace, solidEmptySpaceCut, nullptr, G4ThreeVector{-(LongCutVetoLength/2. + AluminiumThickness + EmptySpaceWidth/2.), VetoWidth/2. + AluminiumThickness, 0.});
		G4SubtractionSolid* solidCutAluminiumFrame = new G4SubtractionSolid("CutAluminiumFrame", solidCutAluminiumFull, solidCutEmptySpace, nullptr, G4ThreeVector{0,0,0});
		auto Scintillator = fVolumeAdder.PlaceSolid(solidCutScintillator,VolumeName,"Scintillator",transformation);
		SetColourFromMaterial(Scintillator.Logical(), "Scintillator");
		auto AluminiumFrame = fVolumeAdder.PlaceSolid(solidCutAluminiumFrame,VolumeName + "_AluminiumFrame","Aluminium",transformation* G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{EmptySpaceWidth/2.,0,0}));
		SetColourFromMaterial(AluminiumFrame.Logical(), "Aluminium");
    	return Scintillator;
    }
    
    VolumePack MuonVetoBuilder::PlaceShortCutPanel(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation)
    {
    	G4VSolid* solidScintillator = new G4Box("MuonVetoScintillator", ShortCutVetoLength/2., VetoWidth/2., VetoThickness/2.);
		G4VSolid* solidAluminiumFull = new G4Box("AluminiumFull", ShortCutVetoLength/2. + EmptySpaceWidth/2. + AluminiumThickness, VetoWidth/2. + AluminiumThickness, VetoThickness/2. + AluminiumThickness);
		G4VSolid* solidEmptySpace = new G4Box("EmptySpace", ShortCutVetoLength/2. + EmptySpaceWidth/2., VetoWidth/2., VetoThickness/2.);
    	G4VSolid* solidScintillatorCut = new G4Tubs("MuonVetoScintillatorCut", 0., RoundedCutRadius, VetoThickness, 0., CLHEP::twopi);
		G4VSolid* solidAluminiumFullCut = new G4Tubs("AluminiumFullCut", 0., RoundedCutRadius-AluminiumThickness, VetoThickness, 0., CLHEP::twopi);
		G4VSolid* solidEmptySpaceCut = new G4Tubs("EmptySpaceCut", 0., RoundedCutRadius, VetoThickness , 0., CLHEP::twopi);
		G4SubtractionSolid* solidCutScintillator = new G4SubtractionSolid("CutMuonVetoScintillator", solidScintillator, solidScintillatorCut, nullptr, G4ThreeVector{-ShortCutVetoLength/2., VetoWidth/2., 0.});
		G4SubtractionSolid* solidCutAluminiumFull = new G4SubtractionSolid("CutAluminiumFull", solidAluminiumFull, solidAluminiumFullCut, nullptr, G4ThreeVector{-(ShortCutVetoLength/2. + AluminiumThickness + EmptySpaceWidth/2.), VetoWidth/2. + AluminiumThickness, 0.});
		G4SubtractionSolid* solidCutEmptySpace = new G4SubtractionSolid("CutEmptySpace", solidEmptySpace, solidEmptySpaceCut, nullptr, G4ThreeVector{-(ShortCutVetoLength/2. + AluminiumThickness + EmptySpaceWidth/2.), VetoWidth/2. + AluminiumThickness, 0.});
		G4SubtractionSolid* solidCutAluminiumFrame = new G4SubtractionSolid("CutAluminiumFrame", solidCutAluminiumFull, solidCutEmptySpace, nullptr, G4ThreeVector{0,0,0});
		auto Scintillator = fVolumeAdder.PlaceSolid(solidCutScintillator,VolumeName,"Scintillator",transformation);
		SetColourFromMaterial(Scintillator.Logical(), "Scintillator");
		auto AluminiumFrame = fVolumeAdder.PlaceSolid(solidCutAluminiumFrame,VolumeName + "_AluminiumFrame","Aluminium",transformation* G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{EmptySpaceWidth/2.,0,0}));
		SetColourFromMaterial(AluminiumFrame.Logical(), "Aluminium");
    	return Scintillator;
    }
    
	// This geometry is rather complex in reality : this is but a simplified copy of the geometry (yet very hard to implement already). Transformation is centered at the middle Cu plate.
    std::vector<G4LogicalVolume*> MuonVetoBuilder::PlaceCryoMuonVeto(std::string VolumeName, VolumeAdder fVolumeAdder, HepGeom::Transform3D& transformation)
    {
    	std::vector<G4LogicalVolume*> volumes;
		// Raw cylindic scintillators and copper playes
		G4VSolid* CMV_Scintillator = new G4Tubs("CMV_Scintillator", 0, CryoVetoRadius, VetoThickness/2., 0, CLHEP::twopi);
		G4VSolid* CMV_CuPlate = new G4Tubs("CMV_CuPlate", 0, CryoVetoRadius, CopperThickness/2, 0, CLHEP::twopi);

		// Simplified cut regions
		G4VSolid* LargeRectangleCut = new G4Box("LargeRectangleCut", LargeRectangleWidth/2., LargeRectangleLength/2., VetoThickness+CopperThickness);
		G4VSolid* MediumRectangleCut = new G4Box("MediumRectangleCut", MediumRectangleWidth/2., MediumRectangleLength/2., VetoThickness+CopperThickness);
		G4VSolid* SmallRectangleCut = new G4Box("SmallRectangleCut", SmallRectangleWidth/2., SmallRectangleLength/2., VetoThickness+CopperThickness);
		
		// Harder to implement this triangular prism
		G4VSolid* TriangleCut = new G4Trd("TriangleCut", VetoThickness+CopperThickness, VetoThickness+CopperThickness, sqrt(3)/2*TriangleHeight/2, 0, TriangleHeight/2);

		// Transformations definition needed for G4MultiUnion
		G4RotationMatrix nullRotation = G4RotationMatrix();
		G4RotationMatrix TriangleRotation = G4RotationMatrix();
		TriangleRotation.rotateY(CLHEP::pi/2);
		G4ThreeVector LargeRectanglePos = G4ThreeVector(CryoVetoRadius - LargeRectangleWidth/2, 0, 0);
		G4ThreeVector MediumRectanglePos = G4ThreeVector(CryoVetoRadius - LargeRectangleWidth - MediumRectangleWidth/2, 0, 0);
		G4ThreeVector SmallRectanglePos = G4ThreeVector(-CryoVetoRadius + SmallRectangleWidth/2, 0, 0);
		G4ThreeVector TrianglePos1 = G4ThreeVector(0, sqrt(4*CryoVetoRadius*CryoVetoRadius - TriangleHeight*TriangleHeight)/2, 0); // harsh formula to calculate the distance so that the height of this triangle is perfectly linked to the circle...
		G4ThreeVector TrianglePos2 = G4ThreeVector(0, -sqrt(4*CryoVetoRadius*CryoVetoRadius - TriangleHeight*TriangleHeight)/2, 0); // same here, but opposite direction
		G4Transform3D LargeRectangleTransf = G4Transform3D(nullRotation,LargeRectanglePos);
		G4Transform3D MediumRectangleTransf = G4Transform3D(nullRotation,MediumRectanglePos);
		G4Transform3D SmallRectangleTransf = G4Transform3D(nullRotation,SmallRectanglePos);
		G4Transform3D TriangleTransf1 = G4Transform3D(TriangleRotation,TrianglePos1);
		G4Transform3D TriangleTransf2 = G4Transform3D(TriangleRotation,TrianglePos2);

		G4MultiUnion* CMV_cuts= new G4MultiUnion("CMV_Cuts");
		CMV_cuts->AddNode(*LargeRectangleCut, LargeRectangleTransf);
		CMV_cuts->AddNode(*MediumRectangleCut, MediumRectangleTransf);
		CMV_cuts->AddNode(*SmallRectangleCut, SmallRectangleTransf);
		CMV_cuts->AddNode(*TriangleCut, TriangleTransf1);
		CMV_cuts->AddNode(*TriangleCut, TriangleTransf2);
		CMV_cuts->Voxelize();

		G4SubtractionSolid* CMV_Scintillator_cut = new G4SubtractionSolid("CMV_Scintillator_cut", CMV_Scintillator, CMV_cuts, nullptr, G4ThreeVector{0., 0., 0.});
		G4SubtractionSolid* CMV_CuPlate_cut = new G4SubtractionSolid("CMV_Scintillator_cut", CMV_CuPlate, CMV_cuts, nullptr, G4ThreeVector{0., 0., 0.});

		// Copper rods implementation
		G4VSolid* CopperRods = new G4Tubs("CopperRods", 0, RodRadius, RodHeight/2, 0, CLHEP::twopi);

		auto Panel_0 = fVolumeAdder.PlaceSolid(CMV_Scintillator_cut, VolumeName+"_0", "Scintillator", transformation*G4Transform3D(nullRotation,G4ThreeVector(0, 0, -(CopperThickness+VetoThickness)/2)));
		volumes.push_back(Panel_0.Logical());
		auto Panel_1 = fVolumeAdder.PlaceSolid(CMV_Scintillator_cut, VolumeName+"_1", "Scintillator", transformation*G4Transform3D(nullRotation,G4ThreeVector(0, 0, (CopperThickness+VetoThickness)/2)));
		volumes.push_back(Panel_1.Logical());
		auto CopperPlate_0 = fVolumeAdder.PlaceSolid(CMV_CuPlate_cut, VolumeName+"_CuPlate_0", "CopperNOSV", transformation*G4Transform3D(nullRotation, G4ThreeVector(0,0,-(CopperThickness+VetoThickness))));
		SetColourFromMaterial(CopperPlate_0.Logical(), "CopperNOSV");
		auto CopperPlate_1 = fVolumeAdder.PlaceSolid(CMV_CuPlate_cut, VolumeName+"_CuPlate_1", "CopperNOSV", transformation*G4Transform3D(nullRotation, G4ThreeVector(0,0,0)));
		SetColourFromMaterial(CopperPlate_1.Logical(), "CopperNOSV");
		auto CopperPlate_2 = fVolumeAdder.PlaceSolid(CMV_CuPlate_cut, VolumeName+"_CuPlate_2", "CopperNOSV", transformation*G4Transform3D(nullRotation, G4ThreeVector(0,0,(CopperThickness+VetoThickness))));
		SetColourFromMaterial(CopperPlate_2.Logical(), "CopperNOSV");
		
		double RodZOffset = (3*CopperThickness/2+VetoThickness) + RodHeight/2;
		G4ThreeVector position_Rod_0 = {RodXOffset_0, 0, RodZOffset};
		auto Rod_0 = fVolumeAdder.PlaceSolid(CopperRods, VolumeName+"_CuSpacer_0", "CopperNOSV", transformation*G4Transform3D(nullRotation,position_Rod_0));
		SetColourFromMaterial(Rod_0.Logical(), "CopperNOSV");
		G4ThreeVector position_Rod_1 = {RodXOffset_1, RodYOffset_1, RodZOffset};
		auto Rod_1 = fVolumeAdder.PlaceSolid(CopperRods, VolumeName+"_CuSpacer_1", "CopperNOSV", transformation*G4Transform3D(nullRotation,position_Rod_1));
		SetColourFromMaterial(Rod_1.Logical(), "CopperNOSV");
		G4ThreeVector position_Rod_2 = {RodXOffset_2, RodYOffset_2, RodZOffset};
		auto Rod_2 = fVolumeAdder.PlaceSolid(CopperRods, VolumeName+"_CuSpacer_2", "CopperNOSV", transformation*G4Transform3D(nullRotation,position_Rod_2));
		SetColourFromMaterial(Rod_2.Logical(), "CopperNOSV");
		G4ThreeVector position_Rod_3 = {RodXOffset_1, -RodYOffset_1, RodZOffset};
		auto Rod_3 = fVolumeAdder.PlaceSolid(CopperRods, VolumeName+"_CuSpacer_3", "CopperNOSV", transformation*G4Transform3D(nullRotation,position_Rod_3));
		SetColourFromMaterial(Rod_3.Logical(), "CopperNOSV");
		G4ThreeVector position_Rod_4 = {RodXOffset_2, -RodYOffset_2, RodZOffset};
		auto Rod_4 = fVolumeAdder.PlaceSolid(CopperRods, VolumeName+"_CuSpacer_4", "CopperNOSV", transformation*G4Transform3D(nullRotation,position_Rod_4));
		SetColourFromMaterial(Rod_4.Logical(), "CopperNOSV");

		return volumes;
    }    
    
    std::vector<G4LogicalVolume*> MuonVetoBuilder::Build(const HepGeom::Transform3D& transformationToMother)
    {
		VolumeAdder volumeAdder{mother, transformationToMother};
		std::vector<G4LogicalVolume*> Panels;
		
		// Cryo muon veto panels definition
		if(mBuildCryoMuonVeto)
		{
	    	auto transfCryoMuonVeto = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{0, 0,-CryoVetoOffset + LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + VetoThickness/2 + 2*AluminiumThickness});
	    	auto CryoPanels = PlaceCryoMuonVeto("MuonVetoCryo",volumeAdder,transfCryoMuonVeto);
	    	Panels.insert(std::end(Panels), std::begin(CryoPanels), std::end(CryoPanels));
		}
	
		// Top panels definition
		auto transfTopPanel_0_0 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{0., -3*(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_0_1 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{0., -3*(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});	
		auto TopPanel_0_0 = PlaceShortPanel("MuonVetoTop_0_0",volumeAdder,transfTopPanel_0_0);
		auto TopPanel_0_1 = PlaceShortPanel("MuonVetoTop_0_1",volumeAdder,transfTopPanel_0_1);
		Panels.push_back(TopPanel_0_0.Logical());
		Panels.push_back(TopPanel_0_1.Logical());
	    
		auto transfTopPanel_1_0 = G4Transform3D(CLHEP::HepRotation(CLHEP::pi,CLHEP::pi,0), G4ThreeVector{-(ShortCutVetoLength/2.+AluminiumThickness), -(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_1_1 = G4Transform3D(CLHEP::HepRotation(CLHEP::pi,CLHEP::pi,0), G4ThreeVector{-(ShortCutVetoLength/2.+AluminiumThickness), -(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});
		auto TopPanel_1_0 = PlaceShortCutPanel("MuonVetoTop_1_0",volumeAdder,transfTopPanel_1_0);
		auto TopPanel_1_1 = PlaceShortCutPanel("MuonVetoTop_1_1",volumeAdder,transfTopPanel_1_1);
		Panels.push_back(TopPanel_1_0.Logical());
		Panels.push_back(TopPanel_1_1.Logical());
	    
		auto transfTopPanel_2_0 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{(ShortCutVetoLength/2.+AluminiumThickness), -(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_2_1 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{(ShortCutVetoLength/2.+AluminiumThickness), -(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});
		auto TopPanel_2_0 = PlaceShortCutPanel("MuonVetoTop_2_0",volumeAdder,transfTopPanel_2_0);
		auto TopPanel_2_1 = PlaceShortCutPanel("MuonVetoTop_2_1",volumeAdder,transfTopPanel_2_1);
		Panels.push_back(TopPanel_2_0.Logical());
		Panels.push_back(TopPanel_2_1.Logical());
	    
		auto transfTopPanel_3_0 = G4Transform3D(CLHEP::HepRotation(CLHEP::pi,0,0), G4ThreeVector{-(LongCutVetoLength/2.+AluminiumThickness), (VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_3_1 = G4Transform3D(CLHEP::HepRotation(CLHEP::pi,0,0), G4ThreeVector{-(LongCutVetoLength/2.+AluminiumThickness), (VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});
		auto TopPanel_3_0 = PlaceLongCutPanel("MuonVetoTop_3_0",volumeAdder,transfTopPanel_3_0);
		auto TopPanel_3_1 = PlaceLongCutPanel("MuonVetoTop_3_1",volumeAdder,transfTopPanel_3_1);
		Panels.push_back(TopPanel_3_0.Logical());
		Panels.push_back(TopPanel_3_1.Logical());
	    
		auto transfTopPanel_4_0 = G4Transform3D(CLHEP::HepRotation(0,CLHEP::pi,0), G4ThreeVector{(LongCutVetoLength/2.+AluminiumThickness), (VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_4_1 = G4Transform3D(CLHEP::HepRotation(0,CLHEP::pi,0), G4ThreeVector{(LongCutVetoLength/2.+AluminiumThickness), (VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});
		auto TopPanel_4_0 = PlaceLongCutPanel("MuonVetoTop_4_0",volumeAdder,transfTopPanel_4_0);
		auto TopPanel_4_1 = PlaceLongCutPanel("MuonVetoTop_4_1",volumeAdder,transfTopPanel_4_1);
		Panels.push_back(TopPanel_4_0.Logical());
		Panels.push_back(TopPanel_4_1.Logical());
	    
		auto transfTopPanel_5_0 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{0., 3*(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + (VetoThickness/2 + AluminiumThickness)});
		auto transfTopPanel_5_1 = G4Transform3D(CLHEP::HepRotation(0,0,0), G4ThreeVector{0., 3*(VetoWidth/2 + AluminiumThickness), LongVetoLength + 2*AluminiumThickness + EmptySpaceWidth + HeightToGround + 3*(VetoThickness/2 + AluminiumThickness)});
		auto TopPanel_5_0 = PlaceLongPanel("MuonVetoTop_5_0",volumeAdder,transfTopPanel_5_0);
		auto TopPanel_5_1 = PlaceLongPanel("MuonVetoTop_5_1",volumeAdder,transfTopPanel_5_1);
		Panels.push_back(TopPanel_5_0.Logical());
		Panels.push_back(TopPanel_5_1.Logical());
	    
		// Side panels definition
		std::string Name_0, Name_1;
		CLHEP::Hep3Vector Base_Position_0 = {-(VetoWidth/2 + AluminiumThickness)/std::tan(CLHEP::pi/NumberOfSidePanels) - (VetoThickness/2 + AluminiumThickness) - overlapFixPolygonal, 0,  LongVetoLength/2 + AluminiumThickness + EmptySpaceWidth + HeightToGround};
		CLHEP::Hep3Vector Base_Position_1 = {-(VetoWidth/2 + AluminiumThickness)/std::tan(CLHEP::pi/NumberOfSidePanels) - 3*(VetoThickness/2 + AluminiumThickness) - overlapFixPolygonal, 0, LongVetoLength/2 + AluminiumThickness + EmptySpaceWidth + HeightToGround};
		CLHEP::HepRotation Rotation;
		double angle;
		for (int i = 0; i < NumberOfSidePanels; i++)
		{
			angle = CLHEP::twopi*i/NumberOfSidePanels;
			Rotation = CLHEP::HepRotation(-CLHEP::pi/2,CLHEP::pi/2,CLHEP::pi/2-angle); // these rotations get me sick
			CLHEP::Hep3Vector Position_0 = Base_Position_0;
			CLHEP::Hep3Vector Position_1 = Base_Position_1;
			Position_0.rotateZ(angle);
			Position_1.rotateZ(angle);
			auto transfSidePanel_0 = G4Transform3D(Rotation,Position_0);
			auto transfSidePanel_1 = G4Transform3D(Rotation,Position_1);
			Name_0 = "MuonVetoSide_" + std::to_string(i) + "_0";
			Name_1 = "MuonVetoSide_" + std::to_string(i) + "_1";
			auto SidePanel_0 = PlaceLongPanel(Name_0,volumeAdder,transfSidePanel_0);
			auto SidePanel_1 = PlaceLongPanel(Name_1,volumeAdder,transfSidePanel_1);
			Panels.push_back(SidePanel_0.Logical());
			Panels.push_back(SidePanel_1.Logical());
		}
		return Panels;
	}
    
    void MuonVetoBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("MuonVeto", "Geometry::MuonVetoBuilder");
		writer.SetKeyValue("MuonVetoBuildCryoMuonVeto", mBuildCryoMuonVeto);
        writer.WriteIn(directory);
    }

}
