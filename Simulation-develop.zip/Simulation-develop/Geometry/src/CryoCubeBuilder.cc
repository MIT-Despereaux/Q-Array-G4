/*
 * CryoCubeBuilder.cc
 *
 *  Created on: 19.01.2016
 *  Modified april 2021 : do not describe the 27 bolometer, but the cryocube structure
 *  Use the GenericBolometerBuilder to build and position the bolometer inside the cryocube.
 *      Author: cazes
 */

#include <iostream>
#include "CLHEP/Units/SystemOfUnits.h"
#include "Geometry/CryoCubeBuilder.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/MaterialColour.hh"
#include "Geometry/GermaniumBolometerBuilder.hh"
#include "SimuOutput/InfoHeaderWriter.hh"


#include "G4VisAttributes.hh"
#include "G4AssemblyVolume.hh"
#include "G4SDManager.hh"
#include "G4NistManager.hh"

namespace Geometry{

  CryoCubeBuilder::CryoCubeBuilder(G4LogicalVolume& mother_)
    :mother(mother_),
     name("CryoCubeBuilder"),
     nbOfBolometers(0.),
     totalCrystalMass(0.),
     fVerbosity(0)
  {
  }


  // dimensions
  /////////////

  // structure
  double CryoCubeBuilder::CryoCubeStructureThickness()  const{
    return 8*CLHEP::mm;
  }
  double CryoCubeBuilder::CryoCubeDepth() const {
    return 191*CLHEP::mm;
  }
  double CryoCubeBuilder::CryoCubeSideHight()  const{
    return 208*CLHEP::mm;
  }
  double CryoCubeBuilder::CryoCubeSideSpaceHight() const{
    return 17*CLHEP::mm;
  }
  double CryoCubeBuilder::CryoCubeSideSpaceShift() const{
    return 47*CLHEP::mm;
  }
  double CryoCubeBuilder::CryoCubeSideSpaceLength() const{
    return  141*CLHEP::mm;
  }
  double CryoCubeBuilder::SideScrewSupportWidth() const{
    return 15*CLHEP::mm;
  }
  double CryoCubeBuilder::TopPlateHole() const {
    return 8*CLHEP::mm;
  }
  double CryoCubeBuilder::BolometerPlateThickness()  const{
    return 5*CLHEP::mm;
  }
  double CryoCubeBuilder::BolometerPlateSide()  const{
    return 190*CLHEP::mm;
  }
  // electronic plate
  double CryoCubeBuilder::ElectronicPlateSide()  const{
    return 160*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicPlateThickness()  const{
    return 7*CLHEP::mm;
  }
  // electronic boards
  double CryoCubeBuilder::ElectronicBoardSide()  const{
    return 40*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicBoardThickness()  const{
    return 3*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicBoardDistanceToEdge()  const{
    return 8*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicBoardSpace()  const{
    return 12*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicBoardCableHoleLength()  const{
    return 15*CLHEP::mm;
  }
  double CryoCubeBuilder::ElectronicBoardCableHoleWidth()  const{
    return 5*CLHEP::mm;
  }
  // connector plate
  double CryoCubeBuilder::ConnectorPlateLength()  const{
    return 80*CLHEP::mm;
  }
  double CryoCubeBuilder::ConnectorPlateWidth()  const{
    return 60*CLHEP::mm;
  }
  double CryoCubeBuilder::ConnectorBoxHigh()  const{
    return 5*CLHEP::mm;
  }
  double CryoCubeBuilder::ConnectorBoxWidth()  const{
    return  20*CLHEP::mm;
  }
  double CryoCubeBuilder::ConnectorBoxDistanceToEdge()  const{
    return  10.*CLHEP::mm;
  }
  // bolometer position
  double CryoCubeBuilder::BolometerDeltaX() const {
    //    return 52*CLHEP::mm; use 55mm to allow the bollometer to fit in the cryocube
    return 55*CLHEP::mm;
  }
  double CryoCubeBuilder::BolometerDeltaY() const {
    return 55*CLHEP::mm;
  }


  // builders
  ///////////

  void CryoCubeBuilder::BuildCryoCubeStructure() const{

    // build side plates

    double sideHight = CryoCubeSideHight() - CryoCubeStructureThickness();
    double sideLength = CryoCubeDepth();

    auto solidFullSide = new FilledBox("CryoCubeFullSide", CryoCubeStructureThickness(), sideLength, sideHight);
    auto solidSideSpace = new FilledBox("CryoCubeSideSpace",CryoCubeStructureThickness(), CryoCubeSideSpaceLength(), CryoCubeSideSpaceHight());

    G4ThreeVector position(0.,0.5*(sideLength-CryoCubeSideSpaceLength()),-0.5*sideHight+CryoCubeSideSpaceShift() + 0.5*CryoCubeSideSpaceHight());
    auto solidFullSide1Space = new G4SubtractionSolid("CryoCubeFullSide1Space",solidFullSide,solidSideSpace,nullptr,position);
    position.setZ(position.z()+CryoCubeSideSpaceShift()+CryoCubeSideSpaceHight());
    auto solidFullSide2Space = new G4SubtractionSolid("CryoCubeFullSide2Space",solidFullSide1Space,solidSideSpace,nullptr,position);
    position.setZ(position.z()+CryoCubeSideSpaceShift()+CryoCubeSideSpaceHight());
    auto solidSide = new G4SubtractionSolid("CryoCubeSide",solidFullSide2Space,solidSideSpace,nullptr,position);

    auto logicSide = new G4LogicalVolume(solidSide, G4Material::GetMaterial("CopperCryoCube"), "CryoCubeSide");
    SetColourFromMaterial(logicSide, "CopperCryoCube");

    // left and right plates
    G4ThreeVector translation(0.5*(CryoCubeSideHight()-CryoCubeStructureThickness()),0.,0.5*(-CryoCubeSideHight()+sideHight));
    cryoCubeAssembly->AddPlacedVolume(logicSide, translation, nullptr);
    translation.setX(-translation.x());
    cryoCubeAssembly->AddPlacedVolume(logicSide, translation, nullptr);


    // screw support

    auto solidSideScrewSupport = new FilledBox("CryoCubeSideScrewSupport",SideScrewSupportWidth(), sideLength, CryoCubeStructureThickness());
    auto logicSideScrewSupport = new G4LogicalVolume(solidSideScrewSupport, G4Material::GetMaterial("CopperCryoCube"), "CryoCubeScrewSupport");
    SetColourFromMaterial(logicSideScrewSupport, "CopperCryoCube");

    //left and right bottom screw support
    translation.setX(0.5*(CryoCubeSideHight()-SideScrewSupportWidth())-CryoCubeStructureThickness());
    translation.setY(0.);
    translation.setZ(0.5*(CryoCubeStructureThickness()-CryoCubeSideHight()));
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);
    translation.setX(-translation.x());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);

    //left and right middle bottom screw support
    translation.setZ(translation.z()+ CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);
    translation.setX(-translation.x());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);

    //left and right middle top screw support
    translation.setZ(translation.z()+ CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);
    translation.setX(-translation.x());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);

    //left and right top screw support
    translation.setZ(translation.z()+ CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);
    translation.setX(-translation.x());
    cryoCubeAssembly->AddPlacedVolume(logicSideScrewSupport, translation, nullptr);

    // build top plate

    auto solidFullTopPlate = new FilledBox("CryoCubeFullTopPlate",CryoCubeSideHight(), CryoCubeDepth(), CryoCubeStructureThickness());
    auto solidTopPlateHole = new FilledTube("CryoCubeTopPlateHole",0.5*TopPlateHole(),CryoCubeStructureThickness());
    position.setX(0.);
    position.setY(0.);
    position.setZ(0.);
    auto solidTopPlate = new G4SubtractionSolid("CryoTopPlate",solidFullTopPlate,solidTopPlateHole,nullptr,position);
    auto logicTopPlate = new G4LogicalVolume(solidTopPlate, G4Material::GetMaterial("CopperCryoCube"), "CryoCubeTopPlate");
    SetColourFromMaterial(logicTopPlate, "CopperCryoCube");

    translation.setX(0.);
    translation.setY(0.);
    translation.setZ(0.5*(CryoCubeSideHight()-CryoCubeStructureThickness()));

    cryoCubeAssembly->AddPlacedVolume(logicTopPlate, translation, nullptr);


    // build bolometer support plates

    auto solidBolometerPlate = new FilledBox("CryoCubeBolometerPlate",BolometerPlateSide(),BolometerPlateSide(),BolometerPlateThickness());
    auto logicBolometerPlate = new G4LogicalVolume(solidBolometerPlate,G4Material::GetMaterial("CopperCryoCube"), "CryoCubeBolometerPlate");
    SetColourFromMaterial(logicBolometerPlate, "CopperCryoCube");

    //bottom plate
    translation.setX(0.);
    translation.setY(0.);
    translation.setZ(0.5*(BolometerPlateThickness()-CryoCubeSideHight())+BolometerPlateThickness());

    cryoCubeAssembly->AddPlacedVolume(logicBolometerPlate, translation, nullptr);

    //middle plate
    translation.setZ(translation.z()+ CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight());
    cryoCubeAssembly->AddPlacedVolume(logicBolometerPlate, translation, nullptr);

    //top plate
    translation.setZ(translation.z()+ CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight());
    cryoCubeAssembly->AddPlacedVolume(logicBolometerPlate, translation, nullptr);

  }



  void CryoCubeBuilder::BuildCryoCubeElectronicPlates() const{

    auto solidFullElectronicPlate = new FilledBox("FullElectronicPlate",ElectronicPlateSide(),ElectronicPlateSide(),ElectronicPlateThickness());

    // the electronic boards

    auto solidElectronicBoard = new FilledBox("ElectronicBoard",ElectronicBoardSide(),ElectronicBoardSide(),ElectronicBoardThickness());
    auto logicElectronicBoard = new G4LogicalVolume(solidElectronicBoard,G4Material::GetMaterial("PCB"),"ElectronicBoard");
    SetColourFromMaterial(logicElectronicBoard,"ElectronicBoard");

    // the hole for cable from board to bolo.

    auto solidCableHole = new FilledBox("CableHole",ElectronicBoardCableHoleLength(),ElectronicBoardCableHoleWidth(),ElectronicPlateThickness()-ElectronicBoardThickness());

    // center of the plate
    G4SubtractionSolid* solidElectronicPlate{nullptr};
    G4ThreeVector position(-0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide(),
			   -0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide(),
			   0.5*(ElectronicPlateThickness()-ElectronicBoardThickness()));
    G4ThreeVector CableHoleShift(0,0,0.5*ElectronicPlateThickness());


    for(int i=0;i<3;i++) {

        for(int j=0;j<3;j++) {

            //remove elecrtonic board space
            G4String namePlate = "ElectronicPlate" +std::to_string(3*i+j) + "boardHole";

            if(i == 0 && j == 0 ) {
                solidElectronicPlate = new G4SubtractionSolid(namePlate,solidFullElectronicPlate,solidElectronicBoard,nullptr,position);
            } else {
                solidElectronicPlate = new G4SubtractionSolid(namePlate,solidElectronicPlate,solidElectronicBoard,nullptr,position);
            }

            if(i==2 && j == 2) {
                namePlate = "ElectronicPlate";
            } else {
                namePlate = "ElectronicPlate" +std::to_string(3*i+j) + "cableHole";
            }
            //remove hole to pass the cable between the baod and the bolometers
            solidElectronicPlate = new G4SubtractionSolid(namePlate,solidElectronicPlate,solidCableHole,nullptr,position-CableHoleShift);
            if(fVerbosity > 0) std::cout << ElectronicPlateThickness() << " " << ElectronicBoardThickness() << " " << position-CableHoleShift << std::endl;


            // move to next position
            position.setX(position.x()+ElectronicBoardSide()+ElectronicBoardSpace());

        }

        // move to next position
        position.setX(-0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide());
        position.setY(position.y()+ElectronicBoardSide()+ElectronicBoardSpace());

    }

    auto logicElectronicPlate = new G4LogicalVolume(solidElectronicPlate,G4Material::GetMaterial("CopperCryoCube"),"ElectronicPlate");
    SetColourFromMaterial(logicElectronicPlate, "CopperCryoCube");
    //the side of the plates

    auto solidConnectorPlate = new FilledBox("ConnectorPlate",ConnectorPlateWidth(),ConnectorPlateLength(),ElectronicPlateThickness());
    auto logicConnectorPlate = new G4LogicalVolume(solidConnectorPlate,G4Material::GetMaterial("CopperCryoCube"),"ConnectorPlate");
    SetColourFromMaterial(logicConnectorPlate, "CopperCryoCube");

    // fake boxe to simulate connectors.

    double connectorBoxLength = ConnectorPlateLength() - ConnectorBoxDistanceToEdge();
    auto solidConnectorBox = new FilledBox("connectorBox",ConnectorBoxWidth(),connectorBoxLength,ConnectorBoxHigh());
    auto logicConnectorBox = new G4LogicalVolume(solidConnectorBox,G4Material::GetMaterial("ConnectorsMaterial"),"ConnectorBox");
    SetColourFromMaterial(logicConnectorBox, "Connector");

    // position volumes

    double zShift = -0.5*CryoCubeSideHight()+CryoCubeSideSpaceShift() + 0.5*CryoCubeSideSpaceHight();
    for(int iPlate = 0; iPlate <3 ; iPlate++) {

      position.setX(0.);
      position.setY(0.);
      position.setZ(zShift);
      cryoCubeAssembly->AddPlacedVolume(logicElectronicPlate,position,nullptr);

      position.setX(-0.5*(ElectronicPlateSide()+ConnectorPlateWidth()));
      position.setY(0.);
      position.setZ(zShift);
      cryoCubeAssembly->AddPlacedVolume(logicConnectorPlate,position,nullptr);
      position.setX(-position.x());
      cryoCubeAssembly->AddPlacedVolume(logicConnectorPlate,position,nullptr);

      position.setX(-0.5*ElectronicPlateSide()-ConnectorPlateWidth()+ConnectorBoxDistanceToEdge());
      position.setY(0.);
      position.setZ(0.5*(ElectronicPlateThickness()+ConnectorBoxHigh())+zShift);
      cryoCubeAssembly->AddPlacedVolume(logicConnectorBox,position,nullptr);
      position.setX(-position.x());
      cryoCubeAssembly->AddPlacedVolume(logicConnectorBox,position,nullptr);

      //Electronic Boards
      position.setX(-0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide());
      position.setY(-0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide());
      position.setZ(0.5*(ElectronicPlateThickness()-ElectronicBoardThickness())+zShift);
      for(int i=0;i<3;i++) {
	for(int j=0;j<3;j++) {
	  cryoCubeAssembly->AddPlacedVolume(logicElectronicBoard,position,nullptr);
	  // move to next position
	  position.setX(position.x()+ElectronicBoardSide()+ElectronicBoardSpace());
	}
	// move to next position
	position.setX(-0.5*ElectronicPlateSide()+ElectronicBoardDistanceToEdge()+0.5*ElectronicBoardSide());
	position.setY(position.y()+ElectronicBoardSide()+ElectronicBoardSpace());

      }

      zShift += CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight();

    }

  }

  // main builder
  ///////////////

  std::vector<G4LogicalVolume*> CryoCubeBuilder::Build(HepGeom::Transform3D transformation)
  {
    if (fVerbosity > 0) std::cout << "> Build " << name << " geometry" << std::endl;

    cryoCubeAssembly = new G4AssemblyVolume();

     // CryoCubeStructure

    BuildCryoCubeStructure();

    BuildCryoCubeElectronicPlates();

    cryoCubeAssembly->MakeImprint(&mother, transformation);

    // Bolometers

    G4ThreeVector position(0.,0.,0.);
    GermaniumBolometerBuilder bolometerBuilder{mother};
    double zBottomBolometerPlate = -0.5*CryoCubeSideHight() + CryoCubeStructureThickness() + BolometerPlateThickness();
    for(int i = -1; i<=1 ; ++i) {
        for(int j = -1; j<=1 ;++j) {
            for(int k = -1; k<=1 ;++k) {

                position.setX(i*BolometerDeltaX());
                position.setY(j*BolometerDeltaY());
                position.setZ(zBottomBolometerPlate + 0.5*bolometerBuilder.GetBolometerFullHight() + (k + 1)*(CryoCubeSideSpaceShift() + CryoCubeSideSpaceHight()));
                G4Transform3D boloPosition(transformation.getRotation(),transformation.getTranslation() + position);
                bolometerBuilder.Build(boloPosition);
                totalCrystalMass += bolometerBuilder.GetCrystalMass();

            }
        }
    }


    auto beginVolIt = cryoCubeAssembly->GetVolumesIterator();
    auto endVolIt = beginVolIt + cryoCubeAssembly->TotalImprintedVolumes();
    auto volIt = beginVolIt;
    nbOfBolometers=1;
    while (volIt != endVolIt)
      {
	if ((*volIt)->GetLogicalVolume()->GetSolid()==bolometerBuilder.GetSolidBolo())
	  //if ((*volIt)->GetLogicalVolume()->GetSolid()->GetName()=="CrystalBolo")
	  {
	    if (fVerbosity > 0) std::cout <<  (*volIt)->GetName() << " assigned copy number " << nbOfBolometers <<std::endl;
	    (*volIt)->SetCopyNo(nbOfBolometers);
	    ++nbOfBolometers;
	  }
	else (*volIt)->SetCopyNo((*volIt)->GetCopyNo()+1000);
	++volIt;
      }

    if (fVerbosity > 0) std::cout << name << " constructed." << std::endl;
    return {bolometerBuilder.GetLogicBolo()};

  }



  double CryoCubeBuilder::TotalHeight() const
  {
    return CryoCubeSideHight();
//	return 12.2 * CLHEP::cm;	
  }

  void ROOTWrite(const CryoCubeBuilder& cryocube, TDirectory& directory)
  {
    double bolometerMass = cryocube.GetBolometerMass();

    InfoHeaderWriter header("CryoCube", "CryoCube info");
    header.SetKeyValue("BolometerMass", bolometerMass);
    header.WriteIn(directory);
  }

}
