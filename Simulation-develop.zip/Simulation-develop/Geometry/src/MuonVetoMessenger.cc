#include "Geometry/MuonVetoMessenger.hh"

/// Project includes
#include "Geometry/MuonVetoBuilder.hh"

/********************************************************
 *							*
 * MuonVetoMessenger.cc				        *
 * Author : Guillaume Chemin			        *
 * Implements the input commands in the macro related   *
 * to the muon veto					*
 *						        *
 ********************************************************/
 
namespace Geometry
{
    MuonVetoMessenger::MuonVetoMessenger(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("MuonVeto command directory");
	
	mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build the muon veto");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);
	
	mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "SetVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);
        
	mCmdBuildCryoMuonVeto.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildCryoMuonVeto").c_str(), this));
        mCmdBuildCryoMuonVeto->SetGuidance("Build cryo muon veto inside the cryostat");
        mCmdBuildCryoMuonVeto->SetParameterName("val",false);
        mCmdBuildCryoMuonVeto->AvailableForStates(G4State_Idle);
    }

    void MuonVetoMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
	else if(command == mCmdBuildCryoMuonVeto.get())
        {
            mBuilder.BuildCryoMuonVeto(G4UIcommand::ConvertToBool(valueStr));
        }
    }
}
