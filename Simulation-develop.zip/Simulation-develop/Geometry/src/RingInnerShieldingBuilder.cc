#include "Geometry/RingInnerShieldingBuilder.hh"

/// Standard includes
#include <vector>

/// Geant4 includes
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "CLHEP/Units/SystemOfUnits.h"

/// ROOT includes
#include "TString.h"

/// Project includes
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/Cryostat.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

namespace Geometry
{
    RingInnerShieldingBuilder::RingInnerShieldingBuilder(G4LogicalVolume &mother): mMother(mother)
    {

    }

    void RingInnerShieldingBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
    }

    void RingInnerShieldingBuilder::SetThickness(double thickness)
    {
        mThickness = thickness;
    }

    void RingInnerShieldingBuilder::SetSpacing(double spacing)
    {
        mSpacing = spacing;
    }

    void RingInnerShieldingBuilder::SetPolyContractionFactor(double factor)
    {
        mPolyContractionFactor = factor;
    }

    void RingInnerShieldingBuilder::SetBuildMylar(bool activate)
    {
        // std::cout << "Set BuildMylar to : " << activate << std::endl;
        mBuildMylar = activate;
    }

    void RingInnerShieldingBuilder::AddRing(double minRadius, double maxRadius, std::string material, double zShift, double length)
    {
        mRingRadiusMin.push_back(minRadius);
        mRingRadiusMax.push_back(maxRadius);
        mRingMaterial.push_back(material);
        mRingZshift.push_back(zShift);
        mRingLength.push_back(length);
    }

    void RingInnerShieldingBuilder::SetTopRingAsOrigin(bool topRingOrigin)
    {
        mTopRingOrigin = topRingOrigin;
    }

    void RingInnerShieldingBuilder::Build(const CLHEP::Hep3Vector& position)
    {
        Build(HepGeom::Transform3D{{}, position});
    }

    void RingInnerShieldingBuilder::Build(const HepGeom::Transform3D& transformation)
    {
        if(mVerbosity > 0) 
        {
            std::cout << "Build RingInnerShielding geometry" << std::endl;
            std::cout << "Total rings to build: " << mRingRadiusMin.size() << std::endl;
            std::cout << "Mylar building enabled: " << (mBuildMylar ? "true" : "false") << std::endl;
        }

        mTransformation = transformation;
        VolumeAdder factory{mMother, mTransformation};

        for(std::size_t iRing = 0; iRing < mRingRadiusMin.size(); ++iRing)
        {
            double originalMaxRadius = mRingRadiusMax[iRing];
            mRingRadiusMax[iRing] -= mSpacing;
            mRingRadiusMax[iRing] -= (mRingRadiusMax[iRing] - mRingRadiusMin[iRing]) * mPolyContractionFactor;
            if(mRingLength[iRing] < 0)
            {
                mRingLength[iRing] = mThickness;
            }

            if(mVerbosity > 0)
            {
                std::cout << "Ring " << iRing << " (material: " << mRingMaterial[iRing] << "): "
                          << "R_min=" << mRingRadiusMin[iRing] 
                          << " R_max=" << mRingRadiusMax[iRing] << " (was " << originalMaxRadius << ")"
                          << " Length=" << mRingLength[iRing] << std::endl;
            }

            if(mRingRadiusMax[iRing] > mRingRadiusMin[iRing])
            {
                G4ThreeVector ringPosition = {0,0, mRingZshift[iRing]};
                if(mTopRingOrigin)
                {
                    ringPosition += G4ThreeVector(0, 0, -mRingLength[iRing] / 2.);
                }
                factory.Add<Tube>(Form("RingInnerShielding_%lu", iRing), mRingMaterial[iRing], ringPosition, mRingRadiusMin[iRing], mRingRadiusMax[iRing], mRingLength[iRing]);
            }
            else if(mVerbosity > 0)
            {
                std::cout << "Skipping ring " << iRing << " due to invalid geometry (R_max <= R_min)" << std::endl;
            }
        }

        if(mBuildMylar)
        {
            BuildMylar("Mylar", 0.1*CLHEP::mm); // Example: 1 mm Mylar; adjust as needed
        }

        if(mVerbosity > 0) std::cout << "RingInnerShielding constructed" << std::endl;
    }

    void RingInnerShieldingBuilder::BuildMylar(const std::string& mylarMaterial, double mylarThickness)
    {
        if(mVerbosity > 0) std::cout << "Adding Mylar around PE rings" << std::endl;

        // Safety check for thickness
        if(mylarThickness <= 0)
        {
            std::cerr << "Invalid Mylar thickness: " << mylarThickness << std::endl;
            return;
        }

        VolumeAdder factory{mMother, mTransformation};
        std::vector<std::size_t> indicesToCover;

        if(mVerbosity > 0)
        {
            std::cout << "BuildMylar: Total rings available: " << mRingMaterial.size() << std::endl;
            for(std::size_t i = 0; i < mRingMaterial.size(); ++i)
            {
                std::cout << "Ring " << i << " material: '" << mRingMaterial[i] << "'" << std::endl;
            }
        }

        for(std::size_t i = 0; i < mRingMaterial.size(); ++i)
        {
            if(mRingMaterial[i] == "PE" || mRingMaterial[i] == "Polyethylene" || mRingMaterial[i] == "Pol")
            {
                indicesToCover.push_back(i);
                if(mVerbosity > 0)
                {
                    std::cout << "Found PE/Pol ring at index " << i << " with material '" << mRingMaterial[i] << "'" << std::endl;
                }
            }
        }

        if(indicesToCover.size() < 2)
        {
            if(mVerbosity > 0)
            {
                std::cout << "Not enough PE rings to apply Mylar. Found " << indicesToCover.size() 
                          << " PE rings, need at least 2." << std::endl;
            }
            return;
        }

        if(mVerbosity > 0)
        {
            std::cout << "Found " << indicesToCover.size() << " PE rings for Mylar wrapping" << std::endl;
        }

        std::size_t middleIndex = indicesToCover[indicesToCover.size() / 2];
        std::size_t outerIndex = indicesToCover.back();

        for(auto idx : {middleIndex, outerIndex})
        {
            // For Mylar wrapping, we should wrap around the outer surface only
            double minR = mRingRadiusMax[idx]; // Start from outer surface of PE ring
            double maxR = mRingRadiusMax[idx] + mylarThickness;
            double length = mRingLength[idx]; // Same length as the PE ring

            // Safety checks
            if(minR <= 0 || maxR <= minR || length <= 0)
            {
                std::cerr << "Invalid Mylar geometry parameters for ring " << idx 
                          << ": minR=" << minR << " maxR=" << maxR << " length=" << length << std::endl;
                continue;
            }

            G4ThreeVector position = {0, 0, mRingZshift[idx]};
            if(mTopRingOrigin)
            {
                position += G4ThreeVector(0, 0, -mRingLength[idx] / 2.);
            }

            // Create Mylar tube using G4Material::GetMaterial for consistency
            auto solidMylar = new Tube(Form("RingInnerShielding_Mylar_%lu", idx), minR, maxR, length);
            auto logicMylar = new G4LogicalVolume(solidMylar, G4Material::GetMaterial(mylarMaterial), Form("RingInnerShielding_Mylar_%lu_logic", idx));
            auto physMylar = new G4PVPlacement(mTransformation * G4Transform3D{{}, position}, logicMylar, Form("RingInnerShielding_Mylar_%lu_physical", idx), &mMother, false, 0, true);
            SetColourFromMaterial(logicMylar, "Mylar");

            if(mVerbosity > 0)
            {
                std::cout << "Added Mylar around PE ring " << idx
                          << " with Rmin=" << minR
                          << " Rmax=" << maxR
                          << " Length=" << length << std::endl;
            }
        }

        if(mVerbosity > 0) std::cout << "Mylar added around selected PE rings." << std::endl;
    }

    void RingInnerShieldingBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("RingInnerShielding", "Geometry::RingInnerShieldingBuilder");
        writer.SetKeyValue("Position_X", mTransformation.dx());
        writer.SetKeyValue("Position_Y", mTransformation.dy());
        writer.SetKeyValue("Position_Z", mTransformation.dz());
        writer.SetKeyValue("Thickness", mThickness);
        writer.SetKeyValue("BuildMylar", mBuildMylar);
        writer.SetKeyValue("RingRadiusMin", mRingRadiusMin);
        writer.SetKeyValue("RingRadiusMax", mRingRadiusMax);
        writer.SetKeyValue("RingMaterial", mRingMaterial);
        writer.SetKeyValue("RingZshift", mRingZshift);
        writer.SetKeyValue("RingLength", mRingLength);
        writer.WriteIn(directory);
    }

}
