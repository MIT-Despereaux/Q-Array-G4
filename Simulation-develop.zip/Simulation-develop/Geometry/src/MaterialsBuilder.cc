#include "Geometry/MaterialsBuilder.hh"
#include "G4NistManager.hh"
#include "G4Colour.hh"

using namespace CLHEP;

namespace{

    constexpr double percent()
    {
        return 1.e-2;
    }

    constexpr double kilo()
    {
        return 1.e3;
    }

    constexpr double kPa()
    {
        return kilo() * CLHEP::pascal;
    }

    // R = Na * kB
    constexpr double GasConstant()
    {
        return CLHEP::Avogadro * CLHEP::k_Boltzmann;
    }

    //energy of one mole is Na * kB * T = R * T
    constexpr double MoleEnergy(double temperature)
    {
        return GasConstant() * temperature;
    }

}

namespace Geometry
{

    void MaterialsBuilder::InitialiseElementsFromNIST()
    {
        auto NistManager = G4NistManager::Instance();
        elH = NistManager->FindOrBuildElement("H");
        elO = NistManager->FindOrBuildElement("O");
        elSi = NistManager->FindOrBuildElement("Si");
        elMg = NistManager->FindOrBuildElement("Mg");
        elAl = NistManager->FindOrBuildElement("Al");
        elFe = NistManager->FindOrBuildElement("Fe");
        elK = NistManager->FindOrBuildElement("K");
        elB = NistManager->FindOrBuildElement("B");
        elC = NistManager->FindOrBuildElement("C");
        elCa= NistManager->FindOrBuildElement("Ca");
        elNi= NistManager->FindOrBuildElement("Ni");
        elMn= NistManager->FindOrBuildElement("Mn");
        elS= NistManager->FindOrBuildElement("S");
        elZn= NistManager->FindOrBuildElement("Zn");
        elF = NistManager->FindOrBuildElement("F");
        elCr = NistManager->FindOrBuildElement("Cr");
        elN = NistManager->FindOrBuildElement("N");
        elCu = NistManager->FindOrBuildElement("Cu");
        elP = NistManager->FindOrBuildElement("P");
        elCl = NistManager->FindOrBuildElement("Cl");
    }

    void MaterialsBuilder::InitialiseUserElements()
    {
        // physics.nist.gov/PhysRefData/Handbook/Tables/heliumtable1.htm
        auto helium3Isotope = new G4Isotope{"He3Iso", 2, 3, 3.01603*g/mole};
        elHe3 = new G4Element{"Helium3", "He3", 1};
        elHe3->AddIsotope(helium3Isotope, 1);
        // physics.nist.gov/PhysRefData/Handbook/Tables/argontable1.htm
        auto argon40Isotope = new G4Isotope{"Ar40Iso", 18, 40, 39.962384*g/mole};
        elAr40 = new G4Element{"Argon40", "Ar40", 1};
        elAr40->AddIsotope(argon40Isotope, 1);
    }

    void MaterialsBuilder::DefineBasicsFromNIST() const
    {
        auto NistManager = G4NistManager::Instance();
        NistManager->FindOrBuildMaterial("G4_Galactic");
        NistManager->FindOrBuildMaterial("G4_Ge");
        NistManager->FindOrBuildMaterial("G4_Si");
        NistManager->FindOrBuildMaterial("G4_AIR");
        NistManager->FindOrBuildMaterial("G4_CONCRETE");
        NistManager->FindOrBuildMaterial("G4_WATER");
        NistManager->FindOrBuildMaterial("G4_Pb");
        NistManager->FindOrBuildMaterial("G4_Os");
        NistManager->FindOrBuildMaterial("G4_Al");
        NistManager->FindOrBuildMaterial("G4_W");
        NistManager->FindOrBuildMaterial("G4_Cu");
        NistManager->FindOrBuildMaterial("G4_Pb");
        NistManager->FindOrBuildMaterial("G4_Zn");
        NistManager->FindOrBuildMaterial("G4_Zr");
        NistManager->FindOrBuildMaterial("G4_Fe");
	std::cout << " Find Bronze and so on" << std::endl;
        NistManager->FindOrBuildMaterial("G4_BRONZE");
        NistManager->FindOrBuildMaterial("G4_ALUMINUM_OXIDE");
        NistManager->FindOrBuildMaterial("G4_KAPTON");
    }

    MaterialsBuilder::MaterialsBuilder()
    {
        InitialiseElementsFromNIST();
        InitialiseUserElements();
    }

    void MaterialsBuilder::DefinePolyethylenes() const{

        //Boron fraction was calculated by keeping constant H/C mass fraction ratio
        //Excluded any oxygen elements in borated polyethylene plastics [Matthieu - Jan 2018]

        G4Material* Pol = new G4Material("Pol", 0.96*g/cm3, 2);
        Pol->AddElement(elH,  14.86*percent());
        Pol->AddElement(elC,  85.14*percent());

        G4Material* PolyInnerShielding = new G4Material("PolyInnerShielding", 0.96*g/cm3, 2);
        PolyInnerShielding->AddElement(elH,  14.86*percent());
        PolyInnerShielding->AddElement(elC,  85.14*percent());

        G4Material* Poly_Chaussettes = new G4Material("Poly_Chaussette", 0.96*g/cm3, 2);
        Poly_Chaussettes->AddElement(elH,  14.86*percent());
        Poly_Chaussettes->AddElement(elC,  85.14*percent());

        // Borated polyethylene for outer shielding. "[C2H4]n polymer modified with 5% B2O3"; Density > 0.975 (--> using lower limit here) - from technical data sheet.
        // Calculation of mass fraction with carbon 12, hydrogen 1, oxygen 16 and natural boron. [Guillaume - Jan 2024] 
        G4Material* PolOuter = new G4Material("PolOuter", 0.975*g/cm3, 4);
        PolOuter->AddElement(elH, 13.69*percent());
        PolOuter->AddElement(elC, 81.31*percent());
        PolOuter->AddElement(elO, 3.45*percent());
        PolOuter->AddElement(elB, 1.55*percent());

        G4Material* PolOuter_Top = new G4Material("PolOuter_Top", 0.975*g/cm3, 4);
        PolOuter_Top->AddElement(elH, 13.69*percent());
        PolOuter_Top->AddElement(elC, 81.31*percent());
        PolOuter_Top->AddElement(elO, 3.45*percent());
        PolOuter_Top->AddElement(elB, 1.55*percent());

        G4Material* PolOuter_Extra = new G4Material("PolOuter_Extra", 0.975*g/cm3, 4);
        PolOuter_Extra->AddElement(elH, 13.69*percent());
        PolOuter_Extra->AddElement(elC, 81.31*percent());
        PolOuter_Extra->AddElement(elO, 3.45*percent());
        PolOuter_Extra->AddElement(elB, 1.55*percent());

        G4Material* PolOuter_Mid = new G4Material("PolOuter_Mid", 0.975*g/cm3, 4);
        PolOuter_Mid->AddElement(elH, 13.69*percent());
        PolOuter_Mid->AddElement(elC, 81.31*percent());
        PolOuter_Mid->AddElement(elO, 3.45*percent());
        PolOuter_Mid->AddElement(elB, 1.55*percent());


        G4Material* PolOuter_Bottom = new G4Material("PolOuter_Bottom", 0.975*g/cm3, 4);
        PolOuter_Bottom->AddElement(elH, 13.69*percent());
        PolOuter_Bottom->AddElement(elC, 81.31*percent());
        PolOuter_Bottom->AddElement(elO, 3.45*percent());
        PolOuter_Bottom->AddElement(elB, 1.55*percent());

        G4Material* materialPoly_Borated = new G4Material("BoratedPoly",1.07*g/cm3,2);
        materialPoly_Borated->AddMaterial(GetNistMaterial("G4_POLYETHYLENE"),95.0*percent());
        materialPoly_Borated->AddElement(elB,5.0*percent());

        // Polyethylene with boron at 1.75% - Has borated polyethylene any oxygen elements? FIXME
        G4Material* PolBor1_75pc = new G4Material("PolBor1_75pc", 0.96*g/cm3, 3);
        PolBor1_75pc->AddElement(elH,  14.6*percent());
        PolBor1_75pc->AddElement(elC,  83.65*percent());
        PolBor1_75pc->AddElement(elB,  1.75 *percent());

        // Polyethylene with boron at 3% - Has borated polyethylene any oxygen elements? FIXME
        G4Material* PolBor3pc = new G4Material("PolBor3pc", 0.96*g/cm3, 3);
        PolBor3pc->AddElement(elH,  14.424*percent());
        PolBor3pc->AddElement(elC,  82.586*percent());
        PolBor3pc->AddElement(elB,  3.00*percent());

        // Polyethylene with boron at 3.5% - Has borated polyethylene any oxygen elements? FIXME
        G4Material* PolBor3_5pc = new G4Material("PolBor3_5pc", 0.96*g/cm3, 3);
        PolBor3_5pc->AddElement(elH,  14.340*percent());
        PolBor3_5pc->AddElement(elC,  82.160*percent());
        PolBor3_5pc->AddElement(elB,  3.50 *percent());

        // Polyethylene with boron at 10% - Has borated polyethylene any oxygen elements? FIXME
        G4Material* PolBor10pc = new G4Material("PolBor10pc", 0.96*g/cm3, 3);
        PolBor10pc->AddElement(elH,  13.374*percent());
        PolBor10pc->AddElement(elC,  76.626*percent());
        PolBor10pc->AddElement(elB,  10.00 *percent());

    }

    void MaterialsBuilder::DefineDoubleChoozLiquids() const{

        G4Material* materialScintillator = new G4Material("Scintillator",1.032*g/cm3,2);
        materialScintillator->AddElement(elC,9);
        materialScintillator->AddElement(elH,10);
        G4Material* mineraloil = new G4Material("MineralOil",0.86*g/cm3,2);
        mineraloil->AddElement(elC,25);
        mineraloil->AddElement(elH,43);

        G4Material* materialDodecane = new G4Material("Dodecane",0.75*g/cm3,2);
        materialDodecane->AddElement(elC,12);
        materialDodecane->AddElement(elH,24);

        G4Material* materialPXE = new G4Material("PXE",0.988*g/cm3,2);
        materialPXE->AddElement(elC,16);
        materialPXE->AddElement(elH,18);

        G4Material* materialPPO = new G4Material("PPO",1.06*g/cm3,3);
        materialPPO->AddElement(elC,3);
        materialPPO->AddElement(elH,6);
        materialPPO->AddElement(elO,1);

        G4Material* materialNuTarget = new G4Material("NuTargetLiquid",804.59*kg/m3,4);
        materialNuTarget->AddMaterial(materialDodecane,74.5*percent());
        materialNuTarget->AddMaterial(materialPXE,24.6*percent());
        materialNuTarget->AddMaterial(materialPPO,0.8*percent());
        materialNuTarget->AddMaterial(GetNistMaterial("G4_Gd"),0.1*percent());

        G4Material* materialGammaCatcher = new G4Material("GammaCatcherLiquid",800.6*kg/m3,3);
        materialGammaCatcher->AddMaterial(materialDodecane,74.94*percent());
        materialGammaCatcher->AddMaterial(materialPXE,24.68*percent());
        materialGammaCatcher->AddMaterial(materialPPO,0.38*percent());

    }

    void MaterialsBuilder::DefineMetals() const{

        G4Material* materialSteel = new G4Material("Steel",7.9*g/cm3,2);
        materialSteel->AddElement(elFe,98.0*percent());
        materialSteel->AddElement(elC,2.0*percent());

        // Stainless Steel --------------------------------------------------------
        G4Material* StainlessSteel=new G4Material("StainlessSteel",8.*g/cm3, 9);
        StainlessSteel->AddElement(elC,  0.03*percent());
        StainlessSteel->AddElement(elCr, 19*percent());
        StainlessSteel->AddElement(elNi, 10*percent());
        StainlessSteel->AddElement(elMn, 2*percent());
        StainlessSteel->AddElement(elFe, 68.33*percent());
        StainlessSteel->AddElement(elSi, 0.5*percent());
        StainlessSteel->AddElement(elN,  0.1*percent());
        StainlessSteel->AddElement(elP,  0.02*percent());
        StainlessSteel->AddElement(elS,  0.02*percent());

        G4Material* StainlessSteelOVCWall=new G4Material("StainlessSteelOVCWall",8.*g/cm3, 9);
        StainlessSteelOVCWall->AddElement(elC,  0.03*percent());
        StainlessSteelOVCWall->AddElement(elCr, 19*percent());
        StainlessSteelOVCWall->AddElement(elNi, 10*percent());
        StainlessSteelOVCWall->AddElement(elMn, 2*percent());
        StainlessSteelOVCWall->AddElement(elFe, 68.33*percent());
        StainlessSteelOVCWall->AddElement(elSi, 0.5*percent());
        StainlessSteelOVCWall->AddElement(elN,  0.1*percent());
        StainlessSteelOVCWall->AddElement(elP,  0.02*percent());
        StainlessSteelOVCWall->AddElement(elS,  0.02*percent());

        G4Material* StainlessSteelOVCBride=new G4Material("StainlessSteelOVCBride",8.*g/cm3, 9);
        StainlessSteelOVCBride->AddElement(elC,  0.03*percent());
        StainlessSteelOVCBride->AddElement(elCr, 19*percent());
        StainlessSteelOVCBride->AddElement(elNi, 10*percent());
        StainlessSteelOVCBride->AddElement(elMn, 2*percent());
        StainlessSteelOVCBride->AddElement(elFe, 68.33*percent());
        StainlessSteelOVCBride->AddElement(elSi, 0.5*percent());
        StainlessSteelOVCBride->AddElement(elN,  0.1*percent());
        StainlessSteelOVCBride->AddElement(elP,  0.02*percent());
        StainlessSteelOVCBride->AddElement(elS,  0.02*percent());


        G4Material* StainlessSteelOVCFlange=new G4Material("StainlessSteelOVCFlange",8.*g/cm3, 9);
        StainlessSteelOVCFlange->AddElement(elC,  0.03*percent());
        StainlessSteelOVCFlange->AddElement(elCr, 19*percent());
        StainlessSteelOVCFlange->AddElement(elNi, 10*percent());
        StainlessSteelOVCFlange->AddElement(elMn, 2*percent());
        StainlessSteelOVCFlange->AddElement(elFe, 68.33*percent());
        StainlessSteelOVCFlange->AddElement(elSi, 0.5*percent());
        StainlessSteelOVCFlange->AddElement(elN,  0.1*percent());
        StainlessSteelOVCFlange->AddElement(elP,  0.02*percent());
        StainlessSteelOVCFlange->AddElement(elS,  0.02*percent());

        G4Material* StainlessSteelOVCBottom=new G4Material("StainlessSteelOVCBottom",8.*g/cm3, 9);
        StainlessSteelOVCBottom->AddElement(elC,  0.03*percent());
        StainlessSteelOVCBottom->AddElement(elCr, 19*percent());
        StainlessSteelOVCBottom->AddElement(elNi, 10*percent());
        StainlessSteelOVCBottom->AddElement(elMn, 2*percent());
        StainlessSteelOVCBottom->AddElement(elFe, 68.33*percent());
        StainlessSteelOVCBottom->AddElement(elSi, 0.5*percent());
        StainlessSteelOVCBottom->AddElement(elN,  0.1*percent());
        StainlessSteelOVCBottom->AddElement(elP,  0.02*percent());
        StainlessSteelOVCBottom->AddElement(elS,  0.02*percent());


        //Coppers ------------------------------------------------------------------
        new G4Material("CopperNOSV", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreenWall", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreenFlange", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreenBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperPlate", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperPillarCryoCube", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperPillar", 29.,  63.55*g/mole,  8.96 *g/cm3);

        //coppers for parts near detectors
        new G4Material("CopperCryoCubeElectronicPlate", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperCryoCubeElectronicCoverPlate", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperCryoCubeBottomPlate", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperCryoCubeConnectorSupport", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperKaptonSupport", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperSideKaptonSupport", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperInnerSupport", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperOuterSupport", 29.,  63.55*g/mole,  8.96 *g/cm3);


        new G4Material("CopperScreen1KWall", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen1KBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen1KFlangeMid", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen1KFlangeTop", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen1KFlangeBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen4KWall", 29.,  63.55*g/mole,  8.96 *g/cm3);

        new G4Material("CopperScreen4KBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen4KFlangeMid", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen4KFlangeTop", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen4KFlangeBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);

        new G4Material("CopperScreen50KWall", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen50KBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen50KFlangeMid", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen50KFlangeTop", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen50KFlangeBottom", 29.,  63.55*g/mole,  8.96 *g/cm3);


        new G4Material("CopperScreen1K", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen4K", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperScreen50K", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperPlate10mK", 29.,  63.55*g/mole,  8.96 *g/cm3);
	new G4Material("CopperPlate100mK", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperBoloCover", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperCryoCube", 29.,  63.55*g/mole,  8.96 *g/cm3);
        new G4Material("CopperInnerShielding", 29.,  63.55*g/mole,  8.96 *g/cm3);


        //Lead --------------------------------------------------------------------
        new G4Material("Lead"  , 82., 207.19*g/mole,  11.36*g/cm3);
        new G4Material("LeadLR"  , 82., 207.19*g/mole,  11.36*g/cm3);
        new G4Material("LeadOuter_Top", 82., 207.19*g/mole,  11.36*g/cm3);
        new G4Material("LeadOuter_Bottom", 82., 207.19*g/mole,  11.36*g/cm3);
        new G4Material("LeadOuter_Mid", 82., 207.19*g/mole,  11.36*g/cm3);
        new G4Material("LeadInnerShielding", 82., 207.19*g/mole,  11.36*g/cm3);

        // Aluminium --------------------------------------------------------------------
        new G4Material("Aluminium" , 13., 26.981539*g/mole,  2.7*g/cm3);

        // Mylar (Polyethylene Terephthalate - PET) ----------------------------------------
        G4Material* Mylar = new G4Material("Mylar", 1.4*g/cm3, 3);
        Mylar->AddElement(elH, 0.041959);  // Fraction by weight
        Mylar->AddElement(elC, 0.625017);  // Fraction by weight
        Mylar->AddElement(elO, 0.333025);  // Fraction by weight
        
    }

    void MaterialsBuilder::DefineSemiConductors() const{

        // Germanium  -------------------------------------------------------------
        G4Isotope* Ge70 = new G4Isotope("Ge70", 32, 70, 69.9240*g/mole);
        G4Isotope* Ge72 = new G4Isotope("Ge72", 32, 72, 71.9216*g/mole);
        G4Isotope* Ge73 = new G4Isotope("Ge73", 32, 73, 72.9233*g/mole);
        G4Isotope* Ge74 = new G4Isotope("Ge74", 32, 74, 73.9210*g/mole);
        G4Isotope* Ge76 = new G4Isotope("Ge76", 32, 76, 75.9213*g/mole);


        G4Element* GeNat = new G4Element("Germanium naturel", "Ge",5);
        GeNat->AddIsotope(Ge70,20.52*percent());
        GeNat->AddIsotope(Ge72,27.43*percent());
        GeNat->AddIsotope(Ge73,7.76*percent());
        GeNat->AddIsotope(Ge74,36.54*percent());
        GeNat->AddIsotope(Ge76,7.76*percent());

        G4Material* Germanium = new G4Material("Germanium", 5.310*g/cm3,1);
        Germanium->AddElement(GeNat, 1);

    }

    void MaterialsBuilder::DefineMinerals() const{

        G4Material* Chrysotile = new G4Material("Chrysotile",2.53*g/cm3,4);
        Chrysotile->AddElement(elMg,3);
        Chrysotile->AddElement(elSi,2);
        Chrysotile->AddElement(elO,9);
        Chrysotile->AddElement(elH,4);

        G4Material* materialQuartz = new G4Material("Quartz",2.81*g/cm3,2);
        materialQuartz->AddElement(elSi,1);
        materialQuartz->AddElement(elO,2);

        G4Material* materialCorundum = new G4Material("Corundum",2.81*g/cm3,2);
        materialCorundum->AddElement(elAl,2);
        materialCorundum->AddElement(elO,3);

        G4Material* materialIronOxide = new G4Material("IronOxide",2.81*g/cm3,2);
        materialIronOxide->AddElement(elFe,1);
        materialIronOxide->AddElement(elO,1);

        G4Material* materialMgOxide = new G4Material("MgOxide",2.81*g/cm3,2);
        materialMgOxide->AddElement(elMg,1);
        materialMgOxide->AddElement(elO,1);

        G4Material* materialKOxide = new G4Material("KOxide",2.81*g/cm3,2);
        materialKOxide->AddElement(elK,2);
        materialKOxide->AddElement(elO,1);

        G4Material* materialChoozRock = new G4Material("ChoozRock",2.81*g/cm3,5);
        materialChoozRock->AddMaterial(materialQuartz,58.0*percent());
        materialChoozRock->AddMaterial(materialCorundum,19.0*percent());
        materialChoozRock->AddMaterial(materialIronOxide,17.0*percent());
        materialChoozRock->AddMaterial(materialMgOxide,4.0*percent());
        materialChoozRock->AddMaterial(materialKOxide,2.0*percent());

    }

    void MaterialsBuilder::DefineDubnaGas() const
    {
        constexpr double heliumPressure = 400. * kPa();
        constexpr double argonPressure = 500. * kPa();
        constexpr double temperature = 293 * kelvin;

        constexpr double moleEnergy = MoleEnergy(temperature);
        double heliumDensity = elHe3->GetA() * heliumPressure / moleEnergy;
        double argonDensity = elAr40->GetA() * argonPressure / moleEnergy;
        double density = heliumDensity + argonDensity;
        constexpr double pressure = heliumPressure + argonPressure;

        auto DubnaGas = new G4Material{"DubnaHe3Ar40", density, 2, kStateGas, temperature, pressure};
        DubnaGas->AddElement(elHe3, heliumDensity / density);
        DubnaGas->AddElement(elAr40, argonDensity / density);

        auto DubnaHe3 = new G4Material{"DubnaHe3", heliumDensity, 1, kStateGas, temperature, heliumPressure};
        DubnaHe3->AddElement(elHe3, 1);
    }

    void MaterialsBuilder::DefineNeutronFilters() const{

        // Natural Iron -------------------------------------------------------------
        //new G4Material("Aluminium" , 13., 26.981539*g/mole,  2.7*g/cm3);
        new G4Material("Iron", 26., 55.845*g/mole, 7.874*g/cm3);

        //Aluminium_Fluoride
        G4Material* Aluminium_Fluoride = new G4Material("Aluminium_Fluoride",3.10*g/cm3,2);
        Aluminium_Fluoride->AddElement(elAl,1);
        Aluminium_Fluoride->AddElement(elF,3);

        //Fluental
        G4Material* Fluental = new G4Material("Fluental",2.94*g/cm3,2);
        Fluental->AddMaterial(Aluminium_Fluoride, 60*percent());
        Fluental->AddElement(elF, 40*percent());
    }

    void MaterialsBuilder::DefineGases() const
    {
        DefineDubnaGas();
    }

    void MaterialsBuilder::DefineAllMaterials() const{

        DefineBasicsFromNIST();

        //Concrete  ---------------------------------------------------------------
        // out of example LowBackground DMX
        G4Material* Concrete_DMX = new G4Material("Concrete_DMX",  2.3*g/cm3, 6,kStateSolid, 300.0*kelvin, 1.0*atmosphere);
        Concrete_DMX->AddElement(elH,  0.09972);
        Concrete_DMX->AddElement(elO,  0.60541);
        Concrete_DMX->AddElement(elAl, 0.014245);
        Concrete_DMX->AddElement(elSi, 0.227915);
        Concrete_DMX->AddElement(elCa, 0.04986);
        Concrete_DMX->AddElement(elFe, 0.00285);

        //Acrylic -----------------------------------------------------------------
        G4Material* Acrylic = new G4Material("Acrylic",1.188*g/cm3,3);
        Acrylic->AddElement(elC, 59.98*percent());
        Acrylic->AddElement(elH, 8.06*percent());
        Acrylic->AddElement(elO, 31.96*percent());



	// MDJ PCB for Electronic cards 
	G4Material* PCB = new G4Material("PCB",1.*g/cm3, 3);
	PCB->AddElement(elC, 12);
	PCB->AddElement(elH, 6);
	PCB->AddElement(elCl, 4);
	

        //Edelweiss bolometer -----------------------------------------------------
        G4Material* Brass = new G4Material("Brass", 8.5*g/cm3, 2);
        Brass->AddElement(elCu ,60.*percent());
        Brass->AddElement(elZn ,40.*percent());

        G4Material* Teflon = new G4Material("Teflon",2.00*g/cm3, 2);
        Teflon->AddElement(elC,1);
        Teflon->AddElement(elF, 2);

        G4Material* ConnectorsMaterial =new G4Material("ConnectorsMaterial",1.*g/cm3, 4);
        ConnectorsMaterial->AddElement(elC, 12);
        ConnectorsMaterial->AddElement(elH, 14);
        ConnectorsMaterial->AddElement(elO, 2);
        ConnectorsMaterial->AddElement(elN, 4);

        G4Material* BoloKapton =new G4Material("BoloKapton",1.36*g/cm3, 4);
        BoloKapton->AddElement(elC, 22);
        BoloKapton->AddElement(elH, 10);
        BoloKapton->AddElement(elO, 5);
        BoloKapton->AddElement(elN, 2);

        G4Material* BoloKaptonBand =new G4Material("BoloKaptonBand",1.36*g/cm3, 4);
        BoloKaptonBand->AddElement(elC, 22);
        BoloKaptonBand->AddElement(elH, 10);
        BoloKaptonBand->AddElement(elO, 5);
        BoloKaptonBand->AddElement(elN, 2);
	
	G4Material* WoodAgglomerate = new G4Material("WoodAgglomerate", 700.*kg/m3, 4);
	WoodAgglomerate->AddElement(elC, 50*percent());
	WoodAgglomerate->AddElement(elH, 6*percent());
	WoodAgglomerate->AddElement(elO, 43.7*percent());
	WoodAgglomerate->AddElement(elN, 0.3*percent());

        DefineDoubleChoozLiquids();
        DefineMetals();
        DefineSemiConductors();
        DefineMinerals();
        DefinePolyethylenes();
        DefineNeutronFilters();
        DefineGases();
        DefineColours();

    }

    void MaterialsBuilder::DefineColours() const{

        G4Colour  orangel  (.85, .35, 0.0) ;
        G4Colour::AddToMap("CopperNOSV", orangel);
        G4Colour::AddToMap("CopperScreenWall", orangel);
        G4Colour::AddToMap("CopperScreenFlange", orangel);
        G4Colour::AddToMap("CopperPlate", orangel);
        G4Colour::AddToMap("CopperPillar", orangel);
        G4Colour::AddToMap("CopperScreenBottom", orangel);

        G4Colour::AddToMap("CopperCryoCubeBottomPlate", orangel);
        G4Colour::AddToMap("CopperCryoCubeElectronicPlate", orangel);
        G4Colour::AddToMap("CopperCryoCubeElectronicCoverPlate", orangel);
        G4Colour::AddToMap("CopperCryoCubeConnectorSupport", orangel);
        G4Colour::AddToMap("CopperKaptonSupport", orangel);
        G4Colour::AddToMap("CopperSideKaptonSupport", orangel);
        G4Colour::AddToMap("CopperInnerSupport", orangel);
        G4Colour::AddToMap("CopperOuterSupport", orangel);


        G4Colour::AddToMap("CopperPillarCryoCube", orangel);
        G4Colour::AddToMap("CopperScreen1K", orangel);
        G4Colour::AddToMap("CopperScreen4K", orangel);
        G4Colour::AddToMap("CopperScreen50K", orangel);
        G4Colour::AddToMap("CopperPlate10mK", orangel);
        G4Colour::AddToMap("CopperPlate100mK", orangel);
        G4Colour::AddToMap("CopperBoloCover", orangel);
        G4Colour::AddToMap("CopperCryoCube", orangel);
        G4Colour::AddToMap("CopperInnerShielding", orangel);

        G4Colour  bluel    (0.0, 0.6, .8,0.5) ;
        G4Colour::AddToMap("StainlessSteel", bluel);
        G4Colour::AddToMap("StainlessSteelOVCWall", bluel);
        G4Colour::AddToMap("StainlessSteelOVCFlange", bluel);
        G4Colour::AddToMap("StainlessSteelOVCBottom", bluel);

        G4Colour  lgrey   (.85, .85, .85) ;
        G4Colour::AddToMap("Acrylic", lgrey);

        G4Colour  grey    (0.5, 0.5, 0.5) ;
	//G4Colour  grey    (0.5, 0.5, 0.5,0.5) ;
        G4Colour::AddToMap("Lead", grey);
        G4Colour::AddToMap("LeadOuter_Top", grey);
        G4Colour::AddToMap("LeadOuter_Bottom", grey);
        G4Colour::AddToMap("LeadOuter_Mid", grey);
        G4Colour::AddToMap("LeadInnerShielding", grey);


        G4Colour lightGrey(0.8, 0.8, 0.8, 1.0);  // light grey for Kapton
        G4Colour::AddToMap("Kapton", lightGrey);

	G4Colour  dgrey   (.25, .25, .25) ;
	G4Colour::AddToMap("LeadLR", dgrey);

        G4Colour  white (1.0, 1.0, 1.0) ;
        G4Colour::AddToMap("PolBor1_75pc", white);
        G4Colour::AddToMap("PolBor3pc", white);
        G4Colour::AddToMap("PolBor3_5pc", white);
        G4Colour::AddToMap("PolBor10pc", white);
        G4Colour::AddToMap("PolOuter_Extra", white);
        G4Colour::AddToMap("PolOuter_Top", white);
        G4Colour::AddToMap("PolOuter_Mid", white);
        G4Colour::AddToMap("PolOuter_Bottom", white);

        G4Colour::AddToMap("Pol", white);
        G4Colour::AddToMap("PolyInnerShielding", white);
        G4Colour::AddToMap("Poly_Chaussette", white);
	G4Colour::AddToMap("Scintillator", white);

        G4Colour  orange  (.75, .55, 0.0, 0.7) ;
        G4Colour::AddToMap("CuBoloCover",orange);

        G4Colour  FIDconnector (0.1, 0.1, 0.8) ;
        G4Colour::AddToMap("FIDconnector",FIDconnector);

        G4Colour  Brass (0.0, 0.9, 1.) ;
        G4Colour::AddToMap("Brass",Brass);

        G4Colour  Concrete (0.25, 0.25, 0.25) ;
        G4Colour::AddToMap("Concrete",Concrete);

        G4Colour  green (0., 1.0, 0.) ;
        G4Colour::AddToMap("Aluminium",green);

        G4Colour  red (1.0, 0., 0.) ;
        G4Colour::AddToMap("Germanium",red);

        G4Colour  dgreen (0., 0.75, 0.) ;
        G4Colour::AddToMap("Iron",green);

        G4Colour  dred (0.75, 0., 0.) ;
        G4Colour::AddToMap("Fluental",red);

        G4Colour silver(0.75, 0.75, 0.75); 
        G4Colour::AddToMap("Mylar", silver);

        G4Colour  yellow (1.0, 1.0, 0.0) ;
        G4Colour::AddToMap("Aluminium_Fluoride",yellow);
	
	G4Colour brown (0.87, 0.72,0.53) ;
	G4Colour::AddToMap("WoodAgglomerate", brown);

	G4Colour lgreen(84.,249.,141.);
	G4Colour::AddToMap("Connector",lgreen);
			  

    }

    G4Material* MaterialsBuilder::GetNistMaterial(const char* materialName)
    {
        return G4NistManager::Instance()->FindOrBuildMaterial(materialName);
    }

}
