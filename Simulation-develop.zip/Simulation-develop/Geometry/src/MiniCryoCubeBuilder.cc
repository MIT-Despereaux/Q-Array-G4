/*
 * minicryocubebuilder.cc
 *
 *  Created on: 9.02.2022
 *  Build the mini cryocube geometry
 *  Author: cazes
 */

#include <iostream>
#include "CLHEP/Units/SystemOfUnits.h"
#include "Geometry/MiniCryoCubeBuilder.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/MaterialColour.hh"
#include "SimuOutput/InfoHeaderWriter.hh"


#include "G4VisAttributes.hh"
#include "G4AssemblyVolume.hh"
#include "G4SDManager.hh"
#include "G4NistManager.hh"
#include "G4UnionSolid.hh"
#include "G4DisplacedSolid.hh"

namespace Geometry{

  MiniCryoCubeBuilder::MiniCryoCubeBuilder(G4LogicalVolume& mother_)
    :mother(mother_),
     name("MiniCryoCubeBuilder"),
     nbOfBolometers(0.),
     totalCrystalMass(0.),
     mVerbosity(1)
  {
  }

  void MiniCryoCubeBuilder::setAskewAngle(double angle) {
    mAskewAngle = angle;
}

double MiniCryoCubeBuilder::AskewAngle() const {
    return mAskewAngle;
}

  void MiniCryoCubeBuilder::setCryoCubeHolderFormationEnabled(bool val) {
      mCryoCubeHolderEnabled = val;
  }

  bool MiniCryoCubeBuilder::isCryoCubeHolderFormationEnabled() const {
      return mCryoCubeHolderEnabled;
  }



void MiniCryoCubeBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
    }
int MiniCryoCubeBuilder::Verbosity() const
    {
        return mVerbosity;
    }
  // dimensions
  /////////////


  double MiniCryoCubeBuilder::TotalHeight() const
  {
    return 64*CLHEP::mm;
  }

  // bottom plate

  double MiniCryoCubeBuilder::bottomPlateThickness() const {
    return 10*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::bottomPlateLength() const {
    return 208.0*CLHEP::mm;  // Reduced by 4.8mm to avoid overlap with 1K screen
  }
  double MiniCryoCubeBuilder::bottomPlateDepth() const {
    return 54.0*CLHEP::mm;   // Reduced by 4.0mm to avoid overlap with 1K screen
  }

  double MiniCryoCubeBuilder::bolometerDistance() const {
    return 55*CLHEP::mm;
  }
  

  // electronic plate

  double MiniCryoCubeBuilder::electronicPlateThickness() const {
    return 7*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::electronicPlateLength() const {
    return 186.0*CLHEP::mm;  // Reduced by 4.8mm to match bottom plate reduction
  }
  double MiniCryoCubeBuilder::electronicPlateDepth() const {
    return 36.0*CLHEP::mm;   // Reduced by 4.0mm to avoid potential overlap
  }
  double MiniCryoCubeBuilder::connectionHoleLength() const {
    return 30.27*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::connectionHoleDepth() const {
    return 4.8*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::electronicHoleThickness() const {
    return 3.3*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::electronicHoleLength() const {
    return 35*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::electronicHoleDepth() const {
    return 21*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::PCBLength() const {
    return 45*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::PCBDepth() const {
    return 30.2*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::PCBThickness() const {
    return 1*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::electronicCoverPlateThickness() const {
    return 2*CLHEP::mm;
  }
    
  // Connector

  double MiniCryoCubeBuilder::connectorThickness() const {
    return 5*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::connectorLength() const {
    return 20*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::connectorDepth() const {
    return 29*CLHEP::mm;     // Reduced by 3mm to avoid overlap with 1K screen
  }

  double MiniCryoCubeBuilder::connectorSupportLength() const {
    return 45*CLHEP::mm;
  }
  double MiniCryoCubeBuilder::connectorSupportDepth() const {
    return 7*CLHEP::mm;
  }

    // Setting in the case of several miniCryoCube build
    
  void MiniCryoCubeBuilder::SetMiniCryoCubeNumber(int miniCryoCubeNumber) //MAEL
  {
      mMiniCryoCubeNumber = miniCryoCubeNumber;
      nrows = (mMiniCryoCubeNumber+2)/3;
  }
    
  void MiniCryoCubeBuilder::SetMiniCryoCubeHorizontalSpacing(double MiniCryoCubeHorizontalSpacing) //MAEL
  {
      mHorizontalSpacing = MiniCryoCubeHorizontalSpacing;
  }
    
  void MiniCryoCubeBuilder::SetMiniCryoCubeVerticalSpacing(double MiniCryoCubeVerticalSpacing) //MAEL
  {
      mVerticalSpacing = MiniCryoCubeVerticalSpacing;
  }

  // main builder
  ///////////////

  std::vector<G4LogicalVolume*> MiniCryoCubeBuilder::Build(HepGeom::Transform3D transformation)
  {
    if (mVerbosity > 0) std::cout << "> Build " << name << " geometry" << std::endl;


    //rotation for everythin
    G4RotationMatrix* rotmat = new G4RotationMatrix();
    rotmat->rotateZ(360*CLHEP::deg/3); //askew
    G4ThreeVector emptypos = {0 , 0, 0};
    G4RotationMatrix* emptyrotmat = new G4RotationMatrix();

  auto finaltransform = new G4Transform3D(*rotmat, emptypos);

    miniCryoCubeAssembly = new G4AssemblyVolume();


    // Bottom plate
    
    auto solidBottomPlate = new FilledBox("MiniCryoCubeBottomPlate", bottomPlateLength(), bottomPlateDepth(), bottomPlateThickness());
    auto logicBottomPlate = new G4LogicalVolume(solidBottomPlate, G4Material::GetMaterial("CopperCryoCubeBottomPlate"), "MiniCryoCubeBottomPlate");
    SetColourFromMaterial(logicBottomPlate, "CopperCryoCubeBottomPlate");
    G4ThreeVector translation(0,0,-TotalHeight()/2.+ bottomPlateThickness()/2.);
    miniCryoCubeAssembly->AddPlacedVolume(logicBottomPlate, translation, nullptr);


    // Electronic plate

    auto solidElectronicPlateVol0 = new FilledBox("ElectronicPlateBaseVolume",electronicPlateLength(), electronicPlateDepth(), electronicPlateThickness());

    auto solidConnectionHole = new FilledBox("connectionHole",connectionHoleLength(), connectionHoleDepth(),electronicPlateThickness());

    G4ThreeVector position(-bolometerDistance(), (-electronicPlateDepth()+connectionHoleDepth())/2. ,0.);
    auto solidElectronicPlateVol1 = new G4SubtractionSolid("ElectronicPlateVol1",solidElectronicPlateVol0,solidConnectionHole,nullptr,position);
    position.setX(0.);
    auto solidElectronicPlateVol2 = new G4SubtractionSolid("ElectronicPlateVol2",solidElectronicPlateVol1,solidConnectionHole,nullptr,position);
    position.setX(bolometerDistance());
    auto solidElectronicPlateVol3 = new G4SubtractionSolid("ElectronicPlateVol3",solidElectronicPlateVol2,solidConnectionHole,nullptr,position);

    auto solidElectronicHole = new FilledBox("elecronicHole",electronicHoleLength(), electronicHoleDepth(), electronicHoleThickness());
    position.setY(-electronicPlateDepth()/2.+connectionHoleDepth()+electronicHoleDepth()/2.);
    position.setZ((-electronicPlateThickness()+electronicHoleThickness())/2.);

    position.setX(-bolometerDistance());
    auto solidElectronicPlateVol4 = new G4SubtractionSolid("ElectronicPlateVol4",solidElectronicPlateVol3,solidElectronicHole,nullptr,position);
    position.setX(0.);
    auto solidElectronicPlateVol5 = new G4SubtractionSolid("ElectronicPlateVol5",solidElectronicPlateVol4,solidElectronicHole,nullptr,position);
    position.setX(bolometerDistance());
    auto solidElectronicPlateVol6 = new G4SubtractionSolid("ElectronicPlateVol6",solidElectronicPlateVol5,solidElectronicHole,nullptr,position);

    
    auto solidPCBHole = new FilledBox("PCBHole",PCBLength(), PCBDepth(), electronicPlateThickness() - electronicHoleThickness());
    position.setY(-electronicPlateDepth()/2.+connectionHoleDepth()+PCBDepth()/2.);
    position.setZ(electronicHoleThickness()/2.);  // = electronicPlateThickness/2 - (electronicPlateThickness - electronicHoleThickness )/2

    position.setX(-bolometerDistance());
    auto solidElectronicPlateVol7 = new G4SubtractionSolid("ElectronicPlateVol7",solidElectronicPlateVol6,solidPCBHole,nullptr,position);
    position.setX(0.);
    auto solidElectronicPlateVol8 = new G4SubtractionSolid("ElectronicPlateVol8",solidElectronicPlateVol7,solidPCBHole,nullptr,position);
    position.setX(bolometerDistance());
    auto solidElectronicPlate = new G4SubtractionSolid("ElectronicPlate",solidElectronicPlateVol8,solidPCBHole,nullptr,position);
   
    auto logicElectronicPlate = new G4LogicalVolume(solidElectronicPlate, G4Material::GetMaterial("CopperCryoCubeElectronicPlate"), "electronicPlate");
    SetColourFromMaterial(logicElectronicPlate, "CopperCryoCubeElectronicPlate");

    translation.setZ(TotalHeight()/2. - electronicCoverPlateThickness()-electronicPlateThickness()/2.);
    miniCryoCubeAssembly->AddPlacedVolume(logicElectronicPlate, translation, nullptr);


    // Kapton from 10mK to 1K (BoloKapton Band)
    // Single-volume U-shaped band with 0.1 mm sheet thickness (X),
    

    auto buildKaptonBandSingle = [&](double xOffset) {
      const double eps              = 0.02*CLHEP::mm;   // tiny gaps to avoid self-overlaps
      const double bandThicknessX   = 0.2*CLHEP::mm;    // sheet thickness (full) along X
      const double horizWidthZ      = 0.2*CLHEP::mm;    // top/bottom: 0.2 mm in Z (full)
      const double bandWidthY       = 10.0*CLHEP::mm;   // 1 cm width along Y for all parts

      // Plate faces (Z) and top/bottom edges (Y)
      const double zTopFace    = +TotalHeight()/2.0 - electronicCoverPlateThickness() - electronicPlateThickness();
      const double zBottomFace = -TotalHeight()/2.0 + bottomPlateThickness();
      const double yTopEdge    =  electronicPlateDepth()/2.0;

      // Outward end is 10 mm beyond the top plate edge
      const double yOutward    = yTopEdge + bandWidthY;

      // Strap center in Y so that top horizontal spans [yTopEdge+eps/2, yOutward-eps/2]
      const double yCenter = yTopEdge + bandWidthY/2.0;
      const double zCenter = 0.5*(zTopFace + zBottomFace);

      // Full sizes (FilledBox expects full lengths)
      // 1) Top horizontal: 10 mm in Y, 0.2 mm in Z
      const double topLenY  = bandWidthY - eps;
      const double topLenZ  = horizWidthZ;

      // 2) Vertical leg: 10 mm in Y, span in Z between horizontals
      const double vertLenY = bandWidthY;
      const double vertLenZ = std::max(0.0, (zTopFace - zBottomFace) - 2.0*(horizWidthZ + eps));

      // 3) Bottom horizontal: 10 mm in Y, 0.2 mm in Z
      const double botLenY  = bandWidthY;
      const double botLenZ  = horizWidthZ;

      // Relative positions (to strap center)
      const double topPosY  = 0.0; // centered at yCenter
      const double topPosZ  = (zTopFace - topLenZ/2.0 - eps) - zCenter;


      double kaptonBandWidth = 20*CLHEP::mm;
      const double vertPosY = (kaptonBandWidth/2.0) - 0.05*CLHEP::mm;
      const double vertPosZ = ((zBottomFace + botLenZ + eps) + (zTopFace - topLenZ - eps))/2.0 - zCenter;

      const double botPosY  = 0.0; // centered at yCenter
      const double botPosZ  = (zBottomFace + botLenZ/2.0 + eps) - zCenter;

      // Build base boxes (full sizes)

  // Set the vertical piece (vertBase) Z-length exactly to the gap between the
  // inner faces of the top and bottom bands (avoid overlaps by accounting for eps)
  // This equals vertLenZ computed above.
  auto topBase  = new FilledBox("KaptonTopStrip_base",  20*CLHEP::mm, kaptonBandWidth,  0.2*CLHEP::mm);
  auto vertBase = new FilledBox("KaptonVertStrip_base", kaptonBandWidth, 0.2*CLHEP::mm, vertLenZ);
  auto botBase  = new FilledBox("KaptonBotStrip_base",  20*CLHEP::mm, kaptonBandWidth, 0.2*CLHEP::mm);

      // Displace parts relative to strap center
      auto idRot = new G4RotationMatrix();
      auto topDisp  = new G4DisplacedSolid("KaptonTopStrip_disp",  topBase,  idRot, G4ThreeVector(0., topPosY,  topPosZ));
      auto vertDisp = new G4DisplacedSolid("KaptonVertStrip_disp", vertBase, idRot, G4ThreeVector(0., vertPosY, vertPosZ));
      auto botDisp  = new G4DisplacedSolid("KaptonBotStrip_disp",  botBase,  idRot, G4ThreeVector(0., botPosY,  botPosZ));

      // Union into a single solid
      auto u1 = new G4UnionSolid("KaptonStrap_u1", topDisp,  vertDisp);
      auto u2 = new G4UnionSolid("KaptonStrap_u2", u1,       botDisp);

      auto logicStrap = new G4LogicalVolume(u2, G4Material::GetMaterial("BoloKaptonBand"), "BoloKaptonBand");
      SetColourFromMaterial(logicStrap, "Kapton");

      // Place at strap center for this column
      G4ThreeVector strapPos(xOffset, yCenter, zCenter);
      miniCryoCubeAssembly->AddPlacedVolume(logicStrap, strapPos, nullptr);
    };

    // One strap per column
    buildKaptonBandSingle(-bolometerDistance());
    buildKaptonBandSingle( 0.0);
    buildKaptonBandSingle( bolometerDistance());


    // electronic board


    auto solidElectronicBoard = new FilledBox("ElectronicBoard",PCBLength(),PCBDepth(),PCBThickness());
    auto logicElectronicBoard = new G4LogicalVolume(solidElectronicBoard,G4Material::GetMaterial("PCB"),"ElectronicBoard");
    SetColourFromMaterial(logicElectronicBoard,"ElectronicBoard");

    translation.setY(-electronicPlateDepth()/2.+connectionHoleDepth()+PCBDepth()/2.);
    translation.setZ(TotalHeight()/2. - electronicCoverPlateThickness()- electronicPlateThickness() + electronicHoleThickness() + PCBThickness()/2.);

    translation.setX(-bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicElectronicBoard, translation, nullptr);
    translation.setX(0.);
    miniCryoCubeAssembly->AddPlacedVolume(logicElectronicBoard, translation, nullptr);
    translation.setX(bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicElectronicBoard, translation, nullptr);

 
    // electronic cover
    
    auto solidElectronicCoverPlate = new FilledBox("ElectronicCoverPlate",electronicPlateLength(), electronicPlateDepth(),electronicCoverPlateThickness());
    auto logicElectronicCoverPlate = new G4LogicalVolume(solidElectronicCoverPlate, G4Material::GetMaterial("CopperCryoCubeElectronicCoverPlate"), "ElectronicCoverPlate");
    SetColourFromMaterial(logicElectronicCoverPlate, "CopperCryoCubeElectronicCoverPlate");

    translation.setX(0.);
    translation.setY(0.);
    translation.setZ(TotalHeight()/2. - electronicCoverPlateThickness()/2.);
    miniCryoCubeAssembly->AddPlacedVolume(logicElectronicCoverPlate, translation, nullptr);
   

    // Connectors

    auto solidConnectorSupportFull = new FilledBox("ConnectorSupportFull", connectorSupportLength(), connectorSupportDepth(), electronicPlateThickness());
    auto solidConnector = new FilledBox("Connector", connectorLength(), connectorDepth(), connectorThickness());
    position.setX(0.);
    position.setY(0.);
    position.setZ(0.);
    auto solidConnectorSupport = new G4SubtractionSolid("ConnectorSupport",solidConnectorSupportFull,solidConnector,nullptr,position);

    auto logicConnectorSupport = new G4LogicalVolume(solidConnectorSupport, G4Material::GetMaterial("CopperCryoCubeConnectorSupport"), "ConnectorSupport");
    SetColourFromMaterial(logicConnectorSupport, "CopperCryoCubeConnectorSupport");

    auto logicConnector = new G4LogicalVolume(solidConnector, G4Material::GetMaterial("ConnectorsMaterial"), "Connector");
    SetColourFromMaterial(logicConnector, "Connector");

    translation.setZ(TotalHeight()/2. - electronicCoverPlateThickness() - electronicPlateThickness()/2.);    
    translation.setY(-electronicPlateDepth()/2. -connectorSupportDepth()/2.);

    translation.setX(-bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicConnectorSupport, translation, nullptr);
    translation.setX(0.);
    miniCryoCubeAssembly->AddPlacedVolume(logicConnectorSupport, translation, nullptr);
    translation.setX(bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicConnectorSupport, translation, nullptr);

    translation.setY(-electronicPlateDepth()/2. - connectorDepth()/2.);

    translation.setX(-bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicConnector, translation, nullptr);
    translation.setX(0.);
    miniCryoCubeAssembly->AddPlacedVolume(logicConnector, translation, nullptr);
    translation.setX(bolometerDistance());
    miniCryoCubeAssembly->AddPlacedVolume(logicConnector, translation, nullptr);
    
    


    G4bool checkOverlaps = (mVerbosity > 0);
    miniCryoCubeAssembly->MakeImprint(&mother, transformation, 0, checkOverlaps);

    if(mVerbosity > 0) {
        G4cout << "MiniCryoCubeBuilder: Overlap checking enabled" << G4endl;
    }

    // Bolometers
    bolometerBuilder = new GermaniumBolometerBuilder(mother);
    bolometerBuilder->SetVerbosity(mVerbosity); 
    double zBottomBolometerPlate = -TotalHeight()/2. + bottomPlateThickness() + 2.5*CLHEP::mm;
    for(int i = -1; i<=1 ; ++i) {
     

      position.setX(i*bolometerDistance());
      position.setY(0);
      position.setZ(zBottomBolometerPlate + 0.5*bolometerBuilder->GetBolometerFullHight());

      // G4ThreeVector position_prerot = transformation.getTranslation() + position;
      G4ThreeVector position_prerot = position;

      double x_val = position_prerot.x();
      double y_val = position_prerot.y();
      double z_val = position_prerot.z();

      G4ThreeVector position_postrot = G4ThreeVector{x_val* std::cos(mAskewAngle) - y_val* std::sin(mAskewAngle),
        x_val* std::sin(mAskewAngle) + y_val* std::cos(mAskewAngle), z_val};

       G4cout << "MiniCryoCube Position" << transformation.getTranslation() << G4endl;
  

      // G4Transform3D boloPosition(transformation.getRotation(),transformation.getTranslation() + position);
      G4Transform3D boloPosition(transformation.getRotation(),transformation.getTranslation() + position_postrot);
      // G4Transform3D boloPosition(*emptyrotmat,position_postrot);
      // G4Transform3D boloPosition(*emptyrotmat,position);
       G4cout << "placing bolometer" << position_postrot << " pos" << G4endl;
      bolometerBuilder->Build(boloPosition);
      totalCrystalMass += bolometerBuilder->GetCrystalMass();
      G4cout << "totalCrystalMass = " << totalCrystalMass << " kg" << G4endl;
    }


    auto beginVolIt = miniCryoCubeAssembly->GetVolumesIterator();
    auto endVolIt = beginVolIt + miniCryoCubeAssembly->TotalImprintedVolumes();
    auto volIt = beginVolIt;
    nbOfBolometers=1;
    while (volIt != endVolIt)
      {
	if ((*volIt)->GetLogicalVolume()->GetSolid()==bolometerBuilder->GetSolidBolo())
	  //if ((*volIt)->GetLogicalVolume()->GetSolid()->GetName()=="CrystalBolo")
	  {
	    if (mVerbosity > 0) std::cout <<  (*volIt)->GetName() << " assigned copy number " << nbOfBolometers <<std::endl;
	    (*volIt)->SetCopyNo(nbOfBolometers);
	    ++nbOfBolometers;
	  }
	else (*volIt)->SetCopyNo((*volIt)->GetCopyNo()+1000);
	++volIt;
      }

    if (mVerbosity > 0) std::cout << name << " constructed." << std::endl;
    return {bolometerBuilder->GetLogicBolo()};

  }
    
std::vector<G4LogicalVolume*> MiniCryoCubeBuilder::BuildSeveral(HepGeom::Transform3D transformation)
  {
      std::vector<G4LogicalVolume*> vecLogicCrystal;
      std::vector<G4LogicalVolume*> volumes;
      G4ThreeVector posMiniCryoCube;
      G4ThreeVector posMiniCryoCube_prerot;


      int miniCryoCubeCounter = 0; 
      G4cout << "nrows = " << nrows <<  G4endl;
      // G4cout << "DO I  WANT TO BUILD THE FORMTAION? " << mCryoCubeHolderEnabled <<  G4endl;
      // G4cout << "DO I  WANT TO BUILD THE FORMTAION? (FUCTION) " << isCryoCubeHolderFormationEnabled() <<  G4endl;

      // double askew_angle = 
      // double* askew_angle{0};
      int j; //initializing j 
      std::vector<double> stand_heights; //initializing list
      

      setAskewAngle(30*CLHEP::deg); // common to both
      if(isCryoCubeHolderFormationEnabled()){
        // double askew_angle = 360/3;
        // setAskewAngle(360/3*CLHEP::deg);
        
        // G4cout << "setting angleeeee" <<   G4endl;
        if (GetNumberOfMiniCryoCube() > 6){
          G4cout << "Unable to fit more than 6 MiniCryoCubes in the CryoCube holder." <<  G4endl;
          SetMiniCryoCubeNumber(6);
          G4cout << "Setting MiniCryoCube number to maximum: " << GetNumberOfMiniCryoCube() <<  G4endl;

        }

        


      G4cout << "Number of MMC = " << GetNumberOfMiniCryoCube() <<  G4endl;

        

        // SetMiniCryoCubeVerticalSpacing(34*CLHEP::mm);
        SetMiniCryoCubeVerticalSpacing(61*CLHEP::mm);
        // SetMiniCryoCubeHorizontalSpacing(-12*CLHEP::mm);
          stand_heights = {17*CLHEP::mm,8.5*CLHEP::mm,0*CLHEP::mm};
          // G4cout << "stand heights!!! inside: ";
      // for (const auto& val : stand_heights) {
      //     G4cout << val << " ";
      // }
      //   G4cout << G4endl;
       j = 0;

      
      }

      else { //mini crycube not in holder
        // double askew_angle = 360/3;
        // setAskewAngle(360/3*CLHEP::deg);
        // setAskewAngle(30*CLHEP::deg);
        // G4cout << "setting angleeeee" <<   G4endl;
        // if (GetNumberOfMiniCryoCube() > 6){
        //   G4cout << "Unable to fit moVerire than 6 MiniCryoCubes in the CryoCube holder." <<  G4endl;
        //   SetMiniCryoCubeNumber(6);
        //   G4cout << "Setting MiniCryoCube number to maximum: " << GetNumberOfMiniCryoCube() <<  G4endl;

        // }

        


      G4cout << "Number of MMC = " << GetNumberOfMiniCryoCube() <<  G4endl;

        

        // SetMiniCryoCubeVerticalSpacing(34*CLHEP::mm);
        SetMiniCryoCubeVerticalSpacing(0*CLHEP::mm); // I think this can be changed 
        // SetMiniCryoCubeHorizontalSpacing(-12*CLHEP::mm);
          stand_heights = {0*CLHEP::mm,0*CLHEP::mm,0*CLHEP::mm};
      //     G4cout << "stand heights!!! insidebut not in the hodler: ";
      // for (const auto& val : stand_heights) {
      //     G4cout << val << " ";
      // }
      //   G4cout << G4endl;
       j = 0;

      
      }



      

      int nMCC_last_row = mMiniCryoCubeNumber % 3;


      // G4cout << "angle:" << mAskewAngle <<  G4endl;
      // G4cout << "stand heights!!! outside: ";
      // for (const auto& val : stand_heights) {
      //     G4cout << val << " ";
      // }
        // G4cout << G4endl;
      


      

      G4RotationMatrix* emptyrotmat = new G4RotationMatrix();


      G4RotationMatrix* rotmat = new G4RotationMatrix();
      rotmat->rotateZ(mAskewAngle); //askew

      // auto subtransform = new G4Transform3D(*rotmat, position_top10mKPlatesub);

      // G4Transform3D MCCtrans = (*top10mKtransform) * mTransformation;*CLHEP::mm

      // std::vector<double> stand_heights = {17*CLHEP::mm,8.5*CLHEP::mm,0*CLHEP::mm};
      // std::vector<double> stand_heights = {8.5*CLHEP::mm,0*CLHEP::mm,17*CLHEP::mm};
      


      for (int row = 0; row < nrows; row++)
      {
        int row_start_pos = -1;
        if (row == nrows -1 && nMCC_last_row == 1){row_start_pos=0;} // centering the MiniCryoCube on the last stage if built alone
        for (int i = row_start_pos; i <= 1; i++)
        {

          // G4cout << "What row I am on" << row <<  G4endl;



  
          // posMiniCryoCube_prerot = transformation.getTranslation() + G4ThreeVector(0, -i*(bottomPlateDepth()/2 + mHorizontalSpacing + connectorDepth() + electronicPlateDepth()/2), row*(TotalHeight() + mVerticalSpacing)); //MAEL on construit en partant du bas
          if(isCryoCubeHolderFormationEnabled()){
          posMiniCryoCube_prerot = transformation.getTranslation() + G4ThreeVector(0, -i*(bottomPlateDepth()+ 14*CLHEP::mm), -row*(TotalHeight() + mVerticalSpacing)); //MAEL on construit en partant du bas
          }
          else{
          posMiniCryoCube_prerot = transformation.getTranslation() + G4ThreeVector(0, -i*(bottomPlateDepth()/2 + mHorizontalSpacing + connectorDepth() + electronicPlateDepth()/2), row*(TotalHeight() + mVerticalSpacing)); //MAEL on construit en partant du bas

          }

          double x_val = posMiniCryoCube_prerot.x();
          double y_val = posMiniCryoCube_prerot.y();
          double z_val;
          // if(isCryoCubeHolderFormationEnabled()){
            if (j == 3){
            j = 0; //resetting j


          }

          // G4cout << "standheights[j] " <<stand_heights[j] <<G4endl;

            if (row == nrows -1 && nMCC_last_row == 1){//if ony one MCC on level
              z_val = posMiniCryoCube_prerot.z() + stand_heights[1]; //use the middle one in the list
              //  G4cout << "HEIGHTS " << stand_heights[1] << G4endl;
              }

            else{
              z_val = posMiniCryoCube_prerot.z() + stand_heights[j];
              //  G4cout << "HEIGHTS " << stand_heights[j] << G4endl;
              }
            // double z_val = posMiniCryoCube_prerot.z() ;
         
          // G4cout << "row number " << z_val << G4endl;
          // G4cout << "yval " << y_val << G4endl;

          

          j++;
          // }
          // else{
          //    z_val = posMiniCryoCube_prerot.z();
          // }
          // G4cout << "row number after increment " << j << G4endl;
          // G4cout << "This is the z_value: " << z_val << G4endl;







          posMiniCryoCube = G4ThreeVector{x_val* std::cos(mAskewAngle) - y_val* std::sin(mAskewAngle),
          x_val* std::sin(mAskewAngle) + y_val* std::cos(mAskewAngle), z_val};

          // G4ThreeVector position_bottom1Kpillar= position_top1KPlate + G4ThreeVector{x_val* std::cos(360*CLHEP::deg/3) - y_val* std::sin(360*CLHEP::deg/3),
          // x_val* std::sin(360*CLHEP::deg/3) + y_val* std::cos(360*CLHEP::deg/3),-(mBottom1KPillar_length/2.+ mTop1KPlate_height/2.)};

          G4cout << "pos " << miniCryoCubeCounter << " mMiniCryoCubeNumber " << mMiniCryoCubeNumber<<" MiniCryoCube " << posMiniCryoCube << G4endl;

          auto MCCtransform = new G4Transform3D(*rotmat, posMiniCryoCube);

          G4Transform3D MCCtransform_total = (*MCCtransform) * transformation;


          // vecLogicCrystal = Build(HepGeom::Translate3D(posMiniCryoCube));
          // vecLogicCrystal = Build(MCCtransform_total);
          vecLogicCrystal = Build(*MCCtransform);
          for (G4LogicalVolume* crystalBolo : vecLogicCrystal )
          {
              name = crystalBolo->GetName();
              std::string newName = name + std::to_string(miniCryoCubeCounter);
              crystalBolo->SetName(newName);
          }
          volumes.insert(std::end(volumes), std::begin(vecLogicCrystal), std::end(vecLogicCrystal));
          miniCryoCubeCounter++;
          if (miniCryoCubeCounter == mMiniCryoCubeNumber){


            break;} // stop building when numbers of MiniCryoCubes reached
        }
      }
      /*
      for(int i = k-1; i<=1 ; ++i) 
      {
          posMiniCryoCube = transformation.getTranslation() + G4ThreeVector(0, i*(bottomPlateDepth()/2 + mHorizontalSpacing + connectorDepth() + electronicPlateDepth()/2), -TotalHeight() - mVerticalSpacing); //MAEL on construit en partant du bas
          miniCryoCubeCounter++;
          G4cout << "pos " << miniCryoCubeCounter << " MiniCryoCube " << posMiniCryoCube << G4endl;
          vecLogicCrystal = Build(HepGeom::Translate3D(posMiniCryoCube));
          for (G4LogicalVolume* crystalBolo : vecLogicCrystal )
          {
              name = crystalBolo->GetName();
              std::string newName = name + std::to_string(miniCryoCubeCounter);
              crystalBolo->SetName(newName);
          }
          volumes.insert(std::end(volumes), std::begin(vecLogicCrystal), std::end(vecLogicCrystal));
      }
      for(int j = l-1; j<=1; j++)
      {
          posMiniCryoCube = transformation.getTranslation() + G4ThreeVector(0, j*(bottomPlateDepth()/2 + mHorizontalSpacing + connectorDepth() + electronicPlateDepth()/2), 0);
          miniCryoCubeCounter++;
          G4cout << "pos " << miniCryoCubeCounter << " MiniCryoCube " << posMiniCryoCube << G4endl;
          vecLogicCrystal = Build(HepGeom::Translate3D(posMiniCryoCube));
          for (G4LogicalVolume* crystalBolo : vecLogicCrystal )
          {
              name = crystalBolo->GetName();
              std::string newName = name + std::to_string(miniCryoCubeCounter);
              crystalBolo->SetName(newName);
          }
          volumes.insert(std::end(volumes), std::begin(vecLogicCrystal), std::end(vecLogicCrystal));
      }
      for(int n = m-1; n<=1; n++)
      {
          posMiniCryoCube = transformation.getTranslation() + G4ThreeVector(0, n*(bottomPlateDepth()/2 + mHorizontalSpacing + connectorDepth() + electronicPlateDepth()/2), TotalHeight() + mVerticalSpacing);
          miniCryoCubeCounter++;
          G4cout << "position " << miniCryoCubeCounter << " MiniCryoCube " << posMiniCryoCube << G4endl;
          vecLogicCrystal = Build(HepGeom::Translate3D(posMiniCryoCube));
          for (G4LogicalVolume* crystalBolo : vecLogicCrystal )
          {
              name = crystalBolo->GetName();
              std::string newName = name + std::to_string(miniCryoCubeCounter);
              crystalBolo->SetName(newName);
          }
          volumes.insert(std::end(volumes), std::begin(vecLogicCrystal), std::end(vecLogicCrystal));
      }
      */  
      return {volumes};
  }


  void ROOTWrite(const MiniCryoCubeBuilder& cryocube, TDirectory& directory)
  {
    double bolometerMass = cryocube.GetBolometerMass();

    InfoHeaderWriter header("MiniCryoCube", "MiniCryoCube info");
    header.SetKeyValue("BolometerMass", bolometerMass);
    header.WriteIn(directory);
  }

}
