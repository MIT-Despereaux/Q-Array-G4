#include "Geometry/OuterShieldingMessengerWithDT.hh"

/// Project includes
#include "Geometry/OuterShieldingBuilderWithDT.hh"

namespace Geometry
{
    OuterShieldingMessengerWithDT::OuterShieldingMessengerWithDT(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("OuterShielding with DT Neutron Source command directory");

        mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build a bucket shape shielding to place around a cryostat with a DT Source drilled into it");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);


        mCmdInnerRadius.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerRadius").c_str(), this));
        mCmdInnerRadius->SetGuidance("Set inner radius of the shielding, arg = XXX unit (ex: 3 cm)");
        mCmdInnerRadius->AvailableForStates(G4State_Idle);

        mCmdInnerHeight.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerHeight").c_str(), this));
        mCmdInnerHeight->SetGuidance("Set inner height of the shielding, arg = XXX unit (ex: 3 cm)");
        mCmdInnerHeight->AvailableForStates(G4State_Idle);

        mCmdLeadThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setLeadThickness").c_str(), this));
        mCmdLeadThickness->SetGuidance("Set thickness of lead layer, arg = XXX unit (ex: 3 cm)");
        mCmdLeadThickness->AvailableForStates(G4State_Idle);

        mCmdPolyThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setPolyThickness").c_str(), this));
        mCmdPolyThickness->SetGuidance("Set thickness of polyethylene layer, arg = XXX unit (ex: 3 cm)");
        mCmdPolyThickness->AvailableForStates(G4State_Idle);

        mCmdIronAsCylinder.reset(new G4UIcmdWithABool((cmdPrefixPath + "setIronAsCylinder").c_str(), this));
        mCmdIronAsCylinder->SetGuidance("Use your Iron Filter in the form of Cylinder");
        mCmdIronAsCylinder->AvailableForStates(G4State_Idle);

        mCmdIronThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setIronThickness").c_str(), this));
        mCmdIronThickness->SetGuidance("Set thickness of Iron Filter, arg = XXX unit (ex: 3 cm)");
        mCmdIronThickness->AvailableForStates(G4State_Idle);

        mCmdFluentalThicknessExtra.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setFluentalThicknessExtra").c_str(), this));
        mCmdFluentalThicknessExtra->SetGuidance("Set thickness of Fluental moderator, arg = XXX unit (ex: 3 cm)");
        mCmdFluentalThicknessExtra->AvailableForStates(G4State_Idle);

        mCmdExtraPolyLayer.reset(new G4UIcmdWithABool((cmdPrefixPath + "setExtraPolyLayer").c_str(), this));
        mCmdExtraPolyLayer->SetGuidance("Active the extra polyethylene layer as external layer");
        mCmdExtraPolyLayer->AvailableForStates(G4State_Idle);

        mCmdExtraPolyThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setExtraPolyThickness").c_str(), this));
        mCmdExtraPolyThickness->SetGuidance("Set thickness of the extra polyethylene layer (external), arg = XXX unit (ex: 3 cm)");
        mCmdExtraPolyThickness->AvailableForStates(G4State_Idle);
    }

    void OuterShieldingMessengerWithDT::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
        else if(command == mCmdInnerRadius.get())
        {
            mBuilder.SetInnerRadius(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdInnerHeight.get())
        {
            mBuilder.SetInnerHeight(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdLeadThickness.get())
        {
            mBuilder.SetLeadThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdPolyThickness.get())
        {
            mBuilder.SetPolyethyleneThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdIronAsCylinder.get())
        {
            mBuilder.SetIronAsCylinder(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdIronThickness.get())
        {
            mBuilder.SetIronThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdFluentalThicknessExtra.get())
        {
            mBuilder.SetFluentalThicknessExtra(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdExtraPolyLayer.get())
        {
            mBuilder.SetExtraPolyethyleneLayer(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdExtraPolyThickness.get())
        {
            mBuilder.SetExtraPolyethyleneThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
    }
}
