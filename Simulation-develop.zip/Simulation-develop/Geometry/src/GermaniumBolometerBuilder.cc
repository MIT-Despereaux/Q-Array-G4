/*
 * GermaniumBolomterBuilder.cc
 *
 *  Created on: 1.04.2021
 *  geometry of the germanium bolometer + casing.
 *      Author: cazes
 */

#include "Geometry/GermaniumBolometerBuilder.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/MaterialsBuilder.hh"
#include "Geometry/MaterialColour.hh"


#include "G4Polycone.hh"
#include "G4Orb.hh"
#include "G4SDManager.hh"
#include "G4NistManager.hh"


namespace Geometry {

  // dimensions
  /////////////

  double GermaniumBolometerBuilder::ClampHeight() const{
    return 0.2*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::ClampLength() const{
    return 5*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::ClampWidth() const{
    return 14.5*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::SaphirDiameter() const{
    return 3.18*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::CrystalRadius() const{
    return 15.358*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::CrystalHeight() const{
    //return 10.*CLHEP::mm;
    return 10.64*CLHEP::mm; 
  }
  double GermaniumBolometerBuilder::KaptonLength() const{
    return 2.*CrystalRadius();
  }
  double GermaniumBolometerBuilder::SideKaptonLength() const{
    return 1.*CrystalHeight();
  }
  double GermaniumBolometerBuilder::KaptonWidth() const{
    return 5.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::KaptonThickness() const{
    return 0.1*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::KaptonSupportThickness() const{
    return 2.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::KaptonSpace() const{
    return 0.5*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::SupportSpace() const{
    //      return 3.5*CLHEP::mm;
    return 4.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportHeight() const{
    return 22.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportBottomThickness() const{
    return 4.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportTopThickness() const{
    return 1.2*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportInnerCavityHeight() const{
    return InnerSupportHeight() - InnerSupportTopThickness() - InnerSupportBottomThickness();
  }
  double GermaniumBolometerBuilder::InnerSupportBottomOuterCavityHeight() const{
    return 6.7*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportTopOuterCavityHeight() const{
    return 6.12*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportInnerCavityRadius() const{
    return 18.2*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportOutRadius() const{
    return 23.35*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::InnerSupportOuterCavityDepth() const{
    return 3.35*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportHeight() const{
    return 31.5*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportThickness() const{
    return 2.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportSmallCavityHeight() const{
    return 2.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportLargeCavityHeight() const{
    return OuterSupportHeight() - 2*OuterSupportThickness();
  }
  double GermaniumBolometerBuilder::OuterSupportOutRadius() const{
    return 26.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportSmallCavityRadius() const{
    return 22.*CLHEP::mm;
  }
  double GermaniumBolometerBuilder::OuterSupportLargeCavityRadius() const{
    return OuterSupportOutRadius() - OuterSupportThickness();
  }
  double GermaniumBolometerBuilder::GetCrystalVolume() {
    return CLHEP::pi*std::pow(CrystalRadius(), 2) * CrystalHeight();
  }
  double GermaniumBolometerBuilder::GetCrystalMass() {
    return GetCrystalVolume()/(CLHEP::cm3) * G4Material::GetMaterial("Germanium")->GetDensity()/(CLHEP::kg/CLHEP::cm3); 
  }
  double GermaniumBolometerBuilder::GetBolometerFullHight() {
    return OuterSupportHeight();
  }

  // builders
  ///////////


  void GermaniumBolometerBuilder::BuildBoloFixations() const{

    auto solidClamp = new FilledBox("BolometerClamp", ClampWidth(), ClampLength(), ClampHeight());
    auto logicClamp = new G4LogicalVolume(solidClamp, G4Material::GetMaterial("G4_BRONZE"), "BolometerClamp");

    auto solidSaphirSphere = new G4Orb("saphirSphere",SaphirDiameter()/2.);
    auto logicSaphirSphere = new G4LogicalVolume(solidSaphirSphere, G4Material::GetMaterial("G4_ALUMINUM_OXIDE"), "SaphirSphere");

    double clampZPos = 0.5*(CrystalHeight()+ClampHeight())+SaphirDiameter();
    double clampRPos = InnerSupportOutRadius() - InnerSupportOuterCavityDepth() - ClampLength()/2. -1*CLHEP::mm;


    G4ThreeVector translation(clampRPos ,0,clampZPos);

    bolometerAssembly->AddPlacedVolume(logicClamp, translation, nullptr);
    translation.setZ(-clampZPos);
    bolometerAssembly->AddPlacedVolume(logicClamp, translation, nullptr);

    translation.setX(clampRPos*cos(CLHEP::twopi/3.));
    translation.setY(clampRPos*sin(CLHEP::twopi/3.));
    G4RotationMatrix* turnAlongZ = new G4RotationMatrix;
    turnAlongZ->rotateZ(CLHEP::twopi/3.);

    bolometerAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);
    translation.setZ(clampZPos);
    bolometerAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);

    translation.setX(clampRPos*cos(2.*CLHEP::twopi/3.));
    translation.setY(clampRPos*sin(2.*CLHEP::twopi/3.));
    turnAlongZ->rotateZ(CLHEP::twopi/3.);

    bolometerAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);
    translation.setZ(-clampZPos);
    bolometerAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);

    double saphirZPos = 0.5*(CrystalHeight()+SaphirDiameter());
    double saphirRPos = CrystalRadius() - 0.5*SaphirDiameter();

    translation.setX(saphirRPos);
    translation.setY(0.);
    translation.setZ(saphirZPos);

    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

    translation.setX(saphirRPos*cos(CLHEP::twopi/3.));
    translation.setY(saphirRPos*sin(CLHEP::twopi/3.));
    translation.setZ(saphirZPos);

    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

    translation.setX(saphirRPos*cos(2.*CLHEP::twopi/3.));
    translation.setY(saphirRPos*sin(2.*CLHEP::twopi/3.));
    translation.setZ(saphirZPos);

    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    bolometerAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

  }

  void GermaniumBolometerBuilder::BuildKapton() const{

    auto solidKaptonSupport = new FilledBox("BoloKaptonSupport", KaptonWidth(), KaptonLength(), KaptonSupportThickness());
    auto logicKaptonSupport = new G4LogicalVolume(solidKaptonSupport, G4Material::GetMaterial("CopperKaptonSupport"), "BoloKaptonSupport");

    auto solidKapton = new FilledBox("BoloKapton", KaptonWidth(), KaptonLength(), KaptonThickness());
    auto logicKapton = new G4LogicalVolume(solidKapton, G4Material::GetMaterial("BoloKapton"), "BoloKapton");

    auto solidSideKaptonSupport = new FilledBox("SideBoloKaptonSupport", KaptonWidth(), KaptonSupportThickness(), SideKaptonLength());
    auto logicSideKaptonSupport = new G4LogicalVolume(solidSideKaptonSupport, G4Material::GetMaterial("CopperSideKaptonSupport"), "SideBoloKaptonSupport");

    auto solidSideKapton = new FilledBox("SideBoloKapton", KaptonWidth(), KaptonThickness(), SideKaptonLength());
    auto logicSideKapton = new G4LogicalVolume(solidSideKapton, G4Material::GetMaterial("BoloKapton"), "SideBoloKapton");

    double kaptonSupportZPos = 0.5*(CrystalHeight()+KaptonSupportThickness())+KaptonSpace();
    double kaptonZpos = 0.5*(CrystalHeight()+KaptonThickness())+KaptonSupportThickness()+KaptonSpace();
    double sideKaptonSupportRPos = CrystalRadius()+KaptonSpace()+0.5*KaptonSupportThickness();
    double sideKaptonRPos = CrystalRadius()+KaptonSpace()+KaptonSupportThickness()+0.5*KaptonThickness();

    G4ThreeVector position(0, 0, kaptonSupportZPos);

    bolometerAssembly->AddPlacedVolume(logicKaptonSupport, position, nullptr);
    position.setZ(-kaptonSupportZPos);
    bolometerAssembly->AddPlacedVolume(logicKaptonSupport, position, nullptr);

    position.setZ(kaptonZpos);
    bolometerAssembly->AddPlacedVolume(logicKapton, position, nullptr);
    position.setZ(-kaptonZpos);
    bolometerAssembly->AddPlacedVolume(logicKapton, position, nullptr);

    position.setZ(0);

    position.setY(sideKaptonSupportRPos);
    bolometerAssembly->AddPlacedVolume(logicSideKaptonSupport, position, nullptr);

    position.setY(sideKaptonRPos);
    bolometerAssembly->AddPlacedVolume(logicSideKapton, position, nullptr);

    SetColourFromMaterial(logicKaptonSupport, "CopperKaptonSupport");
    SetColourFromMaterial(logicSideKaptonSupport, "CopperSideKaptonSupport");
    SetColourFromMaterial(logicKapton, "Kapton");
    SetColourFromMaterial(logicSideKapton, "Kapton");
  }

//  G4LogicalVolume* GermaniumBolometerBuilder::BuildBoloSupportOld() const{
//
//    constexpr std::size_t nEdges = 6;
//
//    std::array<double, nEdges> zSupport;
//    zSupport[0] = -SupportHeight()*.5;
//    zSupport[1] = -SupportHeight()*.5 + SupportThickness();
//    zSupport[2] = -SupportHeight()*.5 + SupportThickness();
//    zSupport[3] = SupportHeight()*.5 - SupportTopThickness();
//    zSupport[4] = SupportHeight()*.5 - SupportTopThickness();
//    zSupport[5] = SupportHeight()*.5;
//
//    std::array<double, nEdges> riSupport;
//    riSupport[0] = 0.;
//    riSupport[1] = 0.;
//    riSupport[2] = SupportOutRadius() - SupportThickness();
//    riSupport[3] = SupportOutRadius() - SupportThickness();
//    riSupport[4] = 0.;
//    riSupport[5] = 0.;
//
//    std::array<double, nEdges> roSupport;
//    std::fill(std::begin(roSupport), std::end(roSupport), SupportOutRadius());
//
//    auto solidSupport = new G4Polycone("solidSupport", 0., CLHEP::twopi, nEdges, zSupport.data(), riSupport.data(), roSupport.data());
//    auto logicSupport = new G4LogicalVolume(solidSupport, G4Material::GetMaterial("CopperNOSV"), "Support");
//
//    SetColourFromMaterial(logicSupport, "CopperNOSV");
//
//    return logicSupport;
//
//  }

  G4LogicalVolume* GermaniumBolometerBuilder::BuildBoloInnerSupport() const{

    constexpr std::size_t nEdges = 10;

    std::array<double, nEdges> zSupport;
    zSupport[0] = -0.5*InnerSupportHeight();
    zSupport[1] = -0.5*InnerSupportHeight() + InnerSupportBottomThickness();
    zSupport[2] = -0.5*InnerSupportHeight() + InnerSupportBottomThickness();
    zSupport[3] = -0.5*InnerSupportHeight() + InnerSupportBottomThickness() + InnerSupportBottomOuterCavityHeight();
    zSupport[4] = -0.5*InnerSupportHeight() + InnerSupportBottomThickness() + InnerSupportBottomOuterCavityHeight();
    zSupport[5] = 0.5*InnerSupportHeight() - InnerSupportTopThickness() - InnerSupportTopOuterCavityHeight();
    zSupport[6] = 0.5*InnerSupportHeight() - InnerSupportTopThickness() - InnerSupportTopOuterCavityHeight();
    zSupport[7] = 0.5*InnerSupportHeight() - InnerSupportTopThickness();
    zSupport[8] = 0.5*InnerSupportHeight() - InnerSupportTopThickness();
    zSupport[9] = 0.5*InnerSupportHeight();

    std::array<double, nEdges> riSupport;
    riSupport[0] = 0.;
    riSupport[1] = 0.;
    riSupport[2] = InnerSupportInnerCavityRadius();
    riSupport[3] = InnerSupportInnerCavityRadius();
    riSupport[4] = InnerSupportInnerCavityRadius();
    riSupport[5] = InnerSupportInnerCavityRadius();
    riSupport[6] = InnerSupportInnerCavityRadius();
    riSupport[7] = InnerSupportInnerCavityRadius();
    riSupport[8] = 0.;
    riSupport[9] = 0.;

    std::array<double, nEdges> roSupport;
    roSupport[0] = InnerSupportOutRadius();
    roSupport[1] = InnerSupportOutRadius();
    roSupport[2] = InnerSupportOutRadius() - InnerSupportOuterCavityDepth();
    roSupport[3] = InnerSupportOutRadius() - InnerSupportOuterCavityDepth();
    roSupport[4] = InnerSupportOutRadius();
    roSupport[5] = InnerSupportOutRadius();
    roSupport[6] = InnerSupportOutRadius() - InnerSupportOuterCavityDepth();
    roSupport[7] = InnerSupportOutRadius() - InnerSupportOuterCavityDepth();
    roSupport[8] = InnerSupportOutRadius();
    roSupport[9] = InnerSupportOutRadius();

    auto solidInnerSupport = new G4Polycone("solidSupport", CLHEP::twopi*7/24, CLHEP::twopi*11/12, nEdges, zSupport.data(), riSupport.data(), roSupport.data());
    auto logicInnerSupport = new G4LogicalVolume(solidInnerSupport, G4Material::GetMaterial("CopperInnerSupport"), "Support");

    SetColourFromMaterial(logicInnerSupport, "CopperInnerSupport");

    return logicInnerSupport;

  }

  G4LogicalVolume* GermaniumBolometerBuilder::BuildBoloOuterSupport() const{

    constexpr std::size_t nEdges = 8;

    std::array<double, nEdges> zSupport;
    zSupport[0] = -0.5*OuterSupportHeight();
    zSupport[1] = -0.5*OuterSupportHeight() + OuterSupportSmallCavityHeight();
    zSupport[2] = -0.5*OuterSupportHeight() + OuterSupportSmallCavityHeight();
    zSupport[3] = -0.5*OuterSupportHeight() + OuterSupportSmallCavityHeight() + OuterSupportThickness();
    zSupport[4] = -0.5*OuterSupportHeight() + OuterSupportSmallCavityHeight() + OuterSupportThickness();
    zSupport[5] = 0.5*OuterSupportHeight() - OuterSupportThickness();
    zSupport[6] = 0.5*OuterSupportHeight() - OuterSupportThickness();
    zSupport[7] = 0.5*OuterSupportHeight();

    std::array<double, nEdges> riSupport;
    riSupport[0] = OuterSupportSmallCavityRadius();
    riSupport[1] = OuterSupportSmallCavityRadius();
    riSupport[2] = 0.;
    riSupport[3] = 0.;
    riSupport[4] = OuterSupportLargeCavityRadius();
    riSupport[5] = OuterSupportLargeCavityRadius();
    riSupport[6] = 0.;
    riSupport[7] = 0.;

    std::array<double, nEdges> roSupport;
    roSupport[0] = OuterSupportOutRadius();
    roSupport[1] = OuterSupportOutRadius();
    roSupport[2] = OuterSupportOutRadius();
    roSupport[3] = OuterSupportOutRadius();
    roSupport[4] = OuterSupportOutRadius();
    roSupport[5] = OuterSupportOutRadius();
    roSupport[6] = OuterSupportOutRadius();
    roSupport[7] = OuterSupportOutRadius();

    auto solidOuterSupport = new G4Polycone("solidSupport", 0., CLHEP::twopi, nEdges, zSupport.data(), riSupport.data(), roSupport.data());
    auto logicOuterSupport = new G4LogicalVolume(solidOuterSupport, G4Material::GetMaterial("CopperOuterSupport"), "Support");
    SetColourFromMaterial(logicOuterSupport, "CopperOuterSupport");

    return logicOuterSupport;

  }


  // main builder
  ///////////////

  std::vector<G4LogicalVolume*>  GermaniumBolometerBuilder::Build(HepGeom::Transform3D transformation)  {

   if(bolometerAssembly == nullptr) {
      bolometerAssembly = new G4AssemblyVolume();

      // Crystal geometry
      solidBolo = new FilledTube("CrystalBolo", CrystalRadius(), CrystalHeight());
      logicBolo = new G4LogicalVolume(solidBolo, G4Material::GetMaterial("Germanium"), "CrystalBolo");
      SetColourFromMaterial(logicBolo, "Germanium");

      G4ThreeVector position(0.,0.,0.);
      bolometerAssembly->AddPlacedVolume(logicBolo, position, nullptr);

      // bolometer fixations
      //BuildBoloFixations();

      // Kaptons
      BuildKapton();

      // Inner Support
      auto logicBoloInnerSupport = BuildBoloInnerSupport();
      position.setZ(0.5*InnerSupportHeight() - (InnerSupportBottomThickness() + 0.5*InnerSupportInnerCavityHeight()));
      bolometerAssembly->AddPlacedVolume(logicBoloInnerSupport, position, nullptr);

      // Outer Support
      auto logicBoloOuterSupport = BuildBoloOuterSupport();
      position.setZ(0.5*OuterSupportHeight() - (OuterSupportSmallCavityHeight() + OuterSupportThickness() + 0.5*OuterSupportLargeCavityHeight()));
      bolometerAssembly->AddPlacedVolume(logicBoloOuterSupport, position, nullptr);

   }

   G4bool checkOverlaps = (mVerbosity > 0);
   bolometerAssembly->MakeImprint(&mother, transformation, 0, checkOverlaps);
   
   if(mVerbosity > 0) {
       G4cout << "GermaniumBolometerBuilder: Overlap checking enabled" << G4endl;
   }
   
   return {logicBolo};
}

} // namespace
