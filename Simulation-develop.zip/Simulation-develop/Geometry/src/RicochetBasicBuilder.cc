#include "Geometry/RicochetBasicBuilder.hh"


// Project includes
#include "SimuOutput/InfoHeaderWriter.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/Shapes.hh"

namespace Geometry
{
    RicochetBasicBuilder::RicochetBasicBuilder(G4LogicalVolume& mother) :
        mMother(mother)
    {

    }

    void RicochetBasicBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
        mCryoCube.SetVerbosity(level);
        mMiniCryoCube.SetVerbosity(1);
        mCryostat.SetVerbosity(level);
        mInnerShielding.SetVerbosity(level);
        mRingInnerShielding.SetVerbosity(level);
        mOuterShielding.SetVerbosity(level);
        mOuterShieldingWithDT.SetVerbosity(level);
    }
    
    void RicochetBasicBuilder::SetBuildCryostat(bool activate)
    {
        mBuildCryostat = activate;
    }

    void RicochetBasicBuilder::SetBuildInnerShielding(bool activate)
    {
      if( !activate && mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : BuildInnerShielding forced to be true by  GeometryConfiguration::RicochetFinalDesign ");
      if( !activate && mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : BuildInnerShielding forced to be true by  GeometryConfiguration::RicochetRUN014 ");
        mBuildInnerShielding = activate;
    }

    void RicochetBasicBuilder::SetBuildRingInnerShielding(bool activate)
    {
        mBuildRingInnerShielding = activate;
    }

    void RicochetBasicBuilder::SetBuildMylar(bool activate)
    {
        mBuildMylar = activate;
        mRingInnerShielding.SetBuildMylar(activate);
    }

    void RicochetBasicBuilder::SetBuildOuterShielding(bool activate)
    {
        mBuildOuterShielding = activate;
    }

    void RicochetBasicBuilder::SetBuildOuterShieldingWithDT(bool activate)
    {
        mBuildOuterShieldingWithDT = activate;
    }

    void RicochetBasicBuilder::SetBuildCryoCube(bool activate)
    {
        mBuildCryoCube = activate;
        if(activate) mBuildMiniCryoCube = false;
    }

    void RicochetBasicBuilder::SetBuildMiniCryoCube(bool activate)
    {
        mBuildMiniCryoCube = activate;
        if(activate) mBuildCryoCube = false;
    }
    void RicochetBasicBuilder::SetMiniCryoCubeConfig(std::string config)
    {
        if(mMiniCryoCube.GetNumberOfMiniCryoCube() > 6) mMiniCryoCubeConfig = "bottom"; //more than 6 miniCC => 3 miniCC floor, if we don't pick the low config with more than 6 miniCC the 3rd floor will be too high.
        if(config == "mid" || config == "bottom" || config == "top") mMiniCryoCubeConfig = config;
        else throw std::runtime_error("unknow configuration, choose between bottom, mid, or top");
        G4cout << "MiniCryoCube config : " << mMiniCryoCubeConfig << G4endl;
    }
    
    void RicochetBasicBuilder::SetBuildMuonVeto(bool activate)
    {
        mBuildMuonVeto = activate;
    }
    
    void RicochetBasicBuilder::SetSpacingCryoCube_FloatingPlate(double spacing)
    {
        mSpacingCryoCube_FloatingPlate = spacing;
    }

    void RicochetBasicBuilder::SetSpacingCryoCube_BottomScreen(double spacing)
    {
        mSpacingCryoCube_BottomScreen = spacing;
    }

    void RicochetBasicBuilder::SetSpacingInnerShielding_Plate10mK(double spacing)
    {
        mSpacingInnerShielding_Plate10mK = spacing;
    }

    void RicochetBasicBuilder::SetSpacingOuterShielding_CryostatOVC(double spacing)
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetSpacingOuterShielding_CryostatOVC forbidden by GeometryConfiguration::RicochetFinalDesign ");
        if(mConfig == GeometryConfiguration::RicochetRUN013()) throw std::runtime_error("ERROR : SetSpacingOuterShielding_CryostatOVC forbidden by GeometryConfiguration::RicochetRUN013 ");
        if(mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetSpacingOuterShielding_CryostatOVC forbidden by GeometryConfiguration::RicochetRUN014 ");
        mSpacingOuterShielding_CryostatOVC = spacing;
    }

    void RicochetBasicBuilder::OverwriteInternalShieldingRadius(bool overwrite)
    {
      if( overwrite && mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : mOverwriteInternalShieldingRadius forced to be false by  GeometryConfiguration::RicochetFinalDesign ");
      if( overwrite && mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : mOverwriteInternalShieldingRadius forced to be false by  GeometryConfiguration::RicochetRUN014 ");
      mOverwriteInternalShieldingRadius = overwrite;
    }

     void RicochetBasicBuilder::SetConfig(GeometryConfiguration config)
    {
        mConfig = config;
        mCryostat.SetConfig(config);
        
        mInnerShielding.SetConfig(config);
        mOuterShielding.SetConfig(config);
        if(mConfig == GeometryConfiguration::RicochetFinalDesign()){
            mBuildCryostat = true;
            mBuildInnerShielding = true;
            mBuildOuterShielding = true;
            mBuildOuterShieldingWithDT = false;
            mBuildMuonVeto = true;
            mOverwriteInternalShieldingRadius = false;
            mSpacingOuterShielding_CryostatOVC = 2*CLHEP::cm;
        }

        else if(mConfig == GeometryConfiguration::RicochetRUN015()){
            mBuildCryostat = true;
            mBuildInnerShielding = true;
            mBuildOuterShielding = true;
            mBuildOuterShieldingWithDT = false;
            mBuildRingInnerShielding = true;
            mBuildMylar = true;
            mBuildMuonVeto = true;
            mBuildCryoMuonVeto = true;
            mOverwriteInternalShieldingRadius = false;
            mSpacingOuterShielding_CryostatOVC = 2*CLHEP::cm;
            mBuildMiniCryoCube = true;
            mBuildCryoCube = false;

            mBuildCryoCubeHolder = true;

            mMiniCryoCube.SetMiniCryoCubeNumber(3); //just to ensure 3 are made
            mMuonVeto.BuildCryoMuonVeto(mBuildCryoMuonVeto);
            mRingInnerShielding.SetBuildMylar(mBuildMylar);

        }

         else if(mConfig == GeometryConfiguration::RicochetRUN016()){
            mBuildCryostat = true;
            mBuildInnerShielding = true;
            mBuildOuterShielding = true;
            mBuildOuterShieldingWithDT = false;
            mBuildRingInnerShielding = true;
            mBuildMylar = true;
            mBuildMuonVeto = true;
            mBuildCryoMuonVeto = true;
            mOverwriteInternalShieldingRadius = false;
            mSpacingOuterShielding_CryostatOVC = 2*CLHEP::cm;
            mBuildMiniCryoCube = true;
            mBuildCryoCube = false;

            mBuildCryoCubeHolder = true;

            mMiniCryoCube.SetMiniCryoCubeNumber(6); //just to ensure 3 are made
            mMuonVeto.BuildCryoMuonVeto(mBuildCryoMuonVeto);
            mRingInnerShielding.SetBuildMylar(mBuildMylar);

        }

        else if(mConfig == GeometryConfiguration::RicochetRUN014()){ //Copy of RicochetFinalDesign
            mBuildCryostat = true;
            mBuildInnerShielding = true;
            mBuildOuterShielding = true;
            mBuildOuterShieldingWithDT = false;
            mBuildRingInnerShielding = true;
            mBuildMylar = false;
            mBuildMuonVeto = true;
            mBuildCryoMuonVeto = false;
            mOverwriteInternalShieldingRadius = false;
            mSpacingOuterShielding_CryostatOVC = 2*CLHEP::cm;

            mBuildCryoCube = false;
            mBuildMiniCryoCube = true;
            mBuildCryoCubeHolder = false;

            mMiniCryoCube.SetMiniCryoCubeNumber(1); //just to ensure 1 is made
            mMuonVeto.BuildCryoMuonVeto(mBuildCryoMuonVeto);
            mRingInnerShielding.SetBuildMylar(mBuildMylar);

        }
        else if(mConfig == GeometryConfiguration::RicochetRUN013()){
            mBuildCryostat = true;
            mBuildInnerShielding = false;
            mBuildOuterShielding = true;
            mBuildOuterShieldingWithDT = false;
            mBuildMuonVeto = false;
            mBuildCryoMuonVeto = false;
            mOverwriteInternalShieldingRadius = false;
            mBuildRingInnerShielding = false;
            mBuildMylar = false;
            mSpacingOuterShielding_CryostatOVC = 2*CLHEP::cm;
            mBuildCryoCube = false;
            mBuildMiniCryoCube = true;
            mBuildCryoCubeHolder = false;

            mMiniCryoCube.SetMiniCryoCubeNumber(1); //just to ensure 1 is made
            mMuonVeto.BuildCryoMuonVeto(mBuildCryoMuonVeto);
            mRingInnerShielding.SetBuildMylar(mBuildMylar);

        }
        
        // Only propagate Mylar setting if it hasn't been explicitly set via messenger
        // This prevents overriding user commands
        // mRingInnerShielding.SetBuildMylar(mBuildMylar);  // Commented out to prevent override
    }



    std::vector<G4LogicalVolume*> RicochetBasicBuilder::Build(const G4ThreeVector& position)
    {
        std::vector<G4LogicalVolume*> volumes;
        mPosition = position;

        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
        {


            if(mConfig == GeometryConfiguration::RicochetFinalDesign()) std::cout << "Config RicochetFinalDesign selected : using fixed build position" << std::endl;
            else if(mConfig == GeometryConfiguration::RicochetRUN013()) std::cout << "Config RicochetRUN013 selected : using fixed build position" << std::endl;
            else if(mConfig == GeometryConfiguration::RicochetRUN014()) std::cout << "Config RicochetRUN014 selected : using fixed build position" << std::endl;
            else if(mConfig == GeometryConfiguration::RicochetRUN015()) std::cout << "Config RicochetRUN015 selected : using fixed build position" << std::endl;
            else if(mConfig == GeometryConfiguration::RicochetRUN016()) std::cout << "Config RicochetRUN016 selected : using fixed build position" << std::endl;


            // main origin = floor
            mPosition = G4ThreeVector(0, 0, 0);
            ///--- OuterShielding origin : top of lower polyethylene layer (below cryostat)
            G4ThreeVector posOuterShield = mPosition + G4ThreeVector(0, 0, 82*CLHEP::cm);
            if(mBuildOuterShielding)
            {
                mOuterShielding.Build(posOuterShield);
            }

            if(mBuildOuterShieldingWithDT) //need to wait for a final design here
            {
                mOuterShieldingWithDT.SetInnerRadius(mCryostat.OVC_radius() + mCryostat.OVC_e() + mSpacingOuterShielding_CryostatOVC);
                mOuterShieldingWithDT.Build(posOuterShield);
            }

            /// Cryostat origin: 10mK plate bottom center
            // std::cout<<".... ****************************....."<<mCryostat.PlateFloating_e()<<std::endl;
            


            G4ThreeVector posCryostat = posOuterShield - mCryostat.OVCBottomCenter() + G4ThreeVector(0, 0, mSpacingOuterShielding_CryostatOVC);
            //  std::cout<<".... *************posCryostat z***************....."<<posCryostat[2]<<std::endl;

            if(mBuildCryostat)
            {
                mCryostat.SetPillarFloatingPlateShiftAngle(mInnerShielding.HoleAngularSpacing());
                // std::cout<<".... *************HoleAngularSpacing***************....."<<mInnerShielding.HoleAngularSpacing()<<std::endl;


                mCryostat.SetPillarFloatingPlateRadialPosition(mInnerShielding.HoleRadialPosition());
                // std::cout<<".... *************HoleRadialPosition***************....."<<mInnerShielding.HoleRadialPosition()<<std::endl;

                mCryostat.Build(posCryostat);
            }
            
            ///--- InnerShielding origin: top center of the shielding
            G4ThreeVector posInnerShield = posCryostat - G4ThreeVector(0, 0, mSpacingInnerShielding_Plate10mK);

            // std::cout << " Inner shielding Config? "<< mInnerShielding.InnerShieldingConfig() << std::endl;
            // std::cout << "Build Inner shielding? "<< mBuildInnerShielding << std::endl;

            

            if(mBuildInnerShielding)
            {
                 mInnerShielding.Build(posInnerShield);

            }

            ///--- Ring Inner Shielding


            if(mBuildRingInnerShielding)
            {
      
                mRingInnerShielding.SetTopRingAsOrigin(true);
                G4ThreeVector posRingInnerShield = G4ThreeVector(0*CLHEP::mm, 0*CLHEP::mm, 170*CLHEP::cm);

                mRingInnerShielding.AddRing(159.5*CLHEP::mm, 167.5*CLHEP::mm, "Poly_Chaussette", 42*CLHEP::mm, 500*CLHEP::mm);
                mRingInnerShielding.AddRing(175*CLHEP::mm, 183*CLHEP::mm, "Poly_Chaussette", 76*CLHEP::mm, 500*CLHEP::mm);
                mRingInnerShielding.AddRing(191.5*CLHEP::mm, 199.5*CLHEP::mm, "Poly_Chaussette", 105*CLHEP::mm, 500*CLHEP::mm);
                mRingInnerShielding.Build(posRingInnerShield);

          

            }

	        // Muon Veto
	        if(mBuildMuonVeto)
	        {
	    	    G4ThreeVector posMuonVeto = mPosition + G4ThreeVector(0, 0, 0); // coordinates used in positioning are relative to build origin, check MuonVetoBuilder.cc // 211.6cm = shield height
                mMuonVeto.Build(posMuonVeto);
		        
	        }


	        // Cryocube 
	        if(mBuildCryoCube) {
                std::cout << "Final Design CryoCube" << G4endl;
                G4ThreeVector posCryoCube = posCryostat - G4ThreeVector(0, 0, mCryoCube.TotalHeight()/2. + mSpacingCryoCube_FloatingPlate) + mCryostat.PlateFloatingBottomCenter();
                G4cout << "posCryoCube " << posCryoCube << G4endl;
                return mCryoCube.Build(posCryoCube);  
	        }

            //*
            // MiniCryoCube
            else if(mBuildMiniCryoCube) {
                G4cout << "Final Design MiniCryoCube" << G4endl;
               
                G4ThreeVector posMiniCryoCube;
                mMiniCryoCube.setCryoCubeHolderFormationEnabled(mBuildCryoCubeHolder);
                if(mConfig == GeometryConfiguration::RicochetRUN013())
                {
                    // posMiniCryoCube = posCryostat + G4ThreeVector(0, 0, mMiniCryoCube.TotalHeight()/2 + mSpacingCryoCube_BottomScreen + mCryostat.PlateFloating_e()) + mCryostat.PlateFloatingBottomCenter();
                    posMiniCryoCube = G4ThreeVector(mCryostat.MCCpos[0],
                                    mCryostat.MCCpos[1],
                                    mCryostat.MCCpos[2]+ mMiniCryoCube.TotalHeight()/2);
                
                }
                else if(mConfig == GeometryConfiguration::RicochetFinalDesign())
                {
                    posMiniCryoCube = posCryostat - G4ThreeVector(0, 0, (mMiniCryoCube.GetNumberOfRows()-1)*(mMiniCryoCube.TotalHeight()+mMiniCryoCube.GetVerticalSpacing()) + mMiniCryoCube.TotalHeight()/2 + mSpacingCryoCube_BottomScreen) + mCryostat.PlateFloatingBottomCenter();
                }
                else if(mConfig == GeometryConfiguration::RicochetRUN014()) //copy of RicochetFinalDesign
                {

                    // posMiniCryoCube = posCryostat - G4ThreeVector(0, 0, (mMiniCryoCube.GetNumberOfRows()-1)*(mMiniCryoCube.TotalHeight()+mMiniCryoCube.GetVerticalSpacing()) + mMiniCryoCube.TotalHeight()/2 + mSpacingCryoCube_BottomScreen) + mCryostat.PlateFloatingBottomCenter();
                    posMiniCryoCube = G4ThreeVector(mCryostat.MCCpos[0],
                                    mCryostat.MCCpos[1],
                                    mCryostat.MCCpos[2]+ mMiniCryoCube.TotalHeight()/2);

                    // G4cout << "Output MCC position (R14): ";
                // for (const auto& val : mCryostat.MCCpos) {
                //     G4cout << val << " ";
                // }
                // G4cout << G4endl;
                }

                else if(mBuildCryoCubeHolder) {
                    std::cout << "How many cryocubes are going in the holder  " << mMiniCryoCube.GetNumberOfMiniCryoCube() << std::endl;

                    


                // G4cout << "Output MCC position (CryoCubeHolder): ";
                // for (const auto& val : mCryostat.MCCpos) {
                //     G4cout << val << " ";
                // }
                // G4cout << G4endl;

                
                // posMiniCryoCube = posCryostat - G4ThreeVector(0, 0, (mMiniCryoCube.GetNumberOfRows()-1)*(mMiniCryoCube.TotalHeight()+mMiniCryoCube.GetVerticalSpacing()) + mMiniCryoCube.TotalHeight()/2 + mSpacingCryoCube_BottomScreen) + mCryostat.PlateFloatingBottomCenter();
                // posMiniCryoCube = mCryostat.MCCpos;

                posMiniCryoCube = G4ThreeVector(mCryostat.MCCpos[0],
                                    mCryostat.MCCpos[1],
                                    mCryostat.MCCpos[2]+ mMiniCryoCube.TotalHeight()/2);

                // mMiniCryoCube.setCryoCubeHolderFormationEnabled(mBuildCryoCubeHolder);


                }
                
                G4cout << "posMiniCryoCube " << posMiniCryoCube << G4endl;


                return mMiniCryoCube.BuildSeveral(HepGeom::Translate3D(posMiniCryoCube));

                
	        }//*/
       
	    }

        else
        {
            /// Cryocube origin: CryoCube center = main origin
            if(mBuildCryoCube) {volumes = mCryoCube.Build(mPosition);}
            else if(mBuildMiniCryoCube) {volumes = mMiniCryoCube.Build(mPosition);}
	        ///--- Cryostat
	        mCryostat.SetConfig(GeometryConfiguration::CROSS());
	        mCryostat.SetExperimentalZoneHeight(mCryoCube.TotalHeight() + mSpacingCryoCube_FloatingPlate + mSpacingCryoCube_BottomScreen + mInnerShielding.TotalHeight() + 2*mSpacingInnerShielding_Plate10mK + mCryostat.PlateFloating_e());
	        mCryostat.SetInnerShieldingZoneHeight(mInnerShielding.TotalHeight() + 2*mSpacingInnerShielding_Plate10mK);


	        /// Cryostat origin: 10mK plate bottom center

	        G4ThreeVector posCryostat = mPosition + G4ThreeVector(0, 0, mCryoCube.TotalHeight()/2. + mSpacingCryoCube_FloatingPlate) - mCryostat.PlateFloatingBottomCenter();
	        mCryostat.SetPillarFloatingPlateShiftAngle(mInnerShielding.HoleAngularSpacing());
	        mCryostat.SetPillarFloatingPlateRadialPosition(mInnerShielding.HoleRadialPosition());
	        mCryostat.Build(posCryostat);

            ///--- Inner Shielding
            G4ThreeVector posInnerShield = posCryostat - G4ThreeVector(0, 0, mSpacingInnerShielding_Plate10mK);
            if(mBuildInnerShielding)
            {
                if(mOverwriteInternalShieldingRadius)
                {
                    mInnerShielding.SetRadius(mCryostat.Screen10mK_radius());
                }
                /// InnerShielding origin: top center of the shielding

                mInnerShielding.Build(posInnerShield);
            }
            
            ///--- Ring Inner Shielding
            if(mBuildRingInnerShielding)
            {
                /// RingInnerShielding origin: center
                G4ThreeVector posRingInnerShield = posInnerShield + mInnerShielding.PolyPosition();
                mRingInnerShielding.AddRing(mCryostat.Screen10mK_radius() + mCryostat.Screen10mK_e(), mCryostat.Screen1K_radius());
                mRingInnerShielding.AddRing(mCryostat.Screen1K_radius() + mCryostat.Screen1K_e(), mCryostat.Screen4K_radius());
                mRingInnerShielding.AddRing(mCryostat.Screen4K_radius() + mCryostat.Screen4K_e(), mCryostat.Screen50K_radius());
                mRingInnerShielding.AddRing(mCryostat.Screen50K_radius() + mCryostat.Screen50K_e(), mCryostat.OVC_radius());
                mRingInnerShielding.Build(posRingInnerShield);
            }
            
            ///--- OuterShielding origin
            if(mBuildOuterShielding)
            {
                G4ThreeVector posOuterShield = posCryostat + mCryostat.OVCBottomCenter() - G4ThreeVector(0, 0, mSpacingOuterShielding_CryostatOVC);
                //mOuterShielding.SetInnerRadius(mCryostat.OVC_radius() + mCryostat.OVC_e() + mSpacingOuterShielding_CryostatOVC);
                mOuterShielding.Build(posOuterShield);
            }

            if(mBuildOuterShieldingWithDT)
            {
                G4ThreeVector posOuterShield = posCryostat + mCryostat.OVCBottomCenter() - G4ThreeVector(0, 0, mSpacingOuterShielding_CryostatOVC);
                mOuterShieldingWithDT.SetInnerRadius(mCryostat.OVC_radius() + mCryostat.OVC_e() + mSpacingOuterShielding_CryostatOVC);
                mOuterShieldingWithDT.Build(posOuterShield);
            }

            ///--- External Veto
            if(!mBuildOuterShieldingWithDT && !mBuildMuonVeto)
            {
                double vetoThickness = 1*CLHEP::mm;
                VolumeAdder volumeFactory(mMother, mPosition);
                double innerRadiusVeto = mOuterShielding.OuterRadius();
                double outerRadiusVeto = innerRadiusVeto + vetoThickness;
                double heightVeto = mCryostat.TotalHeight() + mOuterShielding.TotalThickness() + mSpacingOuterShielding_CryostatOVC;
                G4ThreeVector positionVeto_Side = posCryostat + mCryostat.OVCBottomCenter() + G4ThreeVector(0, 0, -mSpacingOuterShielding_CryostatOVC - mOuterShielding.TotalThickness() + heightVeto/2.);
                G4ThreeVector positionVeto_Top = positionVeto_Side + G4ThreeVector{0, 0, heightVeto/2. + vetoThickness/2.};
                G4ThreeVector positionVeto_Bottom = positionVeto_Side - G4ThreeVector{0, 0, heightVeto/2. + vetoThickness/2.};
                volumeFactory.Add<Tube>("RicochetBasic_OuterVeto_Side", "G4_Galactic", positionVeto_Side, innerRadiusVeto, outerRadiusVeto, heightVeto);
                volumeFactory.Add<FilledTube>("RicochetBasic_OuterVeto_Top", "G4_Galactic", positionVeto_Top, outerRadiusVeto + vetoThickness, vetoThickness);
                volumeFactory.Add<FilledTube>("RicochetBasic_OuterVeto_Bottom", "G4_Galactic", positionVeto_Bottom, outerRadiusVeto + vetoThickness, vetoThickness);
            }
	
	        // Muon Veto
	        if(mBuildMuonVeto)
	        {
	            G4ThreeVector posOuterShield = posCryostat + mCryostat.OVCBottomCenter() - G4ThreeVector(0, 0, mSpacingOuterShielding_CryostatOVC);
	            mMuonVeto.Build(posOuterShield);
	        }
	    }
        return volumes;
    }

    void RicochetBasicBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter header("RicochetBasicShielding", "Geometry::RicochetBasicShieldingBuilder");
        header.SetKeyValue("Position_X", mPosition.x());
        header.SetKeyValue("Position_Y", mPosition.y());
        header.SetKeyValue("Position_Z", mPosition.z());
        header.SetKeyValue("BuildInnerShielding", mBuildInnerShielding);
        header.SetKeyValue("BuildRingInnerShielding", mBuildRingInnerShielding);
        header.SetKeyValue("BuildMylar", mBuildMylar);
        header.SetKeyValue("BuildOuterShielding", mBuildOuterShielding);
        header.SetKeyValue("BuildOuterShieldingWithDT", mBuildOuterShieldingWithDT);
	    header.SetKeyValue("BuildMuonVeto", mBuildMuonVeto);
        header.SetKeyValue("SpacingCryoCube_FloatingPlate", mSpacingCryoCube_FloatingPlate);
        header.SetKeyValue("SpacingInnerShielding_Plate10mK", mSpacingInnerShielding_Plate10mK);
        header.SetKeyValue("SpacingOuterShielding_CryostatOVC", mSpacingOuterShielding_CryostatOVC);
        header.WriteIn(directory);

        if (mBuildCryoCube) {
            ROOTWrite(mCryoCube, directory);
        }
        else if (mBuildMiniCryoCube){
            ROOTWrite(mMiniCryoCube, directory);
        }
        mCryostat.Write(directory);
        mInnerShielding.Write(directory);
        mOuterShielding.Write(directory);
        mOuterShieldingWithDT.Write(directory);
	mMuonVeto.Write(directory);
        mRingInnerShielding.Write(directory);
    }

    ActiveCryoCubeBuilder& RicochetBasicBuilder::GetCryoCube()
    {
        return mCryoCube;
    }

    SensitiveMiniCryoCubeBuilder& RicochetBasicBuilder::GetMiniCryoCube()
    {
        return mMiniCryoCube;
    }

    ActiveGenericCryostatBuilder& RicochetBasicBuilder::GetCryostat()
    {
        return mCryostat;
    }

    ActiveColdInnerShieldingBuilder& RicochetBasicBuilder::GetInnerShielding()
    {
        return mInnerShielding;
    }

    ActiveRingInnerShieldingBuilder& RicochetBasicBuilder::GetRingInnerShielding()
    {
        return mRingInnerShielding;
    }

    ActiveOuterShieldingBuilder& RicochetBasicBuilder::GetOuterShielding()
    {
        return mOuterShielding;
    }

    ActiveOuterShieldingBuilderWithDT& RicochetBasicBuilder::GetOuterShieldingWithDT()
    {
        return mOuterShieldingWithDT;
    }
    SensitiveMuonVetoBuilder& RicochetBasicBuilder::GetMuonVeto()
    {
        return mMuonVeto;
    }
}
