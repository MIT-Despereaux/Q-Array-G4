#include "Geometry/GenericCryostatBuilder.hh"

/// Geant4 includes
#include "CLHEP/Units/SystemOfUnits.h"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
// #include "G4Material.hh"
#include "G4SubtractionSolid.hh"
#include "G4UnionSolid.hh"
#include "G4NistManager.hh"
// #include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"




/// ROOT includes
#include "TDirectory.h"

/// Project includes
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

using CLHEP::cm;
using namespace CLHEP;


namespace Geometry
{
  // const std::vector<int>& vec

   G4SubtractionSolid* BuildCCstandPlate(G4LogicalVolume& mother, const G4String& name,const std::vector<double>& stand_innerlengths,
    const std::vector<double>& stand_innerdepths, const std::vector<double>& stand_heights, const std::vector<double>& stand_thickness,
    const std::vector<double>& stand_xvals, const CLHEP::Hep3Vector position,double plate_height, double plate_radius,  const G4String& material)
    {

      G4RotationMatrix* emptyrotmat = new G4RotationMatrix();
      G4ThreeVector emptypos = {0 , 0, 0};
      auto emptytransform = new G4Transform3D(*emptyrotmat, emptypos);

      //doing first cut 
      G4ThreeVector position_platecut = {-255.123*CLHEP::mm , 0, 0}; //some constant shift
      auto platecuttransform = new G4Transform3D(*emptyrotmat, position_platecut);

      //base fo the plate
      auto baseplate_solid = new Geometry::FilledTube(plate_radius, plate_height);
      // shape to be cut
      auto baseplate_solid_cut = new Geometry::FilledBox( 300*CLHEP::mm , 300*CLHEP::mm , 10*CLHEP::mm ); //constant values


    //doing the cut
    G4SubtractionSolid* plate_solid = new G4SubtractionSolid(name+"base", baseplate_solid, baseplate_solid_cut, *platecuttransform);

      

    G4UnionSolid* plateouterMCCstand_solid{nullptr}; //with no holes
    G4SubtractionSolid* plateMCCstand_wh_solid{nullptr}; //with holes
      //placing the stands 
      for (size_t i = 0; i < stand_innerlengths.size(); ++i) {

         double innerlength = stand_innerlengths[i];
         double innerdepth = stand_innerdepths[i];
         double height = stand_heights[i];
         double thickness = stand_thickness[i];
         double x_val = stand_xvals[i];


        G4ThreeVector position_MCCstand = {x_val, 0, height/2};

      auto MCCstandtransform = new G4Transform3D(*emptyrotmat, position_MCCstand);

      auto outerMCCstand_solid = new Geometry::FilledBox(innerdepth + 2*thickness , innerlength+ 2*thickness, height +plate_height);

          if(i>0) plateouterMCCstand_solid = new G4UnionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateMCCstand_wh_solid, outerMCCstand_solid, *MCCstandtransform);
          else if (i>1) plateouterMCCstand_solid = new G4UnionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateMCCstand_wh_solid, outerMCCstand_solid, *MCCstandtransform);
          
      auto innerMCCstand_solid = new Geometry::FilledBox( innerdepth, innerlength, 50*CLHEP::mm  );

        if(i==0) plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plate_solid, innerMCCstand_solid, *MCCstandtransform);
          else plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateouterMCCstand_solid, innerMCCstand_solid, *MCCstandtransform);
          




      }


      //placing at origin for debugging

      // auto plateMCCstand_wh_logic = new G4LogicalVolume(plateMCCstand_wh_solid, G4NistManager::Instance()->FindOrBuildMaterial(material), "plate_wh_logic");
      //   new G4PVPlacement(*emptytransform, plateMCCstand_wh_logic, "plate_wh_physical",&mother, false, 0, true);


  
      
        return plateMCCstand_wh_solid;
    }

    G4SubtractionSolid* BuildCCstandPlateNoStands(G4LogicalVolume& mother, const G4String& name,const std::vector<double>& stand_innerlengths,
    const std::vector<double>& stand_innerdepths, const std::vector<double>& stand_heights, const std::vector<double>& stand_thickness,
    const std::vector<double>& stand_xvals, const CLHEP::Hep3Vector position,double plate_height, double plate_radius,  const G4String& material)
    {

      G4RotationMatrix* emptyrotmat = new G4RotationMatrix();
      G4ThreeVector emptypos = {0 , 0, 0};
      auto emptytransform = new G4Transform3D(*emptyrotmat, emptypos);

      //doing first cut 
      G4ThreeVector position_platecut = {-255.123*CLHEP::mm , 0, 0}; //some constant shift
      auto platecuttransform = new G4Transform3D(*emptyrotmat, position_platecut);

      //base fo the plate
      auto baseplate_solid = new Geometry::FilledTube(plate_radius, plate_height);
      // shape to be cut
      auto baseplate_solid_cut = new Geometry::FilledBox( 300*CLHEP::mm , 300*CLHEP::mm , 10*CLHEP::mm ); //constant values


    //doing the cut
    G4SubtractionSolid* plate_solid = new G4SubtractionSolid(name+"base", baseplate_solid, baseplate_solid_cut, *platecuttransform);

      

    G4UnionSolid* plateouterMCCstand_solid{nullptr}; //with no holes
    G4SubtractionSolid* plateMCCstand_wh_solid{nullptr}; //with holes
      //placing the stands 
      for (size_t i = 0; i < stand_innerlengths.size(); ++i) {


         double innerlength = stand_innerlengths[i];
         double innerdepth = stand_innerdepths[i];
         double height = stand_heights[i];
         double thickness = stand_thickness[i];
         double x_val = stand_xvals[i];


        G4ThreeVector position_MCCstand = {x_val, 0, height/2};

      auto MCCstandtransform = new G4Transform3D(*emptyrotmat, position_MCCstand);

      // auto outerMCCstand_solid = new Geometry::FilledBox(innerdepth + 2*thickness , innerlength+ 2*thickness, height +plate_height);

      //     if(i>0) plateouterMCCstand_solid = new G4UnionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateMCCstand_wh_solid, outerMCCstand_solid, *MCCstandtransform);
      //     else if (i>1) plateouterMCCstand_solid = new G4UnionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateMCCstand_wh_solid, outerMCCstand_solid, *MCCstandtransform);
          
      auto innerMCCstand_solid = new Geometry::FilledBox( innerdepth, innerlength, 50*CLHEP::mm  );

        // if(i==0) plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plate_solid, innerMCCstand_solid, *MCCstandtransform);
        //   else plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateouterMCCstand_solid, innerMCCstand_solid, *MCCstandtransform);
          
        if(i==0) plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plate_solid, innerMCCstand_solid, *MCCstandtransform);
        else plateMCCstand_wh_solid = new G4SubtractionSolid(Form((name+"plateouterMCCstand%zud_solid").c_str(), i), plateMCCstand_wh_solid, innerMCCstand_solid, *MCCstandtransform);



      }


      //placing at origin for debugging

      // auto plateMCCstand_wh_logic = new G4LogicalVolume(plateMCCstand_wh_solid, G4NistManager::Instance()->FindOrBuildMaterial(material), "plate_wh_logic");
      //   new G4PVPlacement(*emptytransform, plateMCCstand_wh_logic, "plate_wh_physical",&mother, false, 0, true);


  
      
        return plateMCCstand_wh_solid;
    }


  // GenericCryostatBuilder::GenericCryostatBuilder(G4LogicalVolume& mother) : mMother(mother), mPlateFloating_e(0.)
  // {
  //   SetConfig(mConfig);
  // }

  GenericCryostatBuilder::GenericCryostatBuilder(G4LogicalVolume& mother, MiniCryoCubeBuilder* miniCryoCube)
  : mMother(mother), mMiniCryoCube(miniCryoCube), mPlateFloating_e(0.)
{
    SetConfig(mConfig);
}


  void GenericCryostatBuilder::SetVerbosity(int level)
  {
    mVerbosity = level;
  }

  void GenericCryostatBuilder::SetConfig(GeometryConfiguration config)
  {
    mConfig = config;

    if(config == GeometryConfiguration::Lyon())
    {
      mfSetConfigLyon();
    }
    else if(config == GeometryConfiguration::CROSS())
    {
      mfSetConfigCross();
    }
    else if(config == GeometryConfiguration::CryoConcept2020())
    {
      mfSetConfigCryoConcept2020();
    }
    else if(config == GeometryConfiguration::RicochetFinalDesign() || config == GeometryConfiguration::RicochetRUN013() || config == GeometryConfiguration::RicochetRUN014()) //added
    {
      mfSetConfigRicochetFinalDesign();
    }
    else if(config == GeometryConfiguration::RicochetRUN015() || config == GeometryConfiguration::RicochetRUN016()) //added
    {
      mfSetConfigRicochetCryoCubeHolder();
    }
   
  }

  void GenericCryostatBuilder::SetExperimentalZoneHeight(double height)
  {
    if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) throw std::runtime_error("ERROR : SetExperimentalZoneHeight forbidden by GeometryConfiguration::RicochetFinalDesign ");
    mDisPlate10mK_BottomScreen10mK = height;
  }

  void GenericCryostatBuilder::SetInnerShieldingZoneHeight(double height)
  {
    if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) throw std::runtime_error("ERROR : SetInnerShieldingZoneHeight forbidden by GeometryConfiguration::RicochetFinalDesign ");
    mDisPlateFloating_Plate10mK = height;
  }

  void GenericCryostatBuilder::BuildPillarFloatingPlate(bool build)
  {
    if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) throw std::runtime_error("ERROR : BuildPillarFloatingPlate forbidden by GeometryConfiguration::RicochetFinalDesign ");
    mBuildPillarFloatingPlate = build;
  }

  void GenericCryostatBuilder::SetPillarFloatingPlateShiftAngle(double angle)
  {
    mPillarFloatingPlate_AngleShift = angle;
  }

  void GenericCryostatBuilder::SetPillarFloatingPlateRadialPosition(double radius)
  {
    mPillarFloatingPlate_RadialPosition = radius;
  }

  void GenericCryostatBuilder::SetPlateFloatingThickness(double thickness)
  {
    if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) throw std::runtime_error("ERROR : SetPlateFloatingThickness forbidden by GeometryConfiguration::RicochetFinalDesign ");
    mPlateFloating_e = thickness;
  }
  

  void GenericCryostatBuilder::BuildScreen(G4String mat, G4String name, double position, double screen_radius, double screen_e, double screen_bot_h, double screen_mid_h, double screen_top_h, double flange_e, double flange_h) {
    // position : inner bottom center of the screen

        VolumeAdder factory{mMother, mTransformation};
        
	//	if(mat.contains("StainlessSteel")) {
	 if(G4StrUtil::contains(mat, "StainlessSteel")) {       

	  double screen_total_heigh = screen_bot_h + screen_mid_h + screen_top_h;
	  G4ThreeVector positionCylWall = {0, 0, position + screen_total_heigh/2.};
	  factory.Add<Tube>(name+"CylWall","StainlessSteelOVCWall", positionCylWall, screen_radius,screen_radius+screen_e,screen_total_heigh);
	  
	  G4ThreeVector positionBottom = {0, 0, position - screen_e/2.};
	  factory.Add<FilledTube>(name+"Bottom", "StainlessSteelOVCBottom", positionBottom, screen_radius+screen_e,screen_e);

	  G4ThreeVector positionFlange = {0, 0, position + screen_bot_h + flange_h};
	  factory.Add<Tube>(name+"FlangeBot", "StainlessSteelOVCFlange", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, 2*flange_h);
	  positionFlange.setZ(positionFlange.z()+screen_mid_h);
	  factory.Add<Tube>(name+"FlangeMid", "StainlessSteelOVCFlange", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, 2*flange_h);
	  positionFlange.setZ(position+screen_total_heigh-flange_h/2.);
	  factory.Add<Tube>(name+"FlangeTop", "StainlessSteelOVCFlange", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, flange_h);
	} else {

	  double screen_total_heigh = screen_bot_h + screen_mid_h + screen_top_h;
	  G4ThreeVector positionCylWall = {0, 0, position + screen_total_heigh/2.};
	  factory.Add<Tube>(name+"CylWall", "Copper"+mat+"Wall", positionCylWall, screen_radius,screen_radius+screen_e,screen_total_heigh);

	  G4ThreeVector positionBottom = {0, 0, position - screen_e/2.};
	  factory.Add<FilledTube>(name+"Bottom","Copper"+mat+"Bottom", positionBottom, screen_radius+screen_e,screen_e);

	  G4ThreeVector positionFlange = {0, 0, position + screen_bot_h + flange_h};
	  factory.Add<Tube>(name+"FlangeBot", "Copper"+mat+"FlangeBottom", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, 2*flange_h);
	  positionFlange.setZ(positionFlange.z()+screen_mid_h);
	  factory.Add<Tube>(name+"FlangeMid", "Copper"+mat+"FlangeMid", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, 2*flange_h);
	  positionFlange.setZ(position+screen_total_heigh-flange_h/2.);
	  factory.Add<Tube>(name+"FlangeTop", "Copper"+mat+"FlangeTop", positionFlange, screen_radius + screen_e,screen_radius+screen_e+flange_e, flange_h);
	}
    }


    void GenericCryostatBuilder::Build(const CLHEP::Hep3Vector& position)
    {
        Build(HepGeom::Transform3D{{}, position});
    }

    void GenericCryostatBuilder::Build(const HepGeom::Transform3D& transformation)
    {

	if (mVerbosity > 0) G4cout << "Construct Cryostat geometry" << G4endl;

        mTransformation = transformation;

        VolumeAdder factory{mMother, mTransformation};

        // Define 10mK Plate
        G4ThreeVector position_Plate10mK = {0, 0, Plate10mK_e()/2.};
        factory.Add<FilledTube>("Plate10mK", "CopperPlate", position_Plate10mK, Plate10mK_radius(), Plate10mK_e());

        // Define 100mK Plate
        G4ThreeVector position_Plate100mK = position_Plate10mK + G4ThreeVector(0, 0, Plate10mK_e()/2. + DisPlate10mK_100mK() + Plate100mK_e()/2.);
        factory.Add<FilledTube>("Plate100mK", "CopperPlate", position_Plate100mK, Plate100mK_radius(), Plate100mK_e());

        // Define 1K Plate
        G4ThreeVector position_Plate1K = position_Plate100mK + G4ThreeVector(0, 0, Plate100mK_e()/2. + DisPlate100mK_1K() + Plate1K_e()/2.);
        factory.Add<FilledTube>("Plate1K", "CopperPlate", position_Plate1K, Plate1K_radius(), Plate1K_e());

        // Define 4K Plate
        G4ThreeVector position_Plate4K = position_Plate1K + G4ThreeVector(0, 0, Plate1K_e()/2. + DisPlate1K_4K() + Plate4K_e()/2.);
        factory.Add<FilledTube>("Plate4K", "CopperPlate", position_Plate4K, Plate4K_radius(), Plate4K_e());

        // Define 50K Plate
        G4ThreeVector position_Plate50K = position_Plate4K + G4ThreeVector(0, 0, Plate50K_e()/2. + DisPlate4K_50K() + Plate50K_e()/2.);
        factory.Add<FilledTube>("Plate50K", "CopperPlate", position_Plate50K, Plate50K_radius(), Plate50K_e());

	if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014()) {

    std::cout << "Ricochet Final Design Being used here to make the cryostat"<< std::endl;

	  double ScreenFlange_h = 12*CLHEP::mm;
	  double ScreenFlange_e = Plate1K_radius() - Screen1K_radius() - Screen1K_e();

	  double Screen1K_pos = position_Plate1K.z() - Plate1K_e()/2. -  Screen1K_bot_h() - Screen1K_mid_h() - Screen1K_top_h();
	  BuildScreen("Screen1K","Screen1K", Screen1K_pos, Screen1K_radius(), Screen1K_e(), Screen1K_bot_h(), Screen1K_mid_h(), Screen1K_top_h(), ScreenFlange_e, ScreenFlange_h);

	  ScreenFlange_e = Plate4K_radius() - Screen4K_radius() - Screen4K_e();
	  double Screen4K_pos = position_Plate4K.z() - Plate4K_e()/2. -  Screen4K_bot_h() - Screen4K_mid_h() - Screen4K_top_h();
	  BuildScreen("Screen4K","Screen4K", Screen4K_pos, Screen4K_radius(), Screen4K_e(), Screen4K_bot_h(), Screen4K_mid_h(), Screen4K_top_h(), ScreenFlange_e, ScreenFlange_h);
	  ScreenFlange_e = Plate50K_radius() - Screen50K_radius() - Screen50K_e();
	  double Screen50K_pos = position_Plate50K.z() - Plate50K_e()/2. -  Screen50K_bot_h() - Screen50K_mid_h() - Screen50K_top_h();
	  BuildScreen("Screen50K","Screen50K", Screen50K_pos, Screen50K_radius(), Screen50K_e(), Screen50K_bot_h(), Screen50K_mid_h(), Screen50K_top_h(), ScreenFlange_e, ScreenFlange_h);

	  BuildScreen("StainlessSteel","OVC", -DisPlate10mK_InnerBottomOVC(), OVC_radius(), OVC_e(), OVC_bot_h(), OVC_mid_h(), OVC_top_h(), OVCFlange_e(), OVCFlange_h());

	  // Define "bride" = top of the OVC
	  G4ThreeVector position_Bride = {0, 0,  -DisPlate10mK_InnerBottomOVC() + OVC_h() + Bride_h()};
	  factory.Add<ReversedBucket>("Bride", "StainlessSteelOVCBride", position_Bride, Bride_radius(), Bride_e(), Bride_h());

	  mBuildPlateFloating = true;
	  mBuildPillarFloatingPlate = true;

	} 
  else if(mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) {


	  double ScreenFlange_h = 12*CLHEP::mm;
	  double ScreenFlange_e = Plate1K_radius() - Screen1K_radius() - Screen1K_e();

	  double Screen1K_pos = position_Plate1K.z() - Plate1K_e()/2. -  Screen1K_bot_h() - Screen1K_mid_h() - Screen1K_top_h();
	  BuildScreen("Screen1K","Screen1K", Screen1K_pos, Screen1K_radius(), Screen1K_e(), Screen1K_bot_h(), Screen1K_mid_h(), Screen1K_top_h(), ScreenFlange_e, ScreenFlange_h);

	  ScreenFlange_e = Plate4K_radius() - Screen4K_radius() - Screen4K_e();
	  double Screen4K_pos = position_Plate4K.z() - Plate4K_e()/2. -  Screen4K_bot_h() - Screen4K_mid_h() - Screen4K_top_h();
	  BuildScreen("Screen4K","Screen4K", Screen4K_pos, Screen4K_radius(), Screen4K_e(), Screen4K_bot_h(), Screen4K_mid_h(), Screen4K_top_h(), ScreenFlange_e, ScreenFlange_h);
	  ScreenFlange_e = Plate50K_radius() - Screen50K_radius() - Screen50K_e();
	  double Screen50K_pos = position_Plate50K.z() - Plate50K_e()/2. -  Screen50K_bot_h() - Screen50K_mid_h() - Screen50K_top_h();
	  BuildScreen("Screen50K","Screen50K", Screen50K_pos, Screen50K_radius(), Screen50K_e(), Screen50K_bot_h(), Screen50K_mid_h(), Screen50K_top_h(), ScreenFlange_e, ScreenFlange_h);

	  BuildScreen("StainlessSteel","StainlessSteelOVCWall", -DisPlate10mK_InnerBottomOVC(), OVC_radius(), OVC_e(), OVC_bot_h(), OVC_mid_h(), OVC_top_h(), OVCFlange_e(), OVCFlange_h());

	  // Define "bride" = top of the OVC
	  G4ThreeVector position_Bride = {0, 0,  -DisPlate10mK_InnerBottomOVC() + OVC_h() + Bride_h()};
	  factory.Add<ReversedBucket>("Bride", "StainlessSteelOVCBride", position_Bride, Bride_radius(), Bride_e(), Bride_h());

	  // mBuildPlateFloating = true; //these should already be defined... in config at bottom 
	  mBuildPillarFloatingPlate = true;

	}
  else {



	  // Define 10mK Screen
	  G4ThreeVector position_Screen10mK = {0, 0, -DisPlate10mK_BottomScreen10mK()};
	  factory.Add<Bucket>("Screen10mK", "CopperNOSV", position_Screen10mK, Screen10mK_radius(), Screen10mK_e(), Screen10mK_h());
	  
	  // Define 1K Screen
	  G4ThreeVector position_Screen1K = position_Screen10mK + G4ThreeVector(0, 0, -(Screen10mK_e() + DisOuterBottomScreen10mK_InnerBottomScreen1K()));
	  factory.Add<Bucket>("Screen1K", "CopperNOSV", position_Screen1K, Screen1K_radius(), Screen1K_e(), Screen1K_h());

	  // Define 4K Screen
	  G4ThreeVector position_Screen4K = position_Screen1K + G4ThreeVector(0, 0, -(Screen1K_e() + DisOuterBottomScreen1K_InnerBottomScreen4K()));
	  factory.Add<Bucket>("Screen4K", "CopperNOSV", position_Screen4K, Screen4K_radius(), Screen4K_e(), Screen4K_h());

	  // Define 50K Screen
	  G4ThreeVector position_Screen50K = position_Screen4K + G4ThreeVector(0, 0, -(Screen4K_e() + DisOuterBottomScreen4K_InnerBottomScreen50K()));
	  factory.Add<Bucket>("Screen50K", "CopperNOSV", position_Screen50K, Screen50K_radius(), Screen50K_e(), Screen50K_h());

	  // Define OVC Screen
	  G4ThreeVector position_OVC = position_Screen50K + G4ThreeVector(0, 0, -(Screen50K_e() + DisOuterBottomScreen50K_InnerBottomOVC()));
	  factory.Add<Bucket>("OVC", "StainlessSteel", position_OVC, OVC_radius(), OVC_e(), OVC_h());

	  // Define "bride"
	  G4ThreeVector position_Bride = position_Plate50K + G4ThreeVector(0, 0, DisPlate50K_Bride() + Bride_h());
	  factory.Add<ReversedBucket>("Bride", "StainlessSteelOVCBride", position_Bride, Bride_radius(), Bride_e(), Bride_h());

	} // parametrable geometry

  // std::cout << "BuildCryo Cube holder?: " << mBuildCryoCubeHolder << std::endl;
  if(mBuildCryoCubeHolder && mMiniCryoCube) //can aonly access this if you want to build the MCC holder and the MCC itself
	  {////in here I will put the code for the CryCubeHolder
    
    int nMCC = mMiniCryoCube->GetNumberOfMiniCryoCube(); //using previously initalizaed MCC builder
    // std::cout << "Building the CryoCube holder for " << nMCC << " minicryocubes" << std::endl;

    

    // everyhting built from Copper 
    auto Cu_material = "CopperPillar";
    
    mPillarFloatingPlate_AngleShift = 6*CLHEP::deg;
    double holeRadialPosition = mPillarFloatingPlate_RadialPosition;

    // Pillars that go through innershielding===========
    // Pillar10mkFloatingPlates..........................
    for(uint32_t iPillar = 0; iPillar < 3; ++iPillar)
        {
          double angle0 = -mPillarFloatingPlate_AngleShift +  360/3. * iPillar * CLHEP::deg;
          double angle = mPillarFloatingPlate_AngleShift + 360/3. * iPillar * CLHEP::deg;
          


          G4ThreeVector position_Pillar = G4ThreeVector{holeRadialPosition * std::cos(angle), 
          holeRadialPosition * std::sin(angle), -mDisTop10mKPlate_Plate10mK/2.};

          G4ThreeVector position_Pillar0 =  G4ThreeVector{holeRadialPosition * std::cos(angle0), 
          holeRadialPosition * std::sin(angle0), -mDisTop10mKPlate_Plate10mK/2.};
            
          factory.Add<FilledTube>(Form("Pillar10mkFloatingPlates_%ud", iPillar), "CopperPillar", position_Pillar, mPillar_radius, mDisTop10mKPlate_Plate10mK);
          factory.Add<FilledTube>(Form("Pillar10mkFloatingPlates_%ud_0", iPillar), "CopperPillar", position_Pillar0, mPillar_radius, mDisTop10mKPlate_Plate10mK);
        }
    

  // top10mKplate..........................
    G4ThreeVector position_top10mKPlate = {0, 0, -(mDisTop10mKPlate_Plate10mK + mTop10mKPlate_height/2.)};
    // std::cout   << " top 10mK zpos: "<< position_top10mKPlate[2]  << std::endl;

  //empty vector and rotation matrix and transform 
  G4RotationMatrix* emptyrotmat = new G4RotationMatrix();
  G4ThreeVector emptypos = {0 , 0, 0};
  auto emptytransform = new G4Transform3D(*emptyrotmat, emptypos);


  // common offset for all layers
  G4ThreeVector position_top10mKPlatesub = {-71*CLHEP::mm , 0, 0};
  G4RotationMatrix* rotmat = new G4RotationMatrix();
  rotmat->rotateZ(360*CLHEP::deg/3); //askew

  auto top10mKtransform = new G4Transform3D(*rotmat, position_top10mKPlate);
  auto subtransform = new G4Transform3D(*emptyrotmat, position_top10mKPlatesub);

  // G4Transform3D T_total = (*transform) * mTransformation;
  G4Transform3D top10mKplatetransform = (*top10mKtransform) * mTransformation;


    //base plate
    auto top10mKbareplate_solid = new Geometry::FilledTube( mTop10mKPlate_radius, mTop10mKPlate_height);
    //cut out from plate
    auto top10mKbareplate_solid_cut = new Geometry::FilledBox( 300*CLHEP::mm , 180*CLHEP::mm , 10*CLHEP::mm );
    //doing subtraction
    G4SubtractionSolid* top10mKplate_solid = new G4SubtractionSolid("top10mKplate", top10mKbareplate_solid, top10mKbareplate_solid_cut, *subtransform);


  // top1KPillars..........................
  G4RotationMatrix* holerotmat = new G4RotationMatrix();
  holerotmat->rotateZ(360*CLHEP::deg/3); //askew
  G4SubtractionSolid* top10mKplate_wh_solid{nullptr};


    for(uint32_t iPillar = 0; iPillar < 4; ++iPillar)
        {
          double angle = 60 - 6 - 180/3. * iPillar * CLHEP::deg;
          double holeangle = angle - 360*CLHEP::deg/3;
          

          G4ThreeVector position_Pillar = position_top10mKPlate + G4ThreeVector{holeRadialPosition * std::cos(angle), 
          holeRadialPosition * std::sin(angle),0};

          // create holes in the top 10mK plate
          auto top10mKhole_solid = new Geometry::FilledTube("top10mKhole", mPillar_radius*5/3, mTop1KPillar_length);
          G4ThreeVector position_top10mKhole = G4ThreeVector{holeRadialPosition * std::cos(holeangle), 
          holeRadialPosition * std::sin(holeangle),0};

        

          auto holetransform = new G4Transform3D(*emptyrotmat, position_top10mKhole);
          // putting hoels in 10mKplate
          if(iPillar==0) top10mKplate_wh_solid = new G4SubtractionSolid(Form("Top1KPillarhole_%ud_solid", iPillar), top10mKplate_solid, top10mKhole_solid, *holetransform);
          else top10mKplate_wh_solid = new G4SubtractionSolid(Form("Top1KPillarhole_%ud_solid", iPillar), top10mKplate_wh_solid, top10mKhole_solid,*holetransform);
        



       
        // place 1K Pillars
          factory.Add<FilledTube>(Form("Top1KPillar_%ud", iPillar), "CopperPillar", position_Pillar, mPillar_radius, mTop1KPillar_length);

        }

          auto substransform = new G4Transform3D(*holerotmat, emptypos);



        auto top10mKplate_logic = new G4LogicalVolume(top10mKplate_wh_solid, G4NistManager::Instance()->FindOrBuildMaterial("CopperPlate"), "top10mKplate_logic");
        new G4PVPlacement(top10mKplatetransform, top10mKplate_logic, "top10mKplate_physical",&mMother, false, 0, true);




      //top1Kplate..........................

     G4ThreeVector position_top1KPlate = position_top10mKPlate + G4ThreeVector{0, 0, -(mTop1KPillar_length/2.+ mTop1KPlate_height/2.)};
     auto top1Ktransform = new G4Transform3D(*rotmat, position_top1KPlate);
     G4Transform3D top1Kplatetransform = (*top1Ktransform) * mTransformation;




      auto top1Kbareplate_solid = new Geometry::FilledTube(mTop1KPlate_radius, mTop1KPlate_height);
      // FilledBox(const G4String& name, double length, double depth, double height);
      auto top1Kbareplate_solid_cut = new Geometry::FilledBox(300*CLHEP::mm , 180*CLHEP::mm , 10*CLHEP::mm );

      G4SubtractionSolid* top1Kplate_solid = new G4SubtractionSolid("top1Kplate", top1Kbareplate_solid, top1Kbareplate_solid_cut, *subtransform);


      //top10mKPillar..........................
      std::vector<double> x_vals = {-32.5, 32.5,129.3, 129.3, 32.5,-32.5};
      std::vector<double> y_vals = {-127.9, -127.9, -26.5, 26.5, 127.9, 127.9};
      G4SubtractionSolid* top1Kplate_wh_solid{nullptr}; //with holes



      for (size_t i = 0; i < x_vals.size(); ++i) {
          
          G4ThreeVector position_top10mKpillar= position_top10mKPlate + G4ThreeVector{x_vals[i]* std::cos(360*CLHEP::deg/3) - y_vals[i]* std::sin(360*CLHEP::deg/3),
          x_vals[i]* std::sin(360*CLHEP::deg/3) + y_vals[i]* std::cos(360*CLHEP::deg/3),-(mTop10mKPillar_length/2.+ mTop10mKPlate_height/2.)};

          // placing pillars
          factory.Add<FilledTube>(Form("Top10mKPillar_%zud", i), "CopperPillar", position_top10mKpillar, mPillar_radius, mTop10mKPillar_length);


          // making holes
          auto top1Kplatehole_solid = new Geometry::FilledTube( mPillar_radius*5/3, mTop10mKPillar_length);

          G4ThreeVector position_top1Kplatehole = G4ThreeVector{x_vals[i], y_vals[i],0};
          auto top1Kplateholetransform = new G4Transform3D(*emptyrotmat, position_top1Kplatehole);


          // placing holes
          if(i==0) top1Kplate_wh_solid = new G4SubtractionSolid(Form("Top1KPlatehole_%zud_solid", i), top1Kplate_solid, top1Kplatehole_solid, *top1Kplateholetransform);
          else top1Kplate_wh_solid = new G4SubtractionSolid(Form("Top1KPlatehole_%zud_solid", i), top1Kplate_wh_solid, top1Kplatehole_solid,*top1Kplateholetransform);
          
          
      }
      // placing top1Kplate withholes
      G4Material* CopperPlate = new G4Material("CopperPlate", 29.,  63.55*g/mole,  8.96 *g/cm3);
      auto top1Kplate_logic = new G4LogicalVolume(top1Kplate_wh_solid, CopperPlate, "top1Kplate_logic");
      new G4PVPlacement(top1Kplatetransform, top1Kplate_logic, "top1Kplate_physical",&mMother, false, 0, true);


      // information for the MCC stands on the 10mK plates
      std::vector<double> stand_innerlengths = {mMCCstand0_innerlength, mMCCstand1_innerlength, mMCCstand2_innerlength};
      std::vector<double> stand_innerdepths = {mMCCstand0_innerdepth, mMCCstand1_innerdepth, mMCCstand2_innerdepth};
      std::vector<double> stand_heights = {mMCCstand0_height, mMCCstand1_height,mMCCstand2_height};
      std::vector<double> stand_thickness= {mMCCstand0_thickness, mMCCstand1_thickness,mMCCstand2_thickness};
      std::vector<double> stand_xvals = {-(mMCCstand1_innerdepth/2 + 34*CLHEP::mm +mMCCstand0_innerdepth/2), 0,mMCCstand1_innerdepth/2 + 34*CLHEP::mm +mMCCstand2_innerdepth/2};


   
      //mid10mKplate..........................
      G4ThreeVector position_mid10mKPlate = position_top10mKPlate + G4ThreeVector{0, 0, -(mTop10mKPlate_height/2.+mTop10mKPillar_length+ mMid10mKPlate_height/2.)};
      auto mid10mKtransform = new G4Transform3D(*rotmat, position_mid10mKPlate);
      G4Transform3D mid10mKplatetransform = (*mid10mKtransform) * mTransformation;

      auto mid10mKplate_solid = BuildCCstandPlate(mMother, "mid10mKplate",stand_innerlengths,stand_innerdepths, stand_heights, stand_thickness,stand_xvals,
      emptypos,mMid10mKPlate_height, mMid10mKPlate_radius,  Cu_material);

      // place without holes
      // auto mid10mKplate_logic = new G4LogicalVolume(mid10mKplate_solid, G4NistManager::Instance()->FindOrBuildMaterial(Cu_material), "mid10mKplate_logic");
      //   new G4PVPlacement(mid10mKplatetransform, mid10mKplate_logic, "mid10mKplate_physical",&mMother, false, 0, true);

        //bottom1Kpillar..........................

      std::vector<double> x_vals_bottom1Kpillar = {0,holeRadialPosition* std::cos(30*CLHEP::deg), holeRadialPosition,holeRadialPosition* std::cos(30*CLHEP::deg), 0};
      std::vector<double> y_vals_bottom1Kpillar = {-holeRadialPosition,-holeRadialPosition* std::sin(30*CLHEP::deg), 0, holeRadialPosition* std::sin(30*CLHEP::deg), holeRadialPosition};
    


      G4SubtractionSolid* mid10mKplate_wh_solid{nullptr}; //with holes
      for (size_t i = 0; i < x_vals_bottom1Kpillar.size(); ++i) {

          double x_val = x_vals_bottom1Kpillar[i];
          double y_val = y_vals_bottom1Kpillar[i];


          G4ThreeVector position_bottom1Kpillar= position_top1KPlate + G4ThreeVector{x_val* std::cos(360*CLHEP::deg/3) - y_val* std::sin(360*CLHEP::deg/3),
          x_val* std::sin(360*CLHEP::deg/3) + y_val* std::cos(360*CLHEP::deg/3),-(mBottom1KPillar_length/2.+ mTop1KPlate_height/2.)};

          // adding pillars
          factory.Add<FilledTube>(Form("Bottom1KPillar_%zud", i), "CopperPillar", position_bottom1Kpillar, mPillar_radius, mBottom1KPillar_length);


          auto mid10mKplatehole_solid = new Geometry::FilledTube( mPillar_radius*5/3, mBottom1KPillar_length);

          G4ThreeVector position_mid10mKplatehole = G4ThreeVector{x_val, y_val,0};
          auto mid10mKplateholetransform = new G4Transform3D(*emptyrotmat, position_mid10mKplatehole);

          // subtract the holes
          if(i==0) mid10mKplate_wh_solid = new G4SubtractionSolid(Form("Top1KPlatehole_%zud_solid", i), mid10mKplate_solid, mid10mKplatehole_solid, *mid10mKplateholetransform);
          else mid10mKplate_wh_solid = new G4SubtractionSolid(Form("Top1KPlatehole_%zud_solid", i), mid10mKplate_wh_solid, mid10mKplatehole_solid,*mid10mKplateholetransform);
          
  
      }


        // placing mid10mKplate with holes
        auto mid10mKplate_logic = new G4LogicalVolume(mid10mKplate_wh_solid, G4NistManager::Instance()->FindOrBuildMaterial("CopperPlate"), "mid10mKplate_logic");
        new G4PVPlacement(mid10mKplatetransform, mid10mKplate_logic, "mid10mKplate_physical",&mMother, false, 0, true);


        //bottom1Kplate..........................
        G4ThreeVector position_bottom1KPlate = position_top1KPlate + G4ThreeVector{0, 0, -(mBottom1KPillar_length+ mTop1KPlate_height/2.+mBottom1KPlate_height/2)};
        auto bottom1Ktransform = new G4Transform3D(*rotmat, position_bottom1KPlate);
        G4Transform3D bottom1Kplatetransform = (*bottom1Ktransform) * mTransformation;




        auto bottom1Kbareplate_solid = new Geometry::FilledTube( mBottom1KPlate_radius, mBottom1KPlate_height);
        // FilledBox(const G4String& name, double length, double depth, double height);

        auto bottom1Kbareplate_solid_cut = new Geometry::FilledBox( 300*CLHEP::mm , 180*CLHEP::mm , 10*CLHEP::mm );

        G4SubtractionSolid* bottom1Kplate_solid = new G4SubtractionSolid("top1Kplate", bottom1Kbareplate_solid, bottom1Kbareplate_solid_cut, *subtransform);

        // place without holes
        // auto bottom1Kplate_logic = new G4LogicalVolume(bottom1Kplate_solid, G4NistManager::Instance()->FindOrBuildMaterial(Cu_material), "bottom1Kplate_logic");
        //   new G4PVPlacement(bottom1Kplatetransform, bottom1Kplate_logic, "bottom1Kplate_physical",&mMother, false, 0, true);



      //bottom10mKpillar..........................
      double theta =18*CLHEP::deg;
      double phi =theta + 54*CLHEP::deg;
      
      std::vector<double> x_vals_bottom10mKpillar = { -holeRadialPosition* std::cos(phi),holeRadialPosition* std::cos(phi), holeRadialPosition* std::cos(theta),
      holeRadialPosition* std::cos(theta), holeRadialPosition* std::cos(phi),-holeRadialPosition* std::cos(phi)};
      
      std::vector<double> y_vals_bottom10mKpillar = {-holeRadialPosition* std::sin(phi), -holeRadialPosition* std::sin(phi), -holeRadialPosition* std::sin(theta),
      holeRadialPosition* std::sin(theta), holeRadialPosition* std::sin(phi), holeRadialPosition* std::sin(phi)};
    


      G4SubtractionSolid* bottom1Kplate_wh_solid{nullptr}; //with holes
      for (size_t i = 0; i < x_vals_bottom10mKpillar.size(); ++i) {

          double x_val = x_vals_bottom10mKpillar[i];
          double y_val = y_vals_bottom10mKpillar[i];


          G4ThreeVector position_bottom10mKpillar= position_mid10mKPlate + G4ThreeVector{x_val* std::cos(360*CLHEP::deg/3) - y_val* std::sin(360*CLHEP::deg/3),
           x_val* std::sin(360*CLHEP::deg/3) + y_val* std::cos(360*CLHEP::deg/3),-(mBottom10mKPillar_length/2.+ mMid10mKPlate_height/2.)};
        // placing pillars
          factory.Add<FilledTube>(Form("Bottom10mKPillar_%zud", i), "CopperPillar", position_bottom10mKpillar, mPillar_radius, mBottom10mKPillar_length);


          auto bottom1Kplatehole_solid = new Geometry::FilledTube( mPillar_radius*5/3, mBottom10mKPillar_length);
          G4ThreeVector position_bottom1Kplatehole = G4ThreeVector{x_val, y_val,0};
          auto bottom1Kplateholetransform = new G4Transform3D(*emptyrotmat, position_bottom1Kplatehole);


        // doing subtraction of holes
          if(i==0) bottom1Kplate_wh_solid = new G4SubtractionSolid(Form("Bottom1KPlatehole_%zud_solid", i), bottom1Kplate_solid, bottom1Kplatehole_solid, *bottom1Kplateholetransform);
          else bottom1Kplate_wh_solid = new G4SubtractionSolid(Form("Bottom1KPlatehole_%zud_solid", i), bottom1Kplate_wh_solid, bottom1Kplatehole_solid,*bottom1Kplateholetransform);
          
      }

      // placing bottom1Kplate with holes

      auto bottom1Kplate_logic = new G4LogicalVolume(bottom1Kplate_wh_solid, CopperPlate, "bottom1Kplate_logic");
      new G4PVPlacement(bottom1Kplatetransform, bottom1Kplate_logic, "bottom1Kplate_physical",&mMother, false, 0, true);



      //bottom10mKplate..........................
      G4ThreeVector position_bottom10mKPlate = position_mid10mKPlate + G4ThreeVector{0, 0, -(mMid10mKPlate_height/2.+mBottom10mKPillar_length+ mBottom10mKPlate_height/2.)};
      auto bottom10mKtransform = new G4Transform3D(*rotmat, position_bottom10mKPlate);
      G4Transform3D bottom10mKplatetransform = (*bottom10mKtransform) * mTransformation;

      G4SubtractionSolid* bottom10mKplate_solid{nullptr}; //initializing it 
    
      if (nMCC>3){
        // std::cout << "Is there more than 3 <" << nMCC << std::endl;

          bottom10mKplate_solid = BuildCCstandPlate(mMother, "bottom10mKplate",stand_innerlengths,stand_innerdepths, stand_heights, stand_thickness,stand_xvals,
      emptypos,mBottom10mKPlate_height, mBottom10mKPlate_radius,  Cu_material);

      }
      else{
        // std::cout << "Is there less than 3 >=" << nMCC << std::endl;

        bottom10mKplate_solid = BuildCCstandPlateNoStands(mMother, "bottom10mKplate",stand_innerlengths,stand_innerdepths, stand_heights, stand_thickness,stand_xvals,
      emptypos,mBottom10mKPlate_height, mBottom10mKPlate_radius,  Cu_material);

      }
     

      //NO HOLES TO MAKE :)

       auto bottom10mKplate_logic = new G4LogicalVolume(bottom10mKplate_solid, CopperPlate, "bottom10mKplate_logic");
        new G4PVPlacement(bottom10mKplatetransform, bottom10mKplate_logic, "bottom10mKplate_physical",&mMother, false, 0, true);


         MCCpos = {0,0,mid10mKplatetransform.getTranslation().z()+ mMid10mKPlate_height/2};



    }









	if(mBuildPlateFloating)
	  {
	    // Define Floating Plate
      std::cout << "here is where we are building floating plate"  << std::endl;



      
	    G4ThreeVector position_PlateFloating = {0, 0, -(mDisPlateFloating_Plate10mK + PlateFloating_e()/2.)};
      //define pos here 
      MCCpos = {0, 0,  mTransformation.getTranslation().z()-(mDisPlateFloating_Plate10mK)+ mMid10mKPlate_height/2};

	    factory.Add<FilledTube>("PlateFloating", "CopperPlate", position_PlateFloating, PlateFloating_radius(), PlateFloating_e());

	    if(mBuildPillarFloatingPlate)
	      {
		mPillarFloatingPlate_AngleShift = 6*CLHEP::deg;
		double holeRadialPosition = mPillarFloatingPlate_RadialPosition;


		// for(uint32_t iPillar = 0; iPillar < 3; ++iPillar)
		//   {
		//     double angle = mPillarFloatingPlate_AngleShift + 360/3. * iPillar * CLHEP::deg;
		//     G4ThreeVector position_Pillar = position_PlateFloating + G4ThreeVector{holeRadialPosition * std::cos(angle), 
    //     holeRadialPosition * std::sin(angle), mDisPlateFloating_Plate10mK/2. + mPlateFloating_e/2.};
           
		//     factory.Add<FilledTube>(Form("Pillar10mkFloatingPlates_%ud", iPillar), "CopperPlate10mK", position_Pillar, 7.5*CLHEP::mm, mDisPlateFloating_Plate10mK);
		//   }




    for(uint32_t iPillar = 0; iPillar < 3; ++iPillar)
        {
          double angle0 = -mPillarFloatingPlate_AngleShift +  360/3. * iPillar * CLHEP::deg;
          double angle = mPillarFloatingPlate_AngleShift + 360/3. * iPillar * CLHEP::deg;
          


          G4ThreeVector position_Pillar = G4ThreeVector{holeRadialPosition * std::cos(angle), 
          holeRadialPosition * std::sin(angle), -mDisPlateFloating_Plate10mK/2.};

          G4ThreeVector position_Pillar0 =  G4ThreeVector{holeRadialPosition * std::cos(angle0), 
          holeRadialPosition * std::sin(angle0), -mDisPlateFloating_Plate10mK/2.};
            
          factory.Add<FilledTube>(Form("Pillar10mkFloatingPlates_%ud", iPillar), "CopperPillar", position_Pillar,  7.5*CLHEP::mm, mDisPlateFloating_Plate10mK);
          factory.Add<FilledTube>(Form("Pillar10mkFloatingPlates_%ud_0", iPillar), "CopperPillar", position_Pillar0,  7.5*CLHEP::mm, mDisPlateFloating_Plate10mK);
        }






	      }
        
	  }


        if (mVerbosity > 0) G4cout << "Cryostat Constructed." << G4endl;

    }

    void GenericCryostatBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("GenericCrysotat", "Geometry::GenericCrysotatBuilder");
        writer.SetKeyValue("Position_X", mTransformation.dx());
        writer.SetKeyValue("Position_Y", mTransformation.dy());
        writer.SetKeyValue("Position_Z", mTransformation.dz());
        writer.SetKeyValue("Config", mConfig.ToStr());
        writer.SetKeyValue("Plate10mK_e", mPlate10mK_e);
        writer.SetKeyValue("Plate10mK_radius", mPlate10mK_radius);
        writer.SetKeyValue("Plate100mK_e", mPlate100mK_e);
        writer.SetKeyValue("Plate100mK_radius", mPlate100mK_radius);
        writer.SetKeyValue("DisPlate10mK_100mK", mDisPlate10mK_100mK);
        writer.SetKeyValue("Plate1K_e", mPlate1K_e);
        writer.SetKeyValue("Plate1K_radius", mPlate1K_radius);
        writer.SetKeyValue("DisPlate100mK_1K", mDisPlate100mK_1K);
        writer.SetKeyValue("Plate4K_e", mPlate4K_e);
        writer.SetKeyValue("Plate4K_radius", mPlate4K_radius);
        writer.SetKeyValue("DisPlate1K_4K", mDisPlate1K_4K);
        writer.SetKeyValue("Plate50K_e", mPlate50K_e);
        writer.SetKeyValue("Plate50K_radius", mPlate50K_radius);
        writer.SetKeyValue("DisPlate4K_50K", mDisPlate4K_50K);
        writer.SetKeyValue("Screen10mK_radius", mScreen10mK_radius);
        writer.SetKeyValue("Screen10mK_e", mScreen10mK_e);
        writer.SetKeyValue("DisPlate10mK_BottomScreen10mK", mDisPlate10mK_BottomScreen10mK);
        writer.SetKeyValue("Screen1K_radius", mScreen1K_radius);
        writer.SetKeyValue("Screen1K_e", mScreen1K_e);
        writer.SetKeyValue("DisOuterBottomScreen10mK_InnerBottomScreen1K",mDisOuterBottomScreen10mK_InnerBottomScreen1K);
        writer.SetKeyValue("Screen4K_radius", mScreen4K_radius);
        writer.SetKeyValue("Screen4K_e", mScreen4K_e);
        writer.SetKeyValue("DisOuterBottomScreen1K_InnerBottomScreen4K", mDisOuterBottomScreen1K_InnerBottomScreen4K);
        writer.SetKeyValue("Screen50K_radius", mScreen50K_radius);
        writer.SetKeyValue("Screen50K_e", mScreen50K_e);
        writer.SetKeyValue("DisOuterBottomScreen4K_InnerBottomScreen50K", mDisOuterBottomScreen4K_InnerBottomScreen50K);
        writer.SetKeyValue("OVC_radius", mOVC_radius);
        writer.SetKeyValue("OVC_e", mOVC_e);
        writer.SetKeyValue("DisOuterBottomScreen50K_InnerBottomOVC", mDisOuterBottomScreen50K_InnerBottomOVC);
        writer.SetKeyValue("Bride_h", mBride_h);
        writer.SetKeyValue("Bride_radius", mBride_radius);
        writer.SetKeyValue("Bride_e", mBride_e);
        writer.SetKeyValue("DisPlate50K_Bride", mDisPlate50K_Bride);
        writer.SetKeyValue("BuildPlateFloating", mBuildPlateFloating);
        writer.SetKeyValue("PlateFloating_e", mPlateFloating_e);
        writer.SetKeyValue("PlateFloating_radius", mPlateFloating_radius);
        writer.SetKeyValue("DisPlateFloating_Plate10mK", mDisPlateFloating_Plate10mK);
        writer.WriteIn(directory);
    }


    /// Position in the Cryostat frame of reference

    G4ThreeVector GenericCryostatBuilder::PlateFloatingBottomCenter() const
    {
        return {0, 0, -(DisPlateFloating_Plate10mK() + PlateFloating_e())};
    }

    G4ThreeVector GenericCryostatBuilder::OVCBottomCenter() const
    {
      if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) return {0,0, -DisPlate10mK_InnerBottomOVC()-OVC_e()};
	else return {0, 0, -(DisPlate10mK_BottomScreen10mK()
			     + Screen10mK_e() + DisOuterBottomScreen10mK_InnerBottomScreen1K()
			     + Screen1K_e() + DisOuterBottomScreen1K_InnerBottomScreen4K()
			     + Screen4K_e() + DisOuterBottomScreen4K_InnerBottomScreen50K()
			     + Screen50K_e() + DisOuterBottomScreen50K_InnerBottomOVC()
			     + OVC_e())};
    }


    // ---- Geometry of 10mK Plate
    double GenericCryostatBuilder::Plate10mK_e() const
    {
        return mPlate10mK_e;
    }
    double GenericCryostatBuilder::Plate10mK_radius() const
    {
        return mPlate10mK_radius;
    }

    double GenericCryostatBuilder::DisPlate10mK_100mK() const
    {
        return mDisPlate10mK_100mK;
    }

    // ---- Geometry of 100mK Plate
    double GenericCryostatBuilder::Plate100mK_e() const
    {
        return mPlate100mK_e;
    }
    double GenericCryostatBuilder::Plate100mK_radius() const
    {
        return mPlate100mK_radius;
    }

    double GenericCryostatBuilder::DisPlate100mK_1K() const
    {
        return mDisPlate100mK_1K;
    }

    // ---- Geometry of 1K Plate
    double GenericCryostatBuilder::Plate1K_e() const
    {
        return mPlate1K_e;
    }
    double GenericCryostatBuilder::Plate1K_radius() const
    {
        return mPlate1K_radius;
    }

    double GenericCryostatBuilder::DisPlate1K_4K() const
    {
        return mDisPlate1K_4K;
    }

    // ---- Geometry of 4K Plate
    double GenericCryostatBuilder::Plate4K_e() const
    {
        return mPlate4K_e;
    }
    double GenericCryostatBuilder::Plate4K_radius() const
    {
        return mPlate4K_radius;
    }

    double GenericCryostatBuilder::DisPlate4K_50K() const
    {
        return mDisPlate4K_50K;
    }

    // ---- Geometry of 50K Plate
    double GenericCryostatBuilder::Plate50K_e() const
    {
        return mPlate50K_e;
    }
    double GenericCryostatBuilder::Plate50K_radius() const
    {
        return mPlate50K_radius;
    }

    double GenericCryostatBuilder::DisPlate10mK_BottomScreen10mK() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) 
	{
	    G4cout << "WARNING : DisPlate10mK_BottomScreen10mK(). GeometryConfiguration::RicochetFinalDesign, no 10mK Screen" << G4endl;
	} 
        return mDisPlate10mK_BottomScreen10mK;
    }

    // ---- Geometry of Screen 10mK Screen all the radius of screen are the inner radius() = outer radius - thickness of the screen.
    double GenericCryostatBuilder::Screen10mK_h() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) 
	{
	    G4cout << "WARNING : Screen10mK_h(). GeometryConfiguration::RicochetFinalDesign, no 10mK Screen" << G4endl;
	    return 0.;
	} 
	else if(mBuildPlateFloating)
	{
            return DisPlate10mK_BottomScreen10mK() - DisPlateFloating_Plate10mK() - PlateFloating_e();
	}
        else
	{
            return DisPlate10mK_BottomScreen10mK();
        }
    }
    double GenericCryostatBuilder::Screen10mK_e() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) 
	{
	    G4cout << "WARNING : Screen10mK_e(). Config is RicochetFinalDesign, no 10mK Screen" << G4endl;
	} 
        return mScreen10mK_e;
    }
    double GenericCryostatBuilder::Screen10mK_radius() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) 
	{
	    G4cout << "WARNING : Screen10mK_radius(). Config is RicochetFinalDesign, no 10mK Screen" << G4endl;
	} 
        return mScreen10mK_radius;
    }

    double GenericCryostatBuilder::DisOuterBottomScreen10mK_InnerBottomScreen1K() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016()) 
	{
	    G4cout << "WARNING : DisOuterBottomScreen10mK_InnerBottomScreen1K. Config is RicochetFinalDesign, no 10mK Screen" << G4endl;
	} 
        return mDisOuterBottomScreen10mK_InnerBottomScreen1K;
    }

    // ---- Geometry of Screen 1K Screen
    double GenericCryostatBuilder::Screen1K_h() const
    {
      if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
	{
	  return Screen1K_top_h() + Screen1K_mid_h() + Screen1K_bot_h();
	} 
      else
	{
	  return DisOuterBottomScreen10mK_InnerBottomScreen1K() + Screen10mK_e()
	    + DisPlate10mK_BottomScreen10mK() + Plate10mK_e()
	    + DisPlate10mK_100mK() + Plate100mK_e()
	    + DisPlate100mK_1K();
	}
    }
    double GenericCryostatBuilder::Screen1K_e() const
    {
        return mScreen1K_e;
    }
    double GenericCryostatBuilder::Screen1K_radius() const
    {
        return mScreen1K_radius;
    }

    double GenericCryostatBuilder::DisOuterBottomScreen1K_InnerBottomScreen4K() const
    {
        return mDisOuterBottomScreen1K_InnerBottomScreen4K;
    }

    // ---- Geometry of Screen 4K Screen
  double GenericCryostatBuilder::Screen4K_h() const
    {
       if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
	{
	  return Screen4K_top_h() + Screen4K_mid_h() + Screen4K_bot_h();
	} 
      else
	{
	  return DisOuterBottomScreen1K_InnerBottomScreen4K() + Screen1K_e()
	    + DisOuterBottomScreen10mK_InnerBottomScreen1K() + Screen10mK_e()
	    + DisPlate10mK_BottomScreen10mK() + Plate10mK_e()
	    + DisPlate10mK_100mK() + Plate100mK_e()
	    + DisPlate100mK_1K() + Plate1K_e()
	    + DisPlate1K_4K();
	}
    }
    double GenericCryostatBuilder::Screen4K_e() const
    {
        return mScreen4K_e;
    }
    double GenericCryostatBuilder::Screen4K_radius() const
    {
        return mScreen4K_radius;
    }

    double GenericCryostatBuilder::DisOuterBottomScreen4K_InnerBottomScreen50K() const
    {
        return mDisOuterBottomScreen4K_InnerBottomScreen50K;
    }

    // ---- Geometry of Screen 50K Screen
    double GenericCryostatBuilder::Screen50K_h() const
    {
      if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
	{
	  return Screen50K_top_h() + Screen50K_mid_h() + Screen50K_bot_h();
	} 
      else
	{
	  return DisOuterBottomScreen4K_InnerBottomScreen50K() + Screen4K_e()
	    + DisOuterBottomScreen1K_InnerBottomScreen4K() + Screen1K_e()
	    + DisOuterBottomScreen10mK_InnerBottomScreen1K() + Screen10mK_e()
	    + DisPlate10mK_BottomScreen10mK() + Plate10mK_e()
	    + DisPlate10mK_100mK() + Plate100mK_e()
	    + DisPlate100mK_1K() + Plate1K_e()
	    + DisPlate1K_4K() + Plate4K_e()
	    + DisPlate4K_50K();
	}
    }
    double GenericCryostatBuilder::Screen50K_e() const
    {
        return mScreen50K_e;
    }
    double GenericCryostatBuilder::Screen50K_radius() const
    {
        return mScreen50K_radius;
    }

    double GenericCryostatBuilder::DisOuterBottomScreen50K_InnerBottomOVC() const
    {
        return mDisOuterBottomScreen50K_InnerBottomOVC;
    }

    // ---- Geometry of OVC Screen
    double GenericCryostatBuilder::OVC_h() const
    {
        if(mConfig == GeometryConfiguration::RicochetFinalDesign() || mConfig == GeometryConfiguration::RicochetRUN013() || mConfig == GeometryConfiguration::RicochetRUN014() || mConfig == GeometryConfiguration::RicochetRUN015() || mConfig == GeometryConfiguration::RicochetRUN016())
	{
	  return OVC_bot_h() + OVC_mid_h() + OVC_top_h();
	} 
	else
	{
	  return DisOuterBottomScreen50K_InnerBottomOVC() + Screen50K_e()
	    + DisOuterBottomScreen4K_InnerBottomScreen50K() + Screen4K_e()
	    + DisOuterBottomScreen1K_InnerBottomScreen4K() + Screen1K_e()
	    + DisOuterBottomScreen10mK_InnerBottomScreen1K() + Screen10mK_e()
	    + DisPlate10mK_BottomScreen10mK() + Plate10mK_e()
	    + DisPlate10mK_100mK() + Plate100mK_e()
	    + DisPlate100mK_1K() + Plate1K_e()
	    + DisPlate1K_4K() + Plate4K_e()
	    + DisPlate4K_50K() + Plate50K_e()
	    + DisPlate50K_Bride();
	}
    }
    double GenericCryostatBuilder::OVC_e() const
    {
        return mOVC_e;
    }
    double GenericCryostatBuilder::OVC_radius() const
    {
        return mOVC_radius;
    }

    double GenericCryostatBuilder::DisPlate10mK_InnerBottomOVC() const {
      return mDisPlate10mK_InnerBottomOVC;
    }
  
    double GenericCryostatBuilder::DisPlate50K_Bride() const
    {
        return mDisPlate50K_Bride;
    }

    // ---- Geometry of "bride"
    double GenericCryostatBuilder::Bride_h() const
    {
        return mBride_h;
    }
    double GenericCryostatBuilder::Bride_e() const
    {
        return mBride_e;
    }
    double GenericCryostatBuilder::Bride_radius() const
    {
        return mBride_radius;
    }

    // ---- Geometry of Floating Plate
    double GenericCryostatBuilder::PlateFloating_e() const
    {
        return mPlateFloating_e;
    }
    double GenericCryostatBuilder::PlateFloating_radius() const
    {
        return mPlateFloating_radius;
    }

    double GenericCryostatBuilder::DisPlateFloating_Plate10mK() const
    {
        return mDisPlateFloating_Plate10mK;
    }

    double GenericCryostatBuilder::TotalHeight() const
    {
        return OVC_h() + OVC_e() + Bride_h() + Bride_e();
    }


  // final Geometry

    double GenericCryostatBuilder::Screen1K_bot_h() const
    { 
      return 26.45*CLHEP::cm;
    }
    double GenericCryostatBuilder::Screen1K_mid_h() const
    {
      return 59.05*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen1K_top_h() const
    {
      return 17.45*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen4K_bot_h() const
    {
      return 31.45*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen4K_mid_h() const
    {
      return 58.85*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen4K_top_h() const
    {
      return 35.6*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen50K_bot_h() const
    {
      return 36.3*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen50K_mid_h() const
    {
      return 58.8*CLHEP::cm;
    }

    double GenericCryostatBuilder::Screen50K_top_h() const
    {
      return 53.57*CLHEP::cm;
    }

    double GenericCryostatBuilder::OVCFlange_e() const
    {
      return 17*CLHEP::mm;
    }
    double GenericCryostatBuilder::OVCFlange_h() const
    {
      return 23.5*CLHEP::mm ;
    }
    double GenericCryostatBuilder::OVC_bot_h() const
    {
      return 46.55*CLHEP::cm;
    }
  
    double GenericCryostatBuilder::OVC_mid_h() const
    {
      return 58.8*CLHEP::cm;
    }
  
    double GenericCryostatBuilder::OVC_top_h() const
    {
      return 64.53*CLHEP::cm;
    }


    void GenericCryostatBuilder::mfSetConfigLyon()
    {


        mPlate10mK_e = 0.4*cm;
        mPlate10mK_radius = 14.95*cm;;

        mDisPlate10mK_100mK = 18.1*cm;

        mPlate100mK_e = 0.3*cm;
        mPlate100mK_radius = 15.*cm;

        mDisPlate100mK_1K = 14.6*cm;

        mPlate1K_e = 0.4*cm;
        mPlate1K_radius = 16.7*cm;

        mDisPlate1K_4K = 15.*cm;

        mPlate4K_e = 0.4*cm;
        mPlate4K_radius = 18.35*cm;

        mDisPlate4K_50K = 20.52*cm;

        mPlate50K_e = 0.4*cm;
        mPlate50K_radius = 20.*cm;

        mDisPlate10mK_BottomScreen10mK = 17.25*cm;

        mScreen10mK_e = 0.1*cm;
        mScreen10mK_radius = 14*cm;

        mDisOuterBottomScreen10mK_InnerBottomScreen1K = 1.95*cm;

        mScreen1K_e = 0.1*cm;
        mScreen1K_radius = 15.65*cm;

        mDisOuterBottomScreen1K_InnerBottomScreen4K = 1.95*cm;

        mScreen4K_e = 0.2*cm;
        mScreen4K_radius = 17.25*cm;

        mDisOuterBottomScreen4K_InnerBottomScreen50K = 1.98*cm;

        mScreen50K_e = 0.2*cm;
        mScreen50K_radius = 18.95*cm;

        mDisOuterBottomScreen50K_InnerBottomOVC = 9.*cm;

        mOVC_e = 0.2*cm;
        mOVC_radius = 20.65*cm;

        mDisPlate50K_Bride = 24.3*cm;

        mBride_h = 6.6*cm;
        mBride_e = 4.5*cm;
        mBride_radius = 20.85*cm;

        mBuildPlateFloating = false;
        mPlateFloating_e = 0.*cm;
        mPlateFloating_radius = 0.*cm;
    }

    void GenericCryostatBuilder::mfSetConfigCross()
    {

        mPlate10mK_e = 0.5*cm;
        mPlate10mK_radius = 15*cm;

        mDisPlate10mK_100mK = 16.0*cm;

        mPlate100mK_e = 0.4*cm;
        mPlate100mK_radius = 15.*cm;

        mDisPlate100mK_1K = 9.6*cm;

        mPlate1K_e = 0.4*cm;
        mPlate1K_radius = 16.7*cm;

        mDisPlate1K_4K = 14.3*cm;

        mPlate4K_e = 0.4*cm;
        mPlate4K_radius = 18.35*cm;

        mDisPlate4K_50K = 20.52*cm;

        mPlate50K_e = 0.4*cm;
        mPlate50K_radius = 20.*cm;

        mDisPlate10mK_BottomScreen10mK = 82.6*cm;

        mScreen10mK_e = 0.2*cm;
        mScreen10mK_radius = 14.8*cm;

        mDisOuterBottomScreen10mK_InnerBottomScreen1K = 1.95*cm;

        mScreen1K_e = 0.2*cm;
        mScreen1K_radius = 15.65*cm;

        mDisOuterBottomScreen1K_InnerBottomScreen4K = 1.95*cm;

        mScreen4K_e = 0.2*cm;
        mScreen4K_radius = 17.2*cm;

        mDisOuterBottomScreen4K_InnerBottomScreen50K = 1.98*cm;

        mScreen50K_e = 0.2*cm;
        mScreen50K_radius = 18.85*cm;

        mDisOuterBottomScreen50K_InnerBottomOVC = 2*cm;

        mOVC_e = 0.4*cm;
        mOVC_radius = 20.7*cm;

        mDisPlate50K_Bride = 12.6*cm;

        mBride_h = 11.1*cm;
        mBride_e = 6*cm;
        mBride_radius = mOVC_radius + mOVC_e;

        mBuildPlateFloating = true;
	if(mPlateFloating_e == 0. ) mPlateFloating_e = 0.5*cm;
        mPlateFloating_radius = 15*cm;
    }

    void GenericCryostatBuilder::mfSetConfigCryoConcept2020()
    {

        mfSetConfigCross();

        using CLHEP::mm;

        mDisPlate10mK_100mK = 160*mm;
        mDisPlate100mK_1K = 94*mm;
        mDisPlate1K_4K = 203.5*mm;
        mDisPlate4K_50K = 203.2*mm;
        mDisPlate50K_Bride = 126*mm;
    }

    void GenericCryostatBuilder::mfSetConfigRicochetFinalDesign()
    {


        mfSetConfigCross();

        using CLHEP::cm;
        using CLHEP::mm;

        mPlate10mK_e = 5*mm;
        mPlate10mK_radius = 14.6*cm;

        mDisPlate10mK_100mK = 16.0*cm;

        mPlate100mK_e = 4*mm;
        mPlate100mK_radius = 14.6*cm;

        mDisPlate100mK_1K = 9.*cm;

        mPlate1K_e = 1*cm;
        mPlate1K_radius = 16.7*cm;

        mDisPlate1K_4K = 20.35*cm;

        mPlate4K_e = 6*mm;
        mPlate4K_radius = 18.35*cm;

        mDisPlate4K_50K = 20.12*cm;

        mPlate50K_e = 8*mm;
        mPlate50K_radius = 20.*cm;

        mDisPlate10mK_BottomScreen10mK =  0*cm;

	// no 10mK screen
	mScreen10mK_e = 0.;
        mScreen10mK_radius = 0.;
        mDisOuterBottomScreen10mK_InnerBottomScreen1K = 0*cm;

        mScreen1K_e = 0.2*cm;
        mScreen1K_radius = 15.65*cm;

	mDisOuterBottomScreen1K_InnerBottomScreen4K = Screen4K_h() - mPlate1K_e - mDisPlate1K_4K - Screen1K_h() - Screen1K_e();

        mScreen4K_e = 0.2*cm;
        mScreen4K_radius = 17.2*cm;

	mDisOuterBottomScreen4K_InnerBottomScreen50K = Screen50K_h() - mPlate4K_e - mDisPlate4K_50K - Screen4K_h() - Screen4K_e();

        mScreen50K_e = 0.2*cm;
        mScreen50K_radius = 18.85*cm;

        mOVC_e = 0.2*cm;
        mOVC_radius = 20.9*cm;

	mDisPlate10mK_InnerBottomOVC = 88.16*cm;
        mDisPlate50K_Bride = 12.65*cm; 
	mDisOuterBottomScreen50K_InnerBottomOVC = mDisPlate10mK_InnerBottomOVC + mPlate10mK_e + mDisPlate10mK_100mK + mPlate100mK_e + mDisPlate100mK_1K - Screen1K_h() - Screen1K_e() - mDisOuterBottomScreen1K_InnerBottomScreen4K - Screen4K_e() - mDisOuterBottomScreen4K_InnerBottomScreen50K - Screen50K_e() ;

        mBride_h = 11.1*cm;
        mBride_e = 6*cm;
        mBride_radius = mOVC_radius + mOVC_e;

        mBuildPlateFloating = true;
	mPlateFloating_e = 0.3*cm;
        mPlateFloating_radius = 14.6*cm;
	mDisPlateFloating_Plate10mK = 52*cm;
	mBuildPillarFloatingPlate = true;
	
    }


void GenericCryostatBuilder::mfSetConfigRicochetCryoCubeHolder()
    {


        mfSetConfigCross();

        using CLHEP::cm;
        using CLHEP::mm;

        mPlate10mK_e = 5*mm;
        mPlate10mK_radius = 14.6*cm;

        mDisPlate10mK_100mK = 16.0*cm;

        mPlate100mK_e = 4*mm;
        mPlate100mK_radius = 14.6*cm;

        mDisPlate100mK_1K = 9.*cm;

        mPlate1K_e = 1*cm;
        mPlate1K_radius = 16.7*cm;

        mDisPlate1K_4K = 20.35*cm;

        mPlate4K_e = 6*mm;
        mPlate4K_radius = 18.35*cm;

        mDisPlate4K_50K = 20.12*cm;

        mPlate50K_e = 8*mm;
        mPlate50K_radius = 20.*cm;

        mDisPlate10mK_BottomScreen10mK =  0*cm;

	// no 10mK screen
	mScreen10mK_e = 0.;
        mScreen10mK_radius = 0.;
        mDisOuterBottomScreen10mK_InnerBottomScreen1K = 0*cm;

        mScreen1K_e = 0.2*cm;
        mScreen1K_radius = 15.65*cm;

	mDisOuterBottomScreen1K_InnerBottomScreen4K = Screen4K_h() - mPlate1K_e - mDisPlate1K_4K - Screen1K_h() - Screen1K_e();

        mScreen4K_e = 0.2*cm;
        mScreen4K_radius = 17.2*cm;

	mDisOuterBottomScreen4K_InnerBottomScreen50K = Screen50K_h() - mPlate4K_e - mDisPlate4K_50K - Screen4K_h() - Screen4K_e();

        mScreen50K_e = 0.2*cm;
        mScreen50K_radius = 18.85*cm;

        mOVC_e = 0.2*cm;
        mOVC_radius = 20.9*cm;

	mDisPlate10mK_InnerBottomOVC = 88.16*cm;
        mDisPlate50K_Bride = 12.65*cm; 
	mDisOuterBottomScreen50K_InnerBottomOVC = mDisPlate10mK_InnerBottomOVC + mPlate10mK_e + mDisPlate10mK_100mK + mPlate100mK_e + mDisPlate100mK_1K - Screen1K_h() - Screen1K_e() - mDisOuterBottomScreen1K_InnerBottomScreen4K - Screen4K_e() - mDisOuterBottomScreen4K_InnerBottomScreen50K - Screen50K_e() ;

        mBride_h = 11.1*cm;
        mBride_e = 6*cm;
        mBride_radius = mOVC_radius + mOVC_e;

        mBuildPlateFloating = false; //no floating plate
	// mPlateFloating_e = 0.3*cm;
        // mPlateFloating_radius = 14.6*cm;
	// mDisPlateFloating_Plate10mK = 47.1*cm;// change of height of pillars
	// mBuildPillarFloatingPlate = true;

    mPillar_radius = 15*mm/2; //half diameter
    mTop1KPillar_length = 55*mm; 
    mTop10mKPillar_length = 120*mm; 
    mBottom1KPillar_length = 120*mm; 
    mBottom10mKPillar_length = 120*mm; 

    



    mBuildCryoCubeHolder = true; // Build Cryco Cube Holder!
	  mDisTop10mKPlate_Plate10mK = 47.1*cm;// change of height of pillars

    // top10mKPLate
    mTop10mKPlate_height = 5*mm;
    mTop10mKPlate_radius = 300*mm/2; //half diameter

    // top1KPLate
    mTop1KPlate_height = 5*mm;
    mTop1KPlate_radius = 300*mm/2; //half diameter

    //mid10mKplate
    mMid10mKPlate_height = 5*mm;
    mMid10mKPlate_radius = 300*mm/2; //half diameter

    // bottom1KPLate
    mBottom1KPlate_height = 5*mm;
    mBottom1KPlate_radius = 300*mm/2; //half diameter

    // bottom10mKPLate
    mBottom10mKPlate_height = 5*mm;
    mBottom10mKPlate_radius = 300*mm/2; //half diameter


    
    mMCCstand2_height = 17*mm;
    mMCCstand2_innerlength =194 *mm;
    mMCCstand2_innerdepth = 38*mm;
    mMCCstand2_thickness = 10*mm;

    mMCCstand1_height = 8.5*mm;
    mMCCstand1_innerlength =194 *mm;
    mMCCstand1_innerdepth = 38*mm;
    mMCCstand1_thickness = 10*mm;
    
    mMCCstand0_height = 0*mm;
    mMCCstand0_innerlength =194 *mm;
    mMCCstand0_innerdepth = 33*mm;
    mMCCstand0_thickness = 0*mm;


     




	
    }


}
