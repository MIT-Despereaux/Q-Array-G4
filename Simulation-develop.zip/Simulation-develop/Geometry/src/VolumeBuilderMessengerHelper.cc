#include "Geometry/VolumeBuilderMessengerHelper.hh"

namespace Geometry
{

    namespace VolumeBuilderMessengerHelper
    {

        void RunAddCommand(const std::string& type, VolumeBuilder& builder, std::istream& input)
        {
            if(type == "FilledCube") RunAddCommand<FilledCube>(builder, input);
            else if(type == "FilledBox" || type == "Floor") RunAddCommand<FilledBox>(builder, input);
            else if(type == "Wall") RunAddCommand<Wall>(builder, input);
            else if(type == "Box") RunAddCommand<Box>(builder, input);
            else if(type == "SameThicknessBox") RunAddCommand<SameThicknessBox>(builder, input);
            else if(type == "SameThicknessHollowBox" || type == "Room") RunAddCommand<SameThicknessHollowBox>(builder, input);
            else if(type == "Tube") RunAddCommand<Tube>(builder, input);
            else if(type == "FilledTube") RunAddCommand<FilledTube>(builder, input);
            else if(type == "Bucket") RunAddCommand<Bucket>(builder, input);
            else if(type == "ReversedBucket") RunAddCommand<ReversedBucket>(builder, input);
            else if(type == "Cylinder") RunAddCommand<Cylinder>(builder, input);
            else if(type == "SameThicknessCylinder") RunAddCommand<SameThicknessCylinder>(builder, input);
            else throw std::runtime_error("RunAddCommand: unregistered volume type '"+type+"'");
        }

    }

}
