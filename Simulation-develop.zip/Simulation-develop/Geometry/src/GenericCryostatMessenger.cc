#include "Geometry/GenericCryostatMessenger.hh"

/// Geant4 includes
#include "G4Tokenizer.hh"

/// Project includes
#include "Geometry/GenericCryostatBuilder.hh"
#include "Geometry/RunBuildCommand.hh"

namespace Geometry
{
    GenericCryostatMessenger::GenericCryostatMessenger(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("GenericCryostat command directory");

        mCmdBuild.reset(new G4UIcmdWithAString((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build a generic Cryoconcept cryostat, different configurations of lengths are possible");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);

//         mCmdConfig.reset(new G4UIcmdWithAString((cmdPrefixPath + "setConfig").c_str(), this));
//         mCmdConfig->SetGuidance("Set cryostat geometry config");
//         mCmdConfig->AvailableForStates(G4State_Idle);

        mCmdExperimentalZoneHeight.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setExperimentZoneHeight").c_str(), this));
        mCmdExperimentalZoneHeight->SetGuidance("Set experimental zone height, arg = XXX unit (ex: 3 cm), experiment zone is all the zone below the 10mK plate, this zone include the inner shielding zone");
        mCmdExperimentalZoneHeight->AvailableForStates(G4State_Idle);

        mCmdInnerShieldingZoneHeight.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setInnerShieldingZonrHeight").c_str(), this));
        mCmdInnerShieldingZoneHeight->SetGuidance("Set inner shielding zone height, arg = XXX unit (ex: 3 cm)");
        mCmdInnerShieldingZoneHeight->AvailableForStates(G4State_Idle);

        mCmdPlateFloatingThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setFloatingPlateThickness").c_str(), this));
        mCmdPlateFloatingThickness->SetGuidance("Set Plate Floating thicknesss, arg = XXX unit (ex: 5 mm)");
        mCmdPlateFloatingThickness->AvailableForStates(G4State_Idle);

        mCmdBuildPillarFloatingPlate.reset(new G4UIcommand((cmdPrefixPath + "buildPillarFloatingPlate").c_str(), this));
        mCmdBuildPillarFloatingPlate->SetGuidance("Add pillar between MC plate and floating plate");
        mCmdBuildPillarFloatingPlate->SetParameter(new G4UIparameter("build", 'b', false));
        mCmdBuildPillarFloatingPlate->SetParameter(new G4UIparameter("angleShift", 'd', true));
        mCmdBuildPillarFloatingPlate->SetRange("angleShift >= 0 && angleShift <= 360");
        mCmdBuildPillarFloatingPlate->AvailableForStates(G4State_Idle);
    }

    void GenericCryostatMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            RunBuildCommand{}(mBuilder, valueStr);
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
//         else if(command == mCmdConfig.get())
//         {
//             mBuilder.SetConfig(GenericCryostatBuilder::Config::FromStr(valueStr));
//         }
        else if(command == mCmdExperimentalZoneHeight.get())
        {
            mBuilder.SetExperimentalZoneHeight(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdInnerShieldingZoneHeight.get())
        {
            mBuilder.SetInnerShieldingZoneHeight(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdPlateFloatingThickness.get())
        {
            mBuilder.SetPlateFloatingThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdBuildPillarFloatingPlate.get())
        {
            G4Tokenizer next(valueStr);
            double build = StoB(next());
            std::string angleShiftStr = next();

            mBuilder.BuildPillarFloatingPlate(build);

            if(angleShiftStr.empty())
            {
                double angleShift = StoD(angleShiftStr) * CLHEP::deg;
                mBuilder.SetPillarFloatingPlateShiftAngle(angleShift);
            }

        }
    }
}


