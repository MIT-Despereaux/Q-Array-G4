#include "Geometry/MiniCryoCubeMessenger.hh"

/// Project includes
#include "Geometry/MiniCryoCubeBuilder.hh"

/********************************************************
 *							*
 * MiniCryoCubeMessenger.cc				        *
 * Author : Maël GONIN			        *
 * Implements the input commands in the macro related   *
 * to the muon veto					*
 *						        *
 ********************************************************/
 
namespace Geometry
{
    MiniCryoCubeMessenger::MiniCryoCubeMessenger(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("MiniCryoCube command directory");
        
        mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build the muon veto");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);
	
        mCmdMiniCryoCubeNumber.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setMiniCryoCubeNumber").c_str(), this));
        mCmdMiniCryoCubeNumber->SetGuidance("Set the number of miniCryoCube.");
        mCmdMiniCryoCubeNumber->SetParameterName("val",false);
        mCmdMiniCryoCubeNumber->SetRange("val>=0");
        mCmdMiniCryoCubeNumber->AvailableForStates(G4State_Idle);
        
        mCmdMiniCryoCubeHorizontalSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setMiniCryoCubeHorizontalSpacing").c_str(), this));
        mCmdMiniCryoCubeHorizontalSpacing->SetGuidance("Set spacing between 2 miniCryoCube along the Y axis, arg = XXX unit (ex: 1 cm)");
        mCmdMiniCryoCubeHorizontalSpacing->AvailableForStates(G4State_Idle);
        
        mCmdMiniCryoCubeVerticalSpacing.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setMiniCryoCubeVerticalSpacing").c_str(), this));
        mCmdMiniCryoCubeVerticalSpacing->SetGuidance("Set spacing between 2 miniCryoCube along the Y axis, arg = XXX unit (ex: 1 cm)");
        mCmdMiniCryoCubeVerticalSpacing->AvailableForStates(G4State_Idle);
    }

    void MiniCryoCubeMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdMiniCryoCubeNumber.get())
        {
            mBuilder.SetMiniCryoCubeNumber(mCmdMiniCryoCubeNumber->GetNewIntValue(valueStr));
        }
        else if(command == mCmdMiniCryoCubeHorizontalSpacing.get())
        {
            mBuilder.SetMiniCryoCubeHorizontalSpacing(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdMiniCryoCubeVerticalSpacing.get())
        {
            mBuilder.SetMiniCryoCubeVerticalSpacing(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
    }
}
