#include "CLHEP/Units/SystemOfUnits.h"
#include "CLHEP/Vector/Rotation.h"
#include "Geometry/DubnaSpectrometerBuilder.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"

namespace Geometry
{
    constexpr double DubnaSpectrometerBuilder::CavityDiameter()
    {
        return 31 * CLHEP::mm;
    }

    constexpr double DubnaSpectrometerBuilder::TubeDiameter()
    {
        return CavityDiameter() + CLHEP::mm;
    }

    constexpr double DubnaSpectrometerBuilder::CavityLength()
    {
        return 960 * CLHEP::mm;
    }

    constexpr double DubnaSpectrometerBuilder::TubeLength()
    {
        return CavityLength() + CLHEP::mm;
    }

    constexpr double DubnaSpectrometerBuilder::CavityRadius()
    {
        return .5 * CavityDiameter();
    }

    constexpr double DubnaSpectrometerBuilder::TubeRadius()
    {
        return .5 * TubeDiameter();
    }

    constexpr const char* DubnaSpectrometerBuilder::CavityMaterialName()
    {
        return "DubnaHe3Ar40";
    }

    DubnaSpectrometerBuilder::DubnaSpectrometerBuilder(G4LogicalVolume& mother_)
    :mother(mother_)
    {}

    std::vector<G4LogicalVolume*> DubnaSpectrometerBuilder::Build(const HepGeom::Transform3D& transformationToMother)
    {
        VolumeAdder volumeAdder{mother, transformationToMother};
        auto gas = volumeAdder.Add<FilledTube>("Dubna_Gas", CavityMaterialName(), {0., 0., 0.} , CavityRadius(), CavityLength());
        volumeAdder.Add<SameThicknessCylinder>("Dubna_Tube", "StainlessSteel", {0., 0., 0.}, CavityRadius(), TubeRadius(), TubeLength());
        return {gas.Logical()};
    }

    double DubnaSpectrometerBuilder::CavityVolume() const
    {
        return std::acos(-1) * std::pow(TubeRadius(), 2) * CavityLength();
    }

    G4Material* DubnaSpectrometerBuilder::CavityMaterial() const
    {
        return G4Material::GetMaterial(CavityMaterialName());
    }

    double DubnaSpectrometerBuilder::CavityDensity() const
    {
        auto material = CavityMaterial();
        if(material) return material->GetDensity();
        else return 0.;
    }

    double DubnaSpectrometerBuilder::CavityMass() const
    {
        return CavityVolume() * CavityDensity();
    }

}
