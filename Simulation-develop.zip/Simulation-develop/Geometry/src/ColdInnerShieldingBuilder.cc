#include "Geometry/ColdInnerShieldingBuilder.hh"

/// Standard includes
#include <vector>

/// Geant4 includes
#include "G4Material.hh"
#include "G4SubtractionSolid.hh"
#include "G4UnionSolid.hh"
#include "G4NistManager.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"


/// Project includes
#include "Geometry/Shapes.hh"
#include "Geometry/VolumeAdder.hh"
#include "Geometry/IdenticalVolumeAdder.hh"
#include "Geometry/Cryostat.hh"
#include "SimuOutput/InfoHeaderWriter.hh"
#include "Geometry/MaterialColour.hh"
//CADMESH
#include "Geometry/CADMesh.hh"

namespace{

    constexpr double TotalCopperThickness() {

        return 3. * 1.5 * CLHEP::cm;

    }

    void SetHolePosition(G4ThreeVector& position, double holeRadialPosition, double angle)
    {
        position.set(holeRadialPosition * std::cos(angle), holeRadialPosition * std::sin(angle), 0.);
    }

    G4SubtractionSolid* BuildMultiHoleCylinder(const G4String& name, double holeRadius, double holeRadialPosition, double angularSpacing, double outerRadius, double height)
    {
        G4ThreeVector holePosition;

        auto mainTube = new Geometry::FilledTube("mainTube", outerRadius, height);
        auto hole = new Geometry::FilledTube("hole", holeRadius, height);

        G4SubtractionSolid* multiHoleCylinder{nullptr};
        std::string solName;
        double angleOffset = 60*CLHEP::deg;
        for(int i = 0; i < 6; ++i)
        {
            double ithAngle = i*angleOffset;
            SetHolePosition(holePosition, holeRadialPosition, ithAngle+angularSpacing);
            solName = name + std::to_string(i+1) + "holeA";
            if(i==0) multiHoleCylinder = new G4SubtractionSolid(solName, mainTube, hole, nullptr, holePosition);
            else multiHoleCylinder = new G4SubtractionSolid(solName, multiHoleCylinder, hole, nullptr, holePosition);

            SetHolePosition(holePosition, holeRadialPosition, ithAngle-angularSpacing);
            if(i<5) solName = name + std::to_string(i+1) + "holeB";
            else solName = name;
            multiHoleCylinder = new G4SubtractionSolid(solName,multiHoleCylinder, hole, nullptr, holePosition);
        }

        return multiHoleCylinder;
    }

    G4Transform3D Transformation(const CLHEP::Hep3Vector& centre, const CLHEP::Hep3Vector& offsetToMother, const CLHEP::HepRotation& rotation = {})
    {
        return G4Transform3D{rotation, centre + offsetToMother};
    }

    void AddMultiHoleCylinder(G4LogicalVolume& mother, const CLHEP::Hep3Vector& origin, const G4String& name, const G4String& material, const CLHEP::Hep3Vector& position, double holeRadius, double holeRadialPosition, double holeAngularSpacing, double outerRadius, double height)
    {
        auto transformation = Transformation(origin, position);
        auto solid = BuildMultiHoleCylinder(name, holeRadius, holeRadialPosition, holeAngularSpacing, outerRadius, height);
        auto logicalVolume = new G4LogicalVolume(solid, G4NistManager::Instance()->FindOrBuildMaterial(material), name+"_logic");
        
	    Geometry::SetColourFromMaterial(logicalVolume, material);
        new G4PVPlacement(transformation, logicalVolume, name+"_physical", &mother, false, 0, true);

    }

    
    // void AddPECuPlate(G4LogicalVolume& mother, const CLHEP::Hep3Vector origin, const G4String name, const CLHEP::Hep3Vector position, double CuPlateRadius, double CuPlateLength)
    // {
    //     //name is something like "lay#"
    //     //defining copper material (wont change so can hard code)
    //     // G4Material* CuMaterial = G4NistManager::Instance()->FindOrBuildMaterial(material);
    //     auto material = "CopperInnerShielding";


    //     auto transformation = Transformation(origin, position);
        
    //     // auto solid = BuildMultiHoleCylinder(name, holeRadius, holeRadialPosition, holeAngularSpacing, outerRadius, height);
    //     auto CuPlate_solid = new G4Tubs(name+"CuPlate", 0., CuPlateRadius, CuPlateLength, 0. *CLHEP::deg, 360.*CLHEP::deg);

    //     // auto logicalVolume = new G4LogicalVolume(solid, G4NistManager::Instance()->FindOrBuildMaterial(material), name+"_logic");
    //     auto CuPlate_logical = new G4LogicalVolume(CuPlate_solid, G4NistManager::Instance()->FindOrBuildMaterial(material),  name+"CuPlate_logic");
	    
    //     // Geometry::SetColourFromMaterial(logicalVolume, material);
	//     Geometry::SetColourFromMaterial(CuPlate_logical, material);
    //     // new G4PVPlacement(transformation, logicalVolume, name+"_physical", &mother, false, 0, true);
    //     new G4PVPlacement(transformation, CuPlate_logical, name+"CuPlate_physical", &mother, false, 0, true ); //true is for the surface check

    // }
    //based off of AddMultiHoleCylinder
    void AddPECuPlate(G4LogicalVolume& mother, const CLHEP::Hep3Vector origin, const G4String name, const CLHEP::Hep3Vector position,double holeRadius, double holeRadialPosition, double holeAngularSpacing, double CuPlateRadius, double CuPlateLength)
    {
        //name is something like "lay#"
        //defining copper material (wont change so can hard code)
        // G4Material* CuMaterial = G4NistManager::Instance()->FindOrBuildMaterial(material);

        //AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_centralCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);
        //void AddMultiHoleCylinder(G4LogicalVolume& mother, const CLHEP::Hep3Vector& origin, const G4String& name, const G4String& material, const CLHEP::Hep3Vector& position, double holeRadius, double holeRadialPosition, double holeAngularSpacing, double outerRadius, double height)

        auto material = "CopperInnerShielding";

        AddMultiHoleCylinder(mother, origin, name+"CuPlate", material, position, holeRadius, holeRadialPosition, holeAngularSpacing, CuPlateRadius, CuPlateLength);

    }

    
    //Addding the PE layer with the subtracted Copper to fill all the holes
    // void AddPEwithCuLayer(G4LogicalVolume& mother, const CLHEP::Hep3Vector origin, const G4String name, const CLHEP::Hep3Vector position, double CuRadius, double CuLength ,const G4String filename)
    // {
    //     //name should be soemthing like "lay#"
    //     auto Cu_material = "CopperInnerShielding";
    //     auto PE_material = "Pol";
    //     //PE_thickness is a constant from the file
    //     G4double PEthickness = 27.5*CLHEP::mm;
    //     G4RotationMatrix* PErotmat = new G4RotationMatrix();
    //     PErotmat->rotateX(-90*CLHEP::deg);//to make it flat   

    //     auto PE_transformation = Transformation(origin, position + G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm,PEthickness/2 ), *PErotmat); //slight movemnt to put origion in center
    //     // auto solid = BuildMultiHoleCylinder(name, holeRadius, holeRadialPosition, holeAngularSpacing, outerRadius, height);

         
       

    //     //import PE object
    //     auto PE_mesh = CADMesh::TessellatedMesh::FromOBJ(filename);
    //     PE_mesh->SetScale(1);
    //     G4VSolid* PE_solid = PE_mesh->GetSolid();

    //     // auto logicalVolume = new G4LogicalVolume(solid, G4NistManager::Instance()->FindOrBuildMaterial(material), name+"_logic");
    //     auto PE_logical = new G4LogicalVolume( PE_solid, G4NistManager::Instance()->FindOrBuildMaterial(PE_material), name+"_logic" );
    //     //place the PE    
    //     new G4PVPlacement(PE_transformation, PE_logical,  name+"PE_physical",&mother, false, 0, true);

    //     //make subtraction
    //     //this might be an issue** with rotation of the Tesselated Meshs
    //     //G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm, (27.5*CLHEP::cm)/2) //this is constant for every layer, w.r.t each other

    //     //rotation matrix for subtraction solid (wrt PE solid)
    //     G4RotationMatrix* subrotmat = new G4RotationMatrix();
    //     subrotmat->rotateY(180*CLHEP::deg); 
    //     subrotmat->rotateX(90*CLHEP::deg);
    //     auto sub_pos = G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm, -PEthickness/2);
    //     auto sub_transformation =  Transformation(origin, sub_pos, *subrotmat);

    //      //creating Cu to be subtracted from
    //     auto CuFill_Solid = new G4Tubs(name+"CuFill", 0., CuRadius, CuLength, 0.*CLHEP::deg, 360.*CLHEP::deg);
    //     G4RotationMatrix* Curotmat = new G4RotationMatrix();
    //     Curotmat->rotateY(180*CLHEP::deg);//to make it flat 
    //     auto Cu_transformation = Transformation(origin, position, *Curotmat);


    //     G4SubtractionSolid* Cu_solid = new G4SubtractionSolid(name+"Cu", CuFill_Solid, PE_solid, sub_transformation);
    //     auto Cu_logic = new G4LogicalVolume(Cu_solid, G4NistManager::Instance()->FindOrBuildMaterial(Cu_material), name+"Cu_logic");
    //     // G4VPhysicalVolume* lay1Cu_phys = new G4PVPlacement(rotmat,  
    //     //                     posLayer1,  // at (x,y,z)
    //     //                     lay1Cu_logic,  // its logical volume
    //     //                     "lay1Cu",  // its name
    //     //                     &mMother,  // its mother volume
    //     //                     false,  // no boolean operations
    //     //                     0);  // Copy nuumber
    //     // auto trans
    //     new G4PVPlacement(Cu_transformation, Cu_logic, name+"Cu_physical", &mother, false, 0, true ); //true is for the surface check
        

    //     //colors
	//     Geometry::SetColourFromMaterial(PE_logical, PE_material);
	//     Geometry::SetColourFromMaterial(Cu_logic, Cu_material);
	//     // Geometry::SetColourFromMaterial(PE_logical, material);

    //     // new G4PVPlacement(transformation, logicalVolume, name+"_physical", &mother, false, 0, true);
    //     //each layer will have: lay#CuPLate_physical lay#PE_physical, lay#Cu_Physical
    // }

        void AddPEwithCuLayer(G4LogicalVolume& mother, const CLHEP::Hep3Vector origin, const G4String name, const CLHEP::Hep3Vector position, double CuRadius, double CuLength,
        double holeRadius, double holeRadialPosition, double holeAngularSpacing ,const G4String filename)
    {
        //name should be soemthing like "lay#"
        auto Cu_material = "CopperInnerShielding";
        auto PE_material = "PolyInnerShielding";
        //PE_thickness is a constant from the file
        G4double PEthickness = 27.5*CLHEP::mm;
        G4RotationMatrix* PErotmat = new G4RotationMatrix();
        PErotmat->rotateX(90*CLHEP::deg);//to make it flat   
        PErotmat->rotateZ(48*CLHEP::deg);//added

        auto PE_transformation = Transformation(origin, position + G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm,-PEthickness/2 ), *PErotmat); //slight movemnt to put origion in center

        //import PE object
        auto PE_mesh = CADMesh::TessellatedMesh::FromOBJ(filename);
        PE_mesh->SetScale(1);
        G4VSolid* PE_solid = PE_mesh->GetSolid();
        auto PE_logical = new G4LogicalVolume( PE_solid, G4NistManager::Instance()->FindOrBuildMaterial(PE_material), name+"_logic" );
        //place the PE    
	new G4PVPlacement(PE_transformation, PE_logical,  name+"PE_physical",&mother, false, 0, true);


        //make subtraction

        //rotation matrix for subtraction solid (wrt PE solid)
        G4RotationMatrix* subrotmat = new G4RotationMatrix();
	//subrotmat->rotateX(90*CLHEP::deg);
	subrotmat->rotateY(180*CLHEP::deg); 
	subrotmat->rotateX(90*CLHEP::deg);
    subrotmat->rotateZ(48*CLHEP::deg);//added

	auto sub_pos = G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm, -PEthickness/2);
	
	auto sub_transformation =  Transformation(G4ThreeVector(0.*CLHEP::cm,0*CLHEP::cm,0*CLHEP::cm), sub_pos, *subrotmat);

         //creating baisc Cu to be subtracted from
        auto CuFillBasic_Solid = new Geometry::FilledTube(name+"CuFill", CuRadius, CuLength*2);
        //subtracting the PE first
	//G4VSolid *CuFill_Solid = new G4UnionSolid(name+"Cu",CuFillBasic_Solid,PE_solid,sub_transformation);
       	G4SubtractionSolid* CuFill_Solid = new G4SubtractionSolid(name+"Cu", CuFillBasic_Solid, PE_solid,sub_transformation);
	
        //then subtracting the holes
        G4ThreeVector holePosition;

        auto hole = new G4Tubs("hole", 0., holeRadius, CuLength*2, 0.*CLHEP::deg, 360.*CLHEP::deg);

        std::string solName;
        double angleOffset = 60*CLHEP::deg;
		
        for(int i = 0; i < 6; ++i)
        {
            double ithAngle = i*angleOffset;
            SetHolePosition(holePosition, holeRadialPosition, ithAngle+holeAngularSpacing);
            solName = name+"CuFill" + std::to_string(i+1) + "holeA";
            if(i==0) CuFill_Solid = new G4SubtractionSolid(solName, CuFill_Solid, hole, nullptr, holePosition);
            else CuFill_Solid = new G4SubtractionSolid(solName, CuFill_Solid, hole, nullptr, holePosition);

            SetHolePosition(holePosition, holeRadialPosition, ithAngle-holeAngularSpacing);
            if(i<5) solName = name+"CuFill" + std::to_string(i+1) + "holeB";
            else solName = name+"CuFill";
            CuFill_Solid = new G4SubtractionSolid(solName,CuFill_Solid, hole, nullptr, holePosition);
        }
	
        G4RotationMatrix* Curotmat = new G4RotationMatrix();
        Curotmat->rotateY(180*CLHEP::deg);//to make it flat 
        Curotmat->rotateX(180*CLHEP::deg);
        // Curotmat->rotateZ(48*CLHEP::deg);//added
        auto Cu_transformation = Transformation(origin, position, *Curotmat);
        auto Cu_logic = new G4LogicalVolume(CuFill_Solid, G4NistManager::Instance()->FindOrBuildMaterial(Cu_material), name+"Cu_logic");
        new G4PVPlacement(Cu_transformation, Cu_logic, name+"Cu_physical", &mother, false, 0, true ); //true is for the surface check
	
        //colors
	    Geometry::SetColourFromMaterial(PE_logical, PE_material);
	    Geometry::SetColourFromMaterial(Cu_logic, Cu_material);
    }
    void AddPEandCuPlate(G4LogicalVolume& mother, const CLHEP::Hep3Vector& origin, const G4String& name, const CLHEP::Hep3Vector& layerposition, double CuPlateRadius, double CuPlateLength, double CuRadius, double CuLength, double CuSpacing, double holeRadius, double holeRadialPosition, double holeAngularSpacing, const G4String& filename)
    {
        //name something like lay#
        //each layer will have: lay#CuPlate_physical lay#PE_physical, lay#Cu_Physical
        G4double PEthickness = 27.5*CLHEP::mm;
        //creating PE with Copper Fill
         
        auto posCuPlate = layerposition- G4ThreeVector(0*CLHEP::cm, 0*CLHEP::cm, PEthickness/2+CuPlateLength/2+CuSpacing);
        // std::cout << name  << " CuPlate zpos: "<< posCuPlate[2]  << std::endl;

  

        // fucntion definition: void AddPECuPlate(G4LogicalVolume& mother, const CLHEP::Hep3Vector& origin, const G4String& name, const CLHEP::Hep3Vector& position, double CuPlateRadius, double CuPlateLength)
        // AddPECuPlate(mother, origin, name, posCuPlate,  CuPlateRadius,  CuPlateLength);
        AddPECuPlate(mother, origin, name, posCuPlate, holeRadius, holeRadialPosition, holeAngularSpacing, CuPlateRadius,  CuPlateLength);
        //creating Cu Plate
        AddPEwithCuLayer(mother, origin, name, layerposition, CuRadius,  CuLength, holeRadius, holeRadialPosition, holeAngularSpacing ,filename);
        // AddPEwithCuLayer(mother, origin, name, layerposition, CuRadius,  CuLength ,filename); //old version 
        // AddPEwithCuLayer(mother, origin, name, layerposition, 187.1/2*CLHEP::mm,  CuLength, holeRadius, holeRadialPosition, holeAngularSpacing ,filename);
        // AddPEwithCuLayer(mother, origin, name, layerposition, 187.1/2*CLHEP::mm,  CuLength ,filename); //old version 


    }

}

namespace Geometry
{


    void ColdInnerShieldingBuilder::SetConfig(GeometryConfiguration config)
    {
        mConfig = config;

        // std::cout << "(In Config )You chose: " <<  mConfig << std::endl;

        

	if(config == GeometryConfiguration::RicochetFinalDesign())
	{
	  mUseCryoConceptInternalLead = true;
	  mPolyWithHoles = true;
	  mLeadThickness = 8.5 * CLHEP::cm;
	  mLeadRadius = 14.7 * CLHEP::cm;
	  mPolyThickness = 30 * CLHEP::cm;
	  mPolyRadius = 14.7 * CLHEP::cm;
	  mUseRealisticPolyethylene = true;
	  mRealisticPoly_NbPolyLayers = 8;
	  mRealisticPoly_CopperThickness = 10 * CLHEP::mm;
	  mLeadMaterial = "LeadInnerShielding";
	  mPolyMaterial = "PolyInnerShielding";
	  mHoleRadialPosition = 13.2 * CLHEP::cm; // changed from 12.2 cm to account for the 2 poles going through
      mInnerShieldingConfig = 2;
	}

    if(config == GeometryConfiguration::RicochetRUN014()) //same as RicochetFinalDesign
	{
	  mUseCryoConceptInternalLead = true;
	  mPolyWithHoles = true;
	  mLeadThickness = 8.5 * CLHEP::cm;
	  mLeadRadius = 14.7 * CLHEP::cm;
	  mPolyThickness = 30 * CLHEP::cm;
	  mPolyRadius = 14.7 * CLHEP::cm;
	  mUseRealisticPolyethylene = true;
	  mRealisticPoly_NbPolyLayers = 8;
	  mRealisticPoly_CopperThickness = 10 * CLHEP::mm;
	  mLeadMaterial = "LeadInnerShielding";
	  mPolyMaterial = "PolyInnerShielding";
	  mHoleRadialPosition = 13.2 * CLHEP::cm; // changed from 12.2 cm to account for the 2 poles going through
      mInnerShieldingConfig = 2;
	}

    if(config == GeometryConfiguration::RicochetRUN015()) //same as RicochetFinalDesign
	{
	  mUseCryoConceptInternalLead = true;
	  mPolyWithHoles = true;
	  mLeadThickness = 8.5 * CLHEP::cm;
	  mLeadRadius = 14.7 * CLHEP::cm;
	  mPolyThickness = 30 * CLHEP::cm;
	  mPolyRadius = 14.7 * CLHEP::cm;
	  mUseRealisticPolyethylene = true;
	  mRealisticPoly_NbPolyLayers = 8;
	  mRealisticPoly_CopperThickness = 10 * CLHEP::mm;
	  mLeadMaterial = "LeadInnerShielding";
	  mPolyMaterial = "PolyInnerShielding";
	  mHoleRadialPosition = 13.2 * CLHEP::cm; //editted
      mInnerShieldingConfig = 2;
	}

    if(config == GeometryConfiguration::RicochetRUN016()) //same as RicochetFinalDesign
	{
	  mUseCryoConceptInternalLead = true;
	  mPolyWithHoles = true;
	  mLeadThickness = 8.5 * CLHEP::cm;
	  mLeadRadius = 14.7 * CLHEP::cm;
	  mPolyThickness = 30 * CLHEP::cm;
	  mPolyRadius = 14.7 * CLHEP::cm;
	  mUseRealisticPolyethylene = true;
	  mRealisticPoly_NbPolyLayers = 8;
	  mRealisticPoly_CopperThickness = 10 * CLHEP::mm;
	  mLeadMaterial = "LeadInnerShielding";
	  mPolyMaterial = "PolyInnerShielding";
	  mHoleRadialPosition = 13.2 * CLHEP::cm; //editted
      mInnerShieldingConfig = 2;
	}

    if(config == GeometryConfiguration::RicochetRUN013()) //same as RicochetFinalDesign
	{
	  mUseCryoConceptInternalLead = true;
	  mPolyWithHoles = true;
	  mLeadThickness = 8.5 * CLHEP::cm;
	  mLeadRadius = 14.7 * CLHEP::cm;
	  mPolyThickness = 30 * CLHEP::cm;
	  mPolyRadius = 14.7 * CLHEP::cm;
	  mUseRealisticPolyethylene = true;
	  mRealisticPoly_NbPolyLayers = 8;
	  mRealisticPoly_CopperThickness = 10 * CLHEP::mm;
	  mLeadMaterial = "LeadInnerShielding";
	  mPolyMaterial = "PolyInnerShielding";
	  mHoleRadialPosition = 12.2 * CLHEP::cm;
    //   mInnerShieldingConfig = 1; //default should not built this 
	}
    }



    ColdInnerShieldingBuilder::ColdInnerShieldingBuilder(G4LogicalVolume &mother): mMother(mother)
    {

    }

    
    void ColdInnerShieldingBuilder::SetVerbosity(int level)
    {
        mVerbosity = level;
    }

    //copied from RicochetBasicBuilder.cc from MiniCryoCube Config, mCmdColdInnerShieldingConfig
    void ColdInnerShieldingBuilder::SetColdInnerShieldingConfig(double config)
    {
        
        std::cout << "SetColdInnerShieldingConfig using : " << config << std::endl;
        
        mInnerShieldingConfig = config;
        
    
    }


    void ColdInnerShieldingBuilder::SetUseCryoConceptInternalLead(bool activate)
    {
        if( !activate && mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : UseCryoConceptInternalLead forced to be true by  GeometryConfiguration::RicochetFinalDesign ");
        if( !activate && mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : UseCryoConceptInternalLead forced to be true by  GeometryConfiguration::RicochetRUN014 ");
        mUseCryoConceptInternalLead = activate;
    }

    void ColdInnerShieldingBuilder::SetPolyethyleneWithHoles(bool activate)
    {
        if( !activate && mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : mPolyWithHoles forced to be true by  GeometryConfiguration::RicochetFinalDesign ");
        if( !activate && mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : mPolyWithHoles forced to be true by  GeometryConfiguration::RicochetRUN014 ");
	mPolyWithHoles = activate;
    }

    void ColdInnerShieldingBuilder::BuildRealisticPolyShield(bool build)
    {
        if(!build && mConfig == GeometryConfiguration::RicochetFinalDesign())  throw std::runtime_error("ERROR : mUseRealisticPolyethylene forced to be true by  GeometryConfiguration::RicochetFinalDesign ");
        if(!build && mConfig == GeometryConfiguration::RicochetRUN014())  throw std::runtime_error("ERROR : mUseRealisticPolyethylene forced to be true by  GeometryConfiguration::RicochetRUN014 ");
	mUseRealisticPolyethylene = build;
    }

    void ColdInnerShieldingBuilder::SetParamRealisticPolyShield(unsigned int nbPolyLayers, double copperThickness)
    {
        if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetParamRealisticPolyShield forbided by  GeometryConfiguration::RicochetFinalDesign ");
        if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetParamRealisticPolyShield forbided by  GeometryConfiguration::RicochetRUN014 ");
        mRealisticPoly_NbPolyLayers = nbPolyLayers;
        mRealisticPoly_CopperThickness = copperThickness;
    }

    void ColdInnerShieldingBuilder::SetRadius(double radius)
    {
        if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetRadius forbided by  GeometryConfiguration::RicochetFinalDesign ");
        if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetRadius forbided by  GeometryConfiguration::RicochetRUN014 ");
        mLeadRadius = radius;
        mPolyRadius = radius;
    }

    void ColdInnerShieldingBuilder::SetLeadRadius(double radius)
    {
        if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetLeadRadius forbided by  GeometryConfiguration::RicochetFinalDesign ");
        if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetLeadRadius forbided by  GeometryConfiguration::RicochetRUN014 ");
        mLeadRadius = radius;
    }

    void ColdInnerShieldingBuilder::SetLeadThickness(double leadThickness)
    {
      if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : setLeadThickness forbided by  GeometryConfiguration::RicochetFinalDesign ");
      if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : setLeadThickness forbided by  GeometryConfiguration::RicochetRUN014 ");
        mLeadThickness = leadThickness;
    }

    void ColdInnerShieldingBuilder::SetPolyRadius(double radius)
    {
        if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetPolyRadius forbided by  GeometryConfiguration::RicochetFinalDesign ");
        if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetPolyRadius forbided by  GeometryConfiguration::RicochetRUN014 ");
        mPolyRadius = radius;
    }

    void ColdInnerShieldingBuilder::SetPolyethyleneThickness(double polyThickness)
    {
      if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : setPolyEthylenThickness forbided by  GeometryConfiguration::RicochetFinalDesign ");
      if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : setPolyEthylenThickness forbided by  GeometryConfiguration::RicochetRUN014 ");
        mPolyThickness = polyThickness;
    }

    void ColdInnerShieldingBuilder::SetLeadMaterial(std::string material)
    {
      if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetLeadMaterial forbided by  GeometryConfiguration::RicochetFinalDesign ");
      if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetLeadMaterial forbided by  GeometryConfiguration::RicochetRUN014 ");
       mLeadMaterial = material;
    }

    void ColdInnerShieldingBuilder::SetPolyethyleneMaterial(std::string material)
    {
        if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetPolyethylenMaterial forbided by  GeometryConfiguration::RicochetFinalDesign ");
        if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetPolyethylenMaterial forbided by  GeometryConfiguration::RicochetRUN014 ");
        mPolyMaterial = material;
    }

    void ColdInnerShieldingBuilder::SetHoleRadialPosition(double holeRadialPosition)
    {
      if( mConfig == GeometryConfiguration::RicochetFinalDesign()) throw std::runtime_error("ERROR : SetHoleRadialPosition forbided by  GeometryConfiguration::RicochetFinalDesign ");
      if( mConfig == GeometryConfiguration::RicochetRUN014()) throw std::runtime_error("ERROR : SetHoleRadialPosition forbided by  GeometryConfiguration::RicochetRUN014 ");
       mHoleRadialPosition = holeRadialPosition;
    }

    double ColdInnerShieldingBuilder::Radius() const
    {
        return ((mLeadRadius > mPolyRadius) ? mLeadRadius : mPolyRadius);
    }

    double ColdInnerShieldingBuilder::LeadThickness() const
    {
        return mLeadThickness;
    }

    double ColdInnerShieldingBuilder::InnerShieldingConfig() const
    {
        return mInnerShieldingConfig;
    }

    double ColdInnerShieldingBuilder::PolyethyleneThickness() const
    {
        return mPolyThickness;
    }

    double ColdInnerShieldingBuilder::HoleRadialPosition() const
    {
        return mHoleRadialPosition;
    }

    double ColdInnerShieldingBuilder::HoleAngularSpacing() const
    {
        return mHoleAngularSpacing;
    }

    int ColdInnerShieldingBuilder::Verbosity() const
    {
        return mVerbosity;
    }

    double ColdInnerShieldingBuilder::TotalHeight() const
    {
        if(mUseCryoConceptInternalLead)
        {
            return  mPolyThickness + mLeadThickness + TotalCopperThickness();
        }
        else
        {
            return mPolyThickness + mLeadThickness;
        }
    }


    G4ThreeVector ColdInnerShieldingBuilder::PolyPosition() const
    {
          if(mUseCryoConceptInternalLead)
          {
              return {0, 0, - mLeadThickness - TotalCopperThickness() - mPolyThickness/2.};
          }
          else
          {
              return {0, 0, - mLeadThickness - mPolyThickness/2.};
          }
    }

    void ColdInnerShieldingBuilder::Build(const G4ThreeVector& position)
    {
        if(mVerbosity > 0) std::cout << "Build ColdInnerShielding geometry" << std::endl; 
        mPosition = position;
        // if(mVerbosity > 0) std::cout << "Build ColdInnerShielding geometry POSITION "<< mPosition << std::endl;
        std::cout << "Build ColdInnerShielding geometry POSITION "<< mPosition  << std::endl;
        

        VolumeAdder factory(mMother, mPosition);

        /// Volume origin = top center
	double holeRadius = 1.5*CLHEP::cm;

        //configuration options available: 0 (basic, not too sure which is basic), 1 (old 'realistic PE shield', the one that broke), 2 (newesrt shieding)
        std::cout << "You chose: " << InnerShieldingConfig() << std::endl;
        // if (InnerShieldingConfig() >= 2){ //new shielding
        // if(InnerShieldingConfig() <= -1) throw std::runtime_error("ERROR :Need to Set the config");

        if (InnerShieldingConfig() >= 2){ //new shielding
            if(mVerbosity > 0) std::cout << "You chose the new, Cooler B), *not broken* shielding: " << InnerShieldingConfig() << std::endl;
            // std::cout << "Geometry Currently under construction " << std::endl; 
            // std::cout<<".... Nothing to see here (；一_一)!....."<<std::endl;
            
            
            //===========Things needed for every layer:===========
            //Create a Rotation Matrix
            // G4RotationMatrix* rotmat = new G4RotationMatrix();
            // rotmat->rotateX(90*CLHEP::deg); //to make it flat
            // rotmat->rotateY(180*CLHEP::deg); //to flip it over 
            // rotmat->rotateZ(0*CLHEP::deg);
            //Material:
            // G4Material* CuMaterial = G4NistManager::Instance()->FindOrBuildMaterial("G4_Cu");
            // G4Material* layerMaterial = G4NistManager::Instance()->FindOrBuildMaterial("G4_POLYETHYLENE");
            //size of Copper Layers:
            G4double PEthickness = 27.5*CLHEP::mm;
            G4double CuRadius = 294*CLHEP::mm/2-1*CLHEP::mm;
            G4double CuLength = (PEthickness-1*CLHEP::mm)/2; //half of  the heght 
            G4double CuPlateLength = (10*CLHEP::mm); //half of  the heght 
            G4double CuPlateRadius = 294*CLHEP::mm/2;
            G4double CuPlateThickness = (10*CLHEP::mm); //half of  the heght 
            G4double CuSpacing = 0*CLHEP::mm;//plate spacing?


            //=====================================================

            //Lead Layers (same as old shielding)
            if(mVerbosity > 0) std::cout << "Constructing Lead: " << std::endl;
            //CryoConceptInternalLead:
            double leadradius = mLeadRadius;
            double leadThickness = mLeadThickness/2.;
            double leadcopperThickness = TotalCopperThickness()/3.;
            
            // 3 Copper cylinders with holes
            G4ThreeVector leadplatePosition = G4ThreeVector(0, 0, - leadcopperThickness/ 2.);

            if(mVerbosity > 0) std::cout << "Lead Radius: " << leadradius << " LeadCopperThickness: " << leadcopperThickness << " Lead Plate Pos: " << leadplatePosition << std::endl;
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_topCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);
            leadplatePosition.set(0, 0, - 1.5*leadcopperThickness - leadThickness );
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_centralCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);
            leadplatePosition.set(0, 0, - 2.5*leadcopperThickness - 2*leadThickness);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_bottomCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);

            // 2 Lead cylinders with holes
            leadplatePosition.set(0, 0, - leadcopperThickness - leadThickness/ 2.);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_topLead", mLeadMaterial, leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadThickness);
            leadplatePosition.set(0, 0, - 2*leadcopperThickness - 1.5*leadThickness);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_bottomLead", mLeadMaterial, leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadThickness);

            //Using functions created instead of doing it over and over-------------------------------
            //filenames
            //CC:
            auto couche3 = "/sps/ricochet/simulations/OBJFiles/couche3.obj";
            auto couche2 = "/sps/ricochet/simulations/OBJFiles/couche2.obj";
            auto couche4 = "/sps/ricochet/simulations/OBJFiles/couche4.obj";
            
            // local file paths:
            // auto couche3 = "/Users/faith/g4test/B1build/OBJFiles/couche3.obj";
            // auto couche2 = "/Users/faith/g4test/B1build/OBJFiles/couche2.obj";
            // auto couche4 = "/Users/faith/g4test/B1build/OBJFiles/couche4.obj";

            // auto couche3 = "../../build/OBJFiles/couche3.obj";
            // auto couche2 = "../../build/OBJFiles/couche2.obj"; ///pbs/home/f/freyes/Ricochet/Simulation/Geometry/OBJFiles/couche2.obj
            // auto couche4 = "../../build/OBJFiles/couche4.obj";
            auto deltaposition =  G4ThreeVector(0*CLHEP::mm, 0*CLHEP::mm, CuPlateThickness+PEthickness );
            //Layer1 
            auto posLayer1 =  G4ThreeVector(0*CLHEP::cm,0*CLHEP::cm , - 3*leadcopperThickness - 2*leadThickness - CuSpacing- 7*(PEthickness+CuPlateThickness)-PEthickness/2-6*CLHEP::mm);
            AddPEandCuPlate(mMother, mPosition, "lay1",posLayer1, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche3);
            // AddPEandCuPlate(mMother, mPosition, "lay1",posLayer1, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche3);
            if(mVerbosity > 0)  std::cout << "Layer 1 position "<< posLayer1  << std::endl;
            
            
            if(mVerbosity > 0) std::cout << "Layer1 added " << std::endl;

	    
            //Layer2
            auto posLayer2 = posLayer1+ deltaposition;
            
            AddPEandCuPlate(mMother, mPosition, "lay2",posLayer2, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche2);
            // AddPEandCuPlate(mMother, mPosition, "lay2",posLayer2, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche2);
            
            if(mVerbosity > 0) std::cout << "Layer2 added " << std::endl;
            
            //Layer3
            auto posLayer3 = posLayer2+ deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay3",posLayer3, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche3);
            // AddPEandCuPlate(mMother, mPosition, "lay3",posLayer3, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche3);

            if(mVerbosity > 0) std::cout << "Layer3 added " << std::endl;

            //Layer4
            auto posLayer4 = posLayer3+deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay4",posLayer4, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche4);
            // AddPEandCuPlate(mMother, mPosition, "lay4",posLayer4, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche4);

            if(mVerbosity > 0) std::cout << "Layer4 added " << std::endl;

            //Layer5
            auto posLayer5 = posLayer4+deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay5",posLayer5, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche3);
            // AddPEandCuPlate(mMother, mPosition, "lay5",posLayer5, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche3);

            if(mVerbosity > 0) std::cout << "Layer5 added " << std::endl;

            //Layer6
            auto posLayer6 = posLayer5+deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay6",posLayer6, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche4);
            // AddPEandCuPlate(mMother, mPosition, "lay6",posLayer6, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche4);

            if(mVerbosity > 0) std::cout << "Layer6 added " << std::endl;

            //Layer7
            auto posLayer7 = posLayer6+deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay7",posLayer7, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche3);
            // AddPEandCuPlate(mMother, mPosition, "lay7",posLayer7, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche3);

            if(mVerbosity > 0) std::cout << "Layer7 added " << std::endl;

            //Layer8
            auto posLayer8 = posLayer7+deltaposition;
            AddPEandCuPlate(mMother, mPosition, "lay8",posLayer8, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing,holeRadius, mHoleRadialPosition, mHoleAngularSpacing, couche4);
            // AddPEandCuPlate(mMother, mPosition, "lay8",posLayer8, CuPlateRadius,CuPlateLength, CuRadius, CuLength, CuSpacing, couche4);
            if(mVerbosity > 0) std::cout << "Layer8 added " << std::endl;

	    
            if(mVerbosity > 0) std::cout << "All Layers added " << std::endl;
            



            
        }
        else if (InnerShieldingConfig() >= 1){ //old broken shielding
            if(mVerbosity > 0) std::cout << "You have selected the Old, Broken Shielding: " << InnerShieldingConfig() << std::endl;

            if(mVerbosity > 0) std::cout << "Constructing Lead: " << std::endl;
            //CryoConceptInternalLead:
            double leadradius = mLeadRadius;
            double leadThickness = mLeadThickness/2.;
            double leadcopperThickness = TotalCopperThickness()/3.;
            
            // 3 Copper cylinders with holes
            G4ThreeVector leadplatePosition = G4ThreeVector(0, 0, - leadcopperThickness/ 2.);

            if(mVerbosity > 0) std::cout << "Lead Radius: " << leadradius << " LeadCopperThickness: " << leadcopperThickness << " Lead Plate Pos: " << leadplatePosition << std::endl;
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_topCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);
            leadplatePosition.set(0, 0, - 1.5*leadcopperThickness - leadThickness );
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_centralCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);
            leadplatePosition.set(0, 0, - 2.5*leadcopperThickness - 2*leadThickness);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_bottomCopper", "CopperInnerShielding", leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadcopperThickness);

            // 2 Lead cylinders with holes
            leadplatePosition.set(0, 0, - leadcopperThickness - leadThickness/ 2.);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_topLead", mLeadMaterial, leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadThickness);
            leadplatePosition.set(0, 0, - 2*leadcopperThickness - 1.5*leadThickness);
            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_bottomLead", mLeadMaterial, leadplatePosition, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, leadradius, leadThickness);

            if(mVerbosity > 0) std::cout << "Constructing Poly: " << std::endl;
            //RealisticPolyethylene:
            G4ThreeVector positionPoly = PolyPosition();
            unsigned int nbPolyLayers = mRealisticPoly_NbPolyLayers;
            unsigned int nbCopperLayers = nbPolyLayers + 1;

            double polyradius = mPolyRadius;
            double polycopperThickness = mRealisticPoly_CopperThickness;
            double polyThickness = (mPolyThickness - polycopperThickness * nbCopperLayers) / nbPolyLayers;

            

            G4ThreeVector polyplatePosition = PolyPosition() + G4ThreeVector(0, 0, mPolyThickness / 2. - polycopperThickness/ 2.);
            if(mVerbosity > 0) std::cout << "Poly Radius: " << polyradius << " PolyCopperThickness: " << polycopperThickness << " Poly Plate Pos: " << polyplatePosition << std::endl;

            AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_Poly_CopperLayer_0", "CopperInnerShielding", polyplatePosition , holeRadius, mHoleRadialPosition, mHoleAngularSpacing, polyradius, polycopperThickness);
            for(uint32_t iLayer = 0; iLayer < nbPolyLayers; ++iLayer)
            {
                polyplatePosition += G4ThreeVector(0, 0, - polycopperThickness/2. - polyThickness/2.);
                AddMultiHoleCylinder(mMother, mPosition, Form("ColdInnerShielding_Poly_PolyLayer_%ud", iLayer), mPolyMaterial, polyplatePosition , holeRadius, mHoleRadialPosition, mHoleAngularSpacing, polyradius, polyThickness);
                polyplatePosition += G4ThreeVector(0, 0, - polycopperThickness/2. - polyThickness/2.);
                AddMultiHoleCylinder(mMother, mPosition, Form("ColdInnerShielding_centralCopper_%ud", iLayer), "CopperInnerShielding", polyplatePosition , holeRadius, mHoleRadialPosition, mHoleAngularSpacing, polyradius, polycopperThickness);
            }

            
        }
       
        else{ //basic shielding
            if(mVerbosity > 0) std::cout << "You have chosen the basic shielding: " << InnerShieldingConfig() << std::endl;
            //basic lead
            if(mVerbosity > 0) std::cout << "Constructing Lead: " << std::endl;

            G4ThreeVector positionLead = G4ThreeVector(0, 0, -mLeadThickness / 2.);
            factory.Add<FilledTube>("ColdInnerShielding_Lead", mLeadMaterial, positionLead , mLeadRadius, mLeadThickness);

            //keep Poly Holes option 
            G4ThreeVector positionPoly = PolyPosition();
            if(mPolyWithHoles)
            {
                if(mVerbosity > 0) std::cout << "Constructing Poly with Holes: " << std::endl;
                AddMultiHoleCylinder(mMother, mPosition, "ColdInnerShielding_Poly", mPolyMaterial, positionPoly, holeRadius, mHoleRadialPosition, mHoleAngularSpacing, mPolyRadius, mPolyThickness);
            }
            else //this seems to be the most basic thing there is 
            {
                if(mVerbosity > 0) std::cout << "Constructing Basic poly: " << std::endl;
                factory.Add<FilledTube>("ColdInnerShielding_Poly", mPolyMaterial, positionPoly, mPolyRadius, mPolyThickness);
            }
        }

        //


        



        if(mVerbosity > 0) std::cout << "ColdInnerShielding constructed" << std::endl;
    }

    void ColdInnerShieldingBuilder::Write(TDirectory& directory) const
    {
        InfoHeaderWriter writer("ColdInnerShielding", "Geometry::ColdInnerShieldingBuilder");
        writer.SetKeyValue("Position_X", mPosition.x());
        writer.SetKeyValue("Position_Y", mPosition.y());
        writer.SetKeyValue("Position_Z", mPosition.z());
        writer.SetKeyValue("LeadRadius", mLeadRadius);
        writer.SetKeyValue("LeadThickness", mLeadThickness);
        writer.SetKeyValue("PolyRadius", mPolyRadius);
        writer.SetKeyValue("PolyThickness", mPolyThickness);
        writer.WriteIn(directory);
    }
}
