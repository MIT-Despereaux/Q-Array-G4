#include "Geometry/MaterialColour.hh"
#include "G4LogicalVolume.hh"
#include "G4VisAttributes.hh"

namespace Geometry
{
    G4Colour GetMaterialColour(const std::string& material)
    {
        G4Colour colour;
        G4Colour::GetColour(material, colour);
        return colour;
    }

    void SetColourFromMaterial(G4LogicalVolume* volume, const std::string& material)
    {
        SetColourFromMaterial(*volume, material);
    }

    void SetColourFromMaterial(G4LogicalVolume& volume, const std::string& material)
    {
        auto visualAttributes= new G4VisAttributes(Geometry::GetMaterialColour(material));
        visualAttributes->SetVisibility(true);
        volume.SetVisAttributes(visualAttributes);
    }

}
