#include "Geometry/Shapes.hh"

namespace Geometry
{

    FilledCube::FilledCube(const G4String& name, double size)
    :G4Box(name, .5*size, .5*size, .5*size)
    { }

    FilledBox::FilledBox(const G4String& name, double length, double depth, double height)
    :G4Box(name, .5*length, .5*depth, .5*height)
    { }


    FilledBox::FilledBox(double length, double depth, double height)
    :FilledBox("", length, depth, height)
    { }

    Wall::Wall(const G4String& name, double length, double height, double thickness)
    :FilledBox(name, length, thickness, height)
    { }

    Box::Box(const G4String& name, double innerLength, double outerLength, double innerDepth, double outerDepth, double innerHeight, double outerHeight)
    :G4SubtractionSolid(name,
            new FilledBox{outerLength, outerDepth, outerHeight},
            new FilledBox{innerLength, innerDepth, innerHeight})
    {}

    constexpr double Box::OuterSize(double size, double thickness)
    {
        return size + 2 *thickness;
    }

    SameThicknessBox::SameThicknessBox(const G4String& name, double innerLength, double innerDepth, double innerHeight, double thickness)
    :Box(name,
            innerLength, Box::OuterSize(innerLength, thickness),
            innerDepth, Box::OuterSize(innerDepth, thickness),
            innerHeight, Box::OuterSize(innerHeight, thickness)
        )
    {}

    SameThicknessHollowBox::SameThicknessHollowBox(const G4String& name, double innerLength, double innerDepth, double height, double thickness)
    :Box(name,
            innerLength, Box::OuterSize(innerLength, thickness),
            innerDepth, Box::OuterSize(innerDepth, thickness),
            height, height
        )
    {}

    Tube::Tube(const G4String& name, double innerRadius, double outerRadius, double height)
    :G4Tubs(name, innerRadius, outerRadius, .5*height, 0., CLHEP::twopi)
    { }

    FilledTube::FilledTube(const G4String& name, double outerRadius, double height)
    :Tube(name, 0., outerRadius, height)
    { }

    FilledTube::FilledTube(double outerRadius, double height)
    :FilledTube("", outerRadius, height)
    { }

    /// origin position : inner bottom center
    Bucket::Bucket(const G4String& name, double innerRadius, double thickness, double height)
    : G4Polycone(Build(name, innerRadius, thickness, height))
    { }

    G4Polycone Bucket::Build(const G4String& name, double innerRadius, double thickness, double height)
    {
        double z[] = {-thickness, 0., 0., height};
        double ri[] = {0., 0., innerRadius, innerRadius};
        double ro[] = {innerRadius + thickness, innerRadius + thickness, innerRadius + thickness, innerRadius + thickness};
        return G4Polycone(name, 0., CLHEP::twopi, 4, z, ri, ro);
    }

    /// origin position : inner upper center
    ReversedBucket::ReversedBucket(const G4String& name, double innerRadius, double thickness, double height)
    : G4Polycone(Build(name, innerRadius, thickness, height))
    {
    }

    G4Polycone ReversedBucket::Build(const G4String& name, double innerRadius, double thickness, double height)
    {
        double z[] = {-height, 0., 0., thickness};
        double ri[] = {innerRadius, innerRadius, 0., 0.};
        double ro[] = {innerRadius + thickness, innerRadius + thickness, innerRadius + thickness, innerRadius + thickness};
        return G4Polycone(name, 0., CLHEP::twopi, 4, z, ri, ro);
    }

    Cylinder::Cylinder(const G4String& name, double innerRadius, double outerRadius, double innerHeight, double outerHeight)
    :G4SubtractionSolid(name, new FilledTube{outerRadius, outerHeight}, new FilledTube{innerRadius, innerHeight})
    { }

    SameThicknessCylinder::SameThicknessCylinder(const G4String& name, double innerRadius, double outerRadius, double outerHeight)
    :Cylinder(name, innerRadius, outerRadius, InnerHeight(innerRadius, outerRadius, outerHeight), outerHeight)
    { }

    constexpr double SameThicknessCylinder::InnerHeight(double innerRadius, double outerRadius, double outerHeight)
    {
        auto thickness = outerRadius - innerRadius;
        return outerHeight - 2. * thickness;
    }

}
