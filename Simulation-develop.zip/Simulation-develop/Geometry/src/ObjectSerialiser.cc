#include "TDirectory.h"
#include "TTree.h"
#include "SimuOutput/InfoHeaderWriter.hh"
#include "Geometry/ObjectSerialiser.hh"
#include "Geometry/CryoCubeBuilder.hh"
#include "Geometry/MiniCryoCubeBuilder.hh"
#include "Geometry/GenericCryostatBuilder.hh"
#include "Geometry/CylindricalShieldingBuilder.hh"
#include "Geometry/ColdInnerShieldingBuilder.hh"
#include "Geometry/RingInnerShieldingBuilder.hh"
#include "Geometry/OuterShieldingBuilder.hh"
#include "Geometry/OuterShieldingBuilderWithDT.hh"
#include "Geometry/RicochetBasicBuilder.hh"
#include "Geometry/DubnaSpectrometerBuilder.hh"

namespace Geometry{

    ObjectSerialiser::ObjectSerialiser(TDirectory& output_):output(output_){

    }

    void ObjectSerialiser::Serialise(const SensitiveCryoCubeBuilder& builder){

        ROOTWrite(builder, output);

    }

    void ObjectSerialiser::Serialise(const SensitiveMiniCryoCubeBuilder& builder){

        ROOTWrite(builder, output);

    }

    void ObjectSerialiser::Serialise(const ActiveGenericCryostatBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const ActiveCylindricalShieldingBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const ActiveColdInnerShieldingBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const ActiveRingInnerShieldingBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const ActiveOuterShieldingBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const ActiveOuterShieldingBuilderWithDT& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const SensitiveRicochetBasicBuilder& builder){

        builder.Write(output);

    }

    void ObjectSerialiser::Serialise(const SensitiveDubnaSpectrometerBuilder& builder)
    {
        InfoHeaderWriter header("DubnaSpectrometer", "DubnaSpectrometer info");
        header.SetKeyValue("CavityMass", builder.CavityMass() / CLHEP::kg);
        header.SetKeyValue("CavityVolume", builder.CavityVolume() / CLHEP::m3);
        header.WriteIn(output);
    }

}
