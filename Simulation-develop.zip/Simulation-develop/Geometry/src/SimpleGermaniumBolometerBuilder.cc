/*
 * simplegermaniumbolometerbuilder.cc
 *
 *  Created on: 18.02.2022
 *  geometry of the germanium bolometer + simple  casing.
 *      Author: cazes
 */

#include "Geometry/SimpleGermaniumBolometerBuilder.hh"
#include "Geometry/Shapes.hh"
#include "Geometry/MaterialsBuilder.hh"
#include "Geometry/MaterialColour.hh"


#include "G4Polycone.hh"
#include "G4Orb.hh"
#include "G4SDManager.hh"
#include "G4NistManager.hh"





namespace Geometry {

  // dimensions
  /////////////


    double SimpleGermaniumBolometerBuilder::CrystalRadius() const{

        return 15 * CLHEP::mm;

    }
    double SimpleGermaniumBolometerBuilder::CrystalHeight() const{

        return 10 * CLHEP::mm;

    }

    double SimpleGermaniumBolometerBuilder::SupportThickness() const{

      return 6.*CLHEP::mm;

    }

    double SimpleGermaniumBolometerBuilder::SupportTopThickness() const{

      return 2.*CLHEP::mm;

    }

    double SimpleGermaniumBolometerBuilder::SupportOutRadius() const{

     return CrystalRadius() + SupportSpace() + SupportThickness();

    }

    double SimpleGermaniumBolometerBuilder::SupportSpace() const{

      return 3.*CLHEP::mm;

    }

    double SimpleGermaniumBolometerBuilder::SupportHeight() const{

      return CrystalHeight() + 2.*SupportSpace() + SupportThickness() + SupportTopThickness();

    }

    double SimpleGermaniumBolometerBuilder::GetCrystalVolume() const{

        return CLHEP::pi*std::pow(CrystalRadius(), 2) * CrystalHeight();

    }

    double SimpleGermaniumBolometerBuilder::GetCrystalMass() const{

        return GetCrystalVolume() * G4Material::GetMaterial("Germanium")->GetDensity();

    }


    double SimpleGermaniumBolometerBuilder::GetBolometerFullHight()
    {
        return SupportHeight();
    }


  // main builder
  ///////////////

  std::vector<G4LogicalVolume*>  SimpleGermaniumBolometerBuilder::Build(HepGeom::Transform3D transformation)  {


   if(bolometerAssembly == nullptr) {
      bolometerAssembly = new G4AssemblyVolume();


      // Crystal geometry

      solidBolo = new FilledTube("CrystalBolo", CrystalRadius(), CrystalHeight());
      logicBolo = new G4LogicalVolume(solidBolo, G4Material::GetMaterial("Germanium"), "CrystalBolo");
      SetColourFromMaterial(logicBolo, "Germanium");

      G4ThreeVector position(0.,0.,0.);
      bolometerAssembly->AddPlacedVolume(logicBolo, position, nullptr);

      
      // Support geometry

      constexpr std::size_t nEdges = 6;

      std::array<double, nEdges> zSupport;
      zSupport[0] = -SupportHeight()*.5;
      zSupport[1] = -SupportHeight()*.5 + SupportThickness();
      zSupport[2] = -SupportHeight()*.5 + SupportThickness();
      zSupport[3] = SupportHeight()*.5 - SupportTopThickness();
      zSupport[4] = SupportHeight()*.5 - SupportTopThickness();
      zSupport[5] = SupportHeight()*.5;

      std::array<double, nEdges> riSupport;
      riSupport[0] = 0.;
      riSupport[1] = 0.;
      riSupport[2] = SupportOutRadius() - SupportThickness();
      riSupport[3] = SupportOutRadius() - SupportThickness();
      riSupport[4] = 0.;
      riSupport[5] = 0.;

      std::array<double, nEdges> roSupport;
      std::fill(std::begin(roSupport), std::end(roSupport), SupportOutRadius());

      auto solidSupport = new G4Polycone("solidSupport", 0., CLHEP::twopi, nEdges, zSupport.data(), riSupport.data(), roSupport.data());
      auto logicSupport = new G4LogicalVolume(solidSupport, G4Material::GetMaterial("CopperSupport"), "Support");

      SetColourFromMaterial(logicSupport, "CopperSupport");


      position.setZ( -(SupportThickness() - SupportTopThickness())/2.);
      bolometerAssembly->AddPlacedVolume(logicSupport, position, nullptr);

   }

   bolometerAssembly->MakeImprint(&mother,transformation);
   return {logicBolo};

  }

} // namespace
