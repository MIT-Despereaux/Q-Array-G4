#include "Geometry/CylindricalShieldingMessenger.hh"

/// Standard includes
#include <sstream>

/// Project includes
#include "G4Helpers/TransformationParser.hh"

namespace Geometry
{

CylindricalShieldingMessenger::CylindricalShieldingMessenger(BuilderType& builder) :
    mBuilder(builder)
{
    const std::string path = "/geometry/shielding/cylindrical/";

    mCmdBuild.reset(new G4UIcmdWithAString((path + "build").c_str(), this));
    mCmdBuild->SetGuidance("Build cylindrical shielding.");
    mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

    mCmdInitialHeight.reset(new G4UIcmdWithADoubleAndUnit((path + "setInitialHeight").c_str(), this));
    mCmdInitialHeight->SetGuidance("Set initial height (first layer)");
    mCmdInitialHeight->AvailableForStates(G4State_PreInit, G4State_Idle);

    mCmdInitialInnerRadius.reset(new G4UIcmdWithADoubleAndUnit((path + "setInitialInnerRadius").c_str(), this));
    mCmdInitialInnerRadius->SetGuidance("Set initial inner radius (first layer)");
    mCmdInitialInnerRadius->AvailableForStates(G4State_PreInit, G4State_Idle);

    mCmdAddLayer.reset(new G4UIcommand((path + "addLayer").c_str(), this));
    mCmdAddLayer->SetGuidance("Args: <material> <thickness> <unit>. Add new shielding layer (full coverage) above previous layer");
    mCmdAddLayer->AvailableForStates(G4State_PreInit, G4State_Idle);

    mPrmLayerMaterial = new G4UIparameter("material",'s',false);
    mPrmLayerMaterial->SetGuidance("Layer material name");
    mCmdAddLayer->SetParameter(mPrmLayerMaterial);

    mPrmLayerThickness = new G4UIparameter("thickness",'d',false);
    mPrmLayerThickness->SetGuidance("Layer thickness");
    mPrmLayerThickness->SetParameterRange("thickness > 0.");
    mCmdAddLayer->SetParameter(mPrmLayerThickness);

    mPrmLayerUnit = new G4UIparameter("unit",'s',false);
    mPrmLayerUnit->SetGuidance("Layer thickness unit");
    mPrmLayerUnit->SetParameterCandidates(G4UIcommand::UnitsList(G4UIcommand::CategoryOf("cm")));
    mCmdAddLayer->SetParameter(mPrmLayerUnit);

}

void CylindricalShieldingMessenger::SetNewValue(G4UIcommand* cmd, G4String args)
{
    if(cmd == mCmdBuild.get()) mBuilder.Build(G4Helpers::TransformationParser::Parse(args));
    else if(cmd == mCmdInitialHeight.get()) mBuilder.SetInitialHeight(G4UIcommand::ConvertToDimensionedDouble(args));
    else if(cmd == mCmdInitialInnerRadius.get()) mBuilder.SetInitialInnerRadius(G4UIcommand::ConvertToDimensionedDouble(args));
    else if(cmd == mCmdAddLayer.get())
    {
        std::string material;
        double thickness;
        std::string unit;

        std::stringstream ss(args);
        ss >> material >> thickness >> unit;

        thickness *= G4UIcommand::ValueOf(unit.c_str());
        mBuilder.AddLayer(thickness, material);
    }
}

}
