#include "Geometry/ColdInnerShieldingMessenger.hh"

/// Geant4 includes
#include "G4Tokenizer.hh"

/// Project includes
#include "Geometry/ColdInnerShieldingBuilder.hh"

namespace Geometry
{
    ColdInnerShieldingMessenger::ColdInnerShieldingMessenger(BuilderType& builder, std::string cmdPrefixPath) : mBuilder(builder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("ColdInnerShielding command directory");

        mCmdBuild.reset(new G4UIcmdWith3VectorAndUnit((cmdPrefixPath + "build").c_str(), this));
        mCmdBuild->SetGuidance("Build cylindrical shielding to place inside cryostat");
        mCmdBuild->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "setVerbosity").c_str(), this));
        mCmdVerbose->SetGuidance("Set verbosity level");
        mCmdVerbose->SetParameterName("val",false);
        mCmdVerbose->SetRange("val>=0");
        mCmdVerbose->AvailableForStates(G4State_Idle);

        //copied from RicochetBasicMessenger.cc, set config command
        mCmdColdInnerShieldingConfig.reset(new G4UIcmdWithADouble((cmdPrefixPath + "setConfig").c_str(), this));
        mCmdColdInnerShieldingConfig->SetGuidance("Set Cold Inner Shielding config");
        mCmdColdInnerShieldingConfig->AvailableForStates(G4State_Idle);
        

        mCmdUseCryoConceptInternalLead.reset(new G4UIcmdWithABool((cmdPrefixPath + "BuildCryoConceptInnerLeadShielding").c_str(), this));
        mCmdUseCryoConceptInternalLead->SetGuidance("Build cryoconcept inner lead shielding");
        mCmdUseCryoConceptInternalLead->AvailableForStates(G4State_Idle);

        mCmdPolyethyleneWithHoles.reset(new G4UIcmdWithABool((cmdPrefixPath + "PolyethyleneWithHoles").c_str(), this));
        mCmdPolyethyleneWithHoles->SetGuidance("Add holes in inner polyethylene shielding made to allow detector cabling");
        mCmdPolyethyleneWithHoles->AvailableForStates(G4State_Idle);

        mCmdRadius.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setRadius").c_str(), this));
        mCmdRadius->SetGuidance("Set lead and poly shielding radii, arg = XXX unit (ex: 3 cm)");
        mCmdRadius->SetUnitCategory("Length");
        mCmdRadius->AvailableForStates(G4State_Idle);

        mCmdLeadRadius.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setLeadRadius").c_str(), this));
        mCmdLeadRadius->SetGuidance("Set lead shielding radius, arg = XXX unit (ex: 3 cm)");
        mCmdLeadRadius->SetUnitCategory("Length");
        mCmdLeadRadius->AvailableForStates(G4State_Idle);

        mCmdLeadThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setLeadThickness").c_str(), this));
        mCmdLeadThickness->SetGuidance("Set lead layer thickness, arg = XXX unit (ex: 3 cm)");
        mCmdLeadThickness->AvailableForStates(G4State_Idle);

        mCmdPolyRadius.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setPolyRadius").c_str(), this));
        mCmdPolyRadius->SetGuidance("Set poly shielding radius, arg = XXX unit (ex: 3 cm)");
        mCmdPolyRadius->SetUnitCategory("Length");
        mCmdPolyRadius->AvailableForStates(G4State_Idle);

        mCmdPolyethyleneThickness.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setPolyethyleneThickness").c_str(), this));
        mCmdPolyethyleneThickness->SetGuidance("Set polyethylene layer thickness, arg = XXX unit (ex: 3 cm)");
        mCmdPolyethyleneThickness->AvailableForStates(G4State_Idle);

        mCmdBuildRealisticPolyShielding.reset(new G4UIcommand((cmdPrefixPath + "buildRealistucPolyShielding").c_str(), this));
        mCmdBuildRealisticPolyShielding->SetGuidance("Build inner polyethylene shielding made of PE/Cu layers");
        mCmdBuildRealisticPolyShielding->SetParameter(new G4UIparameter("build", 'b', false));
        mCmdBuildRealisticPolyShielding->SetParameter(new G4UIparameter("nbPolyLayers", 'i', false));
        mCmdBuildRealisticPolyShielding->SetParameter(new G4UIparameter("copperThickness", 'd', false));
        G4UIparameter* parUnit = new G4UIparameter("copperThickness_unit", 's', false);
        parUnit->SetParameterCandidates(G4UIcommand::UnitsList(G4UIcommand::CategoryOf("m")));
        mCmdBuildRealisticPolyShielding->SetParameter(parUnit);
        mCmdBuildRealisticPolyShielding->SetRange("nbPolyLayers > 0");
        mCmdBuildRealisticPolyShielding->SetRange("copperThickness >= 0");
        mCmdBuildRealisticPolyShielding->AvailableForStates(G4State_Idle);

        mCmdLeadMaterial.reset(new G4UIcmdWithAString((cmdPrefixPath + "setLeadMaterial").c_str(), this));
        mCmdLeadMaterial->SetGuidance("Set lead layer material, can even be replaced with other material than lead");
        mCmdLeadMaterial->AvailableForStates(G4State_Idle);

        mCmdPolyMaterial.reset(new G4UIcmdWithAString((cmdPrefixPath + "setPolyMaterial").c_str(), this));
        mCmdPolyMaterial->SetGuidance("Set polyethylene layer material, can even be replaced with other material than poly");
        mCmdPolyMaterial->AvailableForStates(G4State_Idle);

        mCmdHoleRadialPosition.reset(new G4UIcmdWithADoubleAndUnit((cmdPrefixPath + "setHoleRadialPosition").c_str(), this));
        mCmdHoleRadialPosition->SetGuidance("Set radial position of holes, arg = XXX unit (ex: 3 cm)");
        mCmdHoleRadialPosition->SetUnitCategory("Length");
        mCmdHoleRadialPosition->AvailableForStates(G4State_Idle);
    }

    void ColdInnerShieldingMessenger::SetNewValue(G4UIcommand* command, G4String valueStr)
    {
        if(command == mCmdBuild.get())
        {
            mBuilder.Build(G4UIcommand::ConvertToDimensioned3Vector(valueStr));
        }
        else if(command == mCmdVerbose.get())
        {
            mBuilder.SetVerbosity(mCmdVerbose->GetNewIntValue(valueStr));
        }
        else if(command == mCmdUseCryoConceptInternalLead.get())
        {
            mBuilder.SetUseCryoConceptInternalLead(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdPolyethyleneWithHoles.get())
        {
            mBuilder.SetPolyethyleneWithHoles(G4UIcommand::ConvertToBool(valueStr));
        }
        else if(command == mCmdRadius.get())
        {
            mBuilder.SetRadius(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdLeadRadius.get())
        {
            mBuilder.SetLeadRadius(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdLeadThickness.get())
        {
            mBuilder.SetLeadThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdPolyRadius.get())
        {
            mBuilder.SetPolyRadius(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdPolyethyleneThickness.get())
        {
            mBuilder.SetPolyethyleneThickness(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
        else if(command == mCmdBuildRealisticPolyShielding.get())
        {
            G4Tokenizer next(valueStr);
            double build = StoB(next());
            double nbPolyLayers = StoI(next());
            double copperThickness = StoD(next());
            std::string unit = next();
            copperThickness *= G4UIcommand::ValueOf(unit.c_str());

            mBuilder.BuildRealisticPolyShield(build);
            mBuilder.SetParamRealisticPolyShield(nbPolyLayers, copperThickness);
        }
        else if(command == mCmdLeadMaterial.get())
        {
            mBuilder.SetLeadMaterial(valueStr);
        }
        //copied from RicochetBasicMessenger.cc
        else if(command == mCmdColdInnerShieldingConfig.get())
        {
            mBuilder.SetColdInnerShieldingConfig(G4UIcommand::ConvertToDouble(valueStr));
            // std::cout << "Macro value:" << G4UIcommand::ConvertToDouble(valueStr) << std::endl;
        }
        else if(command == mCmdPolyMaterial.get())
        {
            mBuilder.SetPolyethyleneMaterial(valueStr);
        }
        else if(command == mCmdHoleRadialPosition.get())
        {
            mBuilder.SetHoleRadialPosition(G4UIcommand::ConvertToDimensionedDouble(valueStr));
        }
    }
}


