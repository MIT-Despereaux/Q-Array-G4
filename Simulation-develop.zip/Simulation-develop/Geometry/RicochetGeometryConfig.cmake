include(CMakeFindDependencyMacro)

find_dependency(ROOT 6.14 REQUIRED COMPONENTS tree)
find_dependency(Geant4 REQUIRED)
find_dependency(RicochetG4Helpers REQUIRED)
find_dependency(RicochetSimuOutput REQUIRED)

if(NOT TARGET Ricochet::Geometry)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetGeometryTargets.cmake")
endif()
