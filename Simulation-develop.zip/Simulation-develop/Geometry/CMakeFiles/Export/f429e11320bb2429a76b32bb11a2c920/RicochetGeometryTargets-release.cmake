#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::Geometry" for configuration "Release"
set_property(TARGET Ricochet::Geometry APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::Geometry PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetGeometry.so"
  IMPORTED_SONAME_RELEASE "libRicochetGeometry.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::Geometry )
list(APPEND _cmake_import_check_files_for_Ricochet::Geometry "${_IMPORT_PREFIX}/lib64/libRicochetGeometry.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
