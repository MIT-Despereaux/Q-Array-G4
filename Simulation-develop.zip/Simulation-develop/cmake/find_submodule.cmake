#----------------------------------------------------------------------------
# Find module as package if already installed or use local directory
function(find_submodule MODULE_NAME MODULE_DIRECTORY)
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/${MODULE_DIRECTORY}/CMakeLists.txt")
        add_subdirectory(${MODULE_DIRECTORY})
    else()
        find_package(${MODULE_NAME} CONFIG REQUIRED)
    endif()
endfunction()
