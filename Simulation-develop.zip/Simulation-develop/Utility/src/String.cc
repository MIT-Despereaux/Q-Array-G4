#include "Utility/String.hh"
#include <regex>

namespace Utility
{

    bool StartsWith(const std::string& string, const char* prefix)
    {
        //search for prefix from begining until position 0 (i.e. no performance loss)
        //return of rfind must be at position 0
        return string.rfind(prefix, 0) == 0;
    }

    std::vector<std::string> Split(const std::string& string, const char* delimiter)
    {
        std::regex regex{delimiter};
        std::sregex_token_iterator it{std::cbegin(string), std::cend(string), regex, -1};
        return std::vector<std::string>{it, {}};
    }

}
