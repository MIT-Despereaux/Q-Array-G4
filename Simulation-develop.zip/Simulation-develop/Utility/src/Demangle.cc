#include "Utility/Demangle.hh"

#ifdef __GNUC__
#include <memory>
#include <cxxabi.h>
#endif

namespace Utility
{

    std::string Demangle(const char* name)
    {
#ifdef __GNUC__
        int status = -1;
        std::unique_ptr<char, void (*)(void*)> chars{abi::__cxa_demangle(name, NULL, NULL, &status), std::free};
        return (status == 0) ? chars.get() : name;
#else
        return name;
#endif
    }

}
