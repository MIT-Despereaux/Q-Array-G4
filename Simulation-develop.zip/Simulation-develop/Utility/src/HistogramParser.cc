#include "Utility/HistogramParser.hh"

namespace Utility
{

namespace HistogramParser{

    std::map<double, double> ParseAsciiSpectrum(const std::string& fileName);
    TH1D BuildHistogram(const std::string& fileName);

}

}
