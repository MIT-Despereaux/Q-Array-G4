/**************************************************************************
* @file String.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 18 Sep 2020
* @brief String functions
* ************************************************************************/

#ifndef RICOCHET_UTILITY_STRING
#define RICOCHET_UTILITY_STRING

#include <string>
#include <vector>

namespace Utility
{

    //check wether 'string' starts with 'prefix'
    bool StartsWith(const std::string& string, const char* prefix);

    //split 'string' using regex 'delimiter'
    std::vector<std::string> Split(const std::string& string, const char* delimiter);

}

#endif /* RICOCHET_UTILITY_STRING */
