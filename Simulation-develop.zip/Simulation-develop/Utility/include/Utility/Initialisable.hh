/**************************************************************************
* @file Initialisable.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 14 Oct 2019
* @brief Have your class MyClass Inherit from Initialise<MyClass> and
* implement InitialiseAction to benefit from caching with MarkUninitialised
* in your setters and Initialise calls before any usage
* ************************************************************************/

#ifndef UTILITY_INITIALISABLE_HH
#define UTILITY_INITIALISABLE_HH

namespace Utility
{

    template <class Class>
    class Initialisable
    {
        bool initialised{false};
        Class& Derived();
        void MarkInitialised();
        bool IsInitialised();
        bool IsUninitialised();
        Initialisable(const Initialisable<Class>&) = default;
        Initialisable(Initialisable<Class>&&) = default;
        Initialisable<Class>& operator=(const Initialisable<Class>&) = default;
        Initialisable<Class>& operator=(Initialisable<Class>&&) = default;
    protected:
        ~Initialisable() = default;//must not be used as pointer to Initialisable
    public:
        Initialisable() = default;
        void Initialise();
        void MarkUninitialised();
    };

    template <class Class>
    Class& Initialisable<Class>::Derived()
    {
        return static_cast<Class&>(*this);
    }

    template <class Class>
    void Initialisable<Class>::MarkInitialised()
    {
        initialised = true;
    }

    template <class Class>
    bool Initialisable<Class>::IsInitialised()
    {
        return initialised;
    }

    template <class Class>
    bool Initialisable<Class>::IsUninitialised()
    {
        return !IsInitialised();
    }


    template <class Class>
    void Initialisable<Class>::MarkUninitialised()
    {
        initialised = false;
    }

    template <class Class>
    void Initialisable<Class>::Initialise()
    {
        if(IsUninitialised())
        {
            Derived().InitialiseAction();
            MarkInitialised();
        }
    }

}

#endif /* UTILITY_INITIALISABLE_HH */
