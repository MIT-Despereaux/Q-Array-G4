/**************************************************************************
* @file HistogramParser.hh
* @author Alexander Leder / Adam Anderson / Valérian Sibille
* @date 10 Oct 2019
* @brief Adapted from old ChoozSimulation
* ************************************************************************/

#ifndef UTILITY_HISTOGRAMPARSER_HH
#define UTILITY_HISTOGRAMPARSER_HH

#include <map>
#include <fstream>
#include "Utility/Maths.hh"
#include "TH1D.h"

namespace Utility
{

namespace HistogramParser{

    std::map<double, double> ParseAsciiSpectrum(const std::string& fileName){

        std::map<double, double> spectrum;
        double energy, value;

        {
            std::ifstream DataFile(fileName);
            if(!DataFile) throw std::runtime_error("Could not open '"+fileName+"'!");
            while(DataFile >> energy >> value) spectrum[energy] = value;

        }

        return spectrum;

    }

    TH1D BuildHistogram(const std::string& fileName) {

        auto data = ParseAsciiSpectrum(fileName);

        if(!data.empty()){

            TH1D histogram("histogram", "histogram", data.size(), data.begin()->first, data.rbegin()->first);
            for(int k = 0; k < histogram.GetNbinsX(); ++k)
                histogram.SetBinContent(k+1, Maths::Interpolate(data, histogram.GetBinCenter(k+1)));
            return histogram;

        }
        else throw std::runtime_error("Empty spectrum in '"+fileName+"'");

    }

}

}

#endif /* UTILITY_HISTOGRAMPARSER_HH */
