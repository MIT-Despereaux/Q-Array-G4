/**************************************************************************
* @file Demangle.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 23 Sep 2020
* @brief Demangle typenames
* ************************************************************************/

#ifndef UTILITY_DEMANGLE_HH
#define UTILITY_DEMANGLE_HH

#include <string>
#include <typeinfo>

namespace Utility
{

    std::string Demangle(const char* name);

    template <class T>
    std::string Demangle()
    {
        return Demangle(typeid(T).name());
    }

    template <typename T>
    std::string Demangle(const T&)
    {
        return Demangle<T>();
    }

}

#endif /* UTILITY_DEMANGLE_HH */
