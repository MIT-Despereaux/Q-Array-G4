/**************************************************************************
* @file Maths.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 23 Sep 2019
* @brief Math helpers
* ************************************************************************/

#ifndef UTILITY_MATHS_HH
#define UTILITY_MATHS_HH

#include <map>

namespace Utility
{

namespace Maths{

    template <class T, class K>
    K Interpolate(const std::map<T,K>& map, T x){

        auto itUpper = map.upper_bound(x);

        if(itUpper == map.end()) return (--itUpper)->second;
        else if(itUpper == map.begin()) return itUpper->second;
        else{

            auto itLower = itUpper;
            --itLower;
            auto slope = (itUpper->second - itLower->second) / (itUpper->first - itLower->first);
            return itLower->second + slope * (x - itLower->first);//y1 + (x - x1) (y2 - y1) / (x2 - x1)

        }

    }

}

}

#endif /* UTILITY_MATHS_HH */
