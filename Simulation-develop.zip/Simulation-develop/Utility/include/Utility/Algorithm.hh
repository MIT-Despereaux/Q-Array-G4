/**************************************************************************
* @file Algorithm.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 22 May 2019
* @brief Missing algorithms from C++17
* ************************************************************************/

#ifndef UTILITY_ALGORITHM_HH
#define UTILITY_ALGORITHM_HH

#include <tuple>

namespace Utility{

    namespace Detail{

        template <std::size_t ...Is, class Tuple, class Functor>
        void Execute(std::index_sequence<Is...>, Tuple&& tuple, Functor&& functor)
        {
            auto zero_integer_list = {(functor(std::get<Is>(std::forward<Tuple>(tuple))), 0)...};
            (void) zero_integer_list; // list forces functor call order; 0 replaces functor return to deduce int list
        }

        template <std::size_t Size, class Tuple, class Functor>
        void Execute(Tuple&& tuple, Functor&& functor)
        {
            Execute(std::make_index_sequence<Size>(), std::forward<Tuple>(tuple), std::forward<Functor>(functor));
        }

    }

    template <class Tuple, class Functor>
    void ForEach(Tuple&& tuple, Functor&& functor)
    {
        Detail::Execute<std::tuple_size<std::remove_reference_t<Tuple>>{}>(std::forward<Tuple>(tuple), std::forward<Functor>(functor));

    }

}

#endif /* UTILITY_ALGORITHM_HH */
