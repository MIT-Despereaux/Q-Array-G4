include(CMakeFindDependencyMacro)

find_dependency(ROOT REQUIRED COMPONENTS Hist)

if(NOT TARGET Ricochet::Utility)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetUtilityTargets.cmake")
endif()

