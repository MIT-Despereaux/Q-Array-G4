#ifndef ILLTreeContainer_hh
#define ILLTreeContainer_hh

#include "TChain.h"
#include "TChainElement.h"
#include "TFile.h"
#include "TVector3.h"
#include "TRotation.h"
#include "TRotMatrix.h"
#include "G4ThreeVector.hh"
#include "ROOTHelpers/Comparisons.hh"
#include "Utility/Initialisable.hh"

class ILLTreeContainer : public Utility::Initialisable<ILLTreeContainer> {

    friend Utility::Initialisable<ILLTreeContainer>;
public :

    //dumb values to allow construction without arguments due to later initialisation
    //being mandated by Geant4's messengers
  ILLTreeContainer(const std::string& inputFilePathPattern, const CLHEP::Hep3Vector& STEREOCentre);
  ~ILLTreeContainer();

  // setters
  void SetInputFilePattern(const std::string& inputFilePathPattern);
  void SetSTEREOCentre(const CLHEP::Hep3Vector& STEREOCentre);

  double GetNbGeneratedEvent() const;
  double GetSurfaceTirage() const;
  double GetSimulatedTime() const;
  TVector3 GetTranslation() const;
  TRotMatrix GetRotation() const;
  TVector3 GetStereoZoneHalf() const;

  // getters
  int GetEvtID() const { return evtID; }
  double GetTime() const { return time;}
  float GetX() const { return  Xinc[0]; }
  float GetY () const { return  Xinc[1]; }
  float GetZ () const { return  Xinc[2]; }
  float GetPx () const { return  Pinc[0]; }
  float GetPy () const { return  Pinc[1]; }
  float GetPz () const { return  Pinc[2]; }
  int GetPDG () const { return  PDGinc; }


  G4ThreeVector GetMomentum() const;
  G4ThreeVector GetPosition() const;

  // tree management
  int GetEntry(Long64_t entry);
  int GetNextEntry();
  Long64_t NumberOfEntries() const;
  bool IsOK() const;

  void ActivateAllBranches();
  void DeactivateAllBranches();
  void ActivateBranch(const char* branchName){fChain->SetBranchStatus(branchName,1);}
  void DeactivateBranch(const char* branchName){fChain->SetBranchStatus(branchName,0);}
  void Show(Long64_t entry);

private :
  void InitialiseAction();//most changes need be propogated by inherited Initialise before usage
  void LoadFiles();
  void SetUpBranches();
  void InitTranslationVector();
  void InitRotationMatrix();
  int testRootFile(const char *filename, bool quit = false);
  template <class Functor>
  void ForEachFile(Functor&& functor) const;
  template <class Class>
  Class* GetUnique(const char* parameterName) const;
  double Accumulate(const char* parameterName) const;

  std::string fFilePathPattern;
  std::unique_ptr<TChain> fChain;

  TVector3 fTranslation;
  TMatrixT<double> fRotation;
  TVector3 fSTEREOCentre;

  Long64_t fEntry;
  int fNumberOfFiles; // nb de fichiers ouverts
  bool fwildcardRootName;// le nom de fichier donne est generic
  const char* fInputTreeName;
  // pour la signification des no de volume voir src/ftofTrackerSD.cc

  // Declaration of leaf types
  int          evtID;
  double       time;
  float        Xinc[3]; // vertex de la particule initiale (mm)
  float        Pinc[3]; // impulsion de la particule initiale (MeV)
  int          PDGinc; // numero de la particule initiale

  // List of branches
  TBranch        *b_evtID;   //!
  TBranch        *b_time;   //!
  TBranch        *b_Xinc;   //!
  TBranch        *b_Pinc;   //!
  TBranch        *b_PDGinc;   //!

};

template <class Functor>
void ILLTreeContainer::ForEachFile(Functor&& functor) const{

  TObjArray* list = fChain->GetListOfFiles();
  TIter next{list};
  TChainElement* chainElement;

  while (( chainElement = static_cast<TChainElement*>(next()) )){

      TFile file(chainElement->GetTitle());
      if( ! ( file.IsZombie() || file.TestBit(TFile::kRecovered))) functor(file);

  }

}

template <class Class>
Class* ILLTreeContainer::GetUnique(const char* parameterName) const{

    Class* first{nullptr};
    Class* other{nullptr};

    ForEachFile([&first,&other,parameterName](auto& file){

        if(!first) first = static_cast<Class*>(file.Get(parameterName));
        else{

            other = static_cast<Class*>(file.Get(parameterName));
            if(other && ROOTHelpers::Differ(*other, *first)) throw std::logic_error("Merging different simulations!");

        }

    });

    return first;

}

#endif // ILLTreeContainer_hh

