/**************************************************************************
* @file ILLMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 11 Oct 2019
* @brief Specialisation of methods of GenericMessenger class template
* for class Generator::ILL
* ************************************************************************/

#ifndef GENERATOR_ILLMESSENGER_HH
#define GENERATOR_ILLMESSENGER_HH

#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"
#include "Generator/ILL.hh"

namespace Generator
{

    DEFINE_COMMAND_PREFIXER(ILLCommandPrefixer, "/generator/ILL/")

    struct ILLCommandsCreator;
    using ILLMessenger = G4Helpers::InitialisablePathModifyingMessenger<ILL, ILLCommandsCreator, ILLCommandPrefixer>;

    struct ILLCommandsCreator
    {
        static void Initialise(ILLMessenger& messenger);
    };

}

#endif /* GENERATOR_ILLMESSENGER_HH */
