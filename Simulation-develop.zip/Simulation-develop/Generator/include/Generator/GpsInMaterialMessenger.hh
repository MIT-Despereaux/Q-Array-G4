/**************************************************************************
* @file GpsInMaterialMessenger.hh
* @author Antoine Cazes <a.cazes@ipnl.in2p3.fr>
* @date  09 july  2020
* @brief Specialisation of methods of Messenger class template
* ************************************************************************/

#ifndef GENERATOR_GPSINMATERIALMESSENGER_HH
#define GENERATOR_GPSINMATERIALMESSENGER_HH

#include "G4Helpers/GenericMessenger.hh"
#include "G4Helpers/InitialisableMessenger.hh"
#include "Generator/GpsInMaterial.hh"

namespace Generator
{

    struct GpsInMaterialCommandsCreator;
    using GpsInMaterialMessenger = G4Helpers::InitialisableMessenger<G4Helpers::GenericMessenger<GpsInMaterial>, GpsInMaterialCommandsCreator>;

    struct GpsInMaterialCommandsCreator
    {
        static void Initialise(GpsInMaterialMessenger& messenger);
    };

}

#endif /* GPSINMATERIALMESSENGER_HH */
