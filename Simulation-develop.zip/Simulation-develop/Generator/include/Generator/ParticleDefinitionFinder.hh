/**************************************************************************
* @file ParticleDefinitionFinder.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 03 Oct 2019
* @brief Fix Geant4's broken FindParticle(PDG)
* ************************************************************************/

#ifndef PARTICLEDEFINITIONFINDER_HH
#define PARTICLEDEFINITIONFINDER_HH

class G4ParticleDefinition;

namespace ParticleDefinitionFinder{

    G4ParticleDefinition* Find(int PDGencoding);//GeantCrap doesn't know about const correctness...

}

#endif /* PARTICLEDEFINITIONFINDER_HH */
