/**************************************************************************
* @file PrimaryGenerator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 14 Oct 2019
* @brief Simple class to select actual generator type to use (for
* generating primary events) with Build method. Generator must be
* subsequently configured with its corresponding messenger calls.
* If you wish to call your generator's methods directly to configure it,
* you don't need this class: simply use your generator class outside
* this wrapper!
* ************************************************************************/

#ifndef PRIMARYGENERATOR_HH
#define PRIMARYGENERATOR_HH

#include <memory>
#include "ROOTWritableEventGenerator.hh"

class G4Event;

namespace Generator{

    class Primary : public ROOTWritableEventGenerator
    {
    public:
      Primary() = default;
      //assigns corresponding generator to member 'generator'
      void Build(const std::string& generatorName);
      void GeneratePrimaries(G4Event*) override;
      void Write(TDirectory& output) const override;

    private:
      std::unique_ptr<ROOTWritableEventGenerator> generator;

    };

}

#endif /* PRIMARYGENERATOR_HH */
