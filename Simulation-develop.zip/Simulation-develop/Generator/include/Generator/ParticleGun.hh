/**************************************************************************
* @file ParticleGun.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Oct 2019
* @brief Fix Geant4's verbosity by redefining sensible methods in this
* wrapper around G4ParticleGun, in particular, have a SetParticleMomentum
* method that does not write to G4out on every bloody call!
* ************************************************************************/

#ifndef PARTICLEGUN_HH
#define PARTICLEGUN_HH

#include "G4ParticleGun.hh"

namespace Generator{

    class ParticleGun{

        G4ParticleGun brokenGun;//the broken piece of rubbish whose SetParticleMomentum must be redefined
    public:
        template <class... Args>
        ParticleGun(Args&&... args);
        void SetParticleTime(double time);
        void SetParticleDefinition(int PDG);
        void SetParticleDefinition(G4ParticleDefinition* particleDefinition);
        void SetKinematics(G4ParticleDefinition* particleDefinition, const CLHEP::Hep3Vector& momentum);
        void SetKinematics(int PDG, const CLHEP::Hep3Vector& momentum);
        void SetParticleMomentum(const CLHEP::Hep3Vector& momentum);
        void SetParticleMomentumDirection(const CLHEP::Hep3Vector& momentum);
        void SetParticleEnergy(double kineticEnergy);
        void SetParticlePosition(const CLHEP::Hep3Vector& position);
        void GeneratePrimaryVertex(G4Event* event);

    };

        template <class... Args>
        ParticleGun::ParticleGun(Args&&... args)
        :brokenGun(std::forward<Args>(args)...){

        }

}

#endif /* PARTICLEGUN_HH */
