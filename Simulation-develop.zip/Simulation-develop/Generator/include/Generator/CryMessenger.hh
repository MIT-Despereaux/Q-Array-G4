/**************************************************************************
* @file CryMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 29 Oct 2019
* @brief Specialisation of G4Helpers::GenericMessenger for Generator::Cry
* ************************************************************************/

#ifndef CRYMESSENGER_HH
#define CRYMESSENGER_HH

#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"
#include "Generator/Cry.hh"

namespace Generator
{

    DEFINE_COMMAND_PREFIXER(CryCommandPrefixer, "/generator/CRY/")

    struct CryCommandsCreator;
    using CryMessenger = G4Helpers::InitialisablePathModifyingMessenger<Cry, CryCommandsCreator, CryCommandPrefixer>;

    struct CryCommandsCreator
    {
        static void Initialise(CryMessenger& messenger);
    };

}

#endif /* CRYMESSENGER_HH */
