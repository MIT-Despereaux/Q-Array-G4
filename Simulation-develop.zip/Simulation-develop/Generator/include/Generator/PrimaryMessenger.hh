/**************************************************************************
* @file PrimaryMessenger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 14 Oct 2019
* @brief Specialisation of methods of Messenger class template
* ************************************************************************/

#ifndef GENERATOR_PRIMARYGENERATORMESSENGER_HH
#define GENERATOR_PRIMARYGENERATORMESSENGER_HH

#include "G4Helpers/GenericMessenger.hh"
#include "G4Helpers/InitialisableMessenger.hh"
#include "Primary.hh"

namespace Generator
{

    struct PrimaryCommandsCreator;
    using PrimaryMessenger =
    G4Helpers::InitialisableMessenger<G4Helpers::GenericMessenger<Primary>, PrimaryCommandsCreator>;

    struct PrimaryCommandsCreator
    {
        static void Initialise(PrimaryMessenger& messenger);
    };

}

#endif /* GENERATOR_PRIMARYGENERATORMESSENGER_HH */
