/**************************************************************************
* @file ILL.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 26 Sep 2019
* @brief Generator class for generating events from a ROOT file
* containing cosmic rays in the ILL reactor building
* ************************************************************************/

#ifndef ILLGENERATOR_HH
#define ILLGENERATOR_HH

#include "Generator/ParticleGun.hh"
#include "Generator/ROOTWritableEventGenerator.hh"
#include "Generator/ILLTreeContainer.hh"

namespace Generator{

    class ILL : public ROOTWritableEventGenerator{

        Generator::ParticleGun particleGun;
        ILLTreeContainer treeContainer;
        void SetEventFromCurrentEntry(G4Event* event);
    public:
        ILL(const std::string& inputFilePathPattern = "", const CLHEP::Hep3Vector& STEREOCentre = {});
        void SetInputFilePattern(const std::string& inputFilePathPattern);
        void SetSTEREOCentre(const CLHEP::Hep3Vector& STEREOCentre);
        void GeneratePrimaries(G4Event* event) override;
        void Write(TDirectory& output) const override;
        void Run();
        void Run(int maxNumberOfEvents); //Geant4's BeamOn truncates to 'int' only...

    };

}

#endif /* ILLGENERATOR_HH */
