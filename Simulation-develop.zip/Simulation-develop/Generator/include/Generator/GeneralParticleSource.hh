/**************************************************************************
* @file GeneralParticleSource.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Oct 2019
* @brief Because EndOfAction expects the Generator to have a Write method
* we must define a type around G4's standard generator that "implements"
* write whilst retaining G4's own class "features".
* ************************************************************************/

#ifndef GENERALPARTICLESOURCE_HH
#define GENERALPARTICLESOURCE_HH

#include "G4GeneralParticleSource.hh"
#include "ROOTWritableEventGenerator.hh"

namespace Generator{

    struct GeneralParticleSource : public G4GeneralParticleSource,  // that turd actually manages its messenger
                                  public ROOTWritableEventGenerator
    {

        void GeneratePrimaries(G4Event* event) override;
        void Write(TDirectory& output) const override;

    };


}
#endif /* GENERALPARTICLESOURCE_HH */
