/**************************************************************************
* @file PositionGenerator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 10 Oct 2019
* @brief Adapted from ugly ChoozSimulation by A. Leder
* ************************************************************************/

#ifndef POSITIONGENERATOR_HH
#define POSITIONGENERATOR_HH

#include <cmath>
#include "CLHEP/Units/SystemOfUnits.h"
#include "CLHEP/Random/Random.h"
#include "G4ThreeVector.hh"

namespace PositionGenerator{

    double Uniform(double min, double max);
    double Uniform(double max);
    double GetUniformPhi();

    namespace UnitSphere{

        G4ThreeVector GetOnSurface();

    }

    namespace Cylinder{

        G4ThreeVector GetOnSide(double radius, double height, double offset);
        G4ThreeVector GetOnDisk(double radius, double height);

    }

}

#endif /* POSITIONGENERATOR_HH */
