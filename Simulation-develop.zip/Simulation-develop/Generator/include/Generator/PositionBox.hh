/**************************************************************************
* @file PositionBox.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 12 Feb 2020
* @brief To generate positions uniformly on the surface(s) of a box
* The frame is as skteched below
*     z (top)
*       ^
*       |
*       |————> y (side right)
*      /
*     /
*    v
*  x (front)
* ************************************************************************/

#ifndef GENERATOR_POSITIONBOX_HH
#define GENERATOR_POSITIONBOX_HH

#include <array>
#include "G4ThreeVector.hh"

namespace Generator
{
namespace Position
{

    enum class Surface
    : std::size_t //for straightforward conversion to array index
    {
        Top = 0, // XY, Z > 0
        Bottom = 1, // XY, Z < 0
        SideRight = 2, // XZ, Y > 0
        SideLeft = 3, // XZ, Y < 0
        Front = 4, // YZ, X > 0
        Back = 5, // YZ, X < 0
        Number = 6
    };

    constexpr std::size_t SurfaceToIndex(Surface surface){return static_cast<std::size_t>(surface);}
    constexpr Surface IndexToSurface(std::size_t index){return static_cast<Surface>(index);}

    class Box
    {
        double halfX;
        double halfY;
        double halfZ;
        std::array<double, SurfaceToIndex(Surface::Number)> cumulativeSurface;
        double& CumulativeSurface(Surface surface);
        void UpdateCummulativeSurface(double depth, double width, double height);

    public:
        Box() = default;
        //\brief depth = X, width = Y, height = Z
        Box(double depth, double width, double height);
        double GetSurface() const;
        double GetSideSurface() const;
        Surface PickSurface() const;
        Surface PickSideSurface() const;
        template <Surface S>
        G4ThreeVector GetOnSurface() const;
        G4ThreeVector GetOnSurface(Surface surface) const;
        void SetDimensions(double depth, double width, double height);
    };

}
}

#endif /* GENERATOR_POSITIONBOX_HH */
