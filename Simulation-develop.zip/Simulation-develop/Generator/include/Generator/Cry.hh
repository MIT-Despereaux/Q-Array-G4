/**************************************************************************
* @file CryGenerator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 28 Oct 2019
* @brief Wrapper around seriously patched CRYGenerator
* ************************************************************************/

#ifndef CRYGENERATOR_HH
#define CRYGENERATOR_HH

#include <sstream>
#include "CLHEP/Random/Random.h"
#include "CRY/Generator.hh"
#include "Generator/ROOTWritableEventGenerator.hh"
#include "Utility/Initialisable.hh"
#include "ParticleGun.hh"

namespace Generator{

    class Cry : public ROOTWritableEventGenerator, public Utility::Initialisable<Cry>{

        friend Utility::Initialisable<Cry>;
        CRY::Generator _cryGenerator;
        ParticleGun _particleGun;
        CRY::Setup _setup;//cached because of Geant4's macro SetX() unforseeable updates
        std::stringstream _cryConfigurationContents;//cached because of Geant4's macro AppendCryConfiguration calls

        void InitialiseAction();
        void ClearConfiguration();
        void GeneratePrimaryVertex(G4Event* event, const CRY::Particle& particle);
    public:
        //CLHEP::HepRandom generator, configure CRY later
        Cry();
        //configure CRY later
        template <class UniformRandomGenerator>
        Cry(UniformRandomGenerator&& generator);
        //setup must not be default constructed
        template <class UniformRandomGenerator>
        Cry(UniformRandomGenerator&& generator, const CRY::Setup& setup);
        //appends to CRY configuration stream
        void AppendConfigurationLine(const std::string& cryConfigurationLine);
        //reads user configuration file and resets CRY configuration stream
        void SetConfigurationFromFile(const std::string& configurationFilePath);
        //loads provided files for known altitudes from pattern containg %ATLTITUDE%
        void SetCosmicDataFromFilePattern(const std::string& dataFilePattern);
        void GeneratePrimaries(G4Event* event) override;
        void Write(TDirectory& output) const override;

    };

    template <class UniformRandomGenerator>
    Cry::Cry(UniformRandomGenerator&& generator)
    :_cryGenerator(std::forward<UniformRandomGenerator>(generator)){

    }

    template <class UniformRandomGenerator>
    Cry::Cry(UniformRandomGenerator&& generator, const CRY::Setup& setup)
    :_cryGenerator(std::forward<UniformRandomGenerator>(generator), setup){

    }

}

#endif /* CRYGENERATOR_HH */
