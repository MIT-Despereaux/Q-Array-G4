/**************************************************************************
* @file GpsOnBoxMessenger.hh
* @author Antoine Cazes <a.cazes@ipnl.in2p3.fr>
* @date 20 nov 2019
* @brief Specialisation of methods of Messenger class template
* ************************************************************************/

#ifndef GENERATOR_GENERATEFROMBOXMESSENGER_HH
#define GENERATOR_GENERATEFROMBOXMESSENGER_HH

#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"
#include "Generator/GpsOnBox.hh"

namespace Generator
{

    DEFINE_COMMAND_PREFIXER(GpsOnBoxCommandPrefixer, "/generator/GpsOnBox/")

    struct GpsOnBoxCommandsCreator;
    using GpsOnBoxMessenger =
    G4Helpers::InitialisablePathModifyingMessenger<GpsOnBox, GpsOnBoxCommandsCreator, GpsOnBoxCommandPrefixer>;

    struct GpsOnBoxCommandsCreator
    {
        static void Initialise(GpsOnBoxMessenger& messenger);
    };

}

#endif /* GENERATEFROMBOXMESSENGER_HH */
