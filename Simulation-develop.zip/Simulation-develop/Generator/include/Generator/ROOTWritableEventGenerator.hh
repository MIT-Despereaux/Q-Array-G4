/**************************************************************************
* @file ROOTWritableEventGenerator.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 26 Sep 2019
* @brief Interface for primary event generator that can be written to
* ROOT files. A more flexible interface would Accept a Serialiser
* interface that could implement different file types or strategies, for
* all Generators, rather than forcing the TDirectory type.
* ************************************************************************/

#ifndef ROOTSERIALISABLEEVENTGENERATOR_HH
#define ROOTSERIALISABLEEVENTGENERATOR_HH

#include "G4VUserPrimaryGeneratorAction.hh"
#include "ROOTHelpers/Writable.hh"

namespace Generator{

    struct ROOTWritableEventGenerator : public G4VUserPrimaryGeneratorAction, public ROOTHelpers::Writable {

        using G4VUserPrimaryGeneratorAction::G4VUserPrimaryGeneratorAction;
        virtual ~ROOTWritableEventGenerator() = default;
        ROOTWritableEventGenerator(const ROOTWritableEventGenerator&) = default;
        ROOTWritableEventGenerator(ROOTWritableEventGenerator&&) = default;
        ROOTWritableEventGenerator& operator=(const ROOTWritableEventGenerator&) = default;
        ROOTWritableEventGenerator& operator=(ROOTWritableEventGenerator&&) = default;

    };

}

#endif /* ROOTSERIALISABLEEVENTGENERATOR_HH */
