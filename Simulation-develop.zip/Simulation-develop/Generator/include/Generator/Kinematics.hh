/**************************************************************************
* @file Kinematics.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 10 Oct 2019
* @brief Basic functions used in relativistic kinematics
* ************************************************************************/

#ifndef KINEMATICS_HH
#define KINEMATICS_HH

#include <cmath>
#include "CLHEP/Vector/ThreeVector.h"
#include "G4ParticleDefinition.hh"

namespace Kinematics{

    double GetKineticEnergy(double momentum, double mass);
    double GetKineticEnergy(double momentum, const G4ParticleDefinition& particleDefinition);
    double GetKineticEnergy(const CLHEP::Hep3Vector& momentum, double mass);
    double GetKineticEnergy(const CLHEP::Hep3Vector& momentum, const G4ParticleDefinition& particleDefinition);

}

#endif /* KINEMATICS_HH */
