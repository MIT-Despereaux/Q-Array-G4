/**************************************************************************
* @file GpsOnBox.hh
* @author Antoine Cazes <a.cazes@ipnl.in2p3.fr>
* @date 20 nov 2019
* @brief Generator class for generating gamma event from a box
* containing cosmic rays in the ILL reactor building
* ************************************************************************/

#ifndef GENERATOR_GPSONBOX_HH
#define GENERATOR_GPSONBOX_HH

#include "G4GeneralParticleSource.hh"
#include "G4ThreeVector.hh"
#include "Generator/ROOTWritableEventGenerator.hh"
#include "Generator/PositionBox.hh"

namespace Generator{

    class GpsOnBox : public ROOTWritableEventGenerator{

        G4GeneralParticleSource fGeneralParticleSource;
        Position::Box fPositionGenerator;//centred around origin
        G4ThreeVector fBoxCentre{0,0,120*CLHEP::cm};//to shift generated positions
    	bool fShootFromSideOnly{false};

    public:
        GpsOnBox() = default;
        void SetBoxDimensions(const G4ThreeVector& boxSize);
        void SetBoxCentre(const G4ThreeVector& boxCentre);
        void ShootFromSide(bool value);
        void GeneratePrimaries(G4Event* event) override;
        void Write(TDirectory& output) const override;

    };

}

#endif /* GENERATOR_GPSONBOX_HH */
