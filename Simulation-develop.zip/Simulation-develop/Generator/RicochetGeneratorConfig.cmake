include(CMakeFindDependencyMacro)

find_dependency(ROOT 6.16 REQUIRED COMPONENTS tree)
find_dependency(Geant4 REQUIRED)
find_dependency(RicochetUtility REQUIRED)
find_dependency(RicochetG4Helpers REQUIRED)
find_dependency(RicochetSimuOutput REQUIRED)
find_dependency(RicochetCRY REQUIRED)

if(NOT TARGET Ricochet::Generator)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetGeneratorTargets.cmake")
endif()
