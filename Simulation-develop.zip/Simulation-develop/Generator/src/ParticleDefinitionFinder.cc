#include "Generator/ParticleDefinitionFinder.hh"
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"

namespace ParticleDefinitionFinder{

    G4ParticleDefinition* Find(int PDGencoding){//GeantCrap doesn't know about const correctness...

        auto particleDefinition = G4ParticleTable::GetParticleTable()->FindParticle(PDGencoding);
        if(!particleDefinition && PDGencoding > 2000){

            particleDefinition = G4ParticleTable::GetParticleTable()->GetIonTable()->GetIon(PDGencoding);
            if(!particleDefinition) throw std::logic_error("Input particle with PDG = "+std::to_string(PDGencoding)+" can't be found!");

        }

        return particleDefinition;

    }

}
