#include "Generator/GpsOnBoxMessenger.hh"
#include "Generator/GpsOnBox.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithABool.hh"

namespace Generator
{

    void GpsOnBoxCommandsCreator::Initialise(GpsOnBoxMessenger& messenger)
    {
        messenger.AddCommand<G4UIcmdWith3VectorAndUnit>("SetBoxDimensions",
                "Set dimensions of the box on the surface of particles are generated uniformly",
                [](auto& generator, const std::string& macroArgument){
                auto vector = G4UIcommand::ConvertToDimensioned3Vector(macroArgument.c_str());
                generator.SetBoxDimensions(vector);
                });

        messenger.AddCommand<G4UIcmdWith3VectorAndUnit>("SetBoxCentre",
                "Set origin of the generation surface",
                [](auto& generator, const std::string& macroArgument){
                auto vector = G4UIcommand::ConvertToDimensioned3Vector(macroArgument.c_str());
                generator.SetBoxCentre(vector);
                });

         messenger.AddCommand<G4UIcmdWithABool>("ShootOnlyFromSides",
                "shoot event only from lateral side of the box (nothing from top and bottom)",
                [](auto& generator, const std::string& macroArgument){
                auto value = G4UIcommand::ConvertToBool(macroArgument.c_str());
                generator.ShootFromSide(value);
                });
	
    }

}
