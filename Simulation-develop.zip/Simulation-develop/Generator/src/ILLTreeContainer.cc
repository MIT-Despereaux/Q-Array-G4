#include <sstream>
#include "Generator/ILLTreeContainer.hh"
#include "TParameter.h"
#include "TChainElement.h"
#include "ROOTHelpers/G4toROOT.hh"
#include "ROOTHelpers/Printing.hh"

TFile* GetIndexedFile(const char* filePattern, int fileIndex)
{
    std::stringstream stream;
    stream<<filePattern<<"_"<<fileIndex<<".root";
    return TFile::Open(stream.str().c_str(),"read");
}

ILLTreeContainer::ILLTreeContainer(const std::string& inputFilePathPattern, const G4ThreeVector& STEREOCentre):
fFilePathPattern(inputFilePathPattern),
fRotation(3,3),
fSTEREOCentre(ROOTHelpers::Convert(STEREOCentre)),
fEntry(-1),
fInputTreeName("Tree")
{ }

ILLTreeContainer::~ILLTreeContainer(){
  if (fChain) delete fChain->GetCurrentFile();
}

void ILLTreeContainer::InitialiseAction()
{
    LoadFiles();
    SetUpBranches();
    InitTranslationVector();
    InitRotationMatrix();
    GetNextEntry();
}

void ILLTreeContainer::SetSTEREOCentre(const CLHEP::Hep3Vector& STEREOCentre)
{
    fSTEREOCentre = ROOTHelpers::Convert(STEREOCentre);
    MarkUninitialised();
}

////////////////////////////////////////////////////////////////////////////////////////////////

void ILLTreeContainer::SetInputFilePattern(const std::string& inputFilePathPattern)
{
    fFilePathPattern = inputFilePathPattern;
    MarkUninitialised();
}

void ILLTreeContainer::LoadFiles()
{
    fChain = std::make_unique<TChain>(fInputTreeName);
    fNumberOfFiles=0;
    fwildcardRootName=true;
    testRootFile(fFilePathPattern.c_str(), true);
    while(!testRootFile(fFilePathPattern.c_str()));
}

void ILLTreeContainer::SetUpBranches()
{
  fChain->SetBranchAddress("evtID", &evtID, &b_evtID);
  fChain->SetBranchAddress("time", &time, &b_time);
  fChain->SetBranchAddress("Xinc", Xinc, &b_Xinc);
  fChain->SetBranchAddress("Pinc", Pinc, &b_Pinc);
  fChain->SetBranchAddress("PDGinc", &PDGinc, &b_PDGinc);
  ActivateAllBranches();
}

void ILLTreeContainer::InitTranslationVector()
{
  fTranslation = GetTranslation();
}

void ILLTreeContainer::InitRotationMatrix()
{
  TRotMatrix dumbRotation = GetRotation();
  fRotation = TMatrixT<double>(3, 3, dumbRotation.GetMatrix());
}

int ILLTreeContainer::testRootFile(const char *filePattern, bool quit){
  // test l'existence du fichier root
  int res=0;
  if(!fwildcardRootName) return -1;
  TFile *fFileIn = nullptr;
  if(fNumberOfFiles==0) {	// premier passage ici
    fFileIn = TFile::Open(filePattern,"READ");
    if (!fFileIn) {
      fFileIn = GetIndexedFile(filePattern, fNumberOfFiles);
      if (fFileIn) fNumberOfFiles++;
    }
    else{
        fwildcardRootName=false;
        ++fNumberOfFiles;  // ouverture direct de filePattern
    }
  }
  else { // passages suivants
    fFileIn = GetIndexedFile(filePattern, fNumberOfFiles);
    if (!fFileIn) {
        if(quit) exit(-1);
        else res=-1;
    }
    else ++fNumberOfFiles;
  }

  if(fNumberOfFiles==0){
    if(quit) throw std::runtime_error("ILLTreeContainer::testRootFile: file pattern '"+std::string(filePattern)+"' did not yield any file!");
    res=-1;
  }
  if(res<0) return res;	// return if file does not exist
  // test l'existence du tree dans le fichier fichier root
  auto testTree = dynamic_cast<TTree*>(fFileIn->Get(fInputTreeName));
  if (!testTree) {
    if(quit!=0) throw std::runtime_error("ILLTreeContainer::testRootFile: no TTree '"+std::string(fInputTreeName)+"'in '"+filePattern+"'!");
    res=-1;
  }
  fFileIn->Close();
  if(res==0) {
    std::cout<<"Adding "<<fFileIn->GetName()<<"\n";
    fChain->Add(fFileIn->GetName());
  }
  return res;
}

int ILLTreeContainer::GetEntry(Long64_t entry){
  // Read contents of entry.
  if (!fChain) return 0;
  fEntry = entry;
  return fChain->GetEntry(fEntry);
}

int ILLTreeContainer::GetNextEntry(){
  // Read contents of entry.
  if (!fChain) return 0;
  return fChain->GetEntry(++fEntry);
}

Long64_t ILLTreeContainer::NumberOfEntries() const{
  if (fChain) return fChain->GetEntries();
  else return 0;
}


bool ILLTreeContainer::IsOK() const{
  if (fChain) return fEntry <= fChain->GetEntries();
  else return false;
}

void ILLTreeContainer::ActivateAllBranches() {
  fChain->SetBranchStatus("*", true);
}

void ILLTreeContainer::DeactivateAllBranches() {
  fChain->SetBranchStatus("*", false);
}

void ILLTreeContainer::Show(Long64_t entry) {
  // Print contents of entry.
  // If entry is not specified, print current entry
  if (fChain) fChain->Show(entry);
}

////////////////////////////////////////////////////////////////////////////////////////////////

double ILLTreeContainer::Accumulate(const char* parameterName) const
{
    double result{0.};
    ForEachFile([&result,parameterName](auto& file){
            auto parameter = static_cast<TParameter<double>*>(file.Get(parameterName));
            result += parameter->GetVal();
    });
    return result;
}

double ILLTreeContainer::GetNbGeneratedEvent() const
{
    return Accumulate("nbGeneratedEvent");
}

double ILLTreeContainer::GetSurfaceTirage() const
{
    auto parameter = GetUnique<TParameter<double>>("surfaceTirage_m2");
    return parameter->GetVal();
}

double ILLTreeContainer::GetSimulatedTime() const
{
    return Accumulate("CRYtimeSimulated_sec");
}

TVector3 ILLTreeContainer::GetTranslation() const
{
    auto stereoTranslation = GetUnique<TVector3>("stereoTranslation");
    /// At this step, stereoTranslation considers the center of STEREO zone as origin, we want the transalation with respect to the cryostat's origin
    *stereoTranslation -= fSTEREOCentre;
    return *stereoTranslation;
}

TRotMatrix ILLTreeContainer::GetRotation() const
{
  return *GetUnique<TRotMatrix>("stereoRotation");
}

TVector3 ILLTreeContainer::GetStereoZoneHalf() const
{
    return *GetUnique<TVector3>("stereoZoneHalf");
}

G4ThreeVector ILLTreeContainer::GetMomentum() const
{
  return {GetPx(), GetPy(), GetPz()};
}

G4ThreeVector ILLTreeContainer::GetPosition() const
{
  TVector3 XV(Xinc[0], Xinc[1], Xinc[2]);
  XV = fRotation*XV - fTranslation; // go to ricochet coordinate frame
  return G4ThreeVector(XV[0], XV[1], XV[2]);
}
