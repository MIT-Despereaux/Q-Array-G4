#include "Generator/PositionBox.hh"
#include "CLHEP/Random/RandFlat.h"

namespace Generator
{

namespace Position
{

    double& Box::CumulativeSurface(Surface surface)
    {
        return cumulativeSurface[SurfaceToIndex(surface)];
    }

    void Box::UpdateCummulativeSurface(double depth, double width, double height)
    {
        CumulativeSurface(Surface::Top) = depth * width;
        CumulativeSurface(Surface::Bottom) = 2 * CumulativeSurface(Surface::Top);
        CumulativeSurface(Surface::SideRight) = depth * height + CumulativeSurface(Surface::Bottom);
        CumulativeSurface(Surface::SideLeft) = depth * height + CumulativeSurface(Surface::SideRight);
        CumulativeSurface(Surface::Front) = width * height + CumulativeSurface(Surface::SideLeft);
        CumulativeSurface(Surface::Back) = width * height + CumulativeSurface(Surface::Front);
    }

    Box::Box(double depth, double width, double height)
    {
        SetDimensions(depth, width, height);
    }

    double Box::GetSurface() const
    {
        return cumulativeSurface.back();
    }
    
    double Box::GetSideSurface() const
    {
        return cumulativeSurface.back() - 2*cumulativeSurface.front();
    }

    Surface Box::PickSurface() const
    {
        double uniform = CLHEP::RandFlat::shoot(0., cumulativeSurface.back());
        auto it = std::find_if(std::cbegin(cumulativeSurface), std::cend(cumulativeSurface), [uniform]
                (double summedSurface){return uniform < summedSurface;}
        );
        auto index = std::distance(cumulativeSurface.begin(), it);
        return IndexToSurface(index);
    }

    Surface Box::PickSideSurface() const
    {
        double uniform = CLHEP::RandFlat::shoot(cumulativeSurface[1], cumulativeSurface.back());
        auto it = std::find_if(std::cbegin(cumulativeSurface), std::cend(cumulativeSurface), [uniform]
               (double summedSurface){return uniform < summedSurface;}
        );
        auto index = std::distance(cumulativeSurface.begin(), it);
        return IndexToSurface(index);
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::Top>() const
    {
        return {CLHEP::RandFlat::shoot(-halfX,halfX),
                CLHEP::RandFlat::shoot(-halfY,halfY),
                halfZ};
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::Bottom>() const
    {
        return {CLHEP::RandFlat::shoot(-halfX,halfX),
                CLHEP::RandFlat::shoot(-halfY,halfY),
                -halfZ};
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::SideRight>() const
    {
        return {CLHEP::RandFlat::shoot(-halfX,halfX),
                halfY,
                CLHEP::RandFlat::shoot(-halfZ,halfZ)};
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::SideLeft>() const
    {
        return {CLHEP::RandFlat::shoot(-halfX,halfX),
                -halfY,
                CLHEP::RandFlat::shoot(-halfZ,halfZ)};
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::Front>() const
    {
        return {halfX,
                CLHEP::RandFlat::shoot(-halfY,halfY),
                CLHEP::RandFlat::shoot(-halfZ,halfZ)};
    }

    template <>
    G4ThreeVector Box::GetOnSurface<Surface::Back>() const
    {
        return {-halfX,
                CLHEP::RandFlat::shoot(-halfY,halfY),
                CLHEP::RandFlat::shoot(-halfZ,halfZ)};
    }

    G4ThreeVector Box::GetOnSurface(Surface surface) const
    {
        switch(surface)
        {
            case Surface::Top: return GetOnSurface<Surface::Top>();
            case Surface::Bottom: return GetOnSurface<Surface::Bottom>();
            case Surface::SideRight: return GetOnSurface<Surface::SideRight>();
            case Surface::SideLeft: return GetOnSurface<Surface::SideLeft>();
            case Surface::Front: return GetOnSurface<Surface::Front>();
            case Surface::Back: return GetOnSurface<Surface::Back>();
            default: throw std::logic_error("Generator::Box: unknown surface");
        }

    }

    void Box::SetDimensions(double depth, double width, double height)
    {
        halfX = .5 * depth;
        halfY = .5 * width;
        halfZ = .5 * height;
        UpdateCummulativeSurface(depth, width, height);
    }

}
}
