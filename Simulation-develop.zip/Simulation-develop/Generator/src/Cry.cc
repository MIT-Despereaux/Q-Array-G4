#include "Generator/Cry.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

namespace Generator{

    Cry::Cry()
    :_cryGenerator([]{return CLHEP::HepRandom::getTheEngine()->flat();}) {

    }

    void Cry::ClearConfiguration(){

        _cryConfigurationContents.str({});

    }

    void Cry::AppendConfigurationLine(const std::string& cryConfigurationLine){

        _cryConfigurationContents<<cryConfigurationLine<<"\n";
        MarkUninitialised();

    }

    void Cry::SetConfigurationFromFile(const std::string& configurationFilePath){

        std::ifstream input{configurationFilePath};

        if(input){
            ClearConfiguration();
            std::copy(std::istreambuf_iterator<char>(input), {}, std::ostreambuf_iterator<char>{_cryConfigurationContents});
            MarkUninitialised();
        }
        else throw std::runtime_error("Generator::Cry: can't open '"+configurationFilePath+"'");

    }

    void Cry::SetCosmicDataFromFilePattern(const std::string& dataFilePattern){

        _setup.SetCosmicDataFromFilePattern(dataFilePattern);
        MarkUninitialised();

    }

    void Cry::InitialiseAction(){

        _setup.SetConfiguration(_cryConfigurationContents);
        _cryGenerator.Configure(_setup);

    }


    void Cry::GeneratePrimaryVertex(G4Event* event, const CRY::Particle& particle){

        _particleGun.SetParticleDefinition(particle.PDGid());
        _particleGun.SetParticleTime(particle.t() * CLHEP::second);
        auto position = CLHEP::Hep3Vector{particle.x(), particle.y(), particle.z()} * CLHEP::m;
        _particleGun.SetParticlePosition(position);
        _particleGun.SetParticleEnergy(particle.ke() * CLHEP::MeV);
        _particleGun.SetParticleMomentumDirection({particle.u(), particle.v(), particle.w()});
        _particleGun.GeneratePrimaryVertex(event);

    }

    void Cry::GeneratePrimaries(G4Event* event){

        Initialise();

        for(const auto& particle : _cryGenerator.GenerateShower())
            GeneratePrimaryVertex(event, particle);

    }

    void Cry::Write(TDirectory& output) const{

        InfoHeaderWriter writer("CRY", "CRY");
        writer.SetKeyValue("SimulatedTime", _cryGenerator.SimulatedTime());
        writer.SetKeyValue("BoxSizeUsed", _cryGenerator.BoxSizeUsed());
        writer.SetKeyValue("SetupContents", _cryConfigurationContents.str());
        writer.WriteIn(output);

    }

}
