#include "Generator/CryMessenger.hh"
#include "G4UIcmdWithAString.hh"

namespace Generator
{

    void CryCommandsCreator::Initialise(CryMessenger& messenger)
    {
        messenger.AddCommand<G4UIcmdWithAString>("ConfigLine",
                "Append CRY-formatted configuration line to managed virtual file",
                &Generator::Cry::AppendConfigurationLine);

        messenger.AddCommand<G4UIcmdWithAString>("ConfigFile",
                "Set CRY-formatted user configuration",
                &Generator::Cry::SetConfigurationFromFile);

        messenger.AddCommand<G4UIcmdWithAString>("DataFilePattern",
                "Set %ALTITUDE% dependent pattern for CRY pre-computed cosmic data",
                &Generator::Cry::SetCosmicDataFromFilePattern);
    }

}
