/*
 * GermaniumBolomterBuilder.cc
 *
 *  Created on: 1.04.2021
 *  geometry of the germanium bolometer + casing.
 *      Author: cazes
 */

#include "Geometry/GermaniumBolometerBuilder.hh"

namespace Geometry {

    G4AssemblyVolume* GermaniumBolometerBuilder::BuildBoloFixations() const{

    double clampHight = 0.2*CLHEP::mm;
    double clampLength = 5*CLHEP::mm; 
    double clampWidth = 14.5*CLHEP::mm;

    auto solidClamp = new FilledBox("BolometerClamp", clampWidth, clampLength, clampHight);
    auto logicClamp = new G4LogicalVolume(solidClamp, G4Material::GetMaterial("G4_BRONZE"), "BolometerClamp");

    double saphirDiameter = 3.18*CLHEP::mm;

    auto solidSaphirSphere = new G4Orb("saphirSphere",saphirDiameter/2.);
    auto logicSaphirSphere = new G4LogicalVolume(solidSaphirSphere, G4Material::GetMaterial("G4_ALUMINUM_OXIDE"), "SaphirSphere");

    auto fixationsAssembly = new G4AssemblyVolume();      
      
    double clampZPos = 0.5*(bolometerHeight+clampHight)+saphirDiameter;
    double clampRPos = SupportOutRadius() - SupportThickness() - clampLength/2. -1*CLHEP::mm;

    G4ThreeVector translation(clampRPos ,0,clampZPos);

    fixationsAssembly->AddPlacedVolume(logicClamp, translation, nullptr);
    translation.setZ(-clampZPos);
    fixationsAssembly->AddPlacedVolume(logicClamp, translation, nullptr);

    translation.setX(clampRPos*cos(CLHEP::twopi/3.));
    translation.setY(clampRPos*sin(CLHEP::twopi/3.));
    G4RotationMatrix* turnAlongZ = new G4RotationMatrix;
    turnAlongZ->rotateZ(CLHEP::twopi/3.);

    fixationsAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);
    translation.setZ(clampZPos);
    fixationsAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);

    translation.setX(clampRPos*cos(2.*CLHEP::twopi/3.));
    translation.setY(clampRPos*sin(2.*CLHEP::twopi/3.));
    turnAlongZ->rotateZ(CLHEP::twopi/3.);

    fixationsAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);
    translation.setZ(-clampZPos);
    fixationsAssembly->AddPlacedVolume(logicClamp, translation, turnAlongZ);

    double saphirZPos = 0.5*(bolometerHeight+saphirDiameter);
    double saphirRPos = bolometerRadius - 0.5*saphirDiameter;

    translation.setX(saphirRPos);
    translation.setY(0.);
    translation.setZ(saphirZPos);

    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

    translation.setX(saphirRPos*cos(CLHEP::twopi/3.));
    translation.setY(saphirRPos*sin(CLHEP::twopi/3.));
    translation.setZ(saphirZPos);

    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

    translation.setX(saphirRPos*cos(2.*CLHEP::twopi/3.));
    translation.setY(saphirRPos*sin(2.*CLHEP::twopi/3.));
    translation.setZ(saphirZPos);

    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);
    translation.setZ(-saphirZPos);
    fixationsAssembly->AddPlacedVolume(logicSaphirSphere, translation, nullptr);

    return fixationsAssembly;
			
  }


  G4LogicalVolume* GermaniumBolometerBuilder::BuildBoloSupport() const{

    constexpr std::size_t nEdges = 6;

    std::array<double, nEdges> zSupport;
    zSupport[0] = -SupportHeight()*.5;
    zSupport[1] = -SupportHeight()*.5 + SupportThickness();
    zSupport[2] = -SupportHeight()*.5 + SupportThickness();
    zSupport[3] = SupportHeight()*.5 - SupportTopThickness();
    zSupport[4] = SupportHeight()*.5 - SupportTopThickness();
    zSupport[5] = SupportHeight()*.5;

    std::array<double, nEdges> riSupport;
    riSupport[0] = 0.;
    riSupport[1] = 0.;
    riSupport[2] = SupportOutRadius() - SupportThickness();
    riSupport[3] = SupportOutRadius() - SupportThickness();
    riSupport[4] = 0.;
    riSupport[5] = 0.;

    std::array<double, nEdges> roSupport;
    std::fill(std::begin(roSupport), std::end(roSupport), SupportOutRadius());

    auto solidSupport = new G4Polycone("solidSupport", 0., CLHEP::twopi, nEdges, zSupport.data(), riSupport.data(), roSupport.data());
    auto logicSupport = new G4LogicalVolume(solidSupport, G4Material::GetMaterial("CopperNOSV"), "Support");

    SetColourFromMaterial(logicSupport, "CopperNOSV");

    return logicSupport;

  }


  G4AssemblyVolume* GermaniumBolometerBuilder::BuildBolometer() const {

    auto bolometerAssembly = new G4AssemblyVolume();


    // Crystal geometry
    solidBolo = new FilledTube("CrystalBolo", CrystalRadius(), CrystalHeight());
    auto logicBolo = new G4LogicalVolume(solidBolo, G4Material::GetMaterial("Germanium"), "CrystalBolo");
    SetColourFromMaterial(logicBolo, "Germanium");

    G4ThreeVector position(0.,0.,0.);
    bolometerAssembly->AddPlacedVolume(logicBolo, position, nullptr);

    // bolometer fixations
    auto assemblyFixations = BuildBoloFixations();
    bolometerAssembly->AddPlacedAssembly(assemblyFixations,position,nullptr);

    // Support
    auto logicBoloSupport = BuildBoloSupport();
    position.setZ(0.5*(SupportTopThickness()- SupportThickness()));
    bolometerAssembly->AddPlacedVolume(logicBoloSupport, position, nullptr);
    
    return bolometerAssembly;

  }

  double GermaniumBolometerBuilder::CrystalRadius() const{

    return 15.*CLHEP::mm;

  }
    double GermaniumBolometerBuilder::CrystalHeight() const{

    return 10.*CLHEP::mm;

  }


  double GermaniumBolometerBuilder::SupportThickness() const{

    return 6.*CLHEP::mm;

  }

  double GermaniumBolometerBuilder::SupportTopThickness() const{

    return 2.*CLHEP::mm;

  }

  double GermaniumBolometerBuilder::SupportOutRadius() const{

    return CrystalRadius() + SupportSpace() + SupportThickness();

  }

  double GermaniumBolometerBuilder::SupportSpace() const{

    //      return 3.5*CLHEP::mm;
    return 4.*CLHEP::mm;

  }

  double GermaniumBolometerBuilder::SupportHeight() const{

    return CrystalHeight() + 2.*SupportSpace() + SupportThickness() + SupportTopThickness();

  }

  double GermaniumBolometerBuilder::GetBolometerFullHight const{

    return SupportHeight();

  }

  double GermaniumBolometerBuilder::GetCrystalVolume() const{

    return CLHEP::pi*std::pow(CrystalRadius(), 2) * CrystalHeight();

  }

  double GermaniumBolometerBuilder::GetCrystalMass() const{

    return GetCrystalVolume() * G4Material::GetMaterial("Germanium")->GetDensity();

  }


} // namespace
