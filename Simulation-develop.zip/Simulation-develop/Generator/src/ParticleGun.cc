#include "Generator/ParticleGun.hh"
#include "Generator/Kinematics.hh"
#include "Generator/ParticleDefinitionFinder.hh"

namespace Generator{


    void ParticleGun::SetParticleTime(double time){

        brokenGun.SetParticleTime(time);

    }

    void ParticleGun::SetParticleDefinition(int PDG){

        SetParticleDefinition(ParticleDefinitionFinder::Find(PDG));

    }

    void ParticleGun::SetParticleDefinition(G4ParticleDefinition* particleDefinition){

        brokenGun.SetParticleDefinition(particleDefinition);

    }

    void ParticleGun::SetKinematics(G4ParticleDefinition* particleDefinition, const CLHEP::Hep3Vector& momentum){

        SetParticleDefinition(particleDefinition);
        SetParticleMomentum(momentum);

    }

    void ParticleGun::SetKinematics(int PDG, const CLHEP::Hep3Vector& momentum){

        SetParticleDefinition(PDG);
        SetParticleMomentum(momentum);

    }

    void ParticleGun::SetParticleMomentum(const CLHEP::Hep3Vector& momentum){

        SetParticleMomentumDirection(momentum);
        SetParticleEnergy(Kinematics::GetKineticEnergy(momentum, *brokenGun.GetParticleDefinition()));

    }


    void ParticleGun::SetParticleMomentumDirection(const CLHEP::Hep3Vector& momentum){

        brokenGun.SetParticleMomentumDirection(momentum);

    }

    void ParticleGun::SetParticleEnergy(double kineticEnergy){

        brokenGun.SetParticleEnergy(kineticEnergy);

    }

    void ParticleGun::SetParticlePosition(const CLHEP::Hep3Vector& position){

        brokenGun.SetParticlePosition(position);

    }

    void ParticleGun::GeneratePrimaryVertex(G4Event* event){

        brokenGun.GeneratePrimaryVertex(event);

    }

}
