#include "Generator/GeneralParticleSource.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

namespace Generator{

        void GeneralParticleSource::GeneratePrimaries(G4Event* event) {

            GeneratePrimaryVertex(event);

        }

        void GeneralParticleSource::Write(TDirectory& output) const {

            InfoHeaderWriter writer("GPS", "GPS");
            writer.SetKeyValue("NumberOfParticles", GetNumberOfParticles());
            writer.SetKeyValue("ParticleName", GetParticleDefinition()->GetParticleName().data());
            writer.WriteIn(output);

        }

}
