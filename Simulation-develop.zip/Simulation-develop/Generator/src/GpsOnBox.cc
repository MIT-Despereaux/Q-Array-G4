#include "Generator/GpsOnBox.hh"
#include "Generator/ParticleDefinitionFinder.hh"
#include "SimuOutput/InfoHeaderWriter.hh"
#include "G4RunManager.hh"

namespace Generator
{

    namespace
    {

        double Sin(double cosTheta)
        {
            return std::sqrt(1 - std::pow(cosTheta, 2));
        }

        double UniformCosTheta()
        {
            return CLHEP::RandFlat::shoot(-1.,1.);
        }

        double UniformCosThetaHalf()
        {
            return CLHEP::RandFlat::shoot(0.,1.);
        }

        G4ThreeVector GetDirection(Position::Surface surface)
        {
            using Position::Surface;
            double cosTheta, sinTheta, phi;

            switch(surface)
            {
                case Surface::Top:
                    phi = CLHEP::RandFlat::shoot(0.,2.*CLHEP::pi);
                    cosTheta = UniformCosThetaHalf();
                    sinTheta = Sin(cosTheta);
                    return {std::cos(phi)*sinTheta, std::sin(phi)*sinTheta,-cosTheta};

                case Surface::Bottom:
                    phi = CLHEP::RandFlat::shoot(0.,2.*CLHEP::pi);
                    cosTheta = UniformCosThetaHalf();
                    sinTheta = Sin(cosTheta);
                    return {std::cos(phi)*sinTheta, std::sin(phi)*sinTheta, cosTheta};

                case Surface::SideRight:
                    phi = CLHEP::RandFlat::shoot(0.,CLHEP::pi);
                    cosTheta = UniformCosTheta();
                    sinTheta = Sin(cosTheta);
                    return {std::cos(phi)*sinTheta,- std::sin(phi)*sinTheta, cosTheta};

                case Surface::SideLeft:
                    phi = CLHEP::RandFlat::shoot(0.,CLHEP::pi);
                    cosTheta = UniformCosTheta();
                    sinTheta = Sin(cosTheta);
                    return {std::cos(phi)*sinTheta, std::sin(phi)*sinTheta, cosTheta};

                case Surface::Front:
                    phi = CLHEP::RandFlat::shoot(CLHEP::halfpi,3.*CLHEP::halfpi);
                    cosTheta = UniformCosTheta();
                    sinTheta = Sin(cosTheta);
                    return {std::cos(phi)*sinTheta, std::sin(phi)*sinTheta, cosTheta};

                case Surface::Back:
                    phi = CLHEP::RandFlat::shoot(CLHEP::halfpi,3.*CLHEP::halfpi);
                    cosTheta = UniformCosTheta();
                    sinTheta = Sin(cosTheta);
                    return {-std::cos(phi)*sinTheta, std::sin(phi)*sinTheta, cosTheta};
                default:
                    throw std::logic_error("GpsOnBox: unknown surface");
            }
        }

    }// anonymous namespace

    void GpsOnBox::GeneratePrimaries(G4Event* event)
    {
        auto selectedSurf = fShootFromSideOnly ? fPositionGenerator.PickSideSurface() : fPositionGenerator.PickSurface();

        auto direction = GetDirection(selectedSurf);
        fGeneralParticleSource.GetCurrentSource()->GetAngDist()->SetParticleMomentumDirection(direction);

        auto position = fBoxCentre + fPositionGenerator.GetOnSurface(selectedSurf);
        auto positionDistribution = fGeneralParticleSource.GetCurrentSource()->GetPosDist();
        positionDistribution->SetPosDisType("Point");
        positionDistribution->SetCentreCoords(position);

        fGeneralParticleSource.GeneratePrimaryVertex(event);
    }

    void GpsOnBox::Write(TDirectory& output) const
    {
        InfoHeaderWriter writer("GpsOnBox", "GpsOnBox");
        writer.SetKeyValue("NumberOfParticles", fGeneralParticleSource.GetNumberOfParticles());
        writer.SetKeyValue("ParticleName", fGeneralParticleSource.GetParticleDefinition()->GetParticleName().data());
        writer.SetKeyValue("BoxArea", fPositionGenerator.GetSurface());
        writer.SetKeyValue("BoxSideArea", fPositionGenerator.GetSideSurface());
        writer.WriteIn(output);
    }

    void GpsOnBox::SetBoxDimensions(const G4ThreeVector& sourceBoxSize)
    {
        fPositionGenerator.SetDimensions(sourceBoxSize.x(), sourceBoxSize.y(), sourceBoxSize.z());
    }

    void GpsOnBox::SetBoxCentre(const G4ThreeVector& boxCentre)
    {
        fBoxCentre = boxCentre;
    }

    void GpsOnBox::ShootFromSide(bool value)
    {
        fShootFromSideOnly = value;
    }


}
