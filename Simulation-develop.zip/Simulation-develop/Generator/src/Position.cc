#include "Generator/Position.hh"

namespace PositionGenerator{

    double Uniform(double min, double max){

        return min + (max - min ) * CLHEP::HepRandom::getTheEngine()->flat();

    }

    double Uniform(double max){

        return Uniform(0., max);

    }

    double GetUniformPhi(){

        return Uniform(2. * CLHEP::pi);

    }

    namespace UnitSphere{

        G4ThreeVector GetOnSurface() {

            double phi = GetUniformPhi();
            double cosTheta = Uniform(-1, 1);
            return G4ThreeVector(std::cos(phi)*std::sqrt(1-std::pow(cosTheta,2)), std::sin(phi)*std::sqrt(1-std::pow(cosTheta,2)), cosTheta);

        }

    }

    namespace Cylinder{

        G4ThreeVector GetOnSide(double radius, double height, double offset) {

            double randPhi = GetUniformPhi();
            double randomHeight = offset + Uniform(-.5*height, .5*height);
            return G4ThreeVector(radius * std::cos(randPhi), radius * std::sin(randPhi), randomHeight);

        }

        G4ThreeVector GetOnDisk(double radius, double height) {

            double randPhi = GetUniformPhi();
            radius = std::sqrt(Uniform(std::pow(radius,2)));
            return G4ThreeVector(radius * std::cos(randPhi), radius * std::sin(randPhi), height);

        }

    }

}
