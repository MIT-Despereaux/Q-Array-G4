#include "Generator/ILLMessenger.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"

namespace Generator
{

    void ILLCommandsCreator::Initialise(ILLMessenger& messenger)
    {

        messenger.AddCommand<G4UIcmdWithAString>("InputFilePattern",
                "Set input file name",
                &Generator::ILL::SetInputFilePattern);

        messenger.AddCommand<G4UIcmdWith3VectorAndUnit>("StereoCentre",
                "Set position of the Stereo zone centre for the ILL cosmic generator (coordinates)",
                [](auto& generator, const std::string& macroArgument){
                auto vector = G4UIcommand::ConvertToDimensioned3Vector(macroArgument.c_str());
                generator.SetSTEREOCentre(vector);
                });

        messenger.AddCommand<G4UIcmdWithoutParameter>("run",
                "Run over all input events",
                [](auto& generator, const std::string&){generator.Run();});

        messenger.AddCommand<G4UIcmdWithAnInteger>("runUntil",
                "Run only N events",
                [](auto& generator, const std::string& macroArgument){generator.Run(std::stoi(macroArgument));});

    }

}
