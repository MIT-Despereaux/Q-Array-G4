#include "Generator/GpsInMaterialMessenger.hh"
#include "G4UIcmdWithAString.hh"

namespace Generator
{

    void GpsInMaterialCommandsCreator::Initialise(GpsInMaterialMessenger& messenger)
    {
        messenger.AddCommand<G4UIcmdWithAString>("/generator/GpsInMaterial/SetMaterial",
                "Set the name of the material",
                &Generator::GpsInMaterial::SetMaterial
                );
        messenger.AddCommand<G4UIcmdWithAString>("/generator/GpsInMaterial/SetStrictlyMaterial",
                "Set the name of the material",
                &Generator::GpsInMaterial::SetStrictlyMaterial
                );
    }

}
