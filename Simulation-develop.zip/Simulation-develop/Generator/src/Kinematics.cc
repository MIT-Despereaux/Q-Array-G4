#include "Generator/Kinematics.hh"

namespace Kinematics{

    double GetKineticEnergy(double momentum, double mass){

        return std::sqrt(std::pow(momentum,2)+std::pow(mass,2))-mass;

    }

    double GetKineticEnergy(double momentum, const G4ParticleDefinition& particleDefinition){

        return GetKineticEnergy(momentum, particleDefinition.GetPDGMass());

    }

    double GetKineticEnergy(const CLHEP::Hep3Vector& momentum, double mass){

        return GetKineticEnergy(momentum.mag(), mass);

    }

    double GetKineticEnergy(const CLHEP::Hep3Vector& momentum, const G4ParticleDefinition& particleDefinition){

        return GetKineticEnergy(momentum, particleDefinition.GetPDGMass());

    }

}
