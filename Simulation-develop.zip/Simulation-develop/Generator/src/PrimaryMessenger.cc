#include "Generator/PrimaryMessenger.hh"
#include "G4UIcmdWithAString.hh"

namespace Generator
{

    void PrimaryCommandsCreator::Initialise(PrimaryMessenger& messenger)
    {
        messenger.AddCommand<G4UIcmdWithAString>("/generator/build",
                "Instantiate given generator",
                &Generator::Primary::Build
                );
    }

}
