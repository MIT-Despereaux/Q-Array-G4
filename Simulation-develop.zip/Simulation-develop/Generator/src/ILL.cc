#include "Generator/ILL.hh"
#include "Generator/ParticleDefinitionFinder.hh"
#include "G4RunManager.hh"
#include "SimuOutput/InfoHeaderWriter.hh"

namespace Generator{

    ILL::ILL(const std::string& filepath, const CLHEP::Hep3Vector& STEREOCentre)
        :particleGun(1),// one particle per GeneratePrimaryVertex call
        treeContainer(filepath.c_str(), STEREOCentre){

        }

        void ILL::SetEventFromCurrentEntry(G4Event* event){

                particleGun.SetKinematics(treeContainer.GetPDG(), treeContainer.GetMomentum());// ILL file in MeV
                particleGun.SetParticlePosition(treeContainer.GetPosition());
                particleGun.GeneratePrimaryVertex(event);

        }

        void ILL::SetInputFilePattern(const std::string& inputFilePathPattern){

            treeContainer.SetInputFilePattern(inputFilePathPattern);

        }

        void ILL::SetSTEREOCentre(const CLHEP::Hep3Vector& STEREOCentre){

            treeContainer.SetSTEREOCentre(STEREOCentre);

        }

        void ILL::GeneratePrimaries(G4Event* event)
        {
            treeContainer.Initialise();
            if(!treeContainer.IsOK()) G4RunManager::GetRunManager()->AbortRun();//the tree has more entries than events
            auto currentEventID = treeContainer.GetEvtID();
            while(treeContainer.IsOK() && currentEventID == treeContainer.GetEvtID())
            {
                SetEventFromCurrentEntry(event);
                treeContainer.GetNextEntry();
            }
        }

        void ILL::Write(TDirectory& output) const
        {
            InfoHeaderWriter writer("ILLFile", "ILLFile");
            writer.SetKeyValue("NbPrimaryCosmics", treeContainer.GetNbGeneratedEvent());
            writer.SetKeyValue("SimulatedTime", treeContainer.GetSimulatedTime());
            writer.SetKeyValue("StereoZoneHalf", treeContainer.GetStereoZoneHalf());
            writer.SetKeyValue("StereoZoneTranslation", treeContainer.GetTranslation());
            writer.SetKeyValue("StereoZoneRotation", treeContainer.GetRotation());
            writer.WriteIn(output);
        }

        void ILL::Run()
        {
            treeContainer.Initialise();
            Run(static_cast<int>(treeContainer.NumberOfEntries()));
        }

        void ILL::Run(int maxNumberOfEvents)
        {
            G4RunManager::GetRunManager()->BeamOn(maxNumberOfEvents);
        }

}
