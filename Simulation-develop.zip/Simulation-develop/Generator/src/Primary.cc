#include "G4Helpers/OwningMessenger.hh"
#include "Generator/Primary.hh"
#include "Generator/ILL.hh"
#include "Generator/ILLMessenger.hh"
#include "Generator/GpsOnBox.hh"
#include "Generator/GpsOnBoxMessenger.hh"
#include "Generator/GpsInMaterial.hh"
#include "Generator/GpsInMaterialMessenger.hh"
#ifdef WITH_CRY
#include "Generator/Cry.hh"
#include "Generator/CryMessenger.hh"
#endif
#include "Generator/GeneralParticleSource.hh"

namespace Generator
{
    namespace
    {

        template <class... Args>
        std::unique_ptr<ROOTWritableEventGenerator> MakeOwningMessenger()
        {
            return std::make_unique<G4Helpers::OwningMessenger<Args...>>();
        }

    }

    void Primary::Build(const std::string& generatorName)
    {
        if(generatorName ==  "ILL") generator = MakeOwningMessenger<ILL,ILLMessenger>();
#ifdef WITH_CRY
        else if(generatorName ==  "CRY") generator = MakeOwningMessenger<Cry,CryMessenger>();
#endif
        else if(generatorName ==  "gps") generator = std::make_unique<GeneralParticleSource>();//manages its messenger
        else if(generatorName ==  "GpsOnBox") generator = MakeOwningMessenger<GpsOnBox,GpsOnBoxMessenger>();
        else if(generatorName ==  "GpsInMaterial") generator = MakeOwningMessenger<GpsInMaterial,GpsInMaterialMessenger>();
        else
        {
            auto message = "Generator '"+generatorName+"' unknown to Primary!";
            throw std::logic_error(message);
        }
    }

    void Primary::GeneratePrimaries(G4Event* anEvent)
    {
        if(generator) generator->GeneratePrimaries(anEvent);
        else throw std::logic_error("Primary: generator not initialised!");
    }

    void Primary::Write(TDirectory& output) const
    {
        generator->Write(output);
    }


}
