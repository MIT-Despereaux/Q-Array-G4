#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::Generator" for configuration "Release"
set_property(TARGET Ricochet::Generator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::Generator PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetGenerator.so"
  IMPORTED_SONAME_RELEASE "libRicochetGenerator.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::Generator )
list(APPEND _cmake_import_check_files_for_Ricochet::Generator "${_IMPORT_PREFIX}/lib64/libRicochetGenerator.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
