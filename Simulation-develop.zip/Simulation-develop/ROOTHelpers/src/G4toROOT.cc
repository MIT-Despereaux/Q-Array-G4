#include "ROOTHelpers/G4toROOT.hh"

namespace ROOTHelpers{

    TVector3 Convert(G4ThreeVector&& G4vector){

        return Convert(G4vector);

    }


    TVector3 Convert(const G4ThreeVector& G4vector){

        return TVector3(G4vector.x(), G4vector.y(), G4vector.z());

    }

}
