#include "ROOTHelpers/Printing.hh"
#include "TRotMatrix.h"

std::ostream& operator<<(std::ostream& output, const TRotMatrix& rotation){

    ROOTHelper::Print(output, const_cast<TRotMatrix&>(rotation).GetMatrix(), 3, 3);
    return output;

}
