#include "ROOTHelpers/Comparisons.hh"
#include "TRotMatrix.h"

bool operator==(const TRotMatrix& first, const TRotMatrix& second){

    return first.GetTheta() == second.GetTheta() && first.GetPhi() == second.GetPhi() && first.GetPsi() == second.GetPsi();

}

bool operator!=(const TRotMatrix& first, const TRotMatrix& second){

    return !(first == second);

}
