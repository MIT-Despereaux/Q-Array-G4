#include "ROOTHelpers/Writable.hh"


namespace ROOTHelpers{

    TDirectory& operator<<(TDirectory& output, const Writable& object){

        object.Write(output);
        return output;

    }

}
