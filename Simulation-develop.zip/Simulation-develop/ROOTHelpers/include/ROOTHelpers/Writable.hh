/**************************************************************************
* @file Writable.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 04 Oct 2019
* @brief Interface for classes that can be written to TDirectory / TFile
* ************************************************************************/

#ifndef ROOT_HELPERS_ROOT_WRITABLE_HH
#define ROOT_HELPERS_ROOT_WRITABLE_HH

#include <iostream>

class TDirectory;

namespace ROOTHelpers{

    struct Writable{

        virtual void Write(TDirectory& output) const = 0;

    };

    TDirectory& operator<<(TDirectory& output, const Writable& object);

}

#endif /* ROOT_HELPERS_ROOT_WRITABLE_HH */
