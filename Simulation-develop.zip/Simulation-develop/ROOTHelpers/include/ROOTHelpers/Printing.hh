/**************************************************************************
* @file Printing.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 16 Oct 2019
* @brief Add sensible missing operator<< for ROOT classes
* ************************************************************************/

#ifndef ROOT_HELPERS_PRINTING_HH
#define ROOT_HELPERS_PRINTING_HH

#include <ostream>
#include <iomanip>
#include "TMatrixT.h"

class TRotMatrix;

// Declarations

namespace ROOTHelper{

    template <class Real>
    void Print(std::ostream& output, const Real* array, unsigned numberOfRows, unsigned numberOfColumns);

}

std::ostream& operator<<(std::ostream& output, const TRotMatrix& matrix);
template <class Real>
std::ostream& operator<<(std::ostream& output, const TMatrixT<Real>& rotation);

// Implentations

template <class Real>
std::ostream& operator<<(std::ostream& output, const TMatrixT<Real>& matrix){

    ROOTHelper::Print(output, matrix.GetMatrixArray(), matrix.GetNrows(), matrix.GetNcols());
    return output;

}

namespace ROOTHelper{

    template <class Real>
    void Print(std::ostream& output, const Real* array, unsigned numberOfRows, unsigned numberOfColumns){

        for(unsigned i = 0; i < numberOfRows; ++i){

            for(unsigned j = 0; j < numberOfColumns; ++j){

                output<<std::setw(10)<<std::right<<array[i * numberOfRows + j];
                if(j < numberOfColumns - 1) output<<"\t";

            }
            if(i < numberOfRows - 1) output<<"\n";

        }

    }

}

#endif /* ROOT_HELPERS_PRINTING_HH */
