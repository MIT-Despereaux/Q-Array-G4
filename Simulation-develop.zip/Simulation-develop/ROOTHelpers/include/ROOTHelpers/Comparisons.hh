/**************************************************************************
* @file Comparisons.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 09 Oct 2019
* @brief Try to fix ROOT's missing operators
* ************************************************************************/

#ifndef ROOT_HELPERS_ROOTCOMPARISONS_HH
#define ROOT_HELPERS_ROOTCOMPARISONS_HH

class TRotMatrix;
template <class Type>
class TParameter;

bool operator==(const TRotMatrix& first, const TRotMatrix& second);
bool operator!=(const TRotMatrix& first, const TRotMatrix& second);

namespace ROOTHelpers{

    template <class Class>
    bool Differ(const Class& first, const Class& second){

        return first != second;

    }

    template<class Type>
    bool Differ(const TParameter<Type>& first, const TParameter<Type>& second){

        return first.GetVal() != second.GetVal();

    }
}

#endif /* ROOT_HELPERS_ROOTCOMPARISONS_HH */
