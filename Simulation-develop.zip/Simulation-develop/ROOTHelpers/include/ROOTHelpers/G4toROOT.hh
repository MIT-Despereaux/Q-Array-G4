/**************************************************************************
* @file G4toROOT.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 27 Sep 2019
* @brief Convert G4 types to ROOT's
* ************************************************************************/

#ifndef ROOT_HELPERS_G4TOROOT_HH
#define ROOT_HELPERS_G4TOROOT_HH

#include "TVector3.h"
#include "G4ThreeVector.hh"

namespace ROOTHelpers{

    TVector3 Convert(G4ThreeVector&& G4vector);
    TVector3 Convert(const G4ThreeVector& G4vector);

}

#endif /* ROOT_HELPERS_G4TOROOT_HH */
