#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::ROOTHelpers" for configuration "Release"
set_property(TARGET Ricochet::ROOTHelpers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::ROOTHelpers PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetROOTHelpers.so"
  IMPORTED_SONAME_RELEASE "libRicochetROOTHelpers.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::ROOTHelpers )
list(APPEND _cmake_import_check_files_for_Ricochet::ROOTHelpers "${_IMPORT_PREFIX}/lib64/libRicochetROOTHelpers.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
