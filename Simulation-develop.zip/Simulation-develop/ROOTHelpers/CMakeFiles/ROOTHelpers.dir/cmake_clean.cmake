file(REMOVE_RECURSE
  "CMakeFiles/ROOTHelpers.dir/src/Comparisons.cc.o"
  "CMakeFiles/ROOTHelpers.dir/src/Comparisons.cc.o.d"
  "CMakeFiles/ROOTHelpers.dir/src/G4toROOT.cc.o"
  "CMakeFiles/ROOTHelpers.dir/src/G4toROOT.cc.o.d"
  "CMakeFiles/ROOTHelpers.dir/src/Printing.cc.o"
  "CMakeFiles/ROOTHelpers.dir/src/Printing.cc.o.d"
  "CMakeFiles/ROOTHelpers.dir/src/Writable.cc.o"
  "CMakeFiles/ROOTHelpers.dir/src/Writable.cc.o.d"
  "libRicochetROOTHelpers.pdb"
  "libRicochetROOTHelpers.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ROOTHelpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
