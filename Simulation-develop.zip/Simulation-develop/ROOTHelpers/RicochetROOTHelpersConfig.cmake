include(CMakeFindDependencyMacro)

find_dependency(ROOT 6.14 REQUIRED COMPONENTS tree)
find_dependency(Geant4 REQUIRED)

if(NOT TARGET Ricochet::ROOTHelpers)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetROOTHelpersTargets.cmake")
endif()
