#include "Event/StepRecorder.hh"

/// Geant4 includes
#include "G4VProcess.hh"

namespace Event
{

    void StepRecorder::InitTree(TFile& file)
    {
        mFile = &file;
        mStepTree = new TTree("StepTree", "Recorded StepEvent tree", 99, mFile);
        mStepEventsPtr = &mStepEvents;
        
        mStepTree->Branch("StepEvent", &mStepEventsPtr);
    }

    void StepRecorder::SetRecordingParentStep(bool option)
    {
        mRecordCreationVertex = option;
    }


    void StepRecorder::ProcessStep(const G4Step* step)
    {
        bool cutPassed = false;
        for(StepSelectionPtr& selection : mSelections)
        {
            if(selection->PassSelection(step))
            {
                cutPassed = true;
                break;
            }
        }

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());
        const G4StepPoint& postStep = *(step->GetPostStepPoint());

        G4StepStatus preStatus  = preStep.GetStepStatus();
        G4StepStatus postStatus = postStep.GetStepStatus();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(cutPassed && preStatus == G4StepStatus::fGeomBoundary) /// Test if particle is entering in a new volume
        {
            RecordEnterVolumeStep(step);
        }
        else if(preStatus == G4StepStatus::fUndefined && track.GetCurrentStepNumber() == 1) /// Test if particle has been created
        {
            RecordCreationStep(step, cutPassed, mRecordCreationVertex);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(postStatus == G4StepStatus::fPostStepDoItProc || postStatus == G4StepStatus::fAlongStepDoItProc || postStatus == G4StepStatus::fAtRestDoItProc) /// Test if particle have done a discrete process
        {
            RecordProcessStep(step, cutPassed, mRecordCreationVertex);
        }
        else if(cutPassed && postStatus == G4StepStatus::fGeomBoundary)  /// Test if particle is exiting a volume
        {
            RecordQuitVolumeStep(step);
        }
        else if(cutPassed && postStatus == G4StepStatus::fWorldBoundary) /// Test if particle is exiting the world
        {
            RecordQuitWorldStep(step);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(cutPassed && track.GetTrackStatus() == G4TrackStatus::fStopAndKill)
        {
            RecordKillStep(step);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        if(mRecordCreationVertex)
        {
            if(cutPassed)
            {
                mStepNodeManager.NotifyValidChild(track);
            }

            if(track.GetTrackStatus() == G4TrackStatus::fStopAndKill && step->GetSecondaryInCurrentStep()->size() == 0)
            {
                mStepNodeManager.NotifyEndOfBranch(track);
            }
        }
    }

    void StepRecorder::RecordCreationStep(const G4Step* step, bool recordStep, bool recordNode)
    {
        SimuOutput::StepEvent event;

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();
        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0)
        {
            event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));
        }
	event.Time = track.GetGlobalTime();
        event.Ekin = preStep.GetKineticEnergy();

        G4ThreeVector momentum = preStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.Edep = 0;
        event.ProcName = "ParticleCreated";
        event.Volume = preStep.GetPhysicalVolume()->GetName();
        event.Material = preStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        G4ThreeVector position = preStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};

        if(recordStep) mStepEvents.emplace_back(event);

        if(recordNode)
        {
            mStepNodeManager.AddNode(event, track, {}, recordStep);
        }
    }

    void StepRecorder::RecordEnterVolumeStep(const G4Step* step)
    {
        mStepEvents.emplace_back();
        auto& event = mStepEvents.back();

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();
        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0) event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));
	event.Time = track.GetGlobalTime();
        event.Ekin = preStep.GetKineticEnergy();

        G4ThreeVector momentum = preStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.Edep = 0;
        event.ProcName = "EnterVolume";
        event.Volume = preStep.GetPhysicalVolume()->GetName();
        event.Material = preStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        G4ThreeVector position = preStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};
    }

    void StepRecorder::RecordProcessStep(const G4Step* step, bool recordStep, bool recordNode)
    {
        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& postStep = *(step->GetPostStepPoint());


        SimuOutput::StepEvent event;

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();

        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0)
        {
            event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));
        }
	event.Time = track.GetGlobalTime();
        event.Ekin = postStep.GetKineticEnergy();

        G4ThreeVector momentum = postStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.ProcName = postStep.GetProcessDefinedStep()->GetProcessName();
        event.Edep = step->GetTotalEnergyDeposit();

        G4ThreeVector position = postStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};

        event.Volume = postStep.GetPhysicalVolume()->GetName();
        event.Material = postStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        const std::vector<const G4Track*>& secondaries = *(step->GetSecondaryInCurrentStep());
        for(const G4Track* trackSec : secondaries)
        {
            event.SecondaryPDGs.push_back(trackSec->GetParticleDefinition()->GetPDGEncoding());
            mfStoreParentStepID(mfMakeParentIndex(event.TrackID, trackSec->GetDynamicParticle()), event.StepID);
        }

        if(recordStep) mStepEvents.emplace_back(event);

        if(recordNode && secondaries.size() > 0)
        {
            mStepNodeManager.AddNode(event, track, secondaries, recordStep);
        }
    }

    void StepRecorder::RecordQuitVolumeStep(const G4Step* step)
    {
        mStepEvents.emplace_back();
        auto& event = mStepEvents.back();

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());
        const G4StepPoint& postStep = *(step->GetPostStepPoint());

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();
        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0) event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));
	event.Time = track.GetGlobalTime();
        event.Ekin = postStep.GetKineticEnergy();

        G4ThreeVector momentum = postStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.Edep = step->GetTotalEnergyDeposit();
        event.ProcName = "QuitVolume";
        event.Volume = preStep.GetPhysicalVolume()->GetName();
        event.Material = preStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        G4ThreeVector position = postStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};
    }

    void StepRecorder::RecordQuitWorldStep(const G4Step* step)
    {
        mStepEvents.emplace_back();
        auto& event = mStepEvents.back();

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());
        const G4StepPoint& postStep = *(step->GetPostStepPoint());

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();
        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0) event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));

	event.Time = track.GetGlobalTime();
        event.Ekin = postStep.GetKineticEnergy();

        G4ThreeVector momentum = postStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.Edep = step->GetTotalEnergyDeposit();
        event.ProcName = "QuitWorld";
        event.Volume = preStep.GetPhysicalVolume()->GetName();
        event.Material = preStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        G4ThreeVector position = postStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};
    }

    void StepRecorder::RecordKillStep(const G4Step* step)
    {
        mStepEvents.emplace_back();
        auto& event = mStepEvents.back();

        const G4Track& track = *(step->GetTrack());
        const G4StepPoint& preStep = *(step->GetPreStepPoint());
        const G4StepPoint& postStep = *(step->GetPostStepPoint());

        event.StepID = mfGetUniqueStepID();
        event.TrackID = track.GetTrackID();
        event.ParticlePDG = track.GetParticleDefinition()->GetPDGEncoding();
        event.ParentStepID = track.GetParentID();
        if(event.ParentStepID != 0) event.ParentStepID = mfGetParentStepID(mfMakeParentIndex(track.GetParentID(), track.GetDynamicParticle()));
	event.Time = track.GetGlobalTime();
        event.Ekin = postStep.GetKineticEnergy();

        G4ThreeVector momentum = postStep.GetMomentum();
        event.Momentum = {momentum.x(), momentum.y(), momentum.z()};

        event.Edep = 0;
        event.ProcName = "ParticleKilled";
        event.Volume = preStep.GetPhysicalVolume()->GetName();
        event.Material = preStep.GetPhysicalVolume()->GetLogicalVolume()->GetMaterial()->GetName();

        G4ThreeVector position = postStep.GetPosition();
        event.Position = {float(position.x()), float(position.y()), float(position.z())};
    }

    bool StepRecorder::RecordedEvents() const
    {
        return mStepNodeManager.SelectedSteps();
    }

    void StepRecorder::FillEvent()
    {
        mStepEventsPtr = &mStepEvents;
        const auto& steps = mStepNodeManager.GetSelectedSteps();
        mStepEvents.insert(mStepEvents.end(), steps.begin(), steps.end());

        struct StepEventSorter
        {
            bool operator()(const SimuOutput::StepEvent& a, const SimuOutput::StepEvent b)
            {
                return a.StepID < b.StepID;
            }
        } stepSorter;
        std::sort(mStepEvents.begin(), mStepEvents.end(), stepSorter);

        mStepTree->Fill();

        ResetEvent();
    }

    void StepRecorder::ResetEvent()
    {
        mStepIDCounter = 0;
        mStepEvents.clear();
        mParentStepIDs.clear();

        mStepNodeManager.Reset();
    }

    void StepRecorder::Save()
    {
        mFile->cd();
        mStepTree->Write("", TFile::kOverwrite);
    }


    int32_t StepRecorder::mfGetUniqueStepID()
    {
        return ++mStepIDCounter;
    }

    void StepRecorder::mfStoreParentStepID(const StepRecorder::ParentSecondaryIndex& index, int32_t parentStepID)
    {
        mParentStepIDs[index] = parentStepID;
    }

    int32_t StepRecorder::mfGetParentStepID(const StepRecorder::ParentSecondaryIndex& index)
    {
        if(mParentStepIDs.find(index) != mParentStepIDs.end()) return mParentStepIDs[index];
        else return -1;
    }

}
