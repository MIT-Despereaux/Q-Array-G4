#include "Event/SteppingAction.hh"
#include "Event/StepRecorder.hh"
#include "G4Step.hh"

namespace Event
{

    SteppingAction::SteppingAction()
    : G4UserSteppingAction()
    { }

    void SteppingAction::UserSteppingAction(const G4Step* step)
    {
      // Register First Track Time; 
      const G4Track& track = *(step->GetTrack());
      if (track.GetTrackID() == 1) {
	firsttracktime = track.GetGlobalTime();
      }
        if(fStepRecorder) fStepRecorder->ProcessStep(step);
    }
  
  double SteppingAction::GetFirstTrackTime()
  {
    double time = firsttracktime;
    return time; 
  }

  void SteppingAction::SetStepRecorder(StepRecorder& stepRecorder)
  {
    fStepRecorder = &stepRecorder;
  }

}
