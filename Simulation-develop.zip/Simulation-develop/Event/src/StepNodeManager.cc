#include "Event/StepNodeManager.hh"

/// Standard includes

/// Geant4 includes
#include "G4Track.hh"

/// Project includes
#include "SimuOutput/StepEvent.hh"

namespace Event
{

    StepNode::StepNode(const SimuOutput::StepEvent &step, bool trackAlive, StepNode *parent, bool alreadySaved) :
        Step(new SimuOutput::StepEvent(step)), Parent(parent), SavedOutsiteIteration(alreadySaved), TrackBegining(step.ProcName == "ParticleCreated"), Count(static_cast<int>(step.SecondaryPDGs.size()) + trackAlive)
    {

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    void StepNodeManager::AddNode(const SimuOutput::StepEvent& step, const G4Track& track, const std::vector<const G4Track*>& secondaries, bool alreadySaved)
    {
        bool particleCreated = (step.ProcName == "ParticleCreated"); /// otherwise it is an interaction
        bool trackAlive = (track.GetTrackStatus() != fStopAndKill) || particleCreated;

        int parentNodeTrackID = ((particleCreated) ? track.GetParentID() : track.GetTrackID());
        ParentSecondaryIndex parentIndex = mfMakeParentIndex(parentNodeTrackID, track.GetDynamicParticle());

        std::unique_ptr<StepNode> node(new StepNode(step, trackAlive, mfGetParentStepNode(parentIndex), alreadySaved));
        StepNode* node_ptr = node.get();
        mStepNodes[node_ptr] = std::move(node);

        for(const G4Track* trackSec : secondaries)
        {
            mfStoreParentStepNode(mfMakeParentIndex(step.TrackID, trackSec->GetDynamicParticle()), node_ptr);
        }

        mfStoreParentStepNode(mfMakeParentIndex(step.TrackID, track.GetDynamicParticle()), node_ptr);
    }

    void StepNodeManager::NotifyValidChild(const G4Track& track)
    {
        StepNode* node = mfGetParentStepNode(mfMakeParentIndex(track.GetTrackID(), track.GetDynamicParticle()));
        if(node)
        {
            node->ValidChild = true;
            node->ValidForSaving = true;
        }
    }

    void StepNodeManager::NotifyEndOfBranch(const G4Track& track)
    {
        ParentSecondaryIndex parentIndex = mfMakeParentIndex(track.GetTrackID(), track.GetDynamicParticle());
        StepNode* node = mfGetParentStepNode(parentIndex);
        mfRemoveParentStepNode(parentIndex);
        if(node)
        {
            mfIterStepNodes(*node, true);
        }
    }

    bool StepNodeManager::SelectedSteps() const
    {
        return !mSelectedSteps.empty();
    }

    const std::vector<SimuOutput::StepEvent>&StepNodeManager::GetSelectedSteps() const
    {
        return mSelectedSteps;
    }

    void StepNodeManager::Reset()
    {
        mStepNodes.clear();
        mParentStepNodes.clear();
        mSelectedSteps.clear();
    }

    void StepNodeManager::mfClearChildAndFollowParent(StepNode& node)
    {
        node.Step.reset(); /// free step memory
        StepNode* parent = node.Parent;
        mfRemoveStepNode(node);
        if(parent)
        {
            parent->Count--;
            mfIterStepNodes(*parent);
        }
    }

    void StepNodeManager::mfIterStepNodes(StepNode& node, bool trackKilled)
    {
        if(trackKilled) node.Count--;

        if(node.ValidChild && node.TrackBegining) node.ValidForSaving = true;
        if(node.ValidForSaving) node.ValidChild = true;

        if(node.Parent && node.ValidChild)
        {
            node.Parent->ValidChild = true;
            if(node.Parent->Step) node.Parent->ValidForSaving = true; /// allow saving only on new vertex
        }

        if(node.ValidForSaving && !node.IsSaved) /// avoid saving two times the step
        {
            if(!node.SavedOutsiteIteration)
            {
                mSelectedSteps.push_back(std::move(*(node.Step.release())));
            }
            node.IsSaved = true;
        }
        if(node.Count == 0) mfClearChildAndFollowParent(node);
    }

    void StepNodeManager::mfStoreParentStepNode(ParentSecondaryIndex index, StepNode* parentNode)
    {
        mParentStepNodes[index] = parentNode;
    }

    StepNode* StepNodeManager::mfGetParentStepNode(ParentSecondaryIndex index)
    {
        if(mParentStepNodes.find(index) != mParentStepNodes.end()) return mParentStepNodes[index];
        else return nullptr;
    }

    void StepNodeManager::mfRemoveParentStepNode(ParentSecondaryIndex index)
    {
        mParentStepNodes.erase(index);
    }

    bool StepNodeManager::mfSearchNode(StepNode& node)
    {
        return mStepNodes.find(&node) != mStepNodes.end();
    }

    void StepNodeManager::mfRemoveStepNode(StepNode& node)
    {
        mStepNodes.erase(&node);
    }

}
