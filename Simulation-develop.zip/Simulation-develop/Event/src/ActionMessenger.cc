#include "Event/ActionMessenger.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithAnInteger.hh"

namespace Event
{

    void ActionCommandsCreator::Initialise(ActionMessenger& messenger)
    {
        messenger.AddCommand<G4UIcmdWithAnInteger>("verbose", "Event::Action's verbosity",
                [](auto& eventAction, const std::string& macroArg){eventAction.SetVerbose(std::stoi(macroArg));});
        messenger.AddCommand<G4UIcmdWithAString>("TriggerStrategy", "Which events should be written to disk (All, Hits, Steps)",
                &Action::SetTriggerStrategy);
        messenger.AddCommand<G4UIcmdWithAnInteger>("ReportEvents", "Print progress and time every N events.",
                [](auto& eventAction, const std::string& macroArg){eventAction.SetReportEvents(std::stoi(macroArg));});
	messenger.AddCommand<G4UIcmdWithAnInteger>("FirstEventNumber", "Set first event number. ",
						    [](auto& eventAction, const std::string& macroArg){eventAction.SetFirstEventNumber(std::stoi(macroArg));});
    }

}
