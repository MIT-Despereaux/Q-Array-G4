#include "Event/StepSelection.hh"

/// Standard includes

namespace Event
{

    StepSelectionParticle::StepSelectionParticle(const std::string& particleName) : mParticleName(particleName) {}

    bool StepSelectionParticle::PassSelection(const G4Step* step)
    {
        std::string currentParticleName = step->GetTrack()->GetParticleDefinition()->GetParticleName();
        return currentParticleName == mParticleName;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    StepSelectionMaterial::StepSelectionMaterial(const std::string& materialName, const std::vector<std::string> particleNames) : mMaterialName(materialName)
    {
        mParticleNames.reserve(particleNames.size());
        for(const std::string& particleName: particleNames)
        {
            mParticleNames.emplace_back(particleName);
        }

        if(mParticleNames.empty()) mParticleNames.emplace_back(".*");
    }

    bool StepSelectionMaterial::PassSelection(const G4Step* step)
    {
        G4StepPoint* prePoint = step->GetPreStepPoint();
        std::string materialNamePre = ((prePoint->GetMaterial()) ? prePoint->GetMaterial()->GetName() : "");

        if(materialNamePre != mMaterialName)
        {
            return false;
        }

        std::string currentParticleName = step->GetTrack()->GetParticleDefinition()->GetParticleName();

        for(const std::regex& regexParticle: mParticleNames)
        {
            if(std::regex_match(currentParticleName, regexParticle)) return true;
        }

        return false;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    StepSelectionVolume::StepSelectionVolume(const std::string& volumeRegex, const std::vector<std::string> particleNames) : mVolumeName(volumeRegex)
    {
        mParticleNames.reserve(particleNames.size());
        for(const std::string& particleName: particleNames)
        {
            mParticleNames.emplace_back(particleName);
        }

        if(mParticleNames.empty()) mParticleNames.emplace_back(".*");
    }

    bool StepSelectionVolume::PassSelection(const G4Step* step)
    {
        G4StepPoint* prePoint = step->GetPreStepPoint();
        std::string volumeNamePre = ((prePoint->GetPhysicalVolume()) ? prePoint->GetPhysicalVolume()->GetName() : "");

        if(!std::regex_match(volumeNamePre, mVolumeName)) return false;

        std::string currentParticleName = step->GetTrack()->GetParticleDefinition()->GetParticleName();

        for(const std::regex& regexParticle: mParticleNames)
        {
            if(std::regex_match(currentParticleName, regexParticle)) return true;
        }

        return false;
    }

}
