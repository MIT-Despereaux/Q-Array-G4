#include "Event/StepTrigger.hh"
#include "Event/StepRecorder.hh"

namespace Event
{

    StepTrigger::StepTrigger(StepRecorder& stepRecorder_)
    :stepRecorder(stepRecorder_)
    {}

    void StepTrigger::Reset()
    {}

    void StepTrigger::NotifyHits()
    {}

    bool StepTrigger::Pass()
    {
        return stepRecorder.RecordedEvents();
    }

}
