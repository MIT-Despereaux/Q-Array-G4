#include "Event/StepRecorderMessenger.hh"

/// Standard includes
#include <algorithm>
#include <sstream>
#include <iterator>

/// Geant4 includes
#include "G4SystemOfUnits.hh"

/// Project includes
#include "Event/StepRecorder.hh"
#include "Event/StepSelection.hh"

namespace Event
{

    StepRecorderMessenger::StepRecorderMessenger(StepRecorder& stepRecorder, std::string cmdPrefixPath) : mStepRecorder(stepRecorder)
    {
        if(cmdPrefixPath.back() != '/') cmdPrefixPath.push_back('/');
        mCmdDir.reset(new G4UIdirectory(cmdPrefixPath.c_str()));
        mCmdDir->SetGuidance("StepRecorder command directory");

        //    mCmdVerbose.reset(new G4UIcmdWithAnInteger((cmdPrefixPath + "verbose").c_str(), this));
        //    mCmdVerbose->SetGuidance("Set verbosee level of Run Action");
        //    mCmdVerbose->SetParameterName("val",false);
        //    mCmdVerbose->SetRange("val>=0");
        //    mCmdVerbose->AvailableForStates(G4State_Idle);

        mCmdSelectionParticle.reset(new G4UIcmdWithAString((cmdPrefixPath + "AddSelectionParticle").c_str(), this));
        mCmdSelectionParticle->SetGuidance("Enable step recorder and add a selection criteria for recording based on the tracked particle name");
        mCmdSelectionParticle->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdSelectionMaterial.reset(new G4UIcmdWithAString((cmdPrefixPath + "AddSelectionMaterial").c_str(), this));
        mCmdSelectionMaterial->SetGuidance("Enable step recorder and add a selection criteria for recording based on material name (and particle names)");
        mCmdSelectionMaterial->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdSelectionVolume.reset(new G4UIcmdWithAString((cmdPrefixPath + "AddSelectionVolume").c_str(), this));
        mCmdSelectionVolume->SetGuidance("Enable step recorder and add a selection criteria for recording based on volume name (and particle names)");
        mCmdSelectionVolume->AvailableForStates(G4State_PreInit, G4State_Idle);

        mCmdVertexTree.reset(new G4UIcmdWithABool((cmdPrefixPath + "RecordParentStep").c_str(), this));
        mCmdVertexTree->SetGuidance("Enable parent vertex step recording for selected steps");
        mCmdVertexTree->AvailableForStates(G4State_PreInit, G4State_Idle);
    }

    bool StepRecorderMessenger::GetActivationStatus() const
    {
        return mStepRecorderActivated;
    }

    void StepRecorderMessenger::SetNewValue(G4UIcommand* command, G4String newValue)
    {

        /// Split arguments delimited by space
        auto SplitArgString = [&]
        {
            std::istringstream iss(newValue);
            return std::vector<std::string>{std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};
        };

        //    if(command == mCmdVerbose.get())
        //    {
        //        mStepRecorder.SetVerbose(mCmdVerbose->GetNewIntValue(newValue));
        //    }
        if(command == mCmdSelectionParticle.get())
        {
            mStepRecorderActivated = true;

            mStepRecorder.AddSelection(StepSelectionParticle(newValue));

        }
        else if(command == mCmdSelectionMaterial.get())
        {
            mStepRecorderActivated = true;

            std::vector<std::string> args = SplitArgString();

            std::string materialName = args[0];
            std::vector<std::string> particleNames{args.begin() + 1, args.end()};

            mStepRecorder.AddSelection(StepSelectionMaterial(materialName, particleNames));

        }
        else if(command == mCmdSelectionVolume.get())
        {
            mStepRecorderActivated = true;

            std::vector<std::string> args = SplitArgString();

            std::string volumeName = args[0];
            std::vector<std::string> particleNames{args.begin() + 1, args.end()};

            mStepRecorder.AddSelection(StepSelectionVolume(volumeName, particleNames));
        }
        else if(command == mCmdVertexTree.get())
        {
            mStepRecorder.SetRecordingParentStep(mCmdVertexTree->ConvertToBool(newValue));
        }
    }

}
