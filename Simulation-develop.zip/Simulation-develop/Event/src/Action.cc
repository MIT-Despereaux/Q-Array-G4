#include <iostream>
#include <time.h>

#include "Event/Action.hh"
#include "Geometry/Hit.hh"

#include "G4Event.hh"
#include "G4RunManager.hh"
#include "CLHEP/Units/SystemOfUnits.h"
#include "G4TransportationManager.hh"
#include "G4SDManager.hh"

#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "TMacro.h"
#include <sstream>

#include "SimuOutput/SimuTreeWriter.hh"
#include "SimuOutput/VolumeHasher.hh"
#include "Event/AllTrigger.hh"
#include "Event/HitTrigger.hh"
#include "Event/StepTrigger.hh"
#include "Event/StepAndHitTrigger.hh"
#include "Event/StepRecorder.hh"

namespace Event
{
 
  void DummyFonction(const G4Event& event)
  {
  }

  
  void PrintEventNumbers(const G4Event& event, G4int evtnum, std::ostream& output)
    {
      output<<"G4Event ID/Ricochet EvtNum "<<event.GetEventID()  << "/" << evtnum << " nb Primary : "<<event.GetNumberOfPrimaryVertex()<<" :" <<std::endl;
      
    }

    void PrintPrimaryInfo(const SimuOutput::PrimaryEvent& particle, std::ostream& output)
    {
        CLHEP::Hep3Vector momentumDirection{particle.Px, particle.Py, particle.Pz};
        momentumDirection /= particle.Momentum();
        output <<  "E("
        << particle.ParticleName() << ") =\t"
        << particle.E
        << "\n  StartPosition: " << particle.Position
        << "\n  MomentumDir: " << momentumDirection
        << "----"
        << std::endl;
    }
    

    // adding a function to write informations about the geometry volumes
    void Event::Action::WriteGeometryTable()
    {
        TMacro geomTable("geometryTable");
        std::stringstream ss;

        auto volumeStore = G4PhysicalVolumeStore::GetInstance();

        // Accumulate total mass per material (in kg)
        std::map<std::string, double> materialMassTotals;
        double grandTotal = 0.0;

        // Header (optional)
        geomTable.AddLine("# VolumeName  Mass_kg  MaterialName");

        for(auto itr = volumeStore->begin(); itr != volumeStore->end(); ++itr)
        {
            auto* phys = *itr;
            auto* log = phys->GetLogicalVolume();
            auto* mat = log->GetMaterial();

            double massKg = log->GetMass(false,false) / CLHEP::kg;

            // Per-volume line
            ss.str("");
            ss.clear();
            ss << phys->GetName() << ' '
               << massKg << ' '
               << mat->GetName();
            geomTable.AddLine(ss.str().c_str());

            // Accumulate per material
            materialMassTotals[mat->GetName()] += massKg;
            grandTotal += massKg;
        }

        // Blank separator
        geomTable.AddLine("");
        geomTable.AddLine("# Per-material totals (kg)");
        for(const auto& kv : materialMassTotals)
        {
            ss.str("");
            ss.clear();
            ss << "TOTAL_MASS " << kv.first << ' ' << kv.second;
            geomTable.AddLine(ss.str().c_str());
        }

        ss.str("");
        ss.clear();
        ss << "GRAND_TOTAL_MASS " << grandTotal;
        geomTable.AddLine(ss.str().c_str());

        geomTable.Write();
    }

    void SetPrimaryVolumeInfo(const G4PrimaryVertex& primaryVertex, SimuOutput::PrimaryEvent& primary)
    {
        auto position = primaryVertex.GetPosition();
	Geometry::SetCoordinates(primary.Position, position.x(), position.y(), position.z());
	// added CG - 25/02/2025 
	primary.Time = primaryVertex.GetT0();
        auto navigator = G4TransportationManager::GetTransportationManager()->GetNavigatorForTracking();
        G4LogicalVolume* lVolume = navigator->LocateGlobalPointAndSetup(position, nullptr, false, false)->GetLogicalVolume();
        primary.VolumeID = SimuOutput::VolumeHasher::Hash(lVolume->GetName());
        primary.MaterialName = lVolume->GetMaterial()->GetName();
    }

    void SetPrimaryParticleInfo(const G4PrimaryParticle& primaryParticle, SimuOutput::PrimaryEvent& primary)
    {
      primary.PDG = primaryParticle.GetPDGcode();
      primary.Px = primaryParticle.GetMomentum().x();
      primary.Py = primaryParticle.GetMomentum().y();
      primary.Pz = primaryParticle.GetMomentum().z();
      primary.E = primaryParticle.GetTotalEnergy();
    }

    void SetPrimaryInfo(const G4PrimaryVertex& primaryVertex, SimuOutput::PrimaryEvent& primary)
    {
      SetPrimaryVolumeInfo(primaryVertex, primary);
      G4PrimaryParticle& primaryParticle = *primaryVertex.GetPrimary();
      SetPrimaryParticleInfo(primaryParticle, primary);
    }

    bool Action::MustPrintDetails(const G4Event& event) const
    {
        return (event.GetEventID()%1000==0 && fVerbose>0) || fVerbose > 1;
    }
    
    void Action::CopyPrimaries(const G4Event* event)
    {
      uint num  = event->GetNumberOfPrimaryVertex() ;
      // if (num > 1)  num =1;
      fSimuEvent->SetNumberOfPrimaries(num);
      for(int i = 0; i < event->GetNumberOfPrimaryVertex() ; ++i)
        {
	  auto& primary = fSimuEvent->PrimaryEvents[i];
	  SetPrimaryInfo(*event->GetPrimaryVertex(i), primary);
	  if(MustPrintDetails(*event)) PrintPrimaryInfo(primary, std::cout);
        }
    }

    void Action::AddHitCollection(const Geometry::HitsCollection& hitCollection)
    {
        for(auto hitPtr : hitCollection)
        {
            if(fVerbose>1)
            {
                std::cout<<"Event::Action process:\n";
                hitPtr->Print();
            }
            fSimuEvent->AddHit(hitPtr->GetDetectorID(), hitPtr->GetDetectorSID(),Geometry::Convert(*hitPtr));
        }
    }

  void Action::WriteEvent(const G4Event *event)
  {

    int nprim =  (int)event->GetNumberOfPrimaryVertex() ;
    int ndet = fSimuEvent->DetectorEvents.size();
    int ntop = fSimuEvent->TopScintEvents.size();
    int nside = fSimuEvent->SideScintEvents.size();
    int ncryo = fSimuEvent->CryoScintEvents.size();
    int nother = fSimuEvent->OtherEvents.size();

    //

    fSimuEvent->EvtNum = GetEventNumber(event);
    fSimuEvent->nDet = ndet;
    fSimuEvent->nPrim = nprim;
    fSimuEvent->nTop = ntop;
    fSimuEvent->nSide = nside;
    fSimuEvent->nCryo = ncryo;
    fSimuEvent->nOther = nother; 
    // Complete detector events
    for (int idet = 0;idet<ndet;idet++) {
      float energy = (fSimuEvent->DetectorEvents[idet]).Energy();
      (fSimuEvent->DetectorEvents[idet]).DetectorE = energy;
      float e_nuclear, e_electronic;
      (fSimuEvent->DetectorEvents[idet]).Epartition(e_nuclear,e_electronic);
      (fSimuEvent->DetectorEvents[idet]).DetectorER = e_electronic;
      (fSimuEvent->DetectorEvents[idet]).DetectorNR = e_nuclear;
    }
    for (int itop = 0;itop<ntop;itop++) {
      float energy = (fSimuEvent->TopScintEvents[itop]).Energy();
      (fSimuEvent->TopScintEvents[itop]).DetectorE = energy;
      (fSimuEvent->TopScintEvents[itop]).DetectorER = 0.;
      (fSimuEvent->TopScintEvents[itop]).DetectorNR = 0.;
    }
    for (int iside = 0;iside<nside;iside++) {
      float energy = (fSimuEvent->SideScintEvents[iside]).Energy();
      (fSimuEvent->SideScintEvents[iside]).DetectorE = energy;
      (fSimuEvent->SideScintEvents[iside]).DetectorER = 0.;
      (fSimuEvent->SideScintEvents[iside]).DetectorNR = 0.;
    }
    for (int icryo = 0;icryo<ncryo;icryo++) {
      float energy = (fSimuEvent->CryoScintEvents[icryo]).Energy();
      (fSimuEvent->CryoScintEvents[icryo]).DetectorE = energy;
      (fSimuEvent->CryoScintEvents[icryo]).DetectorER = 0.;
      (fSimuEvent->CryoScintEvents[icryo]).DetectorNR = 0.;
    }
    for (int ioth = 0;ioth<nother;ioth++) {
      float energy = (fSimuEvent->OtherEvents[ioth]).Energy();
      (fSimuEvent->OtherEvents[ioth]).DetectorE = energy;
      (fSimuEvent->OtherEvents[ioth]).DetectorER = 0.;
      (fSimuEvent->OtherEvents[ioth]).DetectorNR = 0.;
    }
    // Retrieve timing information from SteppingAction in case of primary Radioactive Ions 
    // Generation
    int pdg = fSimuEvent->PrimaryEvents[0].PDG;
    // PDG coding for Ions
    if (pdg > 1000000000) {
      double t0_time = -1;
      t0_time =  fSteppingAction->GetFirstTrackTime() ;
      // Modify generation time in Primary events from 0 to time of the disintegration in ns 
      fSimuEvent->PrimaryEvents[0].Time = t0_time; 
    }
   
    

    fSimuTreeWriter->Fill();
    if (fStepRecorder) fStepRecorder->FillEvent();
  }


  Action::Action(const std::string& triggerStrategy, int verbosity)
    :fTriggerStrategy(triggerStrategy),
     fVerbose(verbosity), reportEvents(0),firstEvent(0)
  { }

  int Action::GetEventNumber(const G4Event* event)
  {
    int evnum;
    evnum = event->GetEventID() + firstEvent  ;
    return evnum;
  }
  
    void Action::BeginOfEventAction(const G4Event* event)
    {
      G4int evtNum = GetEventNumber(event);
        if (reportEvents>0 && event->GetEventID()%reportEvents == 0)
	  G4cout << ">>> G4Event ID/Ricochet EvtNum " << event->GetEventID() <<"/"<< evtNum 
               << " at " << GetLocalTime() << G4endl;

        if(MustPrintDetails(*event)) PrintEventNumbers(*event, evtNum, std::cout);
        fSimuTreeWriter->ResetEvent();
        if(fStepRecorder) fStepRecorder->ResetEvent();
	int num =  event->GetNumberOfPrimaryVertex() ;
	if (num == 0)  return;
	//if (num > 10) return;
	CopyPrimaries(event);
        if(fVerbose>0) std::cout << "exit BeginOfEventAction" <<std::endl;
    }

    void Action::SetHitCollectionsIDs()
    {
        if(fCollectionsIDs.empty()) fCollectionsIDs = Geometry::GetHitCollectionsIDs();
    }

    void Action::EndOfEventAction(const G4Event* evt)
    {
        if(fVerbose>0) std::cout << "enter EndOfEventAction" <<std::endl;
        SetHitCollectionsIDs();
        fTrigger->Reset();
        for(auto collectionID : fCollectionsIDs)
        {
            auto hcOfEvent = evt->GetHCofThisEvent();
            if (!hcOfEvent) break; // sécurité
            auto hitsBase = hcOfEvent->GetHC(collectionID);
            if(!hitsBase) continue;
            auto& hitCollection = *static_cast<const Geometry::HitsCollection*>(hitsBase);
            if(!Geometry::empty(hitCollection))
            {
                AddHitCollection(hitCollection);
                fTrigger->NotifyHits();
            }
        }
        const bool pass = fTrigger->Pass();
        if(pass) {
            WriteEvent(evt);
        }
      
        if(fVerbose>0) std::cout << "exit EndOfEventAction" <<std::endl;
    }

    void Action::SetSimuTreeWriter(SimuTreeWriter& simuTreeWriter)
    {
        fSimuTreeWriter = &simuTreeWriter;
        fSimuEvent = &(fSimuTreeWriter->GetSimuEventRef());
    }

    void Action::SetStepRecorder(StepRecorder& stepRecorder)
    {
        fStepRecorder = &stepRecorder;
    }

  void Action::SetSteppingAction(SteppingAction& steppingAction)
    {
        fSteppingAction = &steppingAction;
    }

  
    void Action::SetTriggerStrategy(const std::string& strategyName)
    {
        fTriggerStrategy = strategyName;
    }

    void Action::SetupTriggerStrategy()
    {
        if(fTriggerStrategy == "All") fTrigger = std::make_unique<AllTrigger>();
        else if(fTriggerStrategy == "Hits") fTrigger = std::make_unique<HitTrigger>(); // Registers event if at least one hit occured in a sensitive volume
        else if(fTriggerStrategy == "Steps") // Registers event if the StepRecorder selection criterias are met
        {
            if(fStepRecorder) fTrigger = std::make_unique<StepTrigger>(*fStepRecorder);
            else throw std::logic_error("Trigger strategy set to '"+fTriggerStrategy+"' but StepRecorder uninitialised");
        }
	else if(fTriggerStrategy == "StepsAndHits") // Registers event if at least one hit occured in a sensitive volume and if the StepRecorder selection criterias are met
        {
            if(fStepRecorder) fTrigger = std::make_unique<StepAndHitTrigger>(*fStepRecorder);
            else throw std::logic_error("Trigger strategy set to '"+fTriggerStrategy+"' but StepRecorder uninitialised");
        }
        else throw std::logic_error("'"+fTriggerStrategy+"' is not a valid Event::Action trigger strategy");
    }

    void Action::InitialiseAction()
    {
        if(!fSimuTreeWriter)
            throw std::runtime_error("Event::Action::Initialise(): SimuTreeWriter uninitialised, call SetSimuTreeWriter first");
        SetupTriggerStrategy();
        WriteGeometryTable();
    }

    void Action::SetVerbose(int verbosity)
    {
        fVerbose = verbosity;
    }

    G4String Action::GetLocalTime() const {
    time_t now = time(0);
    struct tm tstruct;
    localtime_r(&now, &tstruct);

    char buf[80];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S %Z", &tstruct);
    return buf;
    
}


}
