#include "Event/StepAndHitTrigger.hh"
#include "Event/StepRecorder.hh"

namespace Event
{

    StepAndHitTrigger::StepAndHitTrigger(StepRecorder& stepRecorder_)
    :stepRecorder(stepRecorder_)
    {}

    void StepAndHitTrigger::Reset()
    {
        hadHits = false;
    }

    void StepAndHitTrigger::NotifyHits()
    {
        hadHits = true;
    }

    bool StepAndHitTrigger::Pass()
    {
        return stepRecorder.RecordedEvents() && hadHits;
    }

}
