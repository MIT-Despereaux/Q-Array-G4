#include "Event/HitTrigger.hh"

namespace Event
{

    void HitTrigger::Reset()
    {
        hadHits = false;
    }

    void HitTrigger::NotifyHits()
    {
        hadHits = true;
    }

    bool HitTrigger::Pass()
    {
        return hadHits;
    }

}
