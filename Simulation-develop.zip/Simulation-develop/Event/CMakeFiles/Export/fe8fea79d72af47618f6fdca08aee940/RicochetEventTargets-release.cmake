#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ricochet::Event" for configuration "Release"
set_property(TARGET Ricochet::Event APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ricochet::Event PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libRicochetEvent.so"
  IMPORTED_SONAME_RELEASE "libRicochetEvent.so"
  )

list(APPEND _cmake_import_check_targets Ricochet::Event )
list(APPEND _cmake_import_check_files_for_Ricochet::Event "${_IMPORT_PREFIX}/lib64/libRicochetEvent.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
