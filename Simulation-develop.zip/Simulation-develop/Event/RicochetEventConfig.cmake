include(CMakeFindDependencyMacro)

find_dependency(Geant4 REQUIRED)
find_dependency(RicochetGeometry REQUIRED)
find_dependency(RicochetSimuOutput REQUIRED)

if(NOT TARGET Ricochet::Event)
    include("${CMAKE_CURRENT_LIST_DIR}/RicochetEventTargets.cmake")
endif()
