﻿#ifndef STEPRECORDER_H
#define STEPRECORDER_H

/// Standard includes
#include <vector>
#include <regex>

/// Geant4 includes
#include "G4Step.hh"

/// ROOT includes
#include "TTree.h"
#include "TFile.h"

/// Project includes
#include "SimuOutput/StepEvent.hh"
#include "Event/StepSelection.hh"
#include "Event/StepNodeManager.hh"

namespace Event
{

    class StepRecorder
    {
    public:
        StepRecorder() = default;

        void InitTree(TFile& file);

        /// Define cuts to select steps to be saved
        template<class StepSelectionDerivedClass>
        void AddSelection(const StepSelectionDerivedClass& selection)
        {
            mSelections.emplace_back(new StepSelectionDerivedClass(selection));
        }

        /// Enable recording of vertex tree for saved steps
        void SetRecordingParentStep(bool option);

        /// Record step for one unit of "G4 event"
        void ProcessStep(const G4Step* step);
        void RecordCreationStep(const G4Step* step, bool recordStep = true, bool recordNode = false);
        void RecordEnterVolumeStep(const G4Step* step);
        void RecordProcessStep(const G4Step* step, bool recordStep = true, bool recordNode = false);
        void RecordQuitVolumeStep(const G4Step* step);
        void RecordQuitWorldStep(const G4Step* step);
        void RecordKillStep(const G4Step* step);

        /// Save steps to the tree in a single entry
        bool RecordedEvents() const;
        void FillEvent();
        void ResetEvent();

        /// Save tree
        void Save();

    private:
        using StepSelectionPtr = std::unique_ptr<StepSelection>;
        std::vector<StepSelectionPtr> mSelections;
        TFile* mFile{nullptr}; /// not owned by StepRecorder

        TTree* mStepTree{nullptr};
        std::vector<SimuOutput::StepEvent> mStepEvents;
        std::vector<SimuOutput::StepEvent>* mStepEventsPtr{&mStepEvents};
        int32_t mStepIDCounter{0};

        using ParentSecondaryIndex = std::pair<int32_t, const G4DynamicParticle*>;
        inline ParentSecondaryIndex mfMakeParentIndex(int32_t parentTrackID, const G4DynamicParticle* secondaryParticlePtr) { return {parentTrackID, secondaryParticlePtr}; }
        std::map<ParentSecondaryIndex, int32_t> mParentStepIDs;

        bool mRecordCreationVertex{false};
        StepNodeManager mStepNodeManager;

        int32_t mfGetUniqueStepID();
        void mfStoreParentStepID(const ParentSecondaryIndex& index, int32_t parentStepID);
        int32_t mfGetParentStepID(const ParentSecondaryIndex& index);
    };

}

#endif /// STEPRECORDER_H
