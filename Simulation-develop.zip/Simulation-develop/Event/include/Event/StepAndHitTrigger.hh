#ifndef RICOCHET_STEP_AND_HIT_TRIGGER_HH
#define RICOCHET_STEP_AND_HIT_TRIGGER_HH

#include "Event/Trigger.hh"

class StepRecorder;

namespace Event
{

    class StepAndHitTrigger : public Trigger
    {
        StepRecorder& stepRecorder;
	bool hadHits{false};
    public:
        StepAndHitTrigger(StepRecorder& stepRecorder_);
        void Reset();
        void NotifyHits();
        bool Pass();
    };

}

#endif /* RICOCHET_STEP_AND_HIT_TRIGGER_HH */
