#ifndef RICOCHET_EVENT_ACTION_HH
#define RICOCHET_EVENT_ACTION_HH

#include "G4UserEventAction.hh"
#include "Utility/Initialisable.hh"
#include "Event/Trigger.hh"
#include "Event/SteppingAction.hh"

class SimuTreeWriter;
class StepRecorder;
class SteppingAction;      

namespace SimuOutput
{
    class SimuEvent;
}

namespace Geometry
{
    struct HitsCollection;
}

namespace Event
{

    class Action : public G4UserEventAction, public Utility::Initialisable<Action>
    {
    public:
        friend Utility::Initialisable<Action>;
        Action(const std::string& triggerStrategy, int verbosity = 0);
        virtual void BeginOfEventAction(const G4Event* event);
        virtual void EndOfEventAction(const G4Event* event);
        void SetSimuTreeWriter(SimuTreeWriter& simuTreeWriter);
        void SetStepRecorder(StepRecorder& stepRecorder);
        void SetSteppingAction(SteppingAction& steppingAction);
        void SetTriggerStrategy(const std::string& strategyName);
        void SetVerbose(int verbosity);
        void SetReportEvents(int numEvents) {reportEvents = numEvents;};
        void SetFirstEventNumber(int firstev) {firstEvent = firstev;};
        int GetEventNumber(const G4Event* event);
        int GetFirstEventNumber(){return firstEvent;};
        void WriteGeometryTable();
        // Get local system time.
        G4String GetLocalTime() const;
    private:
        std::string fTriggerStrategy;
        int fVerbose;
        SimuTreeWriter* fSimuTreeWriter{nullptr};
        SimuOutput::SimuEvent* fSimuEvent{nullptr};
        StepRecorder* fStepRecorder{nullptr};
        SteppingAction* fSteppingAction{nullptr};
        std::vector<int> fCollectionsIDs;
        std::unique_ptr<Trigger> fTrigger{nullptr};
        void SetupTriggerStrategy();
        void InitialiseAction();
        bool MustPrintDetails(const G4Event& event) const;
        void CopyPrimaries(const G4Event* evt);//converts and copies G4 primaries to SimuOutput primaries
        void SetHitCollectionsIDs();//caches heavy retrieval of IDs (which are setup late by Geant4) into fCollectionsIDs
        //append to current SimuEvent; strategy specific to hitCollection class
        void AddHitCollection(const Geometry::HitsCollection& hitCollection);
        //actually fill the output with SimuTreeWriter
        void WriteEvent(const G4Event *evt);
        G4int reportEvents;
        G4int firstEvent;
    };

}

#endif
