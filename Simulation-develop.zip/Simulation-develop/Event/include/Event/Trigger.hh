/**************************************************************************
* @file Trigger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Jun 2021
* @brief Basic trigger interface. The Pass method is there to cache values
* set in the constructor or by Reset / NotifyHits.
* ************************************************************************/

#ifndef RICOCHET_EVENT_TRIGGER_HH
#define RICOCHET_EVENT_TRIGGER_HH

#include "Event/StepRecorder.hh"

namespace Event
{

    struct Trigger
    {
        virtual void Reset() = 0;
        virtual void NotifyHits() = 0;
        virtual bool Pass() = 0;
        virtual ~Trigger() = default;
    };

}

#endif /* RICOCHET_EVENT_TRIGGER_HH */
