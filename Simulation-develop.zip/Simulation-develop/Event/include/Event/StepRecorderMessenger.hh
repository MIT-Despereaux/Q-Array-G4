#ifndef STEPRECORDERMESSENGER_H
#define STEPRECORDERMESSENGER_H

#include <memory>

#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"

namespace Event
{

    class StepRecorder;

    class StepRecorderMessenger : public G4UImessenger
    {
    public:
        StepRecorderMessenger(StepRecorder& stepRecorder, std::string cmdPrefixPath = "/StepRecorder");

        bool GetActivationStatus() const;

        void SetNewValue(G4UIcommand* command, G4String newValue);

    private:

        StepRecorder& mStepRecorder;
        bool mStepRecorderActivated{false};

        std::unique_ptr<G4UIdirectory> mCmdDir;

        //      std::unique_ptr<G4UIcmdWithAnInteger> mCmdVerbose;

        std::unique_ptr<G4UIcmdWithAString> mCmdSelectionParticle;
        std::unique_ptr<G4UIcmdWithAString> mCmdSelectionMaterial;
        std::unique_ptr<G4UIcmdWithAString> mCmdSelectionVolume;

        std::unique_ptr<G4UIcmdWithABool> mCmdVertexTree;
    };

}

#endif /// STEPRECORDERMESSENGER_H
