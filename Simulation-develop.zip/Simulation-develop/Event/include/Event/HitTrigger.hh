/**************************************************************************
* @file HitTrigger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Jun 2021
* @brief Pass only for notified hits
* ************************************************************************/

#ifndef RICOCHET_EVENT_HITTRIGGER_HH
#define RICOCHET_EVENT_HITTRIGGER_HH

#include "Event/Trigger.hh"

namespace Event
{

    class HitTrigger : public Trigger
    {
        bool hadHits{false};
    public:
        void Reset();
        void NotifyHits();
        bool Pass();
    };

}

#endif /* RICOCHET_EVENT_HITTRIGGER_HH */
