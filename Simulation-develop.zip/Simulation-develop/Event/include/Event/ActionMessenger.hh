#ifndef RICOCHET_EVENT_ACTION_MESSENGER_HH
#define RICOCHET_EVENT_ACTION_MESSENGER_HH

#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"
#include "Event/Action.hh"

namespace Event
{

    DEFINE_COMMAND_PREFIXER(ActionCommandPrefixer, "/ricochetSim/event/")

    struct ActionCommandsCreator;
    using ActionMessenger = G4Helpers::InitialisablePathModifyingMessenger<Action, ActionCommandsCreator, ActionCommandPrefixer>;

    struct ActionCommandsCreator
    {
        static void Initialise(ActionMessenger& messenger);
    };

}

#endif
