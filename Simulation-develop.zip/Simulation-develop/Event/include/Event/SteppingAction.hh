#ifndef EVENT_STEPPINGACTION_H
#define EVENT_STEPPINGACTION_H

#include "G4UserSteppingAction.hh"

namespace Event
{
    class Action;
    class StepRecorder;

    class SteppingAction : public G4UserSteppingAction
    {
    public:
        SteppingAction();
        virtual ~SteppingAction() = default;
        virtual void UserSteppingAction(const G4Step* step);
        void SetStepRecorder(StepRecorder& stepRecorder);
        double GetFirstTrackTime();
    private:
      StepRecorder* fStepRecorder{nullptr};
      double firsttracktime;
    };

}

#endif
