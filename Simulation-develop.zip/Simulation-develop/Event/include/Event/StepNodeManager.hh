#ifndef STEPNODEMANAGER_H
#define STEPNODEMANAGER_H

/// Standard includes
#include <map>
#include <memory>
#include <vector>

namespace SimuOutput
{
    class StepEvent;
}
class G4Track;
class G4DynamicParticle;

namespace Event
{
    struct StepNode
    {
        StepNode(const SimuOutput::StepEvent& step, bool trackAlive, StepNode* parent = nullptr, bool alreadySaved = false);

        std::unique_ptr<SimuOutput::StepEvent> Step{nullptr};
        StepNode* Parent{nullptr};

        bool IsSaved{false};
        bool SavedOutsiteIteration{false};
        bool ValidChild{false};
        bool ValidForSaving{false};
        bool TrackBegining{false};
        int Count;
    };

    class StepNodeManager
    {
    public:
        StepNodeManager() = default;

        void AddNode(const SimuOutput::StepEvent& step, const G4Track& track, const std::vector<const G4Track*>& secondaries, bool alreadySaved);
        void NotifyValidChild(const G4Track& track);
        void NotifyEndOfBranch(const G4Track& track);

        const std::vector<SimuOutput::StepEvent>& GetSelectedSteps() const;
        bool SelectedSteps() const;

        void Reset();

    private:
        using ParentSecondaryIndex = std::pair<int32_t, const G4DynamicParticle*>;
        inline ParentSecondaryIndex mfMakeParentIndex(int32_t parentTrackID, const G4DynamicParticle* secondaryParticlePtr) { return {parentTrackID, secondaryParticlePtr};}

        std::vector<SimuOutput::StepEvent> mSelectedSteps;
        std::map<StepNode*, std::unique_ptr<StepNode>> mStepNodes;
        std::map<ParentSecondaryIndex, StepNode*> mParentStepNodes;

        void mfClearChildAndFollowParent(StepNode& node);
        void mfIterStepNodes(StepNode& node, bool trackKilled = false);
        void mfStoreParentStepNode(ParentSecondaryIndex index, StepNode* parentNode);
        StepNode* mfGetParentStepNode(ParentSecondaryIndex index);
        void mfRemoveParentStepNode(ParentSecondaryIndex index);
        void mfRemoveStepNode(StepNode& node);
        bool mfSearchNode(StepNode& node);

    };

}

#endif /// STEPNODEMANAGER_H
