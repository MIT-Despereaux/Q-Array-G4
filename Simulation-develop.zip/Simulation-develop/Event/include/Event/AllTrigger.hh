/**************************************************************************
* @file AllTrigger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Jun 2021
* @brief
* ************************************************************************/

#ifndef EVENT_ALLTRIGGER_HH
#define EVENT_ALLTRIGGER_HH

#include "Event/Trigger.hh"

namespace Event
{

    struct AllTrigger : Trigger
    {
        void Reset(){}
        void NotifyHits(){}
        bool Pass(){return true;}
    };

}


#endif /* EVENT_ALLTRIGGER_HH */
