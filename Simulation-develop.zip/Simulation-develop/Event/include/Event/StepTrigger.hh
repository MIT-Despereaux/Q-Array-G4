/**************************************************************************
* @file StepTrigger.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 17 Jun 2021
* @brief Pass if the StepRecorder selected steps for its last processed
* event
* ************************************************************************/

#ifndef RICOCHET_STEP_TRIGGER_HH
#define RICOCHET_STEP_TRIGGER_HH

#include "Event/Trigger.hh"

class StepRecorder;

namespace Event
{

    class StepTrigger : public Trigger
    {
        StepRecorder& stepRecorder;
    public:
        StepTrigger(StepRecorder& stepRecorder_);
        void Reset();
        void NotifyHits();
        bool Pass();
    };

}

#endif /* RICOCHET_STEP_TRIGGER_HH */
