#ifndef STEPSELECTION_H
#define STEPSELECTION_H

/// Standard includes
#include <string>
#include <vector>
#include <regex>

/// Geant4
#include "G4Step.hh"

namespace Event
{

    class StepSelection
    {
    public:
        StepSelection() = default;
        StepSelection(const StepSelection&) = default;
        StepSelection& operator=(const StepSelection&) = default;
        StepSelection(StepSelection&&) = default;
        StepSelection& operator=(StepSelection&&) = default;
        virtual ~StepSelection() = default;
        virtual bool PassSelection(const G4Step* step) = 0;
    };

    class StepSelectionParticle: public StepSelection
    {
    public:
        StepSelectionParticle(const std::string& particleName);

        bool PassSelection(const G4Step* step);

    private:
        std::string mParticleName;
    };

    class StepSelectionMaterial: public StepSelection
    {
    public:
        StepSelectionMaterial(const std::string& materialName, const std::vector<std::string> particleNames = {".*"});

        bool PassSelection(const G4Step* step);
    private:
        std::string mMaterialName;
        std::vector<std::regex> mParticleNames;
    };

    class StepSelectionVolume: public StepSelection
    {
    public:
        StepSelectionVolume(const std::string& volumeRegex, const std::vector<std::string> particleNames = {".*"});

        bool PassSelection(const G4Step* step);

    private:
        std::regex mVolumeName;
        std::vector<std::regex> mParticleNames;
    };

}

#endif /// STEPSELECTION_H
