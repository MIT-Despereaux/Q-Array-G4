# RicochetSimulation

Simulation code of Ricochet


## Initialising or updating submodule components

You may install modules such as SimuOutput (mandatory) or CRY (optional) utilising their own repositories. Alternatively, clone this repository with the submodules option, i.e.
```
git clone --recurse-submodules git@gitlab.in2p3.fr:ricochet/Simulation.git
```
From an existing repository, initialise the submodules with
```
git submodule update --init --recursive
```
If you want to update the submodules to the latest commit on master, you can run:
```
git submodule update --remote --merge
```


## Requirements

Root 6.16 or above is mandatory (due to dictionary generation and `enum` compression settings).

Geant4 10.2 or above (need CLHEP 2.3.3.0 or above for correct `constexpr` usage).

Make sure that you installed ROOT and Geant4 with CMake, so that the right `PackageConfig.cmake` files can be found by CMake (edit `CMAKE_PREFIX_PATH` as needed or pass the directories containing these files when executing `cmake`).


## Configure

Change to a temporary build folder (you should not pollute the source folder with build files).
To specify your install prefix and build CRY (for instance), issue from the build folder
```
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/path/to/installation -DWITH_CRY=ON /path/to/ricochetsim
```
If you use the Ninja build system, you may force coloured compiler output for Clang or GCC, a typical configure call from an out-of-source build folder would look like:
```
cmake -GNinja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_INSTALL_PREFIX=/path/to/installation -DFORCE_COLOURED_OUTPUT=ON /path/to/ricochetsim
```
If you decided to clone the repository without submodules and instead installed SimuOutput (mandatory) and CRY (optional) separately, you need to set the configuration accordingly:
```
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/path/to/installation -DWITH_CRY=ON -DWITH_SUBMODULES=OFF /path/to/ricochetsim
```


## Build and install

From the build folder:
```
cmake --build . --target install
```

No need to pollute `LD_LIBRARY_PATH` with ROOT or Geant4 libraries, the `RUNPATH` is embedded correctly into the executable upon installation. Installation is mandatory, should you need to link your analyser against libraries built herein, e.g. `SimuOutput`.

### GitLab CI
There is a GitLab Continuous Integration (CI) job that monitors the `develop` and `master` branches. For any new push to these branches, a test build is done. After the build has completed successfully, some simple execution tests are performed. Developers who triggered the CI will be notified via email about the outcome of the automatic build and execution test.


## Run
To run a given macro simply execute:
```
./RicochetSimulation macro.mac
```

### Visualisation
Classic visualisation macros are provided under `macros/`, feel free to append these visualisation commands to your macro, i.e. type
```
./bin/RicochetSimulation share/macros/{,vis}Lyon.mac

```
NB: If you close the visualiser window with the "X" top button, it will result in a reported [Geant4 10 segfault](https://geant4-forum.web.cern.ch/t/qt5-opengl-segmentation-fault/3319). It is of no consequence, but if it bothers you, simply close the visualiser from the terminal with CTRL-C instead. Alternatively, upgrade to Geant4 11, wherein the bug is fixed.

### Running tips
All the macros are concatenated, so that you can enjoy file-based moldularity to separate your geometry, generator, and visualisation options, e.g.
```
./bin/RicochetSimulation share/macros/{building42,shieldingF,detectorZ,generatorB,visM}.mac
```

The output of compatible programs may be piped directly to `RicochetSimulation` if no macro is specified. For example, to re-run the simulation macro corresponding to a file with [SimuRunInfoPrinter](https://gitlab.in2p3.fr/ricochet/simuruninfoprinter), call
```
SimuRunInfoPrinter simu_output.root | ./bin/RicochetSimulation -o simu_output_other.root
```
Feel free to add an intermediary pipe into e.g. `sed` to change the number of particles.

Process substitution is also supported, which allows you to tamper with multiple input sources. To visualise your geometry quickly, you could call
```
./RicochetSimulation -p none -o /dev/null <(sed -r '/neutron/d;s/(beamOn) [0-9]+/\1 0/' test.mac) vis.mac <(printf "\n/vis/viewer/addCutawayPlane")
```
which loads an empty physics list (for lightning fast initialisation), does not save the output, deletes the line containing `neutron` (because the empty physics list has no neutrons), replaces whatever `beamOn` number of particles you were shooting with 0. A graphical cutaway plane is also added as the last input in the example above.

### Faster analysis times, smaller filesizes
ROOT 6.20 introduced ZSTD compression to replace ZLIB; you can set the compression setting of the output file via the `/ricochetSim/run/OutputCompression` macro command. ROOT relies upon C-style `enum` values and the integer value for the faster ZSTD algorithm (+50% analysis speed gains observed) is `505`. Thus, you are strongly advised to add
```
/ricochetSim/run/OutputCompression 505
```
to your macros if you linked against a recent ROOT.


## Output Description

See `README.md` in SimuOuput directory: [link](https://gitlab.in2p3.fr/ricochet/simuoutput)
