#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "G4Version.hh"

#include "G4RunManager.hh"

#include "G4ParticleHPManager.hh"
#include "G4HadronicProcessStore.hh"
#include "CLHEP/Random/Randomize.h"

#include "TROOT.h"

#include "Physics/BuildPhysicsList.hh"
#include "G4VModularPhysicsList.hh"
#include "DetectorConstruction.hh"
#include "ActionInitialization.hh"
#include "MacroRecorder.hh"
#include "ProgramOptions.hh"

constexpr double WorldSize(){

    return 30*CLHEP::m;

}

int main(int argc,char** argv)
{

  auto options = ProgramOptions::ParseArgs(argc, argv);
  if(options.errorCode >= 0) return options.errorCode;

  // Fix to force Cling initialization early to avoid LLVM symbols exposed to Cling error, happening on CentOS 7
  if(options.useGUI) gROOT->GetInterpreter();

  // Choose the Random engine
  CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);

  // Construct the default run manager
  G4RunManager* runManager = new G4RunManager;

  // Detector construction (cubic world's length)
  runManager->SetUserInitialization(new Geometry::DetectorConstruction(WorldSize(), options.verbosity));

  auto physicsList = BuildPhysicsList(options.physicsListName, options.verbosity);
  runManager->SetUserInitialization(physicsList);

  // User action initialization
  runManager->SetUserInitialization(new ActionInitialization(options));

  // Initialize G4 kernel
  runManager->Initialize();

  if(options.useGUI){
      G4VisExecutive visManager;
      visManager.Initialize();
      G4UIExecutive UIExecutive{argc, argv};
      MacroRecorder::GetSingleton().ExecuteMacroCommands(options.macroCommands);
      UIExecutive.SessionStart();
  }
  else MacroRecorder::GetSingleton().ExecuteMacroCommands(options.macroCommands);

  delete runManager;

  return 0;
}
