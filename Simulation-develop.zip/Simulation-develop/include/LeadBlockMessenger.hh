#ifndef LeadBlockMessenger_h
#define LeadBlockMessenger_h 1

#include "globals.hh"
#include "G4UImessenger.hh"

#include "LeadBlock.hh"

class G4UIdirectory;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithAnInteger;


namespace lyongeom {

  class LeadBlockMessenger: public G4UImessenger {
  public:
    LeadBlockMessenger(LeadBlock* lb);
    ~LeadBlockMessenger();

    void SetNewValue(G4UIcommand*, G4String);

  private:

    LeadBlock* m_LeadBlock;
    G4UIdirectory* m_dirDetector;

    G4UIcmdWithAnInteger *cmdVerbose;
    G4UIcmdWithADoubleAndUnit *cmdSet_x_PbBlock;
    G4UIcmdWithADoubleAndUnit *cmdSet_y_PbBlock;
    G4UIcmdWithADoubleAndUnit *cmdSet_z_PbBlock;
    G4UIcmdWithADoubleAndUnit *cmdSet_theta_PbBlock;

  };

} //namespace lyongeom

#endif

