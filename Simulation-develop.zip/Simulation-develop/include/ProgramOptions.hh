/**************************************************************************
* @file ProgramOptions.hh
* @author Valérian Sibille <vsibille@mit.edu>
* @date 05 Jun 2019
* @brief Extremly dumb short option getopt-based parser
* Positive errorCodes call for stopping the program
* ************************************************************************/

#ifndef PROGRAMOPTIONS_HH
#define PROGRAMOPTIONS_HH

#include <vector>
#include <iostream>

namespace ProgramOptions{

    using MacroCommands = std::vector<std::string>;

    struct Options{

        int verbosity{-1};
        std::string outputFileName;
        bool useGUI{false};
        std::string physicsListName{"Shielding"};
        MacroCommands macroCommands;
        int errorCode{-1};

    };

    void PrintUsage(std::ostream& output);
    void ParseMacro(const std::string& macroPath, Options& options);
    MacroCommands ParseMacroStream(std::ifstream& macroStream);
    void AppendCommands(const MacroCommands& commands, Options& options);
    bool CommandsNeedVisualiser(const MacroCommands& commands);
    Options ParseArgs(int argc, char** argv);

}
#endif /* PROGRAMOPTIONS_HH */
