#ifndef Frame_HH_
#define Frame_HH_

#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"


class G4VPhysicalVolume;

namespace lyongeom {


  class Frame {
  public:

    Frame(bool overlap);
    G4String GetLaboratoryName();
    void Construct(G4LogicalVolume *parentVolume, G4ThreeVector position, G4RotationMatrix* rotation);


    void SetVerbose(G4int i) {
      m_verbose = i;
    }


    void SetAlpha(G4double a) {
      Alpha = a;
    }
    void SetDeltaAlpha(G4double a) {
      DeltaAlpha = a;
    }


    static G4double Pillar_h();
    static G4double Frame_e();
    static G4double Frame_short();
    static G4double Frame_long();
    static G4double Plate10mK_e();
    static G4double disPlate10mK_100mK();
    static G4double Plate100mK_e();
    static G4double disPlate100mK_1K();
    static G4double Plate1K_e();
    static G4double disPlate1K_4K();
    static G4double Plate4K_e();
    static G4double disPlate4K_50K();
    static G4double Plate50K_e();
    static G4double disPlate50K_Bride();
    static G4double Bride_h();




    G4double GetFrameAligneWithBride() {
      return Plate10mK_e()/2.+disPlate10mK_100mK()+Plate100mK_e()+disPlate100mK_1K()+Plate1K_e()+disPlate1K_4K()+Plate4K_e()+disPlate4K_50K()+Plate50K_e()+disPlate50K_Bride()-Bride_h()/2.;
    }


    void dump();


  private:

    //control variables
    G4int m_verbose;
    G4bool m_checkOverlaps;
    G4String m_name;


    G4double Alpha;
    G4double DeltaAlpha;

  };

} // namespace lyongeom

#endif /* FRAME_HH_ */

