#ifndef LeadShieldEX_HH_
#define LeadShieldEX_HH_

#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"


class G4VPhysicalVolume;

namespace lyongeom {


  class LeadShieldEX {
  public:

    LeadShieldEX(bool overlap);
    ~LeadShieldEX();
    G4String GetLaboratoryName();
    void Construct(G4LogicalVolume *parentVolume, G4ThreeVector position, G4RotationMatrix* rotation);


    void SetVerbose(G4int i) {
      m_verbose = i;
    }

    void SetAlpha(G4double a) {
      Alpha = a;
    }
    void SetDeltaAlpha(G4double a) {
      DeltaAlpha = a;
    }

    G4double GetLeadShieldUnderOVC() {
      return Lead_h()/2.-disPlate10mK_BottomCu1K()-Plate10mK_e()/2.-Cu1K_e()-disOuterBottomCu1K_InnerBottomCu4K()-Cu4K_e()-disOuterBottomCu4K_InnerBottomCu50K()-Cu50K_e()-disOuterBottomCu50K_InnerBottomOVCInox()-OVCInox_e()-disLeadBottomOVC();
    }


    void dump();

    G4double Lead_h();
    G4double Lead_e();
    G4double LeadBottom_e();
    G4double Lead_radius();
    G4double Plate10mK_e();
    G4double disPlate10mK_BottomCu1K();
    G4double Cu1K_e();
    G4double disOuterBottomCu1K_InnerBottomCu4K();
    G4double Cu4K_e();
    G4double disOuterBottomCu4K_InnerBottomCu50K();
    G4double Cu50K_e();
    G4double disOuterBottomCu50K_InnerBottomOVCInox();
    G4double OVCInox_e();
    G4double disLeadBottomOVC();

  private:

    //control variables
    G4int m_verbose;
    G4bool m_checkOverlaps;
    G4String m_name;


    G4double Alpha;
    G4double DeltaAlpha;

  };

} //namespace lyongeom


#endif /* LEADSHIELDEX_HH_ */

