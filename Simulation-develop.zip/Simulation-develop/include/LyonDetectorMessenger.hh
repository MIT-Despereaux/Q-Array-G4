#ifndef LyonDetectorMessenger_h
#define LyonDetectorMessenger_h 1

#include "G4UImessenger.hh"

class G4UIdirectory;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithoutParameter;
class G4UIcmdWithAnInteger;
class G4UIcmdWithADouble;

namespace Geometry{

    class DetectorConstruction;

}

namespace lyongeom {

  class LyonDetectorMessenger: public G4UImessenger {
  public:
    LyonDetectorMessenger(Geometry::DetectorConstruction*);
    ~LyonDetectorMessenger();

    void SetNewValue(G4UIcommand*, G4String);

  private:

    Geometry::DetectorConstruction* m_detector;
    G4UIdirectory* m_dirDetector;

    G4UIcmdWithAnInteger *cmdVerbose;
    G4UIcmdWithADoubleAndUnit *cmdAlpha;
    G4UIcmdWithADoubleAndUnit *cmdDeltaAlpha;
    G4UIcmdWithoutParameter *cmdBuildLabo;
    G4UIcmdWithoutParameter *cmdBuildCryostat;
    G4UIcmdWithoutParameter *cmdBuildFrame;
    G4UIcmdWithoutParameter *cmdBuildLeadShieldEX;
    G4UIcmdWithoutParameter *cmdBuildAll;
    G4UIcmdWithoutParameter *cmdAddLeadBlock;

  };


}// namespace lyongeom

#endif

