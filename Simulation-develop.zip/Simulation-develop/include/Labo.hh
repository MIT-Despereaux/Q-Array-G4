#ifndef Labo_HH_
#define Labo_HH_

#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"


class G4VPhysicalVolume;

namespace lyongeom {

  class Labo {
  public:

    Labo(bool overlap);
    ~Labo();
    G4String GetLaboratoryName();
    void Construct(G4LogicalVolume *parentVolume, G4ThreeVector position, G4RotationMatrix* rotation);


    void SetVerbose(G4int i) {
      m_verbose = i;
    }

    void SetAlpha(G4double a) {
      Alpha = a;
    }
    void SetDeltaAlpha(G4double a) {
      DeltaAlpha = a;
    }

    static G4double Labo_h();
    static G4double Labo_e();
    static G4double Labo_x();
    static G4double Labo_y();
    static G4double Plate10mK_e();
    static G4double disPlate10mK_100mK();
    static G4double Plate100mK_e();
    static G4double disPlate100mK_1K();
    static G4double Plate1K_e();
    static G4double disPlate1K_4K();
    static G4double Plate4K_e();
    static G4double disPlate4K_50K();
    static G4double Plate50K_e();
    static G4double disPlate50K_Bride();
    static G4double Bride_h();
    static G4double Frame_e();
    static G4double Pillar_h();
    static G4double PosCryostat_x();
    static G4double PosCryostat_y();
    static G4double Chamber_y();


    static G4double GetCryostatPosition_x() {
      return -Labo_x()/2.+PosCryostat_x();
    }
    static G4double GetCryostatPosition_y() {
      return Labo_y()/2.-PosCryostat_y()-Chamber_y();
    }

    static G4double GetCryostatPosition_z() {
      return Labo_h()/2.+Plate10mK_e()/2.+disPlate10mK_100mK()+Plate100mK_e()+disPlate100mK_1K()+Plate1K_e()+disPlate1K_4K()+Plate4K_e()+disPlate4K_50K()+Plate50K_e()+disPlate50K_Bride()-Bride_h()/2.-Frame_e()/2.-Pillar_h();
    }


    void dump();


  private:

    //control variables
    G4int m_verbose;
    G4bool m_checkOverlaps;
    G4String m_name;

    G4double Alpha;
    G4double DeltaAlpha;

  };


}//namespace lyongeom
#endif /* LABO_HH_ */
