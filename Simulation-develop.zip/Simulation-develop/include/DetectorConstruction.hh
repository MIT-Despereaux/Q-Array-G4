#ifndef DETECTORCONSTRUCTION_HH
#define DETECTORCONSTRUCTION_HH

#include <memory>
#include "G4VUserDetectorConstruction.hh"
#include "Geometry/OwningBuilderMessenger.hh"
#include "Geometry/ChoozSiteBuilder.hh"
#include "Geometry/CryoConceptBuilder.hh"
#include "Geometry/CryoCubeBuilder.hh"
#include "Geometry/MiniCryoCubeBuilder.hh"
#include "Geometry/SensitiveMiniCryoCubeMessenger.hh"
#include "Geometry/VolumeBuilderMessenger.hh"
#include "Geometry/CylindricalShieldingBuilder.hh"
#include "Geometry/CylindricalShieldingMessenger.hh"
#include "Geometry/ColdInnerShieldingBuilder.hh"
#include "Geometry/ColdInnerShieldingMessenger.hh"
#include "Geometry/RingInnerShieldingBuilder.hh"
#include "Geometry/RingInnerShieldingMessenger.hh"
#include "Geometry/OuterShieldingBuilder.hh"
#include "Geometry/OuterShieldingMessenger.hh"
#include "Geometry/OuterShieldingBuilderWithDT.hh"
#include "Geometry/OuterShieldingMessengerWithDT.hh"
#include "Geometry/MuonVetoBuilder.hh"
#include "Geometry/SensitiveMuonVetoMessenger.hh"
#include "Geometry/GenericCryostatBuilder.hh"
#include "Geometry/GenericCryostatMessenger.hh"
#include "Geometry/RicochetBasicBuilder.hh"
#include "Geometry/SensitiveRicochetBasicMessenger.hh"
#include "Geometry/SensitiveVolumeBuilderMessenger.hh"
#include "Geometry/DubnaSpectrometerBuilder.hh"
#include "Geometry/GermaniumBolometerBuilder.hh"
#include "Geometry/SimpleGermaniumBolometerBuilder.hh"
#include "SimuOutput/VolumeNames.hh"

#include "Labo.hh"
#include "Geometry/Cryostat.hh"
#include "Frame.hh"
#include "LeadShieldEX.hh"
#include "LeadBlock.hh"

#ifdef GEANT4_WITH_GDML
#include "GDMLExporter/GDMLExporterMessenger.hh"
#endif

class G4LogicalVolume;
class G4VPhysicalVolume;
class TDirectory;

namespace lyongeom{

    class LyonDetectorMessenger;

}

namespace Geometry{

    class ObjectSerialiser;

    DEFINE_BUILD_COMMAND(ActiveChoozBuilder, "/geometry/site/Chooz/build")
    DEFINE_BUILD_COMMAND(ActiveCryoConceptBuilder, "/geometry/cryostat/CryoConcept/build")
    DEFINE_BUILD_COMMAND(SensitiveCryoCubeBuilder, "/geometry/detector/CryoCube/build")
    DEFINE_BUILD_COMMAND(SensitiveMiniCryoCubeBuilder, "/geometry/detector/MiniCryoCube/build")
    DEFINE_BUILD_COMMAND(SensitiveDubnaSpectrometerBuilder, "/geometry/detector/DubnaSpectrometer/build")
    DEFINE_BUILD_COMMAND(SensitiveGermaniumBolometerBuilder, "/geometry/detector/GermaniumBolometer/build")
    DEFINE_BUILD_COMMAND(SensitiveSimpleGermaniumBolometerBuilder, "/geometry/detector/SimpleGermaniumBolometer/build")
    DEFINE_SENSITIVE_COMMAND(SensitiveCryoCubeBuilder, "/geometry/detector/CryoCube/sensitive")
        
    class DetectorConstruction : public G4VUserDetectorConstruction
    {

    public:
        DetectorConstruction(double worldLength, int verbosity_ = -1);
        G4LogicalVolume* LogicalWorldPtr() {return Get<Volume::Logical>(worldPack);}
        G4PVPlacement* PhysicalWorldPtr() {return Get<Volume::Physical>(worldPack);}
        G4LogicalVolume& LogicalWorld() {return *LogicalWorldPtr();}
        G4PVPlacement& PhysicalWorld() {return *PhysicalWorldPtr();}
        G4VPhysicalVolume* Construct() ;
        void SetVerbosity(int val);
        void SetAlpha(G4double alpha);
        void SetDeltaAlpha(G4double alpha);
        void BuildLabo();
        void BuildCryostat();
        void BuildFrame();
        void BuildLeadShieldEX();
        void AddLeadBlock();
        template <class Builder>
        OwningBuilderMessenger<Builder>& GetMessenger();
        template <class Builder, class... Args>
        void Execute(Args&&... args);
        void SerialiseActivatedBuilders(ObjectSerialiser& objectSerialiser) const;
        static SimuOutput::VolumeNames GetVolumeNames();
        static void WriteVolumeNames(TDirectory& output, const char* treeName);

    private:
        using MessengerCollection =
        std::tuple<
        OwningBuilderMessenger<ActiveOuterShieldingBuilder, OuterShieldingMessenger>,
        OwningBuilderMessenger<ActiveOuterShieldingBuilderWithDT, OuterShieldingMessengerWithDT>,
        OwningBuilderMessenger<ActiveChoozBuilder>,
        OwningBuilderMessenger<ActiveColdInnerShieldingBuilder, ColdInnerShieldingMessenger>,
        OwningBuilderMessenger<ActiveCryoConceptBuilder>,
        OwningBuilderMessenger<ActiveCylindricalShieldingBuilder, CylindricalShieldingMessenger>,
        OwningBuilderMessenger<ActiveGenericCryostatBuilder, GenericCryostatMessenger>,
        OwningBuilderMessenger<ActiveRingInnerShieldingBuilder, RingInnerShieldingMessenger>,
        OwningBuilderMessenger<ActiveVolumeBuilder, VolumeBuilderMessenger>,
        OwningBuilderMessenger<SensitiveCryoCubeBuilder>,
        OwningBuilderMessenger<SensitiveMiniCryoCubeBuilder, SensitiveMiniCryoCubeMessenger>,
        OwningBuilderMessenger<SensitiveMuonVetoBuilder,SensitiveMuonVetoMessenger>,
        OwningBuilderMessenger<SensitiveDubnaSpectrometerBuilder>,
        OwningBuilderMessenger<SensitiveGermaniumBolometerBuilder>,
        OwningBuilderMessenger<SensitiveSimpleGermaniumBolometerBuilder>,
        OwningBuilderMessenger<SensitiveRicochetBasicBuilder, SensitiveRicochetBasicMessenger>,
        OwningBuilderMessenger<SensitiveVolumeBuilder, SensitiveVolumeBuilderMessenger>
        >;

        void DefineMaterials();
        void DefineColors();

        VolumePack worldPack;
        MessengerCollection messengers;
        int verbosity;

        std::unique_ptr<lyongeom::LyonDetectorMessenger>  theLyonDetectorMessenger;

        std::unique_ptr<lyongeom::Labo> fLyonLab;
        std::unique_ptr<Cryostat> fCryostat;
        std::unique_ptr<lyongeom::Frame> fFrame;
        std::unique_ptr<lyongeom::LeadShieldEX> fLeadShieldEX;
        std::unique_ptr<lyongeom::LeadBlock> fLeadBlock;

#ifdef GEANT4_WITH_GDML
        GDMLExporter::GDMLExporterMessenger gdmlMessenger;
#endif

    };

    template <class Builder>
    OwningBuilderMessenger<Builder>& DetectorConstruction::GetMessenger(){

        return std::get<OwningBuilderMessenger<Builder>>(messengers);

    }

    template <class Builder, class... Args>
    void DetectorConstruction::Execute(Args&&... args){

        GetMessenger<Builder>().ExecuteBuilder(std::forward<Args>(args)...);

    }

} //namespace Geometry

#endif /* DETECTORCONSTRUCTION_HH */
