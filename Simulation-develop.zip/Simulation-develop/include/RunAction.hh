#ifndef RICOCHET_RUNACTION_H
#define RICOCHET_RUNACTION_H

#include "G4UserRunAction.hh"

#include "SimuOutput/SimuTreeWriter.hh"
#include "G4Helpers/OwningMessenger.hh"
#include "Generator/Primary.hh"
#include "Generator/PrimaryMessenger.hh"
#include "Event/ActionMessenger.hh"
#include "Event/StepRecorder.hh"
#include "Event/StepRecorderMessenger.hh"

#include <string>
#include <memory>

class G4Run;
class TFile;

namespace Event
{
    class SteppingAction;
}

class RunAction : public G4UserRunAction
{
public:
RunAction(
        G4Helpers::OwningMessenger<Generator::Primary, Generator::PrimaryMessenger>& primaryGeneratorAction,
        G4Helpers::OwningMessenger<Event::Action, Event::ActionMessenger>& Action,
        Event::SteppingAction& steppingAction,
        const std::string& outputFileName_, int verbosity_ = -1);
  void BeginOfRunAction(const G4Run*);
  void EndOfRunAction(const G4Run*);
  void SetRandomSeed(uint64_t seed) {fAutoSeed = false; fRndGenSeed = seed;}
  void SetAutoSeed (const G4bool val) {fAutoSeed = val;}
  void SetVerbose(const G4int val) {fVerbose = val; }
  void SetOutputFileName(const std::string& val) { outputFileName = val; }
  //check  TFile::SetCompressionSettings(Int_t settings) for details
  void SetOutputCompression(int outputCompression_);
  void SetFirstEventNumber(const G4int val) { fFirstEventNumber = val; }
  G4int GetVerbose() {return fVerbose; }
  G4int GetFirstEventNumber() {return fFirstEventNumber;}

private:
  void WriteGeometryInfo(const char* outputDirectoryName) const;
  void SetGlobalGeneratorSeeds();
  void SetOutputFile();
  void SetupStepRecorder();
  void WriteRunInfo(const G4Run& run, const char* headerName) const;

  std::string outputFileName;
  int outputCompression{ROOT::RCompressionSetting::EDefaults::kUseCompiledDefault};
  std::unique_ptr<TFile> outputFile;
  G4Helpers::OwningMessenger<Generator::Primary, Generator::PrimaryMessenger>* fPrimaryGeneratorAction{nullptr};
  Event::Action* fEventAction{nullptr};
  Event::SteppingAction* fSteppingAction{nullptr};
  SimuTreeWriter fSimuTreeWriter;
  Event::StepRecorder fStepRecorder;
  Event::StepRecorderMessenger fStepRecorderMessenger{fStepRecorder, "/ricochetSim/run/stepRecorder"};
  G4int fVerbose;
  uint64_t fRndGenSeed;
  G4bool fAutoSeed{true};
  G4int fFirstEventNumber;

};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
