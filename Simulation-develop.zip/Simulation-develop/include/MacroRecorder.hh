#ifndef MACRORECORDER_H
#define MACRORECORDER_H

/// Standard includes
#include <string>
#include <vector>

class G4UImanager;

class MacroRecorder
{
    public:
        static MacroRecorder& GetSingleton();

        G4UImanager* GetUIManager();
        void ExecuteMacroCommands(const std::vector<std::string>& commands);
        void ExecuteMacroCmd(const std::string& command);
        const std::string& GetMacroAsStr() const;

    private:
        MacroRecorder();

        G4UImanager* mUIManager{nullptr};
        std::string macroStr;

};

#endif /// MACRORECORDER_H
