#ifndef ActionInitialization_h
#define ActionInitialization_h 1

#include "G4VUserActionInitialization.hh"
#include "ProgramOptions.hh"

/// Action initialization class.

class RunAction;

class ActionInitialization : public G4VUserActionInitialization
{
    ProgramOptions::Options options;
public:
  ActionInitialization(ProgramOptions::Options options_);
  ~ActionInitialization() = default;
  void Build() const;
};

#endif
