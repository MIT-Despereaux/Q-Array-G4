#ifndef LeadBlock_HH_
#define LeadBlock_HH_

#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4ThreeVector.hh"


class G4VPhysicalVolume;
class G4LogicalVolume;

namespace lyongeom {

  class LeadBlockMessenger;


  class LeadBlock {
  public:

    LeadBlock(bool overlap);
    ~LeadBlock();
    G4LogicalVolume* Construct();
  
    void PlaceLeadBlock(G4LogicalVolume *motherLogic);
  
  
    void SetVerbose(G4int i) {
      m_verbose = i;
    }

    void SetAlpha(G4double a) {
      Alpha = a;
    }
    void SetDeltaAlpha(G4double a) {
      DeltaAlpha = a;
    }
  
    void Setx_PbBlock(G4double Set_x_PbBlock) {
      x_PbBlock = Set_x_PbBlock;
    }
    void Sety_PbBlock(G4double Set_y_PbBlock) {
      y_PbBlock = Set_y_PbBlock;
    }
    void Setz_PbBlock(G4double Set_z_PbBlock) {
      z_PbBlock = Set_z_PbBlock;
    }
    void Settheta_PbBlock(G4double Set_theta_PbBlock) {
      theta_PbBlock = Set_theta_PbBlock;
    }
  

    static G4double PbBlock_l();
    static G4double PbBlock_e();

  
  private:

    G4int m_verbose;
    G4bool m_checkOverlaps;
    G4String m_name;

    G4double Alpha;
    G4double DeltaAlpha;
  
    G4double x_PbBlock;
    G4double y_PbBlock;
    G4double z_PbBlock;
    G4double theta_PbBlock;
  
    LeadBlockMessenger* m_LeadBlockMessenger;
  
  };

} //namespace lyongeom {


#endif
