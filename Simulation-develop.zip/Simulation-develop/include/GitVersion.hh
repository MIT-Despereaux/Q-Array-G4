#ifndef GITVERSION_H
#define GITVERSION_H

#include <string>

namespace Simulation
{
    namespace GitVersion
    {
        std::string Describe();
        std::string Hash();
        std::string Refspec();
        void Print(std::ostream& output);

    }

}

#endif /// GITVERSION_H
