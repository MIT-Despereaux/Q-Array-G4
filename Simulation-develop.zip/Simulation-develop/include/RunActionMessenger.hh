#ifndef RICOCHET_RUNMESSENGER_H
#define RICOCHET_RUNMESSENGER_H

#include "G4Helpers/CommandPrefixer.hh"
#include "G4Helpers/InitialisablePathModifyingMessenger.hh"
#include "RunAction.hh"

DEFINE_COMMAND_PREFIXER(RunActionCommandPrefixer, "/ricochetSim/run/")

struct RunActionCommandsCreator;
using RunActionMessenger = G4Helpers::InitialisablePathModifyingMessenger<RunAction, RunActionCommandsCreator, RunActionCommandPrefixer>;

struct RunActionCommandsCreator
{
    static void Initialise(RunActionMessenger& messenger);
};

#endif

